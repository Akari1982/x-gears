// $Id$

#ifndef SHAPE_FILE_h
#define SHAPE_FILE_h

#include <vector>

#include "../../common/display/surface/Surface.h"
#include "../../common/utilites/StdString.h"

#include "../filesystem/File.h"







class ShapeFile : public File
{
public:
    explicit
    ShapeFile(const RString& file);

    explicit
    ShapeFile(File* pFile);

    ShapeFile(File* pFile, const u32& offset, const u32& length);

    ShapeFile(u8* pBuffer, const u32& offset, const u32& length);

    virtual
    ~ShapeFile(void);

//    const FrameData
//    GetFrame(const Uint32 frame) const;

private:
//    void
//    InnerGetFrames(void);

private:
//    std::vector<FrameData> m_Frame;
};



#endif
