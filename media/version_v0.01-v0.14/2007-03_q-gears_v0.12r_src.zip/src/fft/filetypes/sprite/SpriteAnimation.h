// $Id$

#ifndef SPRITE_ANIMATION_h
#define SPRITE_ANIMATION_h

#include <queue>
#include <vector>

#include "../../../common/TypeDefine.h"
#include "../../../common/display/actor/Actor.h"

#include "SpriteFrame.h"



class SpriteAnimation : public Actor
{
public:
    SpriteAnimation(void);

    virtual
    ~SpriteAnimation(void);

    virtual void
    Init(void);

    virtual void
    Input(const InputEvent &input);

    virtual void
    Update(const Uint32 delta_time);

    virtual void
    Draw(void) const;

    void
    AddFrame(SpriteFrame* frame);

    void
    SetFrameToDraw(const Uint32 frame_id, const Uint32 show_time);

private:
    std::vector<SpriteFrame*>    m_Animation;

    struct FrameForSequence
    {
        Uint32 frame_id;
        Uint32 show_time;
    };
    std::queue<FrameForSequence> m_FrameSequence;
};



#endif // SPRITE_ANIMATION_h
