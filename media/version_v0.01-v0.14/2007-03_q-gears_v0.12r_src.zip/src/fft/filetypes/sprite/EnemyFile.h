// $Id$

#ifndef ENEMY_FILE_h
#define ENEMY_FILE_h

#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/StdString.h"

#include "SpriteAnimation.h"
#include "../image/Vram.h"
#include "../../filesystem/File.h"
#include "../ShapeFile.h"



struct TileData
{
    Uint8 frame_x;
    Uint8 frame_y;
    Uint8 tile_x;
    Uint8 tile_y;
    Uint8 width;
    Uint8 height;
};



struct FrameData
{
    std::vector<TileData> tile;
};



class EnemyFile : public File
{
public:
    explicit
    EnemyFile(const RString& file);

    explicit
    EnemyFile(File* pFile);

    EnemyFile(File* pFile, const u32& offset, const u32& length);

    EnemyFile(u8* pBuffer, const u32& offset, const u32& length);

    virtual
    ~EnemyFile(void);

    void
    LoadEnemies(SpriteAnimation& animation);

private:
    struct ClutColor
    {
        Uint8 r;                 /**< @brief red color in CLUT */
        Uint8 g;                 /**< @brief green color in CLUT */
        Uint8 b;                 /**< @brief blue color in CLUT */
        Uint8 a;                 /**< @brief alpha in CLUT */
    };

    std::vector<FrameData> m_Frame;

    Vram mVram;
};



#endif
