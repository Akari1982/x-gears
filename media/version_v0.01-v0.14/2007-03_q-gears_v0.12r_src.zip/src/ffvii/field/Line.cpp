// $Id$

#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "FieldModule.h"
#include "Line.h"



Line::Line(FieldModule* field_module, const Vector3& point1, const Vector3& point2, const Sint8 entity_id):
    Trigger(field_module, point1, point2),
    m_EntityId(entity_id)
{
}



Line::~Line(void)
{
}



void
Line::OnEnter(void)
{
    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log(LOGGER_INFO, "We entered line for entity with id = %d", m_EntityId);
    }

    m_pFieldModule->mObjectManager.RequestRunEntity(m_EntityId, 0, 5);
}



void
Line::OnMove(void)
{
    m_pFieldModule->mObjectManager.RequestRunEntity(m_EntityId, 0, 2);
}



void
Line::OnInside(void)
{
    m_pFieldModule->mObjectManager.RequestRunEntity(m_EntityId, 0, 4);
}



void
Line::OnLeave(void)
{
    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log(LOGGER_INFO, "We leave line for entity with id = %d", m_EntityId);
    }

    m_pFieldModule->mObjectManager.RequestRunEntity(m_EntityId, 0, 6);
}



const Sint8
Line::GetEntity(void) const
{
    return m_EntityId;
}
