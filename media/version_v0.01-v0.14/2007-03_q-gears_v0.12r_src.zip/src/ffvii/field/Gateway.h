// $Id: Gateway.h 135 2007-02-06 05:21:01Z halkun $

#ifndef GATEWAY_h
#define GATEWAY_h

#include "../../common/TypeDefine.h"

#include "Trigger.h"



class Gateway : public Trigger
{
public:
             Gateway(FieldModule* pFieldModule, const Vector3& point1, const Vector3& point2, const Vector3& position, const Sint16 map_id);
    virtual ~Gateway(void);

    void     OnEnter(void);
    void     OnMove(void);
    void     OnInside(void);
    void     OnLeave(void);

private:
    Vector3      mPosition;
    Sint16       m_MapId;
};



#endif // GATEWAY_h
