// $Id$

#include "../../common/utilites/Logger.h"

#include "FieldModule.h"
#include "MarkTriangle.h"



MarkTriangle::MarkTriangle(FieldModule* field_module, const Vector3& position, const MarkTriangleColor& color):
    m_FieldModule(field_module),

    m_Position(position),
    m_Color(color),
    m_Frame(0)
{
}



MarkTriangle::~MarkTriangle(void)
{
}



void
MarkTriangle::Input(const InputEvent &input)
{
}



void
MarkTriangle::Update(const Uint32 delta_time)
{
    ++m_Frame;
    m_Frame = (m_Frame == 32) ? 0 : m_Frame;
}



void
MarkTriangle::Draw(void) const
{
    Vector3 screen = m_FieldModule->m_ScreenManager.CoordsWorldToScreen(m_Position);
    KERNEL->DrawMarkTriangle(screen.x - 8, screen.y - 4, m_Frame / 8, m_Color);
}


