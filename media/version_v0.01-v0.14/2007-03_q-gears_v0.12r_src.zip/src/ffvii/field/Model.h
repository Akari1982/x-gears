// $Id: Model.h 151 2007-03-04 11:28:52Z super_gb $

#ifndef MODEL_h
#define MODEL_h

#include "../../common/TypeDefine.h"
#include "../../common/display/actor/Actor.h"
#include "../../common/display/3dTypes.h"



struct BonePosition
{
    float rotation_x;
    float rotation_y;
    float rotation_z;
};



struct Animation
{
    std::vector<BonePosition> idle;
};



class Model : public Actor
{
public:
                   Model(void);
    virtual       ~Model(void);

    virtual void   Input(const InputEvent& input);
    virtual void   Update(const Uint32 delta_time);
    virtual void   Draw(void) const;

    void           DrawHierarchy(const Sint8 level) const;

    void           AddBone(const Sint16 length, const Sint8 parent_id, const Sint8 part_id);
    void           AddPart(const TotalGeometry& geometry);
    void           AddAnimation(const Animation& animation);

private:
    // skeleton related
    struct Bone
    {
        Sint16 length;
        Sint8  parent_id;
        Sint8  part_id;
    };
    std::vector<Bone>          m_Skeleton;



    // geometry related
    std::vector<TotalGeometry> m_Parts;



    // animation
    std::vector<Animation> m_Animation;
};



#endif // MODEL_h
