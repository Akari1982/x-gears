// $Id$

#ifndef MIM_FILE_h
#define MIM_FILE_h

#include "../filesystem/File.h"
#include "../filetypes/image/Vram.h"

#include "../../common/display/surface/Surface.h"
#include "../../common/utilites/StdString.h"



class MimFile : public File
{
public:
    explicit     MimFile(const RString& file);
    explicit     MimFile(File* pFile);
                 MimFile(File* pFile, const u32& offset, const u32& length);
                 MimFile(u8* pBuffer, const u32& offset, const u32& length);
    virtual     ~MimFile(void);

    Surface*     GetSurface(const Uint16 page_x, const Uint16 page_y, const Uint16 clut_x, const Uint16 clut_y, const Uint8 bpp);

    const Uint16 GetNumberOfClut(void) const;

private:
    void         InnerGetImage(void);

private:
    struct MimHeader
    {
        u32 header2_offset;   /**< @brief offset for second header */
        u16 x;                /**< @brief x position of CLUT in VRAM */
        u16 y;                /**< @brief y position of CLUT in VRAM */
        u16 width;            /**< @brief number of colors in CLUT */
        u16 height;           /**< @brief number of CLUT */
    };

    struct MimHeader2
    {
        u32 data_size;        /**< @brief size of image data */
        u16 x;                /**< @brief x position of image in VRAM */
        u16 y;                /**< @brief y position of image in VRAM */
        u16 width;            /**< @brief width of image */
        u16 height;           /**< @brief height of image */
    };

    struct ClutColor
    {
        u8 r;                 /**< @brief red color in CLUT */
        u8 g;                 /**< @brief green color in CLUT */
        u8 b;                 /**< @brief blue color in CLUT */
        u8 a;                 /**< @brief alpha in CLUT */
    };

    u16  mClutVramPositionX;
    u16  mClutVramPositionY;
    u16  mClutWidth;
    u16  mClutHeight;

    u16  mImageVramPositionX;
    u16  mImageVramPositionY;
    u16  mImageWidth;
    u16  mImageHeight;

    Vram mVram;
};



#endif
