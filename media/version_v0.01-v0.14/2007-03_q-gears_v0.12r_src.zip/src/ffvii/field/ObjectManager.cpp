// $Id$

#include "../../common/display/3dTypes.h"
#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "FieldModule.h"
#include "ObjectManager.h"
#include "Math.h"
#include "../kernel/GameState.h"



class line_find
{
public:
    line_find(const Sint8 a):
        m_EntityId(a)
    {
    }

    bool
    operator()(const Line& a) const
    {
        return a.GetEntity() == m_EntityId;
    }

private:
    Sint8 m_EntityId;
};



ObjectManager::ObjectManager(FieldModule* pFieldModule):
    m_pFieldModule(pFieldModule),

    m_Script(NULL),

    m_PlayerCharacterMovable(true),
    m_MovementRotation(0x8000),
    m_LadderMovementId(0),

    m_GatewaysCheck(true),
    m_LinesCheck(true),


    m_bEncounterDisabled(false),
    m_ulDangerCounter(0),

    m_DrawCollisions(false),
    m_DrawWalkmesh(false),
    m_DrawTriggers(false)
{
    // ladder moving button routine
    m_ButtonUp   [0] = MOVE_TO_START;
    m_ButtonUp   [1] = MOVE_TO_END;
    m_ButtonUp   [2] = NOT_MOVE;
    m_ButtonUp   [3] = NOT_MOVE;

    m_ButtonDown [0] = MOVE_TO_END;
    m_ButtonDown [1] = MOVE_TO_START;
    m_ButtonDown [2] = NOT_MOVE;
    m_ButtonDown [3] = NOT_MOVE;

    m_ButtonLeft [0] = NOT_MOVE;
    m_ButtonLeft [1] = NOT_MOVE;
    m_ButtonLeft [2] = MOVE_TO_START;
    m_ButtonLeft [3] = MOVE_TO_END;

    m_ButtonRight[0] = NOT_MOVE;
    m_ButtonRight[1] = NOT_MOVE;
    m_ButtonRight[2] = MOVE_TO_END;
    m_ButtonRight[3] = MOVE_TO_START;
}



ObjectManager::~ObjectManager(void)
{
    Clear();
}



void
ObjectManager::Clear(void)
{
    if (m_Script != NULL)
    {
        delete m_Script;
        m_Script = NULL;
    }



    Uint32 i;

    // clear entitys
    for (i = 0; i < m_Entitys.size(); ++i)
    {
        delete m_Entitys[i];
    }
    m_Entitys.clear();



    // clear mark triangles
    for (i = 0; i < m_MarkTriangles.size(); ++i)
    {
        delete m_MarkTriangles[i];
    }
    m_MarkTriangles.clear();



    // clear walk mesh
    for (i = 0; i < m_WalkMesh.size(); ++i)
    {
        delete m_WalkMesh[i];
    }
    m_WalkMesh.clear();



    m_PlayerCharacterMovable = true;



    m_Gateways.clear();
    m_GatewaysCheck = true;
    m_Lines.clear();
    m_LinesCheck = true;



    m_vEncounters.clear();
    m_bEncounterDisabled = false;
}



void
ObjectManager::Draw(void) const
{
    Uint32 i;

    if (m_DrawWalkmesh == true)
    {
        for (i = 0; i < m_WalkMesh.size(); ++i)
        {
            m_WalkMesh[i]->Draw();
        }
    }



    // draw character
    for (i = 0; i < m_Entitys.size(); ++i)
    {
        if (m_Entitys[i]->IsActionEnabled() == true)
        {
            m_Entitys[i]->Draw();

            if (m_DrawCollisions == true)
            {
                m_Entitys[i]->DrawCollision();
            }
        }
    }



    if (m_DrawTriggers == true)
    {
        // draw triggers
        for (i = 0; i < m_Gateways.size(); ++i)
        {
            m_Gateways[i].Draw();
        }



        // draw lines
        for (i = 0; i < m_Lines.size(); ++i)
        {
            m_Lines[i].Draw();
        }
    }



    // draw mark triangles
    for (i = 0; i < m_MarkTriangles.size(); ++i)
    {
        m_MarkTriangles[i]->Draw();
    }
}



void
ObjectManager::DrawDebugInfo(void) const
{
    RString temp;

    s8 pc = GetPlayerEntity();
    if (pc != -1)
    {
        Vector3 pos = m_Entitys[pc]->GetPosition();
        u16     tri = m_Entitys[pc]->GetTriangle();
        u8      dir = m_Entitys[pc]->GetDirection();

        temp.Format("x(%f) y(%f) z(%f)", pos.x, pos.y, pos.z);
        KERNEL->DrawString(RStringToFFVIIString(temp), 10, 10, F_WHITE);
        temp.Format("triangle = %d", tri);
        KERNEL->DrawString(RStringToFFVIIString(temp), 10, 25, F_WHITE);
        temp.Format("direction = %d", dir);
        KERNEL->DrawString(RStringToFFVIIString(temp), 10, 40, F_WHITE);
    }

    temp.Format("danger counter = %d", m_ulDangerCounter);
    KERNEL->DrawString(RStringToFFVIIString(temp), 10, 65, F_WHITE);
}



void
ObjectManager::Input(const InputEvent& input)
{
    if (m_PlayerCharacterMovable == true)
    {
        // handle moving
        static float step = 20.0f;
        Vector4 next_step(0.0f, 0.0f, 0.0f, 1.0f);

        if (input.type == IET_REPEAT)
        {
            switch (input.button)
            {
                case KEY_UP:    next_step.z =  step; break;
                case KEY_DOWN:  next_step.z = -step; break;
                case KEY_LEFT:  next_step.x = -step; break;
                case KEY_RIGHT: next_step.x =  step; break;
            }
        }

        s8 pc = GetPlayerEntity();
        if ((next_step.x != 0.0f || next_step.z != 0.0f) && pc != -1)
        {
            // if we can do something
            if (m_Entitys[pc]->IsActionEnabled() == true)
            {
                if (m_Entitys[pc]->IsOnLadder() == true)
                {
                    if (input.type == IET_REPEAT)
                    {
                        LadderMovement movement = NOT_MOVE;

                        switch (input.button)
                        {
                            case KEY_UP:    movement = m_ButtonUp   [m_LadderMovementId]; break;
                            case KEY_DOWN:  movement = m_ButtonDown [m_LadderMovementId]; break;
                            case KEY_RIGHT: movement = m_ButtonRight[m_LadderMovementId]; break;
                            case KEY_LEFT:  movement = m_ButtonLeft [m_LadderMovementId]; break;
                        }

                        SetNextLadderStep(pc, movement);
                    }
                }
                else if (m_Entitys[pc]->IsInJump() == false)
                {
                    // if we make move rotate vector according to field
                    Matrix m;
                    MatrixRotationY(m, 180.0f * ((float)m_MovementRotation - 32768.0f) / 32768.0f);
                    Vector4Transform(next_step, next_step, m);

                    if (SetNextStep(pc, next_step, false) == true)
                    {
                        CheckEncounters();
                    }
                }
            }
        }
    }



    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_C3: m_DrawWalkmesh   = (m_DrawWalkmesh)   ? false : true; break;
            case KEY_C4: m_DrawCollisions = (m_DrawCollisions) ? false : true; break;
            case KEY_C5: m_DrawTriggers   = (m_DrawTriggers)   ? false : true; break;

            case KEY_Cx:
            {
                for (s8 i = 0; i < m_Entitys.size(); ++i)
                {
                    if (m_Entitys[i]->IsTalkable() == true)
                    {
                        m_Entitys[i]->RequestRun(0, 1);
                        break;
                    }
                }
            }
            break;
        }
    }



    Uint32 i;

    // give input to entity
    for (i = 0; i < m_Entitys.size(); ++i)
    {
        m_Entitys[i]->Input(input);
    }



    // give input to mark triangles
    for (i = 0; i < m_MarkTriangles.size(); ++i)
    {
        m_MarkTriangles[i]->Input(input);
    }



    // give input to walk mesh
    for (i = 0; i < m_WalkMesh.size(); ++i)
    {
        m_WalkMesh[i]->Input(input);
    }
}



void
ObjectManager::Update(const Uint32 delta_time)
{
    Uint32 i;

    for (i = 0; i < m_Entitys.size(); ++i)
    {
        m_Entitys[i]->Run(m_pFieldModule, m_Script, i);
    }



    // check talk
    Sint8 pc = GetPlayerEntity();

    if (pc != -1)
    {
        for (i = 0; i < m_Entitys.size(); ++i)
        {
            if (i != pc && m_Entitys[i]->IsActionEnabled() == true && m_Entitys[pc]->IsActionEnabled() == true)
            {
                m_Entitys[i]->CheckCollisionTalk(m_Entitys[pc]);
            }
        }
    }



    if (pc != -1)
    {
        m_pFieldModule->m_ScreenManager.SetPlayerCharacterPosition(m_Entitys[pc]->GetPosition());
    }



    // give update to entitys
    for (i = 0; i < m_Entitys.size(); ++i)
    {
        m_Entitys[i]->Update(delta_time);
    }



    // update mark triangles
    for (i = 0; i < m_MarkTriangles.size(); ++i)
    {
        m_MarkTriangles[i]->Update(delta_time);
    }



    // update walk mesh
    for (i = 0; i < m_WalkMesh.size(); ++i)
    {
        m_WalkMesh[i]->Update(delta_time);
    }



    // after all updates check triggers
    if (pc != -1 && m_Entitys[pc]->IsOnLadder() == false && m_Entitys[pc]->IsInJump() == false)
    {
        CheckTriggers(pc);
    }
}



void
ObjectManager::AddEntity(Entity* entity)
{
    m_Entitys.push_back(entity);
}



void
ObjectManager::AddScript(Script* script)
{
    m_Script = script;
}



void
ObjectManager::AddWalkMeshTriangle(WalkMeshTriangle* triangle)
{
    m_WalkMesh.push_back(triangle);
}



void
ObjectManager::AddGateway(const Vector3& point1, const Vector3& point2, const Vector3& position, const Sint16 map_id)
{
    m_Gateways.push_back(Gateway(m_pFieldModule, point1, point2, position, map_id));
}



void
ObjectManager::AddMarkTriangle(const Vector3& position, const MarkTriangleColor& color)
{
    MarkTriangle* triangle = new MarkTriangle(m_pFieldModule, position, color);

    m_MarkTriangles.push_back(triangle);
}



void
ObjectManager::AddEncounterTable(const EncounterTable& encounterTable)
{
    // if this table is enabled - disable all others
    if (encounterTable.enabled == true)
    {
        for (u8 i = 0; i < m_vEncounters.size(); ++i)
        {
            m_vEncounters[i].enabled = false;
        }
    }

    m_vEncounters.push_back(encounterTable);
}



void
ObjectManager::SetMovement(const Uint32 movement)
{
    m_MovementRotation = movement;
}



void
ObjectManager::RequestRunEntity(const s8& sbEntityId, const u8& ubPriority, const u8& ubScriptId)
{
    if (sbEntityId >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::RequestRunEntity: Request to run entity with Id larger than number of entity.");
        return;
    }

    m_Entitys[sbEntityId]->RequestRun(ubPriority, ubScriptId);
}



void
ObjectManager::SetFramesToWait(const s8& sbEntityId, const u16& usWait)
{
    if (sbEntityId >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetFramesToWait: Request to wait entity with Id larger than number of entity.");
        return;
    }

    m_Entitys[sbEntityId]->SetFramesToWait(usWait);
}



void
ObjectManager::SetPlayerCharacrerMovability(const bool& bMovability)
{
    m_PlayerCharacterMovable = !bMovability;
}



void
ObjectManager::SetEncounterTable(const u8& ubEncounterTable)
{
    if (ubEncounterTable >= m_vEncounters.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEncounterTable: Tried set mActiveEncounter greater than current mEncounters number.");
        return;
    }

    // enable this table, disable others
    for (u8 i = 0; i < m_vEncounters.size(); ++i)
    {
        if (i == ubEncounterTable)
        {
            m_vEncounters[i].enabled = true;
        }
        else
        {
            m_vEncounters[i].enabled = false;
        }
    }
}



void
ObjectManager::SetTriangleAccess(const Uint16 triangle_id, const Uint8 lock)
{
    if (triangle_id >= m_WalkMesh.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetTriangleAccess: Tried set access to triangle that are not in walkmesh.");
        return;
    }

    m_WalkMesh[triangle_id]->SetAccessible((lock == 1) ? false : true);
}



void
ObjectManager::DisableEncounter(const bool disable)
{
    m_bEncounterDisabled = disable;
}



void
ObjectManager::SetPlayerCharacter(const s8& sbEntityId, const s8& sbPlayerCharacter)
{
    if (sbEntityId >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetPlayerCharacter: Tried set player character to entity with Id larger than number of entity.");
        return;
    }

    m_Entitys[sbEntityId]->SetPlayerCharacter(sbPlayerCharacter);



    // we always play as 0 PC for now
    if (sbPlayerCharacter == 0)
    {
        // load position from gamestate
        if (GAMESTATE->PlayerPositionIsSet() == true)
        {
            m_Entitys[sbEntityId]->SetPosition(GAMESTATE->PlayerPositionGet());

            if (GAMESTATE->PlayerTriangleIsSet() == true)
            {
                m_Entitys[sbEntityId]->SetTriangle(GAMESTATE->PlayerTriangleGet());
                FixEntityPosition(sbEntityId);
            }
            else
            {
                SetPositionByXZ(sbEntityId, m_Entitys[sbEntityId]->GetPosition());
            }
        }
        else
        {
            m_Entitys[sbEntityId]->SetPositionFixed(false);
        }
    }
}



void
ObjectManager::SetCharacter(const s8& sbEntityId, const s8& sbCharacterId)
{
    if (sbEntityId >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetCharacter: Tried set character to entity with Id larger than number of entity.");
        return;
    }

    m_Entitys[sbEntityId]->SetModelId(sbCharacterId);
}



void
ObjectManager::SetPositionByXYZTriangle(const s8& sbEntityId, const Vector3& coords, const u16& usTriangleId)
{
    if (sbEntityId >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetPositionByXYZTriangle: Tried set position to entity with Id larger than number of entity.");
        return;
    }

    if (m_Entitys[sbEntityId]->IsPositionFixed() == true)
    {
        return;
    }

    m_Entitys[sbEntityId]->SetPosition(coords);
    m_Entitys[sbEntityId]->SetTriangle(usTriangleId);
    FixEntityPosition(sbEntityId);
}



void
ObjectManager::SetDirection(const s8 sbEntityId, const u8 ubDirection)
{
    if (sbEntityId >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetDirection: Tried set direction to entity with Id larger than number of entity.");
        return;
    }

    m_Entitys[sbEntityId]->SetDirection(ubDirection);
}



const Sint16
ObjectManager::GetEntityTriangleId(const Sint8 entity_id)
{
    if (entity_id >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::GetEntityTriangleId: Tried get triangle id from entity with Id larger than number of entity.");
        return 0;
    }

    return m_Entitys[entity_id]->GetTriangle();
}



void
ObjectManager::SetPlayerCharacterToEntity(const s8 sbEntityId)
{
    if (sbEntityId >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetPlayerCharacterToEntity: Tried set player character to entity with Id larger than number of entity.");
        return;
    }

    if (m_Entitys[sbEntityId]->IsActionEnabled() == true)
    {
        for (u8 i = 0; i < m_Entitys.size(); ++i)
        {
            if (m_Entitys[i]->GetPlayerCharacter() == 0)
            {
                m_Entitys[i]->SetPlayerCharacter(-1);
            }

            if (i == sbEntityId)
            {
                m_Entitys[i]->SetPlayerCharacter(0);
            }
        }
    }
}



void
ObjectManager::SetEntityToJump(const Sint8 entity_id, const Vector3& end_point, const Uint16 height)
{
    if (entity_id >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEntityToJump: Tried set change mode to jump to entity with Id larger than number of entity.");
        return;
    }

    m_Entitys[entity_id]->SetJump(end_point, entity_id, this);
}



const Vector3&
ObjectManager::GetEntityPosition(const Sint8 entity_id)
{
    if (entity_id >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::GetEntityPosition: Tried get triangle id from entity with Id larger than number of entity.");
        return 0;
    }

    return m_Entitys[entity_id]->GetPosition();
}



void
ObjectManager::SetEntityToLadder(const Sint8 entity_id, const Vector3& end_point, const Sint16 end_triangle, const Uint8 movement_id)
{
    if (entity_id >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEntityToLadder: Tried set change mode to ladder to entity with Id larger than number of entity.");
        return;
    }

    m_Entitys[entity_id]->SetOnLadder(true);
    m_Entitys[entity_id]->SetLadder(end_point, end_triangle);

    // movement id 0-3
    m_LadderMovementId = (movement_id >= 4) ? 3 : movement_id;
}



void
ObjectManager::SetEntityTalkRange(const Sint8 entity_id, const Uint16 range)
{
    if (entity_id >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEntityTalkRange: Tried set change talk range to entity with Id larger than number of entity.");
        return;
    }

    m_Entitys[entity_id]->SetTalkRange(range);
}



void
ObjectManager::SetEntitySolidRange(const Sint8 entity_id, const Uint16 range)
{
    if (entity_id >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEntitySolidRange: Tried set change solid range to entity with Id larger than number of entity.");
        return;
    }

    m_Entitys[entity_id]->SetSolidRange(range);
}



void
ObjectManager::SetEntitySolid(const Sint8 entity_id, const bool solid)
{
    if (entity_id >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEntitySolid: Tried set solid entity with Id larger than number of entity.");
        return;
    }

    m_Entitys[entity_id]->SetSolid(solid);
}



void
ObjectManager::AddLine(const Sint8 entity_id, const Vector3& point1, const Vector3& point2)
{
    if (entity_id >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::AddLine: Tried add line to entity with Id larger than number of entity.");
        return;
    }

    m_Lines.push_back(Line(m_pFieldModule, point1, point2, entity_id));
}



void
ObjectManager::SetLinesCheck(const bool check)
{
    m_LinesCheck = check;
}



void
ObjectManager::SetGatewaysCheck(const bool check)
{
    m_GatewaysCheck = check;
}



void
ObjectManager::SetLine(const Sint8 entity_id, const Vector3& point1, const Vector3& point2)
{
    if (entity_id >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetLine: Tried set line to entity with Id larger than number of entity.");
        return;
    }

    std::vector<Line>::iterator it = std::find_if(m_Lines.begin(), m_Lines.end(), line_find(entity_id));

    if (it == m_Lines.end())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetLine: line has not been previously enabled.");
    }
    else
    {
        (*it).SetPoint1(point1);
        (*it).SetPoint2(point2);
    }
}



void
ObjectManager::SetPositionByXZ(const s8 sbEntityId, const Vector3& coords)
{
    if (sbEntityId >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetPositionByXZ: Tried set position to entity with Id larger than number of entity.");
        return;
    }

    if (m_Entitys[sbEntityId]->IsPositionFixed() == true)
    {
        return;
    }

    // we search for the highest triangle
    // here we store highest Y value;
    Vector3 highest_point(0.0f, -10000.0f, 0.0f);
    u32     highest_triangle_id = 0;
    bool    highest_find = false;

    Vector3 point1 = coords;

    Vector3 point2;
    point2.x = point1.x + 10000.0f;
    point2.y = point1.y;
    point2.z = point1.z;

    for (u32 i = 0; i < m_WalkMesh.size() ; ++i)
    {
        point1.y = point_elevation(point1, m_WalkMesh[i]->GetA(), m_WalkMesh[i]->GetB(), m_WalkMesh[i]->GetC());
        point2.y = point_elevation(point2, m_WalkMesh[i]->GetA(), m_WalkMesh[i]->GetB(), m_WalkMesh[i]->GetC());

        u8 check = 0;
        // if we cross line 1
        if (line_crossing(point1, point2, m_WalkMesh[i]->GetA(), m_WalkMesh[i]->GetB()) == true)
        {
            ++check;
        }
        // if we cross line 2
        if (line_crossing(point1, point2, m_WalkMesh[i]->GetB(), m_WalkMesh[i]->GetC()) == true)
        {
            ++check;
        }
        // if we cross line 3
        if (line_crossing(point1, point2, m_WalkMesh[i]->GetA(), m_WalkMesh[i]->GetC()) == true)
        {
            ++check;
        }



        // we are in triangle only if we cross one side
        if (check == 1)
        {
            if (highest_point.y < point1.y)
            {
                // store highest Y
                highest_point       = point1;
                highest_triangle_id = i;
                highest_find        = true;
            }
        }
    }



    if (highest_find == true)
    {
        m_Entitys[sbEntityId]->SetPosition(highest_point);
        m_Entitys[sbEntityId]->SetTriangle(highest_triangle_id);
        FixEntityPosition(sbEntityId);
    }
    else
    {
        m_Entitys[sbEntityId]->SetPosition(Vector3(0.0f, 0.0f, 0.0f));
        m_Entitys[sbEntityId]->SetTriangle(-1);
        m_Entitys[sbEntityId]->SetPositionFixed(false);
    }
}



void
ObjectManager::SetWait(const s8 sbEntityId, const bool bWait)
{
    if (sbEntityId >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetWait: Tried set wait to entity with Id larger than number of entity.");
        return;
    }

    m_Entitys[sbEntityId]->SetWait(bWait);
}

    

const bool
ObjectManager::SetNextStep(const s8 sbEntityId, const Vector4& move_vector, const bool bSlide)
{
    if (sbEntityId >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetNextStep: Tried to move entity with Id larger than number of entity.");
        return false;
    }

    if (m_Entitys[sbEntityId]->IsActionEnabled() != true)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetNextStep: Tried set move entity that are not ActionEnabled.");
        return false;
    }

    // if we are not moving anywhere
    if (move_vector.x == 0.0f && move_vector.z == 0.0f)
    {
        return false;
    }

    u16 triangle = m_Entitys[sbEntityId]->GetTriangle();
    u16 prev_triangle = 0xFFFE; // number of triangles never must be such great

    Vector3 start_point = m_Entitys[sbEntityId]->GetPosition();
    Vector3 end_point(start_point.x + move_vector.x,
                      start_point.y + move_vector.y,
                      start_point.z + move_vector.z);

    for (;;)
    {
        Vector3 A = m_WalkMesh[triangle]->GetA();
        Vector3 B = m_WalkMesh[triangle]->GetB();
        Vector3 C = m_WalkMesh[triangle]->GetC();



        // check if we cross board of current triangle
        u8 cross = 0x00;
        // if we cross line 1
        if      (line_crossing(start_point, end_point, A, B) == true && m_WalkMesh[triangle]->GetAccessSide(0) != prev_triangle)
        {
            cross = 0x01;
        }
        // if we cross line 2
        else if (line_crossing(start_point, end_point, B, C) == true && m_WalkMesh[triangle]->GetAccessSide(1) != prev_triangle)
        {
            cross = 0x02;
        }
        // if we cross line 3
        else if (line_crossing(start_point, end_point, A, C) == true && m_WalkMesh[triangle]->GetAccessSide(2) != prev_triangle)
        {
            cross = 0x03;
        }

        // if we do not cross border
        if (cross == 0x00)
        {
            end_point.y = point_elevation(end_point, A, B, C);

            // check collision
            Vector3 prev_pos = m_Entitys[sbEntityId]->GetPosition();
            m_Entitys[sbEntityId]->SetPosition(end_point);

            int numc = 0;

            for (s8 i = 0; i < m_Entitys.size(); ++i)
            {
                if (i == sbEntityId || m_Entitys[i]->IsSolid() == false)
                {
                    continue;
                }

                if (m_Entitys[i]->IsActionEnabled() == true && m_Entitys[sbEntityId]->CheckCollision(m_Entitys[i]) == true)
                {
                    ++numc;
                    break;
                }
            }

            if (numc == 0)
            {
                m_Entitys[sbEntityId]->SetTriangle(triangle);
                m_Entitys[sbEntityId]->SetPosition(end_point);
                // store new place in gamestate
                GAMESTATE->PlayerPositionSet(end_point);
                GAMESTATE->PlayerTriangleSet(triangle);

                return true;
            }

            m_Entitys[sbEntityId]->SetPosition(prev_pos);
            return false;
        }
        else
        {
            // if board can be crossed
            if (m_WalkMesh[triangle]->IsAccessible() == true &&
                m_WalkMesh[triangle]->GetAccessSide(cross - 1) != -1 &&
                m_WalkMesh[m_WalkMesh[triangle]->GetAccessSide(cross - 1)]->IsAccessible() == true)
            {
                // if line crosses corner of the triangle move final point a bit and recheck all things
                if (point_on_line(A, start_point, end_point) == true ||
                    point_on_line(B, start_point, end_point) == true ||
                    point_on_line(C, start_point, end_point) == true)
                {
                    end_point.z += 0.01f;
                    end_point.x += 0.01f;
                    continue;
                }

                prev_triangle = triangle;
                triangle      = m_WalkMesh[triangle]->GetAccessSide(cross - 1);
            }
            else
            {
                if (bSlide == false)
                {
                    Vector3 sp1 = (cross == 1 || cross == 3) ? A : B;
                    Vector3 sp2 = (cross == 1) ? B : C;

                    Vector4 new_move = get_projection_on_line(move_vector, sp1, sp2);

                    return SetNextStep(sbEntityId, new_move, true);
                }
                else
                {
                    return false;
                }
            }
        }
    }
}



void
ObjectManager::SetNextLadderStep(const Sint8 entity_id, const LadderMovement& movement)
{
    if (entity_id >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetNextStep: Tried to move entity with Id larger than number of entity.");
        return;
    }

    if (m_Entitys[entity_id]->IsActionEnabled() != true)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetNextStep: Tried set move entity that are not ActionEnabled.");
        return;
    }

    if (movement == NOT_MOVE)
    {
        return;
    }


    Vector3 start_point   = m_Entitys[entity_id]->GetLadderStart();
    Vector3 current_point = m_Entitys[entity_id]->GetPosition();
    Vector3 end_point     = m_Entitys[entity_id]->GetLadderEnd();

    u8 finish_end   = 0;
    u8 finish_start = 0;

    float step;

    // x moving
    step = (end_point.x - start_point.x) / 100;
    if (start_point.x == current_point.x && movement == MOVE_TO_START)
    {
        ++finish_start;
    }
    if (end_point.x == current_point.x && movement == MOVE_TO_END)
    {
        ++finish_end;
    }
    if (movement == MOVE_TO_END)
    {
        current_point.x += step;
        current_point.x = ((current_point.x > end_point.x && step > 0) || (current_point.x < end_point.x && step < 0)) ? end_point.x : current_point.x;
    }
    else if (movement == MOVE_TO_START)
    {
        current_point.x -= step;
        current_point.x = ((current_point.x < start_point.x && step > 0) || (current_point.x > start_point.x && step < 0)) ? start_point.x : current_point.x;
    }



    // y moving
    step = (end_point.y - start_point.y) / 100;
    if (start_point.y == current_point.y && movement == MOVE_TO_START)
    {
        ++finish_start;
    }
    if (end_point.y == current_point.y && movement == MOVE_TO_END)
    {
        ++finish_end;
    }
    if (movement == MOVE_TO_END)
    {
        current_point.y += step;
        current_point.y = ((current_point.y > end_point.y && step > 0) || (current_point.y < end_point.y && step < 0)) ? end_point.y : current_point.y;
    }
    else if (movement == MOVE_TO_START)
    {
        current_point.y -= step;
        current_point.y = ((current_point.y < start_point.y && step > 0) || (current_point.y > start_point.y && step < 0)) ? start_point.y : current_point.y;
    }



    // z moving
    step = (end_point.z - start_point.z) / 100;
    if (start_point.z == current_point.z && movement == MOVE_TO_START)
    {
        ++finish_start;
    }
    if (end_point.z == current_point.z && movement == MOVE_TO_END)
    {
        ++finish_end;
    }
    if (movement == MOVE_TO_END)
    {
        current_point.z += step;
        current_point.z = ((current_point.z > end_point.z && step > 0) || (current_point.z < end_point.z && step < 0)) ? end_point.z : current_point.z;
    }
    else if (movement == MOVE_TO_START)
    {
        current_point.z -= step;
        current_point.z = ((current_point.z < start_point.z && step > 0) || (current_point.z > start_point.z && step < 0)) ? start_point.z : current_point.z;
    }



    if (finish_start == 3)
    {
        m_Entitys[entity_id]->SetPosition(start_point);
        m_Entitys[entity_id]->SetTriangle(m_Entitys[entity_id]->GetLadderTriangleStart());
        m_Entitys[entity_id]->SetOnLadder(false);
        m_Entitys[entity_id]->SetWait(false);
    }
    else if (finish_end == 3)
    {
        m_Entitys[entity_id]->SetPosition(end_point);
        m_Entitys[entity_id]->SetTriangle(m_Entitys[entity_id]->GetLadderTriangleEnd());
        m_Entitys[entity_id]->SetOnLadder(false);
        m_Entitys[entity_id]->SetWait(false);
    }
    else
    {
        m_Entitys[entity_id]->SetPosition(current_point);
    }
}



void
ObjectManager::CheckTriggers(const s8 sbEntityId)
{
    if (sbEntityId >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::CheckTriggers: Tried check triggers  with entity with Id larger than number of entity.");
        return;
    }

    if (m_GatewaysCheck == true)
    {
        for (u8 i = 0; i < m_Gateways.size(); ++i)
        {
            m_Gateways[i].CheckCollision(m_Entitys[sbEntityId]);
        }
    }

    // check entity lines
    if (m_LinesCheck == true)
    {
        for (u8 i = 0; i < m_Lines.size(); ++i)
        {
            m_Lines[i].CheckCollision(m_Entitys[sbEntityId]);
        }
    }
}



void
ObjectManager::CheckEncounters(void)
{
    // if battle locked
    if (GAMESTATE->BattleLockGet() == true || m_bEncounterDisabled == true)
    {
        return;
    }



    for (u8 j = 0; j < m_vEncounters.size(); ++j)
    {
        // if field encounter not active
        if (m_vEncounters[j].enabled != true || m_vEncounters[j].rate == 0xFF)
        {
            continue;
        }

        m_ulDangerCounter += 1024 / (m_vEncounters[j].rate + 1);

        // check encounter
        if (rand() % 255 < m_ulDangerCounter / 256)
        {
            u16 battle = 0;

            // check special encounter
            for (u8 i = 0; i < 4; ++i)
            {
                if (rand() % 64 < m_vEncounters[j].special_encounter[i].rate)
                {
                    battle = m_vEncounters[j].special_encounter[i].scene;
                    break;
                }
            }



            // check standard encounter
            if (battle == 0)
            {
                u8 chance = rand() % 64;
                u8 chance_sum = 0;

                for (u8 i = 0; i < 6; ++i)
                {
                    if (m_vEncounters[j].standart_encounter[i].rate + chance_sum > chance)
                    {
                        battle = m_vEncounters[j].standart_encounter[i].scene;
                        break;
                    }

                    chance_sum += m_vEncounters[j].standart_encounter[i].rate;
                }
            }



            LOGGER->Log(LOGGER_INFO, "Encount battle %d from table %d", battle, j);
            m_pFieldModule->LoadBattle(battle);
            return;
        }
    }
}



const s8
ObjectManager::GetPlayerEntity(void) const
{
    for (s8 i = 0; i < m_Entitys.size(); ++i)
    {
        // we only play as character 0
        if (m_Entitys[i]->GetPlayerCharacter() == 0)
        {
            return i;
        }
    }

    return -1;
}



void
ObjectManager::FixEntityPosition(const s8 sbEntityId)
{
    if (sbEntityId >= m_Entitys.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::FixEntityPosition: Tried fix position to entity with Id larger than number of entity.");
        return;
    }

    // fix Entity position
    m_Entitys[sbEntityId]->SetPositionFixed(true);
    // store player position set in gamestate
    s8 pc = GetPlayerEntity();
    if (sbEntityId == pc)
    {
        GAMESTATE->PlayerPositionSet(m_Entitys[pc]->GetPosition());
        GAMESTATE->PlayerTriangleSet(m_Entitys[pc]->GetTriangle());
    }
}
