// $Id$

#include <math.h>
#include <vector>

#include "../../common/display/math/Matrix.h"
#include "../../common/display/math/MatrixMath.h"
#include "../../common/display/math/Vector.h"
#include "../../common/display/math/VectorMath.h"
#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "BcxFile.h"
#include "Entity.h"
#include "WalkMeshTriangle.h"
#include "../kernel/Kernel.h"



BcxFile::BcxFile(const RString &file):
    LzsFile(file)
{
}



BcxFile::BcxFile(File *file, const u32 &offset, const u32 &length):
    LzsFile(file, offset, length)
{
}



BcxFile::BcxFile(u8* buffer, const u32 &offset, const u32 &length):
    LzsFile(buffer, offset, length)
{
}



BcxFile::BcxFile(File *file):
    LzsFile(file)
{
}



BcxFile::~BcxFile(void)
{
}



void
BcxFile::GetModel(Model& model)
{
    Uint32 offset_to_model_info = GetU32LE(0x04);

    Uint8 number_of_bones      = GetU8(offset_to_model_info + 0x02);
    Uint8 number_of_parts      = GetU8(offset_to_model_info + 0x03);
    Uint8 number_of_animations = GetU8(offset_to_model_info + 0x04);



    Uint16 offset_to_bones = GetU16LE(offset_to_model_info + 0x1C);
    Sint8 current_part_id = 0;

    for (Uint32 i = 0; i < number_of_bones; ++i)
    {
        Sint16 length    = GetU16LE(offset_to_bones + i * 0x04 + 0x00);
        Sint8  parent_id = GetU8(offset_to_bones + i * 0x04 + 0x02);
        Sint8  part_id   = (GetU8(offset_to_bones + i * 0x04 + 0x03) == 1) ? current_part_id : -1;

        current_part_id += (part_id == -1) ? 0 : 1;

        model.AddBone(length, parent_id, part_id);
    }



    Uint16 offset_to_parts = GetU16LE(offset_to_model_info + 0x1C) + number_of_bones * 4;

    for (Uint32 i = 0; i < number_of_parts; ++i)
    {
        TotalGeometry geometry;

        Uint16 offset_to_part   = offset_to_parts + i * 0x20;



        // add vertexes to array
        Uint8  number_of_vertex  = GetU8(offset_to_part + 0x02);
        Uint16 offset_to_vertexes = GetU16LE(offset_to_part + 0x18);
        LOGGER->Log(LOGGER_INFO, "number_of_vertex:    %02x", number_of_vertex);
        std::vector<Vector3> vertexes;
        for (Uint32 j = 0; j < number_of_vertex; ++j)
        {
            Uint16 offset_to_vertex = offset_to_vertexes + j * 0x08;

            Vector3 point;
            point.x = static_cast<s16>(GetU16LE(offset_to_vertex + 4 + 0x00));
            point.y = static_cast<s16>(GetU16LE(offset_to_vertex + 4 + 0x02));
            point.z = static_cast<s16>(GetU16LE(offset_to_vertex + 4 + 0x04));
            vertexes.push_back(point);
        }



        // skip unknown
        Uint8  number_of_quad_t = GetU8(offset_to_part + 0x04);
        Uint16 offset_to_poly   = offset_to_vertexes + GetU16LE(offset_to_part + 0x0E);
        LOGGER->Log(LOGGER_INFO, "number_of_quad_t:    %02x", number_of_quad_t);
        LOGGER->Log(LOGGER_INFO, "offset_to_poly:      %04x", offset_to_poly);
        offset_to_poly += number_of_quad_t * 0x18;



        Uint8  number_of_triangle_t = GetU8(offset_to_part + 0x05);
        LOGGER->Log(LOGGER_INFO, "number_of_quad_t:    %02x", number_of_triangle_t);
        LOGGER->Log(LOGGER_INFO, "offset_to_poly:      %04x", offset_to_poly);
        offset_to_poly += number_of_triangle_t * 0x14;



        // add color triangle
        Uint8  number_of_triangle  = GetU8(offset_to_part + 0x0A);
        LOGGER->Log(LOGGER_INFO, "number_of_triangle:  %02x", number_of_triangle);
        LOGGER->Log(LOGGER_INFO, "offset_to_poly:      %04x", offset_to_poly);
        for (Uint32 j = 0; j < number_of_triangle; ++j)
        {
            Geometry poly;
            poly.blend           = BLEND_PSX_0;
            poly.texture_enabled = false;

            Vertex a, b, c;
            a.p = vertexes[GetU8(offset_to_poly + 0x00)];
            b.p = vertexes[GetU8(offset_to_poly + 0x01)];
            c.p = vertexes[GetU8(offset_to_poly + 0x02)];

            Color color(1.0f, 1.0f, 1.0f, 1.0f);
            color.r = GetU8(offset_to_poly + 0x04) / 255.0f;
            color.g = GetU8(offset_to_poly + 0x05) / 255.0f;
            color.b = GetU8(offset_to_poly + 0x06) / 255.0f;
            a.c = color;
            color.r = GetU8(offset_to_poly + 0x08) / 255.0f;
            color.g = GetU8(offset_to_poly + 0x09) / 255.0f;
            color.b = GetU8(offset_to_poly + 0x0A) / 255.0f;
            b.c = color;
            color.r = GetU8(offset_to_poly + 0x0C) / 255.0f;
            color.g = GetU8(offset_to_poly + 0x0D) / 255.0f;
            color.b = GetU8(offset_to_poly + 0x0E) / 255.0f;
            c.c = color;

            poly.vertexes.push_back(a);
            poly.vertexes.push_back(b);
            poly.vertexes.push_back(c);

            geometry.triangles.push_back(poly);

            offset_to_poly += 0x10;
        }



        // add color quad
        Uint8  number_of_quads = GetU8(offset_to_part + 0x0B);
        for (Uint32 j = 0; j < number_of_quads; ++j)
        {
            Geometry poly;
            poly.blend           = BLEND_PSX_0;
            poly.texture_enabled = false;

            Vertex a, b, c, d;
            a.p = vertexes[GetU8(offset_to_poly + 0x00)];
            b.p = vertexes[GetU8(offset_to_poly + 0x01)];
            d.p = vertexes[GetU8(offset_to_poly + 0x02)];
            c.p = vertexes[GetU8(offset_to_poly + 0x03)];

            Color color(1.0f, 1.0f, 1.0f, 1.0f);
            color.r = GetU8(offset_to_poly + 0x04) / 255.0f;
            color.g = GetU8(offset_to_poly + 0x05) / 255.0f;
            color.b = GetU8(offset_to_poly + 0x06) / 255.0f;
            a.c = color;
            color.r = GetU8(offset_to_poly + 0x08) / 255.0f;
            color.g = GetU8(offset_to_poly + 0x09) / 255.0f;
            color.b = GetU8(offset_to_poly + 0x0A) / 255.0f;
            b.c = color;
            color.r = GetU8(offset_to_poly + 0x0C) / 255.0f;
            color.g = GetU8(offset_to_poly + 0x0D) / 255.0f;
            color.b = GetU8(offset_to_poly + 0x0E) / 255.0f;
            d.c = color;
            color.r = GetU8(offset_to_poly + 0x10) / 255.0f;
            color.g = GetU8(offset_to_poly + 0x11) / 255.0f;
            color.b = GetU8(offset_to_poly + 0x12) / 255.0f;
            c.c = color;

            poly.vertexes.push_back(a);
            poly.vertexes.push_back(b);
            poly.vertexes.push_back(c);
            poly.vertexes.push_back(d);

            geometry.quads.push_back(poly);

            offset_to_poly += 0x14;
        }

        model.AddPart(geometry);
    }



    Uint16 offset_to_animations = GetU16LE(offset_to_model_info + 0x1C) + number_of_bones * 4 + number_of_parts * 0x20;

    for (Uint32 i = 0; i < number_of_animations; ++i)
    {
        Uint16 offset_to_animation = offset_to_animations + i * 0x10;

        Animation animation;



        Uint16 offset_to_animation_data = GetU16LE(offset_to_animation + 0x0C);

        LOGGER->Log(LOGGER_INFO, "offset_to_animation_data %04x", offset_to_animation_data);

        offset_to_animation_data += 0x04;

        for (Uint32 j = 0; j < number_of_bones; ++j)
        {
            BonePosition position;

            position.rotation_x = 360.0f * GetU8(offset_to_animation_data + 0x01) / 255.0f;
            position.rotation_y = 360.0f * GetU8(offset_to_animation_data + 0x02) / 255.0f;
            position.rotation_z = 360.0f * GetU8(offset_to_animation_data + 0x03) / 255.0f;

            animation.idle.push_back(position);

            offset_to_animation_data += 0x08;
        }



        model.AddAnimation(animation);
    }
}
