// $Id: Gateway.cpp 151 2007-03-04 11:28:52Z super_gb $

#include "../../common/utilites/Logger.h"

#include "FieldModule.h"
#include "Gateway.h"
#include "../kernel/GameState.h"



Gateway::Gateway(FieldModule* pFieldModule, const Vector3& point1, const Vector3& point2, const Vector3& position, const Sint16 map_id):
    Trigger(pFieldModule, point1, point2),
    mPosition(position),
    m_MapId(map_id)
{
}



Gateway::~Gateway(void)
{
}



void
Gateway::OnEnter(void)
{
    if (m_MapId != -1)
    {
        LOGGER->Log(LOGGER_INFO, "Gateway activates. Load next Map %d", m_MapId);

        GAMESTATE->PlayerPositionSet(mPosition);
        GAMESTATE->PlayerTriangleUnset();

        m_pFieldModule->RequestLoadMap(m_MapId);
    }
    else
    {
        LOGGER->Log(LOGGER_INFO, "Gateway inactive.");
    }
}



void
Gateway::OnMove(void)
{
}



void
Gateway::OnInside(void)
{
}



void
Gateway::OnLeave(void)
{
}
