// $Id$

#ifndef LINE_h
#define LINE_h

#include "../../common/TypeDefine.h"

#include "Trigger.h"



class Line : public Trigger
{
public:
                Line(FieldModule* field_module, const Vector3& point1, const Vector3& point2, const Sint8 entity_id);
    virtual    ~Line(void);

    void        OnEnter(void);
    void        OnMove(void);
    void        OnInside(void);
    void        OnLeave(void);

    const Sint8 GetEntity(void) const;

private:
    Sint8 m_EntityId;
};



#endif // LINE_h
