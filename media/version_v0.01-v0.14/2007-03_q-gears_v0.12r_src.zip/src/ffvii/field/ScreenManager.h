// $Id$

#ifndef SCREEN_MANAGER_h
#define SCREEN_MANAGER_h

#include "../../common/TypeDefine.h"
#include "../../common/display/3dTypes.h"
#include "../../common/utilites/NoCopy.h"

class FieldModule;



class ScreenManager : public NoCopy<ScreenManager>
{
public:
    explicit   ScreenManager(FieldModule* pFieldModule);
    virtual   ~ScreenManager(void);

    void       Clear(void);
    void       Update(const u32& ulDeltaTime);
    void       Draw(void) const;

    // set data from field file
    void       SetCameraMatrix(const Matrix& matrix);
    void       SetOrigin(const Vector3& origin);
    void       SetProjection(const float x_max, const float x_min, const float y_max, const float y_min);
    void       SetScreenRange(const Sint16 x_max, const Sint16 x_min, const Sint16 y_max, const Sint16 y_min);

    // set data for player character scrolling
    void       SetPlayerCharacterPosition(const Vector3& position);

    // set/unset camera for 3d entity with screen offset
    void       EnableCamera(void) const;
    void       DisableCamera(void) const;

    s16        GetCameraPositionX(void) const;
    s16        GetCameraPositionY(void) const;

    Vector3    CoordsWorldToScreen(const Vector3& position) const;

    // script
    // 0x64 SCR2D
    void       ScrollToCoordsInstant(const s16& ssX, const s16& ssY);
    // 0x65 SCRCC
    void       ScrollToPlayerCharacter(void);
    // 0x66 SCR2DC
    void       ScrollToCoordsSmooth(const s16& ssX, const s16& ssY, const u16& usSpeed);
    // 0x67 SCRLW
    void       AddWaitForScroll(const s8& sbEntityId);
    // 0x68 SCR2DL
    void       ScrollToCoordsLinear(const s16& ssX, const s16& ssY, const u16& usSpeed);

private:
    Matrix     GetCameraMatrix(void) const;
    Matrix     GetProjectionMatrix(void) const;

private:
    // feed back to field module
    FieldModule*        m_pFieldModule;

    u16                 m_usScreenWidth;
    u16                 m_usScreenHeight;
    std::vector<Vertex> m_vScreenBorder;

    // camera
    Matrix              m_Matrix;
    Vector3             m_Origin; // in camera space

    // projection
    float               m_fXMax;
    float               m_fXMin;
    float               m_fYMax;
    float               m_fYMin;

    // current position
    s16                 m_ssXMax;
    s16                 m_ssXMin;
    s16                 m_ssYMax;
    s16                 m_ssYMin;
    s16                 m_ssCameraPositionX;
    s16                 m_ssCameraPositionY;

    // scrolling
    // requested position
    bool                m_bSmooth;
    s16                 m_ssStartScrollPositionX;
    s16                 m_ssStartScrollPositionY;
    s16                 m_ssRequestPositionX;
    s16                 m_ssRequestPositionY;
    u16                 m_FramesToScrollTotal;
    u16                 m_FrameScrollNumber;
    std::vector<s8>     m_vWaitingForScroll;

    bool                m_ScrollToPlayerCharacter;
};



#endif // CAMERA_h
