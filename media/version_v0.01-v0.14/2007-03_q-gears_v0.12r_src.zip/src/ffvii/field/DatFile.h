// $Id: DatFile.h 151 2007-03-04 11:28:52Z super_gb $

#ifndef DATFILE_H
#define DATFILE_H

#include <vector>

#include "../../common/display/3dTypes.h"
#include "../../common/display/math/Matrix.h"
#include "../../common/utilites/StdString.h"

#include "BackgroundManager.h"
#include "ObjectManager.h"
#include "ScreenManager.h"
#include "WindowManager.h"
#include "../filetypes/LzsFile.h"
#include "../filesystem/File.h"



class DatFile : public LzsFile
{
public:
    explicit DatFile(const RString &file);
    explicit DatFile(File* file);
    DatFile(File* file, const u32 &offset, const u32 &length);
    DatFile(u8* buffer, const u32 &offset, const u32 &length);
    virtual ~DatFile();

    void GetScripts(ObjectManager& objectManager);
    void GetDialogs(WindowManager& windowManager);
    void GetBackground(BackgroundManager& backgroundManager);
    void GetWalkMesh(ObjectManager& objectManager);
    void GetCameraMatrix(ScreenManager& cam);
    void GetGateway(ObjectManager& objectManager);
    void GetMarkTriangles(ObjectManager& object_manager);
    void GetScreenRange(ScreenManager& screen);
    void GetMovementRotation(ObjectManager& object_manager);
    void GetEncounter(ObjectManager& objectManager);
};



#endif // DATFILE_H
