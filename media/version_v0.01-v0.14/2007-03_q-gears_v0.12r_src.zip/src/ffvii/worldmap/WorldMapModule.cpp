// $Id: WorldMapModule.cpp 135 2007-02-06 05:21:01Z halkun $

#include <cassert>
#include <iostream>

#include "../../common/display/Display.h"
#include "../../common/module/ModuleManager.h"
#include "../../common/utilites/Logger.h"

#include "WorldMapModule.h"
#include "MapFile.h"
#include "WorldMap.h"
#include "../field/FieldModule.h"
#include "../kernel/Kernel.h"



WorldMapModule::WorldMapModule(void)
{
    Init();
}

WorldMapModule::~WorldMapModule(void)
{
    delete mWorldMap;
    mWorldMap = 0;
}

//
void
WorldMapModule::Init()
{
    MapFile f("WORLD/WM0.MAP");

  mWorldMap = f.Read();
  assert(mWorldMap);

  //
  DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
  // DISPLAY->SetCullMode(CULL_NONE);
  DISPLAY->SetPolygonMode(POLYGON_LINE);

  // FIXME: Setup lighting
  
  // Set up camera
  mTranslation.x = -24.0f; mTranslation.y = 0.0f; mTranslation.z = -42.0f;
  mScale = 0.3f / 1024.0f;
    
  DISPLAY->LoadLookAt(50, Vector3(10.1, 5.1, 10.1), Vector3(0, 0, 0), Vector3(0, 1, 0));
}



void
WorldMapModule::Input(const InputEvent& input)
{
    // handle system input ourself
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            // Zoom
            case KEY_KP_PLUS:   mScale += 1.0f / 10240.0f; break;
            case KEY_KP_HYPHEN: mScale -= 1.0f / 10240.0f; break;

            // Translate
            case KEY_KP_C4:     mTranslation.x += 1.0f; break;
            case KEY_KP_C6:     mTranslation.x -= 1.0f; break;
            case KEY_KP_C9:     mTranslation.y += 1.0f; break;
            case KEY_KP_C3:     mTranslation.y -= 1.0f; break;
            case KEY_KP_C8:     mTranslation.z += 1.0f; break;
            case KEY_KP_C2:     mTranslation.z -= 1.0f; break;

            case KEY_Cn:
            {
                MODULEMAN->PopTopModule();
                FieldModule* screen = new FieldModule();
                MODULEMAN->PushModule(screen);
                break;
            }
        }

        std::cout << mTranslation.x << ", " << mTranslation.y << ", " << mTranslation.z << std::endl;
        std::cout << mScale << std::endl;
    }
}



void
WorldMapModule::Update(const Uint32 deltaTime)
{
}



void
WorldMapModule::Draw(void) const
{
  DISPLAY->PushMatrix();
  DISPLAY->Translate(mTranslation.x, mTranslation.y, mTranslation.z);
  DISPLAY->Scale(mScale, mScale, mScale);
  
  //
  int i = 0;
  const WorldCellVector &cells = mWorldMap->GetCells();
  for (WorldCellVector::const_iterator c = cells.begin(); c != cells.end(); ++c, ++i)
    {
      const WorldCell &cell = *(*c);

      DISPLAY->PushMatrix();

      const Vector3 cell_translation(cell.GetTranslation());
      DISPLAY->Translate(cell_translation.x, cell_translation.y, cell_translation.z);

      // if cell is in frustum:
      {
	int j = 0;
	const WorldMeshVector &meshes = cell.GetMeshes();
	for (WorldMeshVector::const_iterator m = meshes.begin(); m != meshes.end(); ++m, ++j)
	  {
	    const WorldMesh &world_mesh = *(*m);

	    DISPLAY->PushMatrix();

	    const Vector3 mesh_translation(world_mesh.GetTranslation());
	    DISPLAY->Translate(mesh_translation.x, mesh_translation.y, mesh_translation.z);

	    // if mesh is in frustum:
	    {
	      // DISPLAY->DrawGeometrys(world_mesh.GetGeometry());
	      DISPLAY->DrawStaticMesh(world_mesh.GetMesh());
	    }

	    DISPLAY->PopMatrix();
	  }
      }

      DISPLAY->PopMatrix();
    }

  DISPLAY->PopMatrix();
}
