// $Id$

#ifndef WORLD_CELL_H
#define WORLD_CELL_H

#include "../../common/display/math/Vector.h"

#include "WorldMesh.h"

class WorldCell
{
public:
  WorldCell(const WorldMeshVector &meshes, const Vector3 &translation):
    mMeshes(meshes),
    mTranslation(translation)
  {}

  ~WorldCell();

public:
  inline const Vector3 &GetTranslation() const { return mTranslation; }
  inline const WorldMeshVector &GetMeshes() const { return mMeshes; }
 
protected:
  WorldMeshVector mMeshes;
  Vector3 mTranslation;
};

typedef std::vector<WorldCell *> WorldCellVector;

#endif // !WORLD_CELL_H
