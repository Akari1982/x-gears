// $Id: BattleModule.h 135 2007-02-06 05:21:01Z halkun $

#ifndef BATTLE_MODULE_h
#define BATTLE_MODULE_h

#include "../../common/display/actor/Actor.h"



class BattleModule : public Actor
{
public:
    BattleModule(void);

    virtual ~BattleModule(void);

    virtual void Init(void);

    virtual void Draw(void) const;

    virtual void Input(const InputEvent& input);

    virtual void Update(const Uint32 deltaTime);

    // we cant give id by reference because we may delete caller when clear map resources.
    void LoadBattle(const u16 id);

private:
    u16 mBattleId;
};



#endif // BATTLE_MODULE_h
