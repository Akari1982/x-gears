// $Id: DisplayTest.h 151 2007-03-04 11:28:52Z super_gb $

#ifndef SCREENDISPLAYTEST_H
#define SCREENDISPLAYTEST_H

#include <vector>

#include "../../common/TypeDefine.h"
#include "../../common/display/3dTypes.h"
#include "../../common/display/actor/Actor.h"
#include "../field/Model.h"



class ScreenDisplayTest : public Actor
{
public:
    ScreenDisplayTest();
    virtual ~ScreenDisplayTest();

    virtual void Init();

    virtual void Input(const InputEvent &input);

    virtual void Update(const Uint32 delta_time);

    virtual void Draw() const;

private:
    std::vector<Vertex> mPoints;
    Model               m_Model;
    float               m_ModelRot;
};



#endif // SCREENDISPLAYTEST_H
