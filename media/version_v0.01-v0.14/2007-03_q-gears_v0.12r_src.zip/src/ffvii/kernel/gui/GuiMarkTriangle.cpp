// $Id: GuiMarkTriangle.cpp 103 2006-11-26 07:19:38Z crazy_otaku $

#include "GuiMarkTriangle.h"
#include "../../../common/display/3dTypes.h"
#include "../../../common/display/Display.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/Logger.h"



GuiMarkTriangle::GuiMarkTriangle(Surface* image, Surface* image2)
{
    Surface* temp;

    // 1st frame red
    temp = CreateSubSurface(48, 208, 16, 8, image);
    mTexId[0] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 2nd frame red
    temp = CreateSubSurface(64, 208, 16, 8, image);
    mTexId[1] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 3rd frame red
    temp = CreateSubSurface(80, 208, 16, 8, image);
    mTexId[2] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 4th frame red
    temp = CreateSubSurface(96, 208, 16, 8, image);
    mTexId[3] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 1st frame green
    temp = CreateSubSurface(48, 208, 16, 8, image2);
    mTexId[4] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 2nd frame green
    temp = CreateSubSurface(64, 208, 16, 8, image2);
    mTexId[5] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 3rd frame green
    temp = CreateSubSurface(80, 208, 16, 8, image2);
    mTexId[6] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 4th frame green
    temp = CreateSubSurface(96, 208, 16, 8, image2);
    mTexId[7] = DISPLAY->CreateTexture(temp);
    delete temp;



    Vertex point;
    point.p.x = 0.0f;  point.p.y = 0.0f;  point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f;  point.t.y = 0.0f;
    mPoly.vertexes.push_back(point);
    point.p.x = 16.0f; point.p.y = 0.0f;  point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 0.0f;
    mPoly.vertexes.push_back(point);
    point.p.x = 16.0f; point.p.y = -8.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 1.0f;
    mPoly.vertexes.push_back(point);
    point.p.x = 0.0f;  point.p.y = -8.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a =  1.0f;
    point.t.x = 0.0f;  point.t.y = 1.0f;
    mPoly.vertexes.push_back(point);
}



GuiMarkTriangle::~GuiMarkTriangle()
{
    DISPLAY->DeleteTexture(mTexId[0]);
    DISPLAY->DeleteTexture(mTexId[1]);
    DISPLAY->DeleteTexture(mTexId[2]);
    DISPLAY->DeleteTexture(mTexId[3]);
    DISPLAY->DeleteTexture(mTexId[4]);
    DISPLAY->DeleteTexture(mTexId[5]);
    DISPLAY->DeleteTexture(mTexId[6]);
    DISPLAY->DeleteTexture(mTexId[7]);
}



void
GuiMarkTriangle::Draw(const int& x, const int& y, const u8& frame, const MarkTriangleColor &color)
{
    if (frame >= 4 || color == INVISIBLE)
    {
        return;
    }

    DISPLAY->PushMatrix();
    DISPLAY->Translate(x, -y, 0);

    u8 texture = frame + 4 * ((color == RED) ? 1 : 0);

    DISPLAY->SetTexture(mTexId[texture]);
    DISPLAY->DrawQuads(mPoly);
    DISPLAY->UnsetTexture();

    DISPLAY->PopMatrix();
}
