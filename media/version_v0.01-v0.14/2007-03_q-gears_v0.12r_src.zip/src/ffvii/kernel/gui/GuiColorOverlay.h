// $Id$

#ifndef GUI_COLOR_OVERLAY_h
#define GUI_COLOR_OVERLAY_h

#include "../../../common/TypeDefine.h"
#include "../../../common/display/3dTypes.h"
#include "../../../common/utilites/NoCopy.h"



class GuiColorOverlay : public NoCopy<GuiColorOverlay>
{
public:
             GuiColorOverlay(void);
    virtual ~GuiColorOverlay(void);

    void Draw(const Color& color);

private:
    Geometry mPoly;
};



#endif // GUI_COLOR_OVERLAY_h
