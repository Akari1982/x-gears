// $Id: GuiTriangle.h 103 2006-11-26 07:19:38Z crazy_otaku $

#ifndef GUI_MARK_TRIANGLE_h
#define GUI_MARK_TRIANGLE_h

#include "../../../common/TypeDefine.h"
#include "../../../common/display/3dTypes.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/NoCopy.h"



enum MarkTriangleColor {INVISIBLE, GREEN, RED};



class GuiMarkTriangle : public NoCopy<GuiMarkTriangle>
{
public:
    GuiMarkTriangle(Surface* image, Surface* image2);

    virtual ~GuiMarkTriangle(void);

    void Draw(const int& x, const int& y, const u8& frame, const MarkTriangleColor& color);

private:
    int      mTexId[8];
    Geometry mPoly;
};



#endif // GUI_MARK_TRIANGLE_h
