// $Id$

#include "Actor.h"
#include "../Display.h"



Actor::Actor(void)
{
}



Actor::~Actor(void)
{
}
