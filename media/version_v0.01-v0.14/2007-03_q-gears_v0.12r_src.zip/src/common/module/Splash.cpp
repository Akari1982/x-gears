// $Id: Splash.cpp 147 2007-02-24 06:13:17Z super_gb $

#include "Splash.h"

#include "ModuleManager.h"
#include "../Main.h"
#include "../display/Display.h"
#include "../display/surface/SurfaceLoad.h"
#include "../utilites/Logger.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

Splash::Splash(void):
    mTexId(0)
{
    Init();
}



Splash::~Splash(void)
{
    DISPLAY->DeleteTexture(mTexId);
}



//============================= OPERATIONS ===================================

void
Splash::Init(void)
{
    Vertex point;

    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
    DISPLAY->SetCullMode(CULL_NONE);

    Surface* texture = SurfaceUtils::LoadFile("data/splash.bmp");
    if (texture != NULL)
    {
        mTexId = DISPLAY->CreateTexture(texture);
        delete texture;
    }
    else
    {
        LOGGER->Log(LOGGER_ERROR, "Can't load texture.");
    }

    point.p.x = -1.0f; point.p.y = -1.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  0.0f; point.t.y =  1.0f;
    mQuadsTex.vertexes.push_back(point);
    point.p.x = -1.0f; point.p.y =  1.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  0.0f; point.t.y =  0.0f;
    mQuadsTex.vertexes.push_back(point);
    point.p.x =  1.0f; point.p.y =  1.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  1.0f; point.t.y =  0.0f;
    mQuadsTex.vertexes.push_back(point);
    point.p.x =  1.0f; point.p.y = -1.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  1.0f; point.t.y =  1.0f;
    mQuadsTex.vertexes.push_back(point);
}



void
Splash::Draw(void) const
{
    DISPLAY->SetTexture(mTexId);
    DISPLAY->DrawQuads(mQuadsTex);
    DISPLAY->UnsetTexture();
}



void
Splash::Input(const InputEvent& input)
{
    switch (input.button)
    {
        case KEY_SPACE:
        {
            // remove itself
            MODULEMAN->PopTopModule();
            game_module_start();
            break;
        }
    }
}



void
Splash::Update(const Uint32 deltaTime)
{
}
