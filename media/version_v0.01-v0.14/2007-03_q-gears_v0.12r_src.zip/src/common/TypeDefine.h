// $Id: TypeDefine.h 144 2007-02-18 08:45:23Z super_gb $

#ifndef TYPE_DEFINE_h
#define TYPE_DEFINE_h

#include <SDL/SDL_types.h>



#ifdef HAVE_CONFIG_h
# include "config.h"
#endif // HAVE_CONFIG_h



#ifdef HAVE_INTTYPES_H
#include <inttypes.h>
#else
#ifndef _MSC_VER
typedef unsigned char      uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned long int  uint32_t;

typedef signed char        int8_t;
typedef signed short int   int16_t;
typedef signed long int    int32_t;
#else
typedef unsigned __int8    uint8_t;
typedef unsigned __int16   uint16_t;
typedef unsigned __int32   uint32_t;

typedef signed __int8      int8_t;
typedef signed __int16     int16_t;
typedef signed __int32     int32_t;
#endif // _MSC_VER
#endif // HAVE_INTTYPES_H

typedef uint8_t  u8;  /**< @brief shortcut for 1 unsigned byte type. */
typedef uint16_t u16; /**< @brief shortcut for 2 unsigned byte type. */
typedef uint32_t u32; /**< @brief shortcut for 4 unsigned byte type. */

typedef int8_t   s8;  /**< @brief shortcut for 1 signed byte type. */
typedef int16_t  s16; /**< @brief shortcut for 2 signed byte type. */
typedef int32_t  s32; /**< @brief shortcut for 4 signed byte type. */

#endif // TYPE_DEFINE_h
