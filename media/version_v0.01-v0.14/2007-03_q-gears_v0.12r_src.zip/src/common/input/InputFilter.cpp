// $Id: InputFilter.cpp 147 2007-02-24 06:13:17Z super_gb $

#include <vector>

#include "InputFilter.h"
#include "InputUtils.h"
#include "handlers/InputHandlerSdl.h"
#include "../utilites/Logger.h"



InputFilter* INPUTFILTER = NULL;



InputFilter::InputFilter(void)
{
    m_InputHandler = new InputHandlerSDL();
    Reset();
}



InputFilter::~InputFilter(void)
{
    delete m_InputHandler;
}



void
InputFilter::Reset(void)
{
    for (int button = 0; button < MAX_BUTTONS; ++button)
    {
        ButtonPressed((enum Button)button, false);
    }
}



void
InputFilter::ButtonPressed(const Button& button, const bool down)
{
    if (m_ButtonState[button] != down)
    {
        m_ButtonState[button] = down;
        m_Queue.push_back(InputEvent(button, (m_ButtonState[button] == true) ? IET_FIRST_PRESS : IET_RELEASE));

        m_HandledButton.push_back(button);
    }
}



void
InputFilter::Update(void)
{
    m_InputHandler->Update();

    for (u32 button = 0; button < MAX_BUTTONS; ++button)
    {
        if (m_ButtonState[button] == true)
        {
            std::vector<Button>::iterator p = find(m_HandledButton.begin(), m_HandledButton.end(), button);

            if (p == m_HandledButton.end())
            {
                m_Queue.push_back(InputEvent((enum Button)button, IET_REPEAT));
            }
        }
    }

    m_HandledButton.clear();
}



bool
InputFilter::IsButtonPressed(const Button& button) const
{
    if (button == KEY_INVALID)
    {
        LOGGER->Log(LOGGER_ERROR,
			"InputFilter::IsButtonPressed: Invalid key was given.");
        return false;
    }

    return m_ButtonState[button];
}



void
InputFilter::GetInputEvents(InputEventArray& input_events)
{
    input_events = m_Queue;

    m_Queue.clear();
}
