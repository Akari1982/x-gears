// $Id: FileDriver.cpp 93 2006-11-12 13:49:02Z einherjar $

#include "FileDriver.h"



FileDriver::FileDriver()
{
}



FileDriver::~FileDriver()
{
}
