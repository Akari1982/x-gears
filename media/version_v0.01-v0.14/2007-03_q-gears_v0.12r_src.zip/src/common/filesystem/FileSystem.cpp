// $Id: FileSystem.cpp 93 2006-11-12 13:49:02Z einherjar $

#include "FileSystem.h"



FileSystem::FileSystem()
{
}



FileSystem::~FileSystem()
{
}
