// $Id: Model.cpp 135 2007-02-06 05:21:01Z halkun $

#include "../../common/display/Display.h"
#include "../../common/display/surface/Surface.h"
#include "../../common/display/surface/SurfaceSaveBmp.h"

#include "Model.h"
#include "ModelUtilites.h"
#include "../filesystem/File.h"
#include "../filetypes/PacketFile.h"
#include "../filetypes/SubPacketFile.h"
#include "../filetypes/model/HrcFile.h"
#include "../filetypes/model/MeshFile.h"
#include "../filetypes/model/TextureFile.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

Model::Model(const RString& file)
{
    File* temp;

    PacketFile* pack = new PacketFile(file);

    temp = pack->ExtractFile(0);
    SubPacketFile* tex_pack = new SubPacketFile(temp);
    delete temp;

    Surface* clut = CreateSurface(256, 512);
    Surface* vram = CreateSurface(512, 512);

    unsigned long number_of_tex = tex_pack->GetNumberOfFiles();
    for (unsigned long i = 0; i < number_of_tex; ++i)
    {
        temp = tex_pack->ExtractFile(i);
        TextureFile* tex = new TextureFile(temp);
        delete temp;

        tex->GetSurfaces(clut, vram);
        delete tex;
    }

    delete tex_pack;



    temp = pack->ExtractFile(1);
    MeshFile* mesh = new MeshFile(temp);
    delete temp;

    mesh->GetGeometry(mBlockMeshes, mTexForGen);
    delete mesh;



    temp = pack->ExtractFile(2);
    HrcFile* hrc = new HrcFile(temp);
    delete temp;

    hrc->GetHierarchy(mHierarchy);
    delete hrc;



    delete pack;



    // load needed textures
    u32 i;
    mTex.clear();

SurfaceUtils::SaveBMP("clut.bmp", clut);

//    Surface *tex = ModelUtilites::Gen8bppTex(clut, vram, 496);
//    SurfaceUtils::SaveBMP("texture.bmp", tex);
//    delete tex;

    for (i = 0; i < mTexForGen.size(); ++i)
    {
        Surface* tex = ModelUtilites::Gen256x256Tex(clut, vram, mTexForGen[i]);
//        char file[7];
//        sprintf(file, "%02d.bmp", i);
//        SurfaceUtils::SaveBMP(std::string(file), tex);
        mTex.push_back(DISPLAY->CreateTexture(tex));
        delete tex;
    }
/*
    for (i = 0; i < mBlockMeshes.size(); ++i)
    {
        for (int j = 0; j < mBlockMeshes[i].GeometryVector.size(); ++j)
        {
            if (mBlockMeshes[i].GeometryVector[j].TexEnabled)
            {
                mBlockMeshes[i].GeometryVector[j].TexIndex = mTex[mBlockMeshes[i].GeometryVector[j].TexIndex];
            }
        }
    }
*/
    delete clut;
    delete vram;
}



Model::~Model(void)
{
    for (u32 i = 0; i < mTex.size(); ++i)
    {
        DISPLAY->DeleteTexture(mTex[i]);
    }
}



//============================= OPERATIONS ===================================

void
Model::Draw(void)
{
    DISPLAY->TexturePushMatrix();
    DISPLAY->TextureScale(1.0f / 256.0f, 1.0f / 256.0f, 1.0f / 256.0f);

    for (u32 i = 0; i < mHierarchy.size(); ++i)
    {
        if (mHierarchy[i].first != 0xFFFF)
        {
//            DISPLAY->DrawTotalGeometry(mBlockMeshes[mHierarchy[i].first]);
        }
    }

    DISPLAY->TexturePopMatrix();
}
