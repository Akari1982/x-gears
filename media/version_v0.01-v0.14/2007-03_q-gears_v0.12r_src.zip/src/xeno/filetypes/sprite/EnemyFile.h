// $Id$

#ifndef ENEMY_FILE_h
#define ENEMY_FILE_h

#include "../../common/display/surface/Surface.h"
#include "../../common/utilites/StdString.h"

#include "../image/Vram.h"
#include "../filesystem/File.h"



class EnemyFile : public File
{
public:
    explicit  EnemyFile(const RString& file);
    explicit  EnemyFile(File* pFile);
              EnemyFile(File* pFile, const u32& offset, const u32& length);
              EnemyFile(u8* pBuffer, const u32& offset, const u32& length);
    virtual  ~EnemyFile(void);

private:
    Vram mVram;
};



#endif
