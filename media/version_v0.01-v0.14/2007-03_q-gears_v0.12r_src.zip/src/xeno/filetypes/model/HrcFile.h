// $Id: HrcFile.h 93 2006-11-12 13:49:02Z einherjar $

/**
 * @brief Class for common model hierarchy.
 */

#ifndef HRC_FILE_h
#define HRC_FILE_h

#include <vector>

#include "../../../common/utilites/StdString.h"

#include "../../filesystem/File.h"



typedef std::pair<u16, u16> HrcCell;
typedef std::vector<HrcCell> HrcArray;



class HrcFile : public File
{
public:
// LIFECYCLE

    /**
     * @brief A constructor.
     *
     * Read file from given path into memory.
     * @note after creation in buffer stored unarchived file.
     * @param file - path to file that we want to open.
     */
    explicit HrcFile(const RString& file);

    /**
     * @brief A constructor.
     *
     * Create completle copy of given file.
     * @note after creation in buffer stored unarchived file.
     * @param pFile - object that we want to copy.
     */
    explicit HrcFile(File* pFile);

    /**
     * @brief A constructor.
     *
     * Create partitial copy of given file.
     * @note after creation in buffer stored unarchived file.
     * @param pFile  - object that we want to copy.
     * @param offset - offset from where we want to copy data.
     * @param length - size of data that we want ot copy.
     */
    HrcFile(File* pFile, const u32& offset, const u32& length);

    /**
     * @brief A constructor.
     *
     * Create partitial copy of given buffer.
     * @note after creation in buffer stored unarchived file.
     * @param pBuffer - buffer from which we want to create new file.
     * @param offset  - offset from where we want to copy data.
     * @param length  - size of data that we want ot copy.
     */
    HrcFile(u8* pBuffer, const u32& offset, const u32& length);

    /**
     * @brief A destructor.
     */
    virtual ~HrcFile(void);

// OPERATIONS

    /**
     * @brief Gets hierarchy.
     *
     * Clear given array of hierarchy and fill it with data.
     * @param hrc - array of hierarchy to fill.
     */
    void GetHierarchy(HrcArray& hrc);
};



#endif // HRC_FILE_h
