// $Id: TypeDefine.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef TYPE_DEFINE_h
#define TYPE_DEFINE_h



typedef unsigned char      u8;  /**< @brief shortcut for 1 unsigned byte type. */
typedef unsigned short int u16; /**< @brief shortcut for 2 unsigned byte type. */
typedef unsigned long  int u32; /**< @brief shortcut for 4 unsigned byte type. */

typedef signed   char      s8;  /**< @brief shortcut for 1 signed byte type. */
typedef signed   short int s16; /**< @brief shortcut for 2 signed byte type. */
typedef signed   long  int s32; /**< @brief shortcut for 4 signed byte type. */



#endif // TYPE_DEFINE_h
