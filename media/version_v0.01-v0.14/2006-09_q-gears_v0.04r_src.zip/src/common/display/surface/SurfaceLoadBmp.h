// $Id: SurfaceLoadBmp.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef SURFACELOADBMP_H
#define SURFACELOADBMP_H



#include "Surfaceload.h"

#include <string>



namespace SurfaceUtils
{
    OpenResult
    LoadBMP(const std::string &file, Surface* &img);
};



#endif
