// $Id: Surface.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef SURFACE_H
#define SURFACE_H



#include <string>



struct Surface
{
    Surface();
    Surface(const Surface &copy);
    Surface& operator =(const Surface &copy);
    ~Surface();


    unsigned char *pixels;
    int            width;
    int            height;
};



Surface* CreateSurface(const int width, const int height);
Surface* CreateSubSurface(const int x, const int y, const int width, const int height, Surface* surface);
Surface* CreateSurfaceFrom(const int width, const int height, unsigned char* pixels);

void     SetSurfaceSize(Surface* &surface, const int &width, const int &height);



#endif
