// $Id: SurfaceLoad.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef SURFACELOAD_H
#define SURFACELOAD_H



#include "Surface.h"

#include <string>



namespace SurfaceUtils
{
    enum OpenResult
    {
        OPEN_OK,
        OPEN_UNKNOWN_FILE_FORMAT = 1,
        OPEN_FATAL_ERROR = 2,
    };

    Surface *LoadFile(const std::string &file);
}



#endif
