// $Id: Display.h 76 2006-08-25 18:41:20Z crazy_otaku $

/**
 * @brief Abstract base class for 3d render
 */

#ifndef DISPLAY_h
#define DISPLAY_h

#include "3dTypes.h"
#include "MatrixStack.h"
#include "math/Vector.h"
#include "math/VectorMath.h"
#include "math/Matrix.h"
#include "math/MatrixMath.h"
#include "surface/Surface.h"
#include "../TypeDefine.h"
#include "../utilites/NoCopy.h"

#include <vector>



class Display : public NoCopy<Display>
{
public:
// LIFECYCLE

    /**
     * @brief Default constructor.
     */
    Display(void);

    /**
     * @brief Default destructor.
     */
    virtual ~Display(void);

// OPERATIONS

// DRAW DIFFERENT TYPE OF DATA

    /**
     * @brief Draw points.
     *
     * Draw number of vertex as points.
     * @param v - vector of vertexes.
     */
    void DrawPoints(const std::vector<Vertex>& v);

    /**
     * @brief Draw lines.
     *
     * Draw number of vertex as lines.
     * @param v - vector of vertexes.
     */
    void DrawLines(const std::vector<Vertex>& v);

    /**
     * @brief Draw triangles.
     *
     * Draw number of vertex as triangles.
     * @param v - vector of vertexes.
     */
    void DrawTriangles(const std::vector<Vertex>& v);

    /**
     * @brief Draw quads.
     *
     * Draw number of vertex as quads.
     * @param v - vector of vertexes.
     */
    void DrawQuads(const std::vector<Vertex>& v);

    /**
     * @brief Draw geometry.
     *
     * @param g - model geometry.
     */
    void DrawGeometry(const Geometry& g);

    /**
     * @brief Draw total geometry.
     *
     * @param g - model total geometry.
     */
    void DrawTotalGeometry(const TotalGeometry& g);

// WORLD MATRIX STACK FUNCTIONS

    /**
     * @brief Push world matrix.
     */
    void PushMatrix(void);

    /**
     * @brief Pop world matrix.
     */
    void PopMatrix(void);

    /**
     * @brief Translate world matrix.
     *
     * Multiply world matrix on translation matrix.
     * @param x - x coord to translate.
     * @param y - y coord to translate.
     * @param z - z coord to translate.
     */
    void Translate(float x, float y, float z);

    /**
     * @brief Translate world matrix.
     *
     * Multiply translation matrix on world matrix.
     * @param x - x coord to translate.
     * @param y - y coord to translate.
     * @param z - z coord to translate.
     */
    void TranslateWorld(float x, float y, float z);

    /**
     * @brief Scale world matrix.
     *
     * @param x - x coord to translate.
     * @param y - y coord to translate.
     * @param z - z coord to translate.
     */
    void Scale(float x, float y, float z);

    /**
     * @brief Rotate world matrix around X axis.
     *
     * @param deg - angle to rotate (in degree).
     */
    void RotateX(float deg);

    /**
     * @brief Rotate world matrix around Y axis.
     *
     * @param deg - angle to rotate (in degree).
     */
    void RotateY(float deg);

    /**
     * @brief Rotate world matrix around Z axis.
     *
     * @param deg - angle to rotate (in degree).
     */
    void RotateZ(float deg);

    /**
     * @brief Multiply given matrix on world matrix.
     *
     * @param m - matrix.
     */
    void PostMultMatrix(const Matrix& m);

    /**
     * @brief Multiply world matrix on given matrix.
     *
     * @param m - matrix.
     */
    void PreMultMatrix(const Matrix& m);

    /**
     * @brief Load identity matrix instead of current.
     */
    void LoadIdentity(void);

// TEXTURE MATRIX STACK FUNCTIONS

    /**
     * @brief Push texture matrix.
     */
    void TexturePushMatrix(void);

    /**
     * @brief Pop texture matrix.
     */
    void TexturePopMatrix(void);

    /**
     * @brief Load identity matrix instead of current.
     */
    void TextureLoadIdentity(void);

    /**
     * @brief Translate texture matrix.
     *
     * @param x - x coord to translate.
     * @param y - y coord to translate.
     */
    void TextureTranslate(float x, float y);

    /**
     * @brief Scale texture matrix.
     *
     * @param x - x coord to translate.
     * @param y - y coord to translate.
     * @param z - z coord to translate.
     */
    void TextureScale(float x, float y, float z);

// PROJECTION AND VIEW MATRIX STACK FUNCTIONS

    /**
     * @brief Push camera matrix.
     */
    void CameraPushMatrix(void);

    /**
     * @brief Pop camera matrix.
     */
    void CameraPopMatrix(void);

    /**
     * @brief Load identity matrix instead of current.
     */
    void CameraLoadIdentity(void);

    /**
     * @brief Loads given matrix instead of current.
     *
     * @param m - matrix.
     */
    void LoadCameraMatrix(const Matrix& m);

    /**
     * @brief Creates and loads "LookAt" matrix from given parameters.
     *
     * @param angley - angle of view.
     * @param eye    - position of camera.
     * @param at     - where we look.
     * @param up     - up direction.
     */
    void LoadLookAt(float angley, const Vector3 &eye, const Vector3 &at, const Vector3 &up);

// IMPLEMENTATION NEEDS METHODS

    /**
     * @brief Begin frame.
     *
     * Implementation of this method prepare frame buffer.
     */
    virtual void BeginFrame(void) = 0;

    /**
     * @brief Begin frame.
     *
     * Implementation of this method flush frame buffer.
     */
    virtual void EndFrame(void) = 0;

    /**
     * @brief Creates texture from given surface.
     *
     * @note you must call DeleteTexture to avoid memory leak.
     * @note you must delete pImage to avoid memory leak.
     * @param pImage - pointer to surface.
     * @return texture index.
     */
    virtual u32 CreateTexture(Surface* pImage) = 0;

    virtual void          UpdateTexture(unsigned int tex_handle, Surface *image, int xoffset, int yoffset, int width, int height) = 0;
    virtual void          DeleteTexture(unsigned int tex_handle) = 0;
    virtual void          SetTexture(unsigned int tex_handle) = 0;
    virtual void          UnsetTexture() = 0;

    virtual void          SetAlphaTest(bool b) = 0;
    virtual void          SetZTestMode(ZTestMode mode) = 0;
    virtual void          SetBlendMode(BlendMode mode) = 0;
    virtual void          SetCullMode(CullMode mode) = 0;
    virtual void          SetPolygonMode(PolygonMode pm) = 0;
    virtual void          SetLineWidth(float width) = 0;
    virtual void          SetPointSize(float size) = 0;

protected:
    virtual void          DrawPointsInternal(const std::vector<Vertex> &v) = 0;
    virtual void          DrawLinesInternal(const std::vector<Vertex> &v) = 0;
    virtual void          DrawTrianglesInternal(const std::vector<Vertex> &v) = 0;
    virtual void          DrawQuadsInternal(const std::vector<Vertex> &v) = 0;

protected:
    Matrix                GetPerspectiveMatrix(float angley, float aspect, float zNear, float zFar);
    // Different for D3D and OpenGL.
    Matrix                GetOrthoMatrix(float l, float r, float b, float t, float zn, float zf);
    Matrix                GetFrustumMatrix(float l, float r, float b, float t, float zn, float zf);

    // Called by the derivitives
    const Matrix *        GetProjectionTop();
    const Matrix *        GetViewTop();
    const Matrix *        GetWorldTop();
    const Matrix *        GetTextureTop();

protected:
    MatrixStack ProjectionStack; /**< @brief Projection matrix stack. */
    MatrixStack ViewStack;       /**< @brief View matrix stack.       */
    MatrixStack WorldStack;      /**< @brief World matrix stack.      */
    MatrixStack TextureStack;    /**< @brief Texture matrix stack.    */
};



extern Display *DISPLAY; /**< @brief global Display instance. Visible from anywhere as the header are included. */



#endif // DISPLAY_h
