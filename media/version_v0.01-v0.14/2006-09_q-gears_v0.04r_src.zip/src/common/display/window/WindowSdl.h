// $Id: WindowSdl.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef WINDOWSDL_H
#define WINDOWSDL_H
// The WindowSDL Class : Implementation of window



#include "Window.h"



class WindowSDL : public Window
{
public:
    ~WindowSDL();

    static Window* MakeWindow();

    void SwapBuffers();

private:
    WindowSDL();
};



#endif // WINDOWSDL_H
