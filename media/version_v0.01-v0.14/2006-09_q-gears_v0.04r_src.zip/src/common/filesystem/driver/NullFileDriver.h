// $Id: NullFileDriver.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef NULLFILEDRIVER_H
#define NULLFILEDRIVER_H


#include "FileDriver.h"
#include "../../utilites/StdString.h"



class NullFileDriver : public FileDriver
{
public:
             NullFileDriver();
    virtual ~NullFileDriver();

    virtual unsigned int GetFileSize(const RString &path);
    virtual bool         ReadFile(const RString &path, const void* buffer, const unsigned int start, const unsigned int length);
};



#endif // NULLFILEDRIVER_H
