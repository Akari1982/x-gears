// $Id: FileSystem.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef FILESYSTEM_H
#define FILESYSTEM_H



#include "../utilites/NoCopy.h"
#include "../utilites/StdString.h"

#include <vector>



class FileSystem : public NoCopy<FileSystem>
{
public:
                         FileSystem();
    virtual             ~FileSystem();

    virtual unsigned int GetFileSize(const RString &path) = 0;
    virtual bool         ReadFile(const RString &path, const void* buffer, const unsigned int start, const unsigned int length) = 0;
};



#endif // FILESYSTEM_H
