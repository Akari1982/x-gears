// $Id: Math.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef MATH_H
#define MATH_H

#include "../display/3dTypes.h"

#include <math.h>



int
find_triangle_crossing(Vector3& crossPoint, float& crossLength,
                       const Vector3& p11, const Vector3& p12, // our line
                       const Vector3& A, const Vector3& B, const Vector3& C,
                       const Vector3& ignore1, const Vector3& ignore2);



bool
line_crossing(Vector3& crossPoint,
              const Vector3& p11, const Vector3& p12,  // 1st line coords (our vector)
              const Vector3& p21, const Vector3& p22); // 2nd line coords (triangle side)



Vector3
find_point_in_triangle(const Vector3& moveVector, const Vector3& curPoint,
                       const Vector3& A, const Vector3& B, const Vector3& C);



float
point_elevation(const float &point_x, const float &point_y,
                const float &x1, const float &y1, const float &z1,
                const float &x2, const float &y2, const float &z2,
                const float &x3, const float &y3, const float &z3);



Vector3
get_projection_on_line(const Vector3& moveVector,
                       const Vector3& sp1, const Vector3& sp2);



#endif // MATH_H
