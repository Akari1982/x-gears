// $Id: InputHandler.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "InputHandler.h"
#include "../InputFilter.h"



void
InputHandler::ButtonPressed(Button b, bool Down)
{
    INPUTFILTER->ButtonPressed(b, Down);
}
