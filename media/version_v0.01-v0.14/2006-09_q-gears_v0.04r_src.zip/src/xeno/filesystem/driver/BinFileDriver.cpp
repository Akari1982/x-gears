// $Id: BinFileDriver.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "BinFileDriver.h"
#include "../../../common/filesystem/RealFileSystem.h"
#include "../../../common/utilites/Config.h"
#include "../../../common/utilites/Logger.h"



BinFileDriver::BinFileDriver()
{
    MountFileSystem();
}



BinFileDriver::~BinFileDriver()
{
    ClearFileDB();
}



unsigned int
BinFileDriver::GetFileSize(const RString &path)
{
    std::string sPath = mRoot + path;
    // erase last "/" if exist
    if (sPath.size() > 0 && sPath[sPath.size() - 1] == '/')
    {
        sPath.erase(sPath.size() - 1);
    }

    for (std::map<unsigned int, FileDesc *>::iterator z = mFileDB.begin(); z != mFileDB.end(); z++)
    {
        if ((*z).second->name == ".")
        {
            continue;
        }
        if ((*z).second->root + "/" + (*z).second->name == sPath)
        {
            return (*z).second->size;
        }
    }

    return 0;
}

bool
BinFileDriver::ReadFile(const RString &path, const void* buffer, const unsigned int start, const unsigned int length)
{
    std::string sPath = mRoot + path;
    // erase last "/" if exist
    if (sPath.size() > 0 && sPath[sPath.size() - 1] == '/')
    {
        sPath.erase(sPath.size() - 1);
    }

    for (std::map<unsigned int, FileDesc *>::iterator z = mFileDB.begin(); z != mFileDB.end(); z++)
    {
        if ((*z).second->name == ".")
        {
            continue;
        }
        if ((*z).second->isDir)
        {
            continue;
        }
        if ((*z).second->root + "/" + (*z).second->name == sPath)
        {
            // start position cannot be after end of file
            unsigned int correct_start  = (start <= (*z).second->size) ? start : (*z).second->size;
            // if we try to read something after file - deny it. Set length according to start and file size
            unsigned int correct_length = (correct_start + length <= (*z).second->size) ? length : (*z).second->size - correct_start;
            // create real file offset from the beginning of the cd image
            unsigned int correct_offset = (*z).second->sector * 2352 + (correct_start / 2048) * 2352 + correct_start % 2048;

            // we skip sector header for now (we need special function or flag to read str files with file sectors)
            unsigned int size_to_skip      = 24;
            unsigned int size_to_read      = 2048;

            unsigned int file_position     = correct_offset;
            // if we start not from the beginning of sector we need to correct how much bytes we need to read until the sector ends
            unsigned int real_size_to_read = size_to_read - correct_start % 2048;
            unsigned int buffer_position   = 0;

            while (correct_length > 0)
            {
                file_position += size_to_skip;

                unsigned int read = (correct_length > real_size_to_read) ? real_size_to_read : correct_length;

                REALFILESYSTEM->ReadFile(CONFIG->mGameCD, (unsigned char *)buffer + buffer_position, file_position, read);

                correct_length   -= read;

                file_position    += read;
                file_position    += 280;
                buffer_position  += read;

                // real size to read needs only for the first time when we may want to read not from beginning of sector
                real_size_to_read = size_to_read;
            }

            return true;
        }
    }

    return false;
}



void
BinFileDriver::MountFileSystem()
{
    mRoot = "./";

    int dir_count       = 0;
    // we use number of record in index file as file name
    // its not sure but it seems that it is the way how game gets the file
    int file_count      = 0;
    // parent of record in mFileDB
    unsigned int parent = 0;
    // index of record in mFileDB
    unsigned int index  = 0;

    // first clear mFileDB then reload it
    ClearFileDB();

    // load root
    FileDesc *root = new FileDesc();
    root->isDir    = true;
    root->name     = ".";
    root->root     = ".";
    root->sector   = 0;
    root->size     = 0;
    root->parentId = 0;
    mFileDB.insert(std::make_pair(index++, root));



    // read index file for game file system

    // size of index file including sector headers
    unsigned int size_of_index = 37632;
    // size offset of index file including sector headers
    unsigned int start_of_index = 56448;
    unsigned char *buffer = (unsigned char *)malloc(sizeof(unsigned char) * size_of_index);

    REALFILESYSTEM->ReadFile(CONFIG->mGameCD, buffer, start_of_index, size_of_index);



    // load index file with game file system

    // offset from the start index data (including sector headers)
    unsigned int start         = 0;

    unsigned long file_size    = 0;
    unsigned long start_sector = 0;
    unsigned char temp[7];

    // index ends with 0x00FFFFFF
    while (file_size != 0x00ffffff && start < size_of_index)
    {
        // copy data to temp
        for (int i = 0; i < 7; i++)
        {
            if (start % 2352 == 0)
            {
                start += 24;
            }
            // skip end of sector and start of new sector
            if ((start + 280) % 2352 == 0)
            {
                start += 304;
            }

            temp[i] = buffer[start];
            start++;
        }



        // reverse bytes order (low endian)
        start_sector = temp[0] | (temp[1] << 8) | (temp[2] << 16);
        file_size    = temp[3] | (temp[4] << 8) | (temp[5] << 16) | (temp[6] << 24);

        // directory
        if (file_size > 0xff000000)
        {
            char name[3];
            sprintf(name, "%02d", dir_count++);
            name[2] = '\0';

            FileDesc *dir = new FileDesc();
            dir->isDir    = true;
            dir->name     = RString(name);
            dir->root     = ".";
            dir->sector   = start_sector;
            dir->size     = file_size;
            dir->parentId = 0;
            mFileDB.insert(std::make_pair(index, dir));

            parent = index++;
        }
        // file
        else if (start_sector != 0 && file_size < 0xff000000 && file_size > 0)
        {
            char name[5];
            sprintf(name, "%04d", file_count);
            name[4] = '\0';

            FileDesc *file = new FileDesc();
            file->isDir    = false;
            file->name     = RString(name);
            file->root     = mFileDB[parent]->root + "/" + mFileDB[parent]->name;
            file->sector   = start_sector;
            file->size     = file_size;
            file->parentId = parent;

            mFileDB.insert(std::make_pair(index++, file));
        }

        file_count++;
    }

    free(buffer);
}



void
BinFileDriver::ClearFileDB()
{
    for (std::map<unsigned int, FileDesc *>::iterator z = mFileDB.begin(); z != mFileDB.end(); ++z)
    {
        delete (*z).second;
    }

    mFileDB.clear();
}