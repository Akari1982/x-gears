// $Id: ModelUtilites.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef MODEL_UTILITES_h
#define MODEL_UTILITES_h

#include <vector>

#include "../../common/TypeDefine.h"
#include "../../common/display/surface/Surface.h"



namespace ModelUtilites
{
    struct TexForGen
    {
        u8  texture_x;
        u8  texture_y;
        u16 palette_y;
        u8  palette_x;
        bool bpp;

        bool operator==(const TexForGen &i) const
        {
            return i.texture_x == texture_x &&
                   i.texture_y == texture_y &&
                   i.palette_y == palette_y &&
                   i.palette_x == palette_x &&
                   i.bpp       == bpp;
        }
    };

    typedef std::vector<TexForGen> VectorTexForGen;

    Surface *Gen256x256Tex(Surface* pClut, Surface* pVram, TexForGen texForGen);
    Surface *Gen8bppTex(Surface* pClut, Surface* pVram, const u16& clutY);
}



#endif // MODEL_UTILITES_h
