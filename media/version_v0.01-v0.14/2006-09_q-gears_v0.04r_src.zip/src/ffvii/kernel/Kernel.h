// $Id: Kernel.h 81 2006-09-28 15:35:24Z crazy_otaku $

#ifndef KERNEL_H
#define KERNEL_H



#include "Database.h"
#include "GameState.h"
#include "gui/BattleFont.h"
#include "gui/DialogWindow.h"
#include "gui/Font.h"
#include "gui/FFVIIString.h"
#include "gui/GuiAvatar.h"
#include "gui/GuiBar.h"
#include "gui/GuiBarexp.h"
#include "gui/GuiCounter.h"
#include "gui/GuiDigit.h"
#include "gui/GuiPointer.h"
#include "gui/GuiSlash.h"
#include "../../common/utilites/NoCopy.h"
#include "../../common/utilites/StdString.h"



class Kernel : public NoCopy<Kernel>
{
public:
                     Kernel();
    virtual         ~Kernel();

    void             Init();
    void             Update();

    const Database&  GetDatabase();
    const Gamestate& GetGamestate();

    void             DrawAvatar(const int &x, const int &y, const unsigned char &avatar_id);
    void             DrawBar(const int &x, const int &y, const unsigned int &cur, const unsigned int &max, const BarType &type);
    void             DrawBarExp(const int &x, const int &y, const unsigned int &cur, const unsigned int &max, const BarExpType &type);
    void             DrawBattleString(const RString &string, const int &x, const int &y, const BattleFontColor &color);
    void             DrawCounter(const int &x, const int &y, const RString &string);
    void             DrawDigit(const int &x, const int &y, const RString &string);
    void             DrawPointer(const int &x, const int &y, const PointerType &type);
    void             DrawSlash(const int &x, const int &y);
    void             DrawString(const FFVIIString& string, const int& x, const int& y, const FontColor& color, const int& size = 0);
    void             DrawWindow(const int &x, const int &y, const int &width, const int &height, const bool& opacity);

    void             LoadSavemap(File* file);

private:
    void             InitDatabase();
    void             LoadKernelString(std::vector<FFVIIString> &string_vector, File* &file);
    void             InitGraphics();

    void             SetFrontScreen();
    void             UnsetFrontScreen();

private:
    Gamestate     mGamestate;
    Database      mDatabase;

    GuiAvatar*    mGuiAvatar;
    GuiBar*       mGuiBar;
    GuiBarExp*    mGuiBarExp;
    GuiCounter*   mGuiCounter;
    GuiDigit*     mGuiDigit;
    GuiPointer*   mGuiPointer;
    GuiSlash*     mGuiSlash;
    BattleFont*   mBattleFont;
    Font*         mFont;
    DialogWindow* mWindow;
};



// Visible from every part of programm
extern Kernel *KERNEL;



#endif // KERNEL_H
