// $Id: GameState.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include <memory.h>

#include "GameState.h"
#include "Savemap.h"
#include "../../common/utilites/Logger.h"



// initializing of static member
Savemap Gamestate::mSavemap;



Gamestate::Gamestate()
{
}



Gamestate::~Gamestate()
{
}



const Savemap&
Gamestate::GetSavemap() const
{
    return mSavemap;
}



void
Gamestate::DumpSavemap()
{
    LOGGER->Log("Checksum: %08x\n\n", mSavemap.Checksum);

    LOGGER->Log("Preview\n");

    LOGGER->Log("PreviewLeadCharacterLevel: %d", mSavemap.PreviewLeadCharacterLevel);
    LOGGER->Log("PreviewLeadCharacterPortrait: %02x", mSavemap.PreviewLeadCharacterPortrait);
    LOGGER->Log("PreviewSecondCharacterPortrait: %02x", mSavemap.PreviewSecondCharacterPortrait);
    LOGGER->Log("PreviewThirdCharacterPortrait: %02x", mSavemap.PreviewThirdCharacterPortrait);
    LOGGER->Log("PreviewLeadCharacterName[16] --- skip");
    LOGGER->Log("PreviewLeadCharacterCurrentHP: %d", mSavemap.PreviewLeadCharacterCurrentHP);
    LOGGER->Log("PreviewLeadCharacterMaxHP: %d", mSavemap.PreviewLeadCharacterMaxHP);
    LOGGER->Log("PreviewLeadCharacterCurrentMP: %d", mSavemap.PreviewLeadCharacterCurrentMP);
    LOGGER->Log("PreviewLeadCharacterMaxMP: %d", mSavemap.PreviewLeadCharacterMaxMP);
    LOGGER->Log("PreviewGilAmount: %d", mSavemap.PreviewGilAmount);
    LOGGER->Log("PreviewPlayedSeconds: %d", mSavemap.PreviewPlayedSeconds);
    LOGGER->Log("PreviewCurrentLocationName[32] --- skip\n\n");

    LOGGER->Log("Window RGB\n\n");

    LOGGER->Log("Character Record\n");
    for (int i = 0; i < 9; ++i)
    {
        switch (i)
        {
            case 0: LOGGER->Log("Cloud\n");  break;
            case 1: LOGGER->Log("Barret\n"); break;
            case 2: LOGGER->Log("Tifa\n"); break;
            case 3: LOGGER->Log("Aeris\n"); break;
            case 4: LOGGER->Log("RedXIII\n"); break;
            case 5: LOGGER->Log("Yuffie\n"); break;
            case 6: LOGGER->Log("CaitSith\n"); break;
            case 7: LOGGER->Log("Vinsent\n"); break;
            case 8: LOGGER->Log("Cid\n"); break;
        }

        LOGGER->Log("Id: %02x", mSavemap.Character[i].Id);
        LOGGER->Log("Level: %d", mSavemap.Character[i].Level);
        LOGGER->Log("Strength: %d", mSavemap.Character[i].Strength);
        LOGGER->Log("Vitality: %d", mSavemap.Character[i].Vitality);
        LOGGER->Log("Magic: %d", mSavemap.Character[i].Magic);
        LOGGER->Log("Spirit: %d", mSavemap.Character[i].Spirit);
        LOGGER->Log("Dexterity: %d", mSavemap.Character[i].Dexterity);
        LOGGER->Log("Luck: %d", mSavemap.Character[i].Luck);
        LOGGER->Log("StrengthBonus: %d", mSavemap.Character[i].StrengthBonus);
        LOGGER->Log("VitalityBonus: %d", mSavemap.Character[i].VitalityBonus);
        LOGGER->Log("MagicBonus: %d", mSavemap.Character[i].MagicBonus);
        LOGGER->Log("SpiritBonus: %d", mSavemap.Character[i].SpiritBonus);
        LOGGER->Log("DexterityBonus: %d", mSavemap.Character[i].DexterityBonus);
        LOGGER->Log("LuckBonus: %d", mSavemap.Character[i].LuckBonus);
        LOGGER->Log("CurrentLimitLevel: %d", mSavemap.Character[i].CurrentLimitLevel);
        LOGGER->Log("CurrentLimitBar: %d", mSavemap.Character[i].CurrentLimitBar);
        LOGGER->Log("Name --- skip");
        LOGGER->Log("EquippedWeapon: %02x", mSavemap.Character[i].EquippedWeapon);
        LOGGER->Log("EquippedArmor: %02x", mSavemap.Character[i].EquippedArmor);
        LOGGER->Log("EquippedAccessory: %02x", mSavemap.Character[i].EquippedAccessory);
        LOGGER->Log("StatusFlags: %02x", mSavemap.Character[i].StatusFlags);
        LOGGER->Log("RowFlags: %02x", mSavemap.Character[i].RowFlags);
        LOGGER->Log("LevelProgressBar: %02x", mSavemap.Character[i].LevelProgressBar);
        LOGGER->Log("LearnedLimitSkills: %04x", mSavemap.Character[i].LearnedLimitSkills);
        LOGGER->Log("NumberOfKills: %d", mSavemap.Character[i].NumberOfKills);
        LOGGER->Log("TimesUsedLimit11: %d", mSavemap.Character[i].TimesUsedLimit11);
        LOGGER->Log("TimesUsedLimit21: %d", mSavemap.Character[i].TimesUsedLimit21);
        LOGGER->Log("TimesUsedLimit31: %d", mSavemap.Character[i].TimesUsedLimit31);
        LOGGER->Log("CurrentHP: %d", mSavemap.Character[i].CurrentHP);
        LOGGER->Log("BaseHP: %d", mSavemap.Character[i].BaseHP);
        LOGGER->Log("CurrentMP: %d", mSavemap.Character[i].CurrentMP);
        LOGGER->Log("BaseMP: %d", mSavemap.Character[i].BaseMP);
        LOGGER->Log("Unknown1[4]: %02x %02x %02x %02x", mSavemap.Character[i].Unknown1[0], mSavemap.Character[i].Unknown1[1], mSavemap.Character[i].Unknown1[2], mSavemap.Character[i].Unknown1[3]);
        LOGGER->Log("MaximumHP: %d", mSavemap.Character[i].MaximumHP);
        LOGGER->Log("MaximumMP: %d", mSavemap.Character[i].MaximumMP);
        LOGGER->Log("CurrentEXP: %d", mSavemap.Character[i].CurrentEXP);
        LOGGER->Log("WeaponMateriaSlot: %08x %08x %08x %08x %08x %08x %08x %08x", mSavemap.Character[i].WeaponMateriaSlot1, mSavemap.Character[i].WeaponMateriaSlot2, mSavemap.Character[i].WeaponMateriaSlot3, mSavemap.Character[i].WeaponMateriaSlot4, mSavemap.Character[i].WeaponMateriaSlot5, mSavemap.Character[i].WeaponMateriaSlot6, mSavemap.Character[i].WeaponMateriaSlot7, mSavemap.Character[i].WeaponMateriaSlot8);
        LOGGER->Log("ArmorMateriaSlot: %08x %08x %08x %08x %08x %08x %08x %08x", mSavemap.Character[i].ArmorMateriaSlot1, mSavemap.Character[i].ArmorMateriaSlot2, mSavemap.Character[i].ArmorMateriaSlot3, mSavemap.Character[i].ArmorMateriaSlot4, mSavemap.Character[i].ArmorMateriaSlot5, mSavemap.Character[i].ArmorMateriaSlot6, mSavemap.Character[i].ArmorMateriaSlot7, mSavemap.Character[i].ArmorMateriaSlot8);
        LOGGER->Log("NextLevelEXP: %d\n\n", mSavemap.Character[i].NextLevelEXP);
    }

    LOGGER->Log("Slot1Char: %02x", mSavemap.Slot1Char);
    LOGGER->Log("Slot2Char: %02x", mSavemap.Slot2Char);
    LOGGER->Log("Slot3Char: %02x", mSavemap.Slot3Char);

    LOGGER->Log("GilAmount: %d", mSavemap.GilAmount);
    LOGGER->Log("PlayedSeconds: %d", mSavemap.PlayedSeconds);
    LOGGER->Log("Unknown2[16]: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x", mSavemap.Unknown2[0], mSavemap.Unknown2[1], mSavemap.Unknown2[2], mSavemap.Unknown2[3], mSavemap.Unknown2[4], mSavemap.Unknown2[5], mSavemap.Unknown2[6], mSavemap.Unknown2[7], mSavemap.Unknown2[8], mSavemap.Unknown2[9], mSavemap.Unknown2[10], mSavemap.Unknown2[11], mSavemap.Unknown2[12], mSavemap.Unknown2[13], mSavemap.Unknown2[14], mSavemap.Unknown2[15]);
    LOGGER->Log("CurrentMap: %d", mSavemap.CurrentMap);
    LOGGER->Log("CurrentLocation: %d", mSavemap.CurrentLocation);
    LOGGER->Log("Unknown3[2]: %02x %02x", mSavemap.Unknown3[0], mSavemap.Unknown3[1]);
    LOGGER->Log("MapLocationX: %d", mSavemap.MapLocationX);
    LOGGER->Log("MapLocationY: %d", mSavemap.MapLocationY);
    LOGGER->Log("MapLocationZ: %d", mSavemap.MapLocationZ);
    LOGGER->Log("Unknown4[4]: %02x %02x %02x %02x", mSavemap.Unknown4[0], mSavemap.Unknown4[1], mSavemap.Unknown4[2], mSavemap.Unknown4[3]);

    LOGGER->Log("\n\nConfig\n");

    LOGGER->Log("BattleSpeed: %02x", mSavemap.BattleSpeed);
    LOGGER->Log("BattleMessageSpeed: %02x", mSavemap.BattleMessageSpeed);
    LOGGER->Log("GeneralConfiguration: %04x", mSavemap.GeneralConfiguration);
    LOGGER->Log("UnknownFE[16]: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x", mSavemap.UnknownFE[0], mSavemap.UnknownFE[1], mSavemap.UnknownFE[2], mSavemap.UnknownFE[3], mSavemap.UnknownFE[4], mSavemap.UnknownFE[5], mSavemap.UnknownFE[6], mSavemap.UnknownFE[7], mSavemap.UnknownFE[8], mSavemap.UnknownFE[9], mSavemap.UnknownFE[10], mSavemap.UnknownFE[11], mSavemap.UnknownFE[12], mSavemap.UnknownFE[13], mSavemap.UnknownFE[14], mSavemap.UnknownFE[15]);
    LOGGER->Log("MessageSpeed: %02x", mSavemap.MessageSpeed);
    LOGGER->Log("UnknownFF[7]: %02x %02x %02x %02x %02x %02x %02x", mSavemap.UnknownFF[0], mSavemap.UnknownFF[1], mSavemap.UnknownFF[2], mSavemap.UnknownFF[3], mSavemap.UnknownFF[4], mSavemap.UnknownFF[5], mSavemap.UnknownFF[6]);
}



void
Gamestate::Update()
{
    // move seconds forward
    static unsigned char timer = 0;
    ++timer;
    if (timer == 100)
    {
        ++mSavemap.PlayedSeconds;
        timer = 0;
    }
}
