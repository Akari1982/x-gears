// $Id: GameState.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef GAMESTATE_H
#define GAMESTATE_H
// The Gamestate Class : Contain all info about current game state



#include "Savemap.h"
#include "../../common/utilites/NoCopy.h"



// forward declaration
class Kernel;
class MemoryBank;



class Gamestate : public NoCopy<Gamestate>
{
    friend class Kernel;
    friend class MemoryBank;

public:
             Gamestate();
    virtual ~Gamestate();

    const Savemap& GetSavemap() const;

    void DumpSavemap();

    void Update();

private:
    static Savemap mSavemap;
};



#endif // GAMESTATE_H
