// $Id: DbAccessory.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef DBACCESSORY_H
#define DBACCESSORY_H



typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;



struct DBAccessory
{
    u8 Unknown[16];
};




#endif
