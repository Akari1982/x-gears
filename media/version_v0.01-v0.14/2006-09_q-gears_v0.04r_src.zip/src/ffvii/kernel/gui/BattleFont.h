// $Id: BattleFont.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef BATTLEFONT_H
#define BATTLEFONT_H



#include <vector>
#include <map>
#include <utility>

#include "FFVIIString.h"
#include "../../../common/display/3dTypes.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/NoCopy.h"



enum BattleFontColor {BF_GRAY, BF_BLUE, BF_WHITE};



class BattleFont : public NoCopy<BattleFont>
{
public:
             BattleFont(Surface* image_gray,
                        Surface* image_blue,
                        Surface* image_white);

    virtual ~BattleFont();

    void     DrawString(const RString &string, const int &x, const int &y, const BattleFontColor &color);

protected:
    int mLetterWidth;
    int mLetterHeight;
    int mLetterSpacing;
    int mRowSpacing;

    std::map<int, int>  mFontGrayTexId;
    std::map<int, int>  mFontBlueTexId;
    std::map<int, int>  mFontWhiteTexId;
    std::vector<Vertex> mFontPoly;

    int mTab;
    int mNewLine;
};



#endif
