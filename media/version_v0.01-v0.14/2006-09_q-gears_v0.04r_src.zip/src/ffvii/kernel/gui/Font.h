// $Id: Font.h 81 2006-09-28 15:35:24Z crazy_otaku $

#ifndef FONT_H
#define FONT_H



#include "FFVIIString.h"
#include "../../../common/display/3dTypes.h"
#include "../../../common/display/surface/Surface.h"
#include "../../filesystem/File.h"
#include "../../../common/utilites/NoCopy.h"

#include <vector>
#include <map>
#include <utility>



enum FontColor {F_GRAY, F_BLUE, F_WHITE};



class Font : public NoCopy<Font>
{
public:
             Font(Surface* image_gray,
                  Surface* image_blue,
                  Surface* image_white,
                  File* font_padding);

    virtual ~Font();

    void     DrawString(const FFVIIString& string, const int& x, const int& y, const FontColor& color, const int& size = 0);

protected:
    int mLetterWidth;
    int mLetterHeight;
    int mLetterSpacing;
    int mRowSpacing;

    struct FontStat
    {
        int TexId;
        int Padding;
        int Width;
    };

    std::vector<FontStat> mFontGrayTexId;
    std::vector<FontStat> mFontBlueTexId;
    std::vector<FontStat> mFontWhiteTexId;
    std::vector<Vertex>     mFontPoly;
};



#endif
