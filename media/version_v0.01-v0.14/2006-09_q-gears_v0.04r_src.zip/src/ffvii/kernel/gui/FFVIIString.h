// $Id: FFVIIString.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef FFVIISTRING_H
#define FFVIISTRING_H



#include "../../../common/utilites/StdString.h"

#include <vector>



typedef std::vector<unsigned char> FFVIIString;



// converter
FFVIIString RStringToFFVIIString(const RString &string);



#endif
