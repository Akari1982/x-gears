// $Id: GuiDigit.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef GUIDIGIT_H
#define GUIDIGIT_H



#include "../../../common/display/3dTypes.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/NoCopy.h"
#include "../../../common/utilites/StdString.h"

#include <map>
#include <vector>



class GuiDigit : public NoCopy<GuiDigit>
{
public:
             GuiDigit(Surface* image);

    virtual ~GuiDigit();

    void     DrawDigit(const int &x, const int &y, const RString &string);

private:
    std::map<int, int>  mDigitTexId;
    std::vector<Vertex> mDigitPoly;
};



#endif
