// $Id: WindowManager.h 81 2006-09-28 15:35:24Z crazy_otaku $

/**
 * @brief Windows manager for field module (Message, Ask and so).
 */

#ifndef WINDOW_MANAGER_h
#define WINDOW_MANAGER_h

#include "script/Script.h"
#include "../kernel/gui/FFVIIString.h"
#include "../../common/TypeDefine.h"
#include "../../common/input/InputFilter.h"
#include "../../common/utilites/NoCopy.h"

#include <vector>




struct DialogWindowData
{
    bool              show;

    bool              inited;
    u8                init_state;

    u16               x;
    u16               y;
    u16               width;
    u16               height;
    u8                style;
    u8                cbc;

    struct SpecialData
    {
        u16     x;
        u16     y;
        u8      type;

        // for numerical display
        u32     digit;
        u8      digit_number;
    } special;

    struct MessageDialogData
    {
        u8      memory_bank;
        u8      offset;
        u8      dialog_id;
        u8      first;
        u8      last;
        Script* caller;
    } message;
};



class WindowManager : public NoCopy<WindowManager>
{
public:
// LIFECYCLE

    /**
     * @brief Default constructor.
     */
    WindowManager(void);

    /**
     * @brief Default destructor.
     */
    virtual ~WindowManager(void);

// OPERATIONS

    /**
     * @brief Init data.
     */
    void Init(void);

    /**
     * @brief Clear data.
     */
    void Clear(void);

    /**
     * @brief Draw data.
     */
    void Draw(void);

    /**
     * @brief Handles input.
     *
     * @param input - single input event.
     * @return true if we handled input, false otherwise
     */
    bool Input(const InputEvent& input);

    /**
     * @brief Handles update.
     *
     * @param deltaTime - time passed from last call.
     */
    void Update(const u32& deltaTime);

    /**
     * @brief Set position and size of window.
     *
     * @param id     - id of window to set.
     * @param x      - x coord.
     * @param y      - y coord.
     * @param width  - width of window.
     * @param height - height of window.
     */
    void SetWindow(const u8& id, const u16& x, const u16& y, const u16& width, const u16& height);

    /**
     * @brief Set position and size of window.
     *
     * @param id     - id of window to set.
     * @param style  - style of window (0 - usual, 1 - without border, 2 - transparent).
     * @param cbc    - can be clicked (0 - can be, 1 - can not).
     */
    void SetWindowStyle(const u8& id, const u8& style, const u8& cbc);

    /**
     * @brief Creates a numerical display inside the given window.
     *
     * @param id     - id of window to set.
     * @param x      - X-coordinate of the numerical display, relative to the top-left of the window.
     * @param cbc    - Y-coordinate of the numerical display, relative to the top-left of the window.
     * @param type   - Type of display.
     */
    void SetSpecialStyle(const u8& id, const u8& x, const u8& y, const u8& type);

    /**
     * @brief Set Number for numerical display inside the given window.
     *
     * @param id          - id of window to set.
     * @param digit       - A four-byte number to set the numerical display.
     * @param digitNumber - The number of digits to display, from 1 to 8.
     */
    void SetSpecialNumber(const u8& id, const u32& digit, const u8& digitNumber);

    /**
     * @brief Set inner timer value (affects all windows).
     *
     * @param hours   - set hours.
     * @param minutes - set minutes.
     * @param seconds - set seconds.
     */
    void SetTimer(const u8& hours, const u8& minutes, const u8& seconds);

    /**
     * @brief Set message to window.
     *
     * @param window - new message that we want to add.
     */
    void ShowMessage(const u8& id, const s8& dialogId, const u8& first, const u8& last, const u8& memoryBank, const u8& offset, Script* script);

    /**
     * @brief Remove top ask from stack.
     */
    void CloseWindow(const u8& id);

    /**
     * @brief Add new dialog.
     *
     * @param dialog - text in FFVIIString format.
     */
    void AddDialog(const FFVIIString& dialog);

private:
    DialogWindowData               mWindows[8];   /**< @brief array of windows                  */

    std::vector<FFVIIString>       mDialogs;      /**< @brief vector of dialogs                 */

    u8                             mPointerPos;   /**< @brief current pointer position          */

    u8                             mClockHours;
    u8                             mClockMinutes;
    u8                             mClockSeconds;
};



#endif // WINDOW_MANAGER_h
