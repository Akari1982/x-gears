// $Id: WindowManager.cpp 81 2006-09-28 15:35:24Z crazy_otaku $

#include "WindowManager.h"
#include "script/MemoryBank.h"
#include "../kernel/Kernel.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

WindowManager::WindowManager(void):
    mPointerPos(0),
    mClockHours(0),
    mClockMinutes(0),
    mClockSeconds(0)
{
    Init();
}



WindowManager::~WindowManager(void)
{
}



//============================= OPERATIONS ===================================

void
WindowManager::Init(void)
{
    for (u8 i = 0; i < 8; ++i)
    {
        mWindows[i].show       = false;

        mWindows[i].inited     = false;
        mWindows[i].init_state = 0;

        mWindows[i].x          = 0;
        mWindows[i].y          = 0;
        mWindows[i].width      = 0;
        mWindows[i].height     = 0;
        mWindows[i].style      = 0;
        mWindows[i].cbc        = 0;

        mWindows[i].special.x            = 0;
        mWindows[i].special.y            = 0;
        mWindows[i].special.type         = 0;
        mWindows[i].special.digit        = 0;
        mWindows[i].special.digit_number = 0;

        mWindows[i].message.memory_bank  = 0;
        mWindows[i].message.offset       = 0;
        mWindows[i].message.dialog_id    = 0;
        mWindows[i].message.first        = 0;
        mWindows[i].message.last         = 0;
        mWindows[i].message.caller       = NULL;
    }
}



void
WindowManager::Clear(void)
{
    // clear window info
    Init();
    // clear dialogs
    mDialogs.clear();
}



void
WindowManager::Draw(void)
{
    for (int i = 0; i < 8 ; ++i)
    {
        if (mWindows[i].show)
        {
            if (mWindows[i].style != 1)
            {
                KERNEL->DrawWindow(mWindows[i].x,
                                   mWindows[i].y,
                                   mWindows[i].width,
                                   mWindows[i].height,
                                  (mWindows[i].style == 2) ? true : false);
            }

            KERNEL->DrawString(mDialogs[mWindows[i].message.dialog_id],
                               mWindows[i].x + 8,
                               mWindows[i].y + 8,
                               F_WHITE,
                               mWindows[i].init_state);

            // if this is ask
            if (mWindows[i].message.first != 0 || mWindows[i].message.last != 0)
            {
                KERNEL->DrawPointer(mWindows[i].x + 6,
                                    mWindows[i].y + 8 + mPointerPos * 16,
                                    TO_RIGHT);
            }



            // if it is timer or Clock (00:00) or Numeric (000000)
            if (mWindows[i].special.type)
            {
                RString string;
                if (mWindows[i].special.type == 1)
                {
                    string.Format("%02d:%02d", mClockMinutes, mClockSeconds);
                }
                else if (mWindows[i].special.type == 2)
                {
                    // construct output string
                    string.Format("%08u", mWindows[i].special.digit);
                    string = string.Right(mWindows[i].special.digit_number);
                }

                // draw counter
                KERNEL->DrawCounter(mWindows[i].x + mWindows[i].special.x, mWindows[i].y + mWindows[i].special.y, string);
            }
        }
    }
}



bool
WindowManager::Input(const InputEvent &input)
{
    for (u8 i = 0; i < 8 ; ++i)
    {
        if (mWindows[i].show && mWindows[i].inited == true && mWindows[i].cbc == 0)
        {
            if (input.type == IET_RELEASE)
            {
                switch (input.button)
                {
                    case KEY_Cx:
                    {
                        mWindows[i].message.caller->mMemoryBank.Put(mWindows[i].message.memory_bank, mWindows[i].message.offset, mPointerPos);
                        CloseWindow(i);
                    }
                    break;

                    case KEY_UP:
                    {
                        if (mPointerPos > mWindows[i].message.first)
                        {
                            mPointerPos--;
                        }
                    }
                    break;

                    case KEY_DOWN:
                    {
                        if (mPointerPos < mWindows[i].message.last)
                        {
                            mPointerPos++;
                        }
                    }
                    break;
                }
            }
        }
    }

    return true;
}



void
WindowManager::Update(const u32& deltaTime)
{
    for (u8 i = 0; i < 8 ; ++i)
    {
        if (mWindows[i].show && mWindows[i].inited == false)
        {
            // add init state (in future this must be added according to message speed)
            ++(mWindows[i].init_state);

            printf("Window %d state: %d.\n", i, mWindows[i].init_state);

            // if we displayed whole message or no message has been set - set window to inited
            if (mWindows[i].init_state >= mDialogs[mWindows[i].message.dialog_id].size())
            {
                mWindows[i].inited = true;
            }
        }
    }
}



void
WindowManager::SetWindow(const u8& id, const u16& x, const u16& y, const u16& width, const u16& height)
{
    if (id < 8)
    {
        mWindows[id].x      = x;
        mWindows[id].y      = y;
        mWindows[id].width  = width;
        mWindows[id].height = height;
    }
}



void
WindowManager::SetWindowStyle(const u8& id, const u8& style, const u8& cbc)
{
    if (id < 8)
    {
        mWindows[id].style = style;
        mWindows[id].cbc   = cbc;
    }
}



void
WindowManager::SetSpecialStyle(const u8& id, const u8& x, const u8& y, const u8& type)
{
    if (id < 8)
    {
        mWindows[id].special.x    = x;
        mWindows[id].special.y    = y;
        mWindows[id].special.type = type;
    }
}



void
WindowManager::SetSpecialNumber(const u8& id, const u32& digit, const u8& digitNumber)
{
    if (id < 8)
    {
        mWindows[id].special.digit        = digit;
        mWindows[id].special.digit_number = digitNumber;
    }
}



void
WindowManager::SetTimer(const u8& hours, const u8& minutes, const u8& seconds)
{
    mClockHours   = hours;
    mClockMinutes = minutes;
    mClockSeconds = seconds;
}



void
WindowManager::ShowMessage(const u8& id, const s8& dialogId, const u8& first, const u8& last, const u8& memoryBank, const u8& offset, Script* script)
{
    // set pointer to 0 for new ask
    mPointerPos = 0;

    mWindows[id].show       = true;

    mWindows[id].inited     = false;
    mWindows[id].init_state = 0;

    mWindows[id].message.dialog_id   = dialogId;
    mWindows[id].message.first       = first;
    mWindows[id].message.last        = last;
    mWindows[id].message.memory_bank = memoryBank;
    mWindows[id].message.offset      = offset;
    mWindows[id].message.caller      = script;

    // if this window cant be clicked - release sync
    if (mWindows[id].cbc != 0)
    {
        script->SetWait(false);
    }
}



void
WindowManager::CloseWindow(const u8& id)
{
    mWindows[id].message.caller->SetWait(false);
    mWindows[id].show = false;
}



void
WindowManager::AddDialog(const FFVIIString& dialog)
{
    mDialogs.push_back(dialog);
}
