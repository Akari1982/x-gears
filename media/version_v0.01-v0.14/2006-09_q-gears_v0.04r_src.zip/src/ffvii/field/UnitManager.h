// $Id$

/**
 * @brief Unit manager for field module.
 */

#ifndef UNIT_MANAGER_h
#define UNIT_MANAGER_h

#include <vector>

#include "../../common/TypeDefine.h"
#include "../../common/input/InputFilter.h"
#include "../../common/utilites/NoCopy.h"

#include "Model.h"




struct AccessPool
{
    unsigned short access[3];
};



struct UnitData
{
    UnitData():
        position(0.0f, 0.0f, 0.0f),
        visible(false)
    {
    }

    Model        model;
    Vector3      position;
    bool         visible;
};



class UnitManager : public NoCopy<UnitManager>
{
public:
// LIFECYCLE

    /**
     * @brief Default constructor.
     */
    UnitManager(void);

    /**
     * @brief Default destructor.
     */
    virtual ~UnitManager(void);

// OPERATIONS

    /**
     * @brief Clear walkmesh data.
     */
    void ClearWalkmesh(void);

    /**
     * @brief Draw data.
     */
    void Draw(void);

    /**
     * @brief Handles input.
     *
     * @param input - single input event.
     * @return true if we handled input, false otherwise
     */
    bool Input(const InputEvent& input);

    /**
     * @brief Handles update.
     *
     * @param deltaTime - time passed from last call.
     */
    void Update(const u32& deltaTime);

    /**
     * @brief Add new point to walkmesh.
     *
     * @param v - single vertex.
     */
    void AddWalkmeshVertex(const Vertex& v);

    /**
     * @brief Add new triangle access.
     *
     * @param accessPool - triangle access.
     */
    void AddAccessPool(const AccessPool& accessPool);

    /**
     * @brief Add new access geometry vertex.
     *
     * @param v - single vertex.
     */
    void AddAccessVertex(const Vertex& v);

private:
//    Vector3 GetWalkMeshCoords(const unsigned int& triangleIndex);

//    Vector3 GetNextStep(const Vector3& moveVector, const Vector3& ignorePoint1 = Vector3(0.0f, 0.0f, 0.0f), const Vector3& ignorePoint2 = Vector3(0.0f, 0.0f, 0.0f));

private:
    // move managing
    bool                    mMoveForward;
    bool                    mMoveBack;
    bool                    mMoveLeft;
    bool                    mMoveRight;



    // walkmesh
    std::vector<AccessPool> mAccessPool;
    std::vector<Vertex>     mAccess;
    std::vector<Vertex>     mWalkMesh;



    // units
    UnitData                mUnits[32]; /**< @brief array of units */
};



#endif // UNIT_MANAGER_h
