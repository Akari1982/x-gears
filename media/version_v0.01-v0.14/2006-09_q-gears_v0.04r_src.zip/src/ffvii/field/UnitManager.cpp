// $Id$

#include "../../common/display/Display.h"
#include "../../common/utilites/Math.h"

#include "UnitManager.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

UnitManager::UnitManager(void):
    mMoveForward(false),
    mMoveBack(false),
    mMoveLeft(false),
    mMoveRight(false)
{
}



UnitManager::~UnitManager(void)
{
}



//============================= OPERATIONS ===================================

void
UnitManager::ClearWalkmesh(void)
{
    // clear data
    mWalkMesh.clear();
    mAccess.clear();
    mAccessPool.clear();
}



void
UnitManager::Draw(void)
{
    DISPLAY->SetLineWidth(1);
    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->DrawTriangles(mWalkMesh);
    DISPLAY->SetPolygonMode(POLYGON_FILL);

    DISPLAY->SetLineWidth(2);
    DISPLAY->DrawLines(mAccess);

    // draw character
    for (u8 i = 0; i < 32; ++i)
    {
        if (mUnits[i].visible == true)
        {
            DISPLAY->PushMatrix();
            DISPLAY->Translate(mUnits[i].position.x, mUnits[i].position.y, mUnits[i].position.z);
            mUnits[i].model.DrawModel();
            DISPLAY->PopMatrix();
        }
    }
}



bool
UnitManager::Input(const InputEvent &input)
{
    bool ret = false;

    // handle left input ourself
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_UP:    mMoveForward = true; ret = true; break;
            case KEY_DOWN:  mMoveBack    = true; ret = true; break;
            case KEY_LEFT:  mMoveRight   = true; ret = true; break;
            case KEY_RIGHT: mMoveLeft    = true; ret = true; break;
        }
    }

    if (input.type == IET_RELEASE)
    {
        switch (input.button)
        {
            case KEY_UP:    mMoveForward = false; ret = true; break;
            case KEY_DOWN:  mMoveBack    = false; ret = true; break;
            case KEY_LEFT:  mMoveRight   = false; ret = true; break;
            case KEY_RIGHT: mMoveLeft    = false; ret = true; break;
        }
    }

    return ret;
}



void
UnitManager::Update(const u32& deltaTime)
{
    static float step = 5.0f;
    Vector3 next_step(0.0f, 0.0f, 0.0f);

    if (mMoveForward)
    {
        next_step.z =  step;
    }

    if (mMoveBack)
    {
        next_step.z = -step;
    }

    if (mMoveLeft)
    {
        next_step.x =  step;
    }

    if (mMoveRight)
    {
        next_step.x = -step;
    }

//    mUnits.vector_pos = GetNextStep(next_step);
//    mUnits.char_model.SetCoords(mUnits.vector_pos);
}



void
UnitManager::AddWalkmeshVertex(const Vertex& v)
{
    mWalkMesh.push_back(v);
}



void
UnitManager::AddAccessPool(const AccessPool& accessPool)
{
    mAccessPool.push_back(accessPool);
}



void
UnitManager::AddAccessVertex(const Vertex& v)
{
    mAccess.push_back(v);
}


/*
Vector3
UnitManager::GetWalkMeshCoords(const unsigned int& triangleIndex)
{
    Vector3 coords;

    float x1 = mWalkMesh[triangleIndex * 3 + 0].p.x;
    float y1 = mWalkMesh[triangleIndex * 3 + 0].p.y;
    float z1 = mWalkMesh[triangleIndex * 3 + 0].p.z;

    float x2 = mWalkMesh[triangleIndex * 3 + 1].p.x;
    float y2 = mWalkMesh[triangleIndex * 3 + 1].p.y;
    float z2 = mWalkMesh[triangleIndex * 3 + 1].p.z;

    float x3 = mWalkMesh[triangleIndex * 3 + 2].p.x;
    float y3 = mWalkMesh[triangleIndex * 3 + 2].p.y;
    float z3 = mWalkMesh[triangleIndex * 3 + 2].p.z;

    // get points of line that crosses in center of triangle
    float xc1 = x1 + (x2 - x1) * 0.5f;
    float zc1 = z1 + (z2 - z1) * 0.5f;

    float xc2 = x1 + (x3 - x1) * 0.5f;
    float zc2 = z1 + (z3 - z1) * 0.5f;

    // find coords of point in center of triangle
    float t = ((zc1 - zc2) * (x2 - xc1) - (xc1 - xc2) * (z2 - zc1)) / (( x3 - xc1) * (z2 - zc2) - ( z3 - zc1) * (x2 - xc2));

    float x = xc1 + (x3 - xc1) * t;
    float z = zc1 + (z3 - zc1) * t;

    coords.x = x;
    coords.y = point_elevation(x, z, x1 , y1, z1, x2, y2, z2, x3, y3, z3);
    coords.z = z;

    return coords;
}
*/


/*
Vector3
UnitManager::GetNextStep(const Vector3& moveVector, const Vector3& ignorePoint1, const Vector3& ignorePoint2)
{
    // if we are not moving anywhere
    if (moveVector.x == 0.0f && moveVector.y == 0.0f && moveVector.z == 0.0f)
    {
        return mUnits.vector_pos;
    }

    Vector3 A(mWalkMesh[mUnits.current_triangle * 3 + 0].p.x,
              mWalkMesh[mUnits.current_triangle * 3 + 0].p.y,
              mWalkMesh[mUnits.current_triangle * 3 + 0].p.z);
    Vector3 B(mWalkMesh[mUnits.current_triangle * 3 + 1].p.x,
              mWalkMesh[mUnits.current_triangle * 3 + 1].p.y,
              mWalkMesh[mUnits.current_triangle * 3 + 1].p.z);
    Vector3 C(mWalkMesh[mUnits.current_triangle * 3 + 2].p.x,
              mWalkMesh[mUnits.current_triangle * 3 + 2].p.y,
              mWalkMesh[mUnits.current_triangle * 3 + 2].p.z);

    Vector3 point_in_triangle = find_point_in_triangle(moveVector, mUnits.vector_pos, A, B, C);



    // check if we cross current triangle
    Vector3 crossPoint(0.0f, 0.0f, 0.0f);
    float crossLength = 0.0f;
    int crossSide = find_triangle_crossing(crossPoint, crossLength, mUnits.vector_pos, point_in_triangle, A, B, C, ignorePoint1, ignorePoint2);

    // if we not cross any triangle border
    if (crossSide == 0)
    {
        return point_in_triangle;
    }
    // if we try to cross triangle border
    else
    {
        int access_triangle = mAccessPool[mUnits.current_triangle].access[crossSide - 1];

        Vector3 sp1 = (crossSide == 1 || crossSide == 3) ? A : B;
        Vector3 sp2 = (crossSide == 1) ? B : C;

        // if we met border - then slide
        if (access_triangle == 0xFFFF)
        {
            Vector3 new_move = get_projection_on_line(moveVector, sp1, sp2);
            return GetNextStep(new_move);
        }

        mUnits.vector_pos = crossPoint;
        mUnits.current_triangle = access_triangle;

        // get new move vector
        float t = crossLength / sqrtf(moveVector.x * moveVector.x + moveVector.y * moveVector.y + moveVector.z * moveVector.z);
        Vector3 new_move(0.0f, 0.0f, 0.0f);
        new_move.x = moveVector.x * t;
        new_move.z = moveVector.z * t;

        return GetNextStep(new_move, sp1, sp2);
    }
}
*/
