// $Id: MemoryBank.h 76 2006-08-25 18:41:20Z crazy_otaku $

/**
 * @brief Memory bank for script variables.
 *
 * Interface for Savemap data bank, temporary data bank and immediate data bank.
 */

#ifndef MEMORY_BANK_h
#define MEMORY_BANK_h

#include "../../../common/TypeDefine.h"
#include "../../../common/utilites/NoCopy.h"



class MemoryBank : public NoCopy<MemoryBank>
{
public:
// LIFECYCLE

    /**
     * @brief A constructor.
     */
    MemoryBank(void);

    /**
     * @brief Default destructor.
     */
    virtual ~MemoryBank(void);

// OPERATIONS

    /**
     * @brief Put u8 value in data bank.
     *
     * @param memoryBank - number of memory bank to put value to.
     * @param offset     - offset in memory bank to where save value.
     * @param value      - value to put in memory bank.
     */
    void Put(const u8& memoryBank, const u8& offset, const u8& value);

    /**
     * @brief Put u16 value in data bank.
     *
     * @param memoryBank - number of memory bank to put value to.
     * @param offset     - offset in memory bank to where save value.
     * @param value      - value to put in memory bank.
     */
    void Put(const u8& memoryBank, const u8& offset, const u16& value);

    /**
     * @brief Get u8 value from data bank.
     *
     * @param memoryBank - number of memory bakn to put value to.
     * @param offset     - value to put in memory bank.
     */
    u8 Get(const u8& memoryBank, const u8& offset);

    /**
     * @brief Get u16 value from data bank.
     *
     * @param memoryBank - number of memory bank to put value to.
     * @param offset     - value to put in memory bank.
     */
    u16 Get(const u8& memoryBank, const u16& offset);

private:
    u8* mpMemoryBank56; /**< @brief memory bank 5/6 */
};



#endif // MEMORY_BANK_h
