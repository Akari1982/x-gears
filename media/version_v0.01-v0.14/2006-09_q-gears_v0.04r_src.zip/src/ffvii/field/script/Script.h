// $Id: Script.h 79 2006-09-15 19:02:27Z crazy_otaku $

/**
 * @brief Script holder.
 */

#ifndef SCRIPT_h
#define SCRIPT_h

#include "MemoryBank.h"
#include "ScriptManager.h"
#include "../../../common/TypeDefine.h"
#include "../../../common/utilites/NoCopy.h"

class WindowManager;



u8* OpcodesToRawScript(u8* pBuffer, const u32& bufferSize, u32& rawScriptSize);



class Script : public NoCopy<Script>
{
friend class WindowManager;

public:
// LIFECYCLE

    /**
     * @brief A constructor.
     *
     * @param pBuffer - buffer from which we want to load script.
     * @param length  - size of buffer.
     */
    Script(u8* pBuffer, const u32& length);

    /**
     * @brief Default destructor.
     */
    virtual ~Script(void);

// OPERATIONS

    /**
     * @brief Run script.
     *
     * @param fieldModule    - pointer to this FieldModule object.
     * @param scriptPosition - position from where to start script.
     * @param init           - is this initialization run or not
     * @return if return value is -1 then script work is finished of there is some error.
     */
    s32 Run(FieldModule* fieldModule, const s32& scriptPosition, bool init);

    /**
     * @brief Get 1 byte.
     *
     * Utility function that extract data with given offset from buffer
     * @param offset - offset to 1 byte that we want to get.
     * @return 1 byte from file buffer with given offset.
     */
    const u8 GetU8(const u32& offset) const;

    /**
     * @brief Get 2 bytes.
     *
     * Utility function that extract data with given offset from buffer
     * @param offset - offset to 2 bytes that we want to get.
     * @return 2 bytes from file buffer with given offset.
     */
    const u16 GetU16LE(const u32& offset) const;

// ACCESS

    /**
     * @brief Check if script is wait for syncronize with command.
     *
     * @return true if we wait for syncronize, false otherwise.
     */
    bool IsWait(void) const;

    /**
     * @brief Set if script is wait for syncronize with command.
     *
     * @param wait - true if we wait for syncronize, false otherwise.
     */
    void SetWait(const bool& wait);

private:
    static MemoryBank mMemoryBank; /**< @brief memory bank instance */
    u8*               mpBuffer;    /**< @brief script buffer */
    u32               mLength;     /**< @brief length of script buffer */
    bool              mWait;       /**< @brief bool value tha shows if we wait for syncronize with command */
};



#endif // SCRIPT_h
