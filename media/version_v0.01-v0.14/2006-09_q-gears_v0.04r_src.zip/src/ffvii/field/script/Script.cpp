// $Id: Script.cpp 81 2006-09-28 15:35:24Z crazy_otaku $

#include <cassert>
#include <memory>

#include "../../../common/utilites/Logger.h"

#include "Script.h"
#include "../FieldModule.h"
#include "../WindowManager.h"



// static member
MemoryBank Script::mMemoryBank;



// help function
u8*
OpcodesToRawScript(u8* pBuffer, const u32& bufferSize, u32& rawScriptSize)
{
    rawScriptSize = 0;
    u8* raw_script = NULL;

    raw_script = (u8*)malloc(rawScriptSize);
    u32 script_size = 0;
    u32 current_position = 0;

    static std::vector< std::pair<RString, u32> > opcodes;
    opcodes.resize(256);
    opcodes[0x00].first = "RET";     opcodes[0x00].second = 0x1; opcodes[0x01].first = "REQ";     opcodes[0x01].second = 0x3;

    opcodes[0x10].first = "JMPF";    opcodes[0x10].second = 0x2; opcodes[0x11].first = "JMPFL";   opcodes[0x11].second = 0x3;
    opcodes[0x12].first = "JMPB";    opcodes[0x12].second = 0x2; opcodes[0x13].first = "JMPBL";   opcodes[0x13].second = 0x3;
    opcodes[0x14].first = "IFUB";    opcodes[0x14].second = 0x6; opcodes[0x15].first = "IFUBL";   opcodes[0x15].second = 0x7;
    opcodes[0x16].first = "IFSW";    opcodes[0x16].second = 0x8; opcodes[0x17].first = "IFSWL";   opcodes[0x17].second = 0x9;
    opcodes[0x18].first = "IFUW";    opcodes[0x18].second = 0x8; opcodes[0x19].first = "IFUWL";   opcodes[0x19].second = 0x9;

    opcodes[0x36].first = "WSPCL";   opcodes[0x36].second = 0x5; opcodes[0x37].first = "WNUMB";   opcodes[0x37].second = 0x8;
    opcodes[0x38].first = "STTIM";   opcodes[0x38].second = 0x6;

    opcodes[0x40].first = "MESSAGE"; opcodes[0x40].second = 0x3;

    opcodes[0x48].first = "ASK";     opcodes[0x48].second = 0x7;

    opcodes[0x50].first = "WINDOW";  opcodes[0x50].second = 0xA;

    opcodes[0x52].first = "WMODE";   opcodes[0x52].second = 0x4;

    opcodes[0x60].first = "MAPJUMP"; opcodes[0x60].second = 0xA;

    opcodes[0x76].first = "PLUS!";   opcodes[0x76].second = 0x4; opcodes[0x77].first = "PLUS2!";  opcodes[0x77].second = 0x5;
    opcodes[0x78].first = "MINUS!";  opcodes[0x78].second = 0x4; opcodes[0x79].first = "MINUS2!"; opcodes[0x79].second = 0x5;



    for (unsigned int i = 0; i < bufferSize;)
    {
        u32 string_size = 0;
        // get the size of string
        while (pBuffer[i + string_size] != '\r' && pBuffer[i + string_size] != '\n' && i + string_size < bufferSize)
        {
            ++string_size;
        }

        // Read the string
        std::string line = "";
        char* temp_string = new char[string_size + 1];
        memcpy(temp_string, pBuffer + i, string_size);
        temp_string[string_size] = '\0';
        line = temp_string;
        delete[] temp_string;

        // comments and empty row
        if (line[0] == '#' || line.size() > 1 && line[0] == '/' && line[1] == '/')
        {
            i += string_size;
            continue;
        }

        // add new opcode to raw.
        int equal_index = line.find(" ");
        if (equal_index != std::string::npos)
        {

            std::string opcode_name = line.substr(0, equal_index);

            // we skip space and ( and then read string after that
            std::string opcode_data = line.substr(equal_index + 2, line.size() - equal_index - 2);

            // search for opcode (if it finds nothing - it inserts RET opcode)
            u8 k = 0;
            for (; k < 255; ++k)
            {
                if (opcodes[k].first == opcode_name)
                {
                    break;
                }
            }

            if (k != 255)
            {
                rawScriptSize += opcodes[k].second;
                raw_script = (u8*)realloc(raw_script, rawScriptSize);

                raw_script[current_position] = k;
    //            printf("%02x", raw_script[current_position]);
                ++current_position;

                for (u8 j = 1; j < opcodes[k].second; ++j)
                {
                    if (opcode_data.size() >= 3)
                    {
                        std::string value = opcode_data.substr(0, 2);
                        opcode_data       = opcode_data.substr(3, opcode_data.size() - 3);

                        u32 hex = 0;
                        sscanf(value.c_str(), "%02x", &hex);
                        raw_script[current_position] = (u8)hex;
    //                    printf("%02x", raw_script[current_position]);
                        ++current_position;
                    }
                    else
                    {
                        LOGGER->Log("Not enough arguments in opcode %s", opcodes[k].first.c_str());
                    }
                }
            }
            else
            {
                LOGGER->Log("Opcode %s not found!", opcode_name.c_str());
            }
        }
        else
        {
            LOGGER->Log("Row '%s' incorrect! Must contain space.", line.c_str());
        }

        i += string_size;

        // skip '\r' or '\n' on the end of string and go to start of new string
        while (pBuffer[i] == '\r' || pBuffer[i] == '\n')
        {
            ++i;
        }
    }



    return raw_script;
}


/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

Script::Script(u8* pBuffer, const u32& length):
    mpBuffer(0),
    mLength(length),
    mWait(false)
{
    assert(pBuffer != 0);

    mpBuffer = (u8*)malloc(sizeof(u8) * mLength);
    memcpy(mpBuffer, pBuffer, mLength);
}



Script::~Script(void)
{
    free(mpBuffer);
}



//============================= OPERATIONS ===================================

s32
Script::Run(FieldModule* fieldModule, const s32& scriptPosition, bool init)
{
    // check if we are not finish this script yet
    if (scriptPosition < 0)
    {
        return -1;
    }

    if (IsWait() == true)
    {
        return scriptPosition;
    }

    for (u32 i = scriptPosition; i < mLength;)
    {
        switch (*(mpBuffer + i))
        {
            // Return from subroutine
            case 0x00:
            {
                printf("RET\n");
                if (init)
                {
                    i += 1;
                    return i;
                }
                else
                {
                    return -1;
                }
            }
            break;



            // Request remote execution (asynchronous , non-guaranteed)
            case 0x01:
            {
                u8 entity_id = GetU8(i + 1);
                u8 priority  = GetU8(i + 2) >> 5;
                u8 script_id = GetU8(i + 2) & 0x1F;
                fieldModule->mScriptManager.RequestRun(entity_id, priority, script_id);

                printf("REQ\n");

                i += 3;
            }
            break;



//case 0x02:
//case 0x03:
//case 0x04:
//case 0x05:
//case 0x06:
//case 0x07:
//case 0x08:
//case 0x09:
//case 0x0A:
//case 0x0B:
//case 0x0C:
//case 0x0D:
//case 0x0E:
//case 0x0F:



            // Jump ahead relative (8-bit)
            case 0x10:
            {
                u8 jump = GetU8(i + 1);

                printf("JMPF(jump = %02x)\n", jump);

                i += 1 + jump;
            }
            break;



            // Jump ahead relative (16-bit)
            case 0x11:
            {
                u16 jump = GetU16LE(i + 1);

                printf("JMPFL(jump = %04x)\n", jump);

                i += 1 + jump;
            }
            break;



            // Jump backward relative (8-bit)
            case 0x12:
            {
                u8 jump = GetU8(i + 1);

                printf("JMPB(jump = %02x)\n", jump);

                i -= jump;
            }
            break;



            // Jump back relative (16-bit)
            case 0x13:
            {
                u16 jump = GetU16LE(i + 1);

                printf("JMPBL(jump = %04x)\n", jump);

                i -= jump;
            }
            break;



            // Unsigned byte conditional with byte relative jump
            case 0x14:
            {
                u8  memory_bank = GetU8(i + 1) >> 4;
                u8  offset      = GetU8(i + 2);
                u16 value1      = mMemoryBank.Get(memory_bank, offset);
                u16 value2      = GetU8(i + 3);
                u8  relation    = GetU8(i + 4);
                u8  jump        = GetU8(i + 5);

                printf("IFUB(bank = %02x, offset = %02x, value2 = %02x, relation = %02x, jump = %02x)\n", memory_bank, offset, value2, relation, jump);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  ((value1 << 1) & value2); break;
                    case 0x0A: result = !((value1 << 1) & value2); break;
                    default: printf("Strange relation: %02x\n", relation);
                }

                if (result == true)
                {
                    i += 6;
                }
                else
                {
                    i += 5 + jump;
                }
            }
            break;



            // Unsigned byte conditional with long relative jump
            case 0x15:
            {
                u8  memory_bank = GetU8(i + 1) >> 4;
                u8  offset      = GetU8(i + 2);
                u16 value1      = mMemoryBank.Get(memory_bank, offset);
                u16 value2      = GetU8(i + 3);
                u8  relation    = GetU8(i + 4);
                u16 jump        = GetU16LE(i + 5);

                printf("IFUBL(bank = %02x, offset = %02x, value2 = %02x, relation = %02x, jump = %04x)\n", memory_bank, offset, value2, relation, jump);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  ((value1 << 1) & value2); break;
                    case 0x0A: result = !((value1 << 1) & value2); break;
                    default: printf("Strange relation: %02x\n", relation);
                }

                if (result == true)
                {
                    i += 7;
                }
                else
                {
                    i += 5 + jump;
                }
            }
            break;



            // Signed word conditional with byte relative jump
            case 0x16:
            {
                u8  memory_bank = GetU8(i + 1) >> 4;
                u16 offset      = GetU16LE(i + 2);
                s16 value1      = mMemoryBank.Get(memory_bank, offset);
                s16 value2      = GetU16LE(i + 4);
                u8  relation    = GetU8(i + 6);
                u8  jump        = GetU8(i + 7);

                printf("IFSW(bank = %02x, offset = %04x, value2 = %04x, relation = %02x, jump = %02x)\n", memory_bank, offset, value2, relation, jump);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  ((value1 << 1) & value2); break;
                    case 0x0A: result = !((value1 << 1) & value2); break;
                    default: printf("Strange relation: %02x\n", relation);
                }

                if (result == true)
                {
                    i += 8;
                }
                else
                {
                    i += 7 + jump;
                }
            }
            break;



            // Signed word conditional with long relative jump
            case 0x17:
            {
                u8  memory_bank = GetU8(i + 1) >> 4;
                u16 offset      = GetU16LE(i + 2);
                s16 value1      = mMemoryBank.Get(memory_bank, offset);
                s16 value2      = GetU16LE(i + 4);
                u8  relation    = GetU8(i + 6);
                u16 jump        = GetU16LE(i + 7);

                printf("IFSWL(bank = %02x, offset = %04x, value2 = %04x, relation = %02x, jump = %04x)\n", memory_bank, offset, value2, relation, jump);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  ((value1 << 1) & value2); break;
                    case 0x0A: result = !((value1 << 1) & value2); break;
                    default: printf("Strange relation: %02x\n", relation);
                }

                if (result == true)
                {
                    i += 9;
                }
                else
                {
                    i += 7 + jump;
                }
            }
            break;



            // Unsigned word conditional with byte relative jump
            case 0x18:
            {
                u8  memory_bank = GetU8(i + 1) >> 4;
                u16 offset      = GetU16LE(i + 2);
                u16 value1      = mMemoryBank.Get(memory_bank, offset);
                u16 value2      = GetU16LE(i + 4);
                u8  relation    = GetU8(i + 6);
                u8  jump        = GetU8(i + 7);

                printf("IFUW(bank = %02x, offset = %04x, value2 = %04x, relation = %02x, jump = %02x)\n", memory_bank, offset, value2, relation, jump);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  ((value1 << 1) & value2); break;
                    case 0x0A: result = !((value1 << 1) & value2); break;
                    default: printf("Strange relation: %02x\n", relation);
                }

                if (result == true)
                {
                    i += 8;
                }
                else
                {
                    i += 7 + jump;
                }
            }
            break;



            // Unsigned word conditional with long relative jump
            case 0x19:
            {
                u8  memory_bank = GetU8(i + 1) >> 4;
                u16 value1      = mMemoryBank.Get(memory_bank, GetU16LE(i + 2));
                u16 value2      = GetU16LE(i + 4);
                u8  relation    = GetU8(i + 6);
                u16 jump        = GetU16LE(i + 7);

                printf("IFUWL(bank = %02x, value1 = %04x, value2 = %04x, relation = %02x, jump = %04x)\n", memory_bank, value1, value2, relation, jump);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  ((value1 << 1) & value2); break;
                    case 0x0A: result = !((value1 << 1) & value2); break;
                    default: printf("Strange relation: %02x\n", relation);
                }

                if (result == true)
                {
                    i += 9;
                }
                else
                {
                    i += 7 + jump;
                }
            }
            break;



//case A lot of!!



            // Window Special
            case 0x36:
            {
                u8 window_id = GetU8(i + 1);
                u8 type      = GetU8(i + 2);
                u8 x         = GetU8(i + 3);
                u8 y         = GetU8(i + 4);

                fieldModule->mWindowManager.SetSpecialStyle(window_id, x, y, type);

                printf("WSPCL(id = %02x, type = %02x, x = %02x, y = %02x)\n", window_id, x, y, type);

                i += 5;
            }
            break;



            //  Set Number
            case 0x37:
            {
                // need to be fixed
                u8  memory_bank_1 = GetU8(i + 1) >> 4;
                u8  memory_bank_2 = GetU8(i + 1) & 0x0F;
                u8  window_id     = GetU8(i + 2);
                u32 digit         = mMemoryBank.Get(memory_bank_1, GetU16LE(i + 3)) | (mMemoryBank.Get(memory_bank_2, GetU16LE(i + 5)) << 16);
                u8  digit_number  = GetU8(i + 7);

                fieldModule->mWindowManager.SetSpecialNumber(window_id, digit, digit_number);

                printf("WNUMB(mb1 = %02x, mb2 = %02x, w_id = %02x, digit = %08x, num = %02x)\n", memory_bank_1, memory_bank_2, window_id, digit, digit_number);

                i += 8;
            }
            break;



            //  Set Timer
            case 0x38:
            {
                // need to be fixed
                u8  memory_bank_1 = GetU8(i + 1) >> 4;
                u8  memory_bank_2 = GetU8(i + 1) & 0x0F;
                u8  memory_bank_3 = GetU8(i + 2) & 0x0F;
                u8  hours         = mMemoryBank.Get(memory_bank_1, GetU8(i + 3));
                u8  minutes       = mMemoryBank.Get(memory_bank_2, GetU8(i + 4));
                u8  seconds       = mMemoryBank.Get(memory_bank_3, GetU8(i + 5));

                fieldModule->mWindowManager.SetTimer(hours, minutes, seconds);

                printf("STTIM(hours = %02x, minutes = %02x, seconds = %02x)\n", hours, minutes, seconds);

                i += 6;
            }
            break;



//case A lot of!!



            // Open a message
            case 0x40:
            {
                u8 memory_bank = 0;
                u8 window_id   = GetU8(i + 1);
                u8 dialog_id   = GetU8(i + 2);
                u8 first       = 0;
                u8 last        = 0;
                u8 offset      = 0;

                // set syncronize with window
                SetWait(true);
                fieldModule->mWindowManager.ShowMessage(window_id, dialog_id, first, last, memory_bank, offset, this);

                printf("MESSAGE(w_id = %02x, d_id = %02x)\n", window_id, dialog_id);

                i += 3;
                return i;
            }
            break;



//case A lot of!!



            // Open a choice dialog box
            case 0x48:
            {
                u8 memory_bank = GetU8(i + 1);
                u8 window_id   = GetU8(i + 2);
                u8 dialog_id   = GetU8(i + 3);
                u8 first       = GetU8(i + 4);
                u8 last        = GetU8(i + 5);
                u8 offset      = GetU8(i + 6);

                // set syncronize with window
                SetWait(true);
                fieldModule->mWindowManager.ShowMessage(window_id, dialog_id, first, last, memory_bank, offset, this);

                printf("ASK(bank = %02x, w_id = %02x, d_id = %02x, 1st = %02x, last = %02x, offset = %02x)\n", memory_bank, window_id, dialog_id, first, last, offset);

                i += 7;
                return i;
            }
            break;



//case 0x49:



            // Initializes a windowpane
            case 0x50:
            {
                u8  id     = GetU8(i + 1);
                u16 x      = GetU16LE(i + 2);
                u16 y      = GetU16LE(i + 4);
                u16 width  = GetU16LE(i + 6);
                u16 height = GetU16LE(i + 8);

                fieldModule->mWindowManager.SetWindow(id, x, y, width, height);

                printf("WINDOW(id = %02x, x = %04x, y = %04x, width = %04x, height = %04x)\n", id, x, y, width, height);

                i += 10;
            }
            break;



//case 0x51:



            // Change window mode
            case 0x52:
            {
                u8 id    = GetU8(i + 1);
                u8 style = GetU8(i + 2);
                u8 cbc   = GetU8(i + 3);

                fieldModule->mWindowManager.SetWindowStyle(id, style, cbc);

                printf("WMODE(id = %02x, style = %02x, cbc = %02x)\n", id, style, cbc);

                i += 4;
            }
            break;



//case A lot of!!



            // Load another map
            case 0x60:
            {
                u16 map_id = GetU16LE(i + 1);

                fieldModule->RequestLoadMap(map_id);

                printf("MAPJUMP(id = %04x)\n", map_id);

                i += 10;
            }
            break;



//case A lot of!!



            // Saturated Addition (8-bit)
            case 0x76:
            {
                u8  destination_bank   = GetU8(i + 1) >> 4;
                u8  source_bank        = GetU8(i + 1) & 0x0F;
                u8  destination_offset = GetU8(i + 2);
                u8  source_offset      = GetU8(i + 3);

                u8  value1             = mMemoryBank.Get(destination_bank, destination_offset);
                u8  value2             = mMemoryBank.Get(source_bank, source_offset);

                u16 result = (u16)value1 + (u16)value2;
                result = (result > 0xFF) ? 0xFF : result;

                mMemoryBank.Put(destination_bank, destination_offset, (u8)result);

                printf("PLUS!(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %02x)\n", destination_bank, source_bank, destination_offset, source_offset);

                i += 4;
            }
            break;



            // Saturated Addition (16-bit)
            case 0x77:
            {
                u8  destination_bank   = GetU8(i + 1) >> 4;
                u8  source_bank        = GetU8(i + 1) & 0x0F;
                u8  destination_offset = GetU8(i + 2);
                u16 source_offset      = GetU16LE(i + 3);

                s16 value1             = mMemoryBank.Get(destination_bank, (u16)destination_offset);
                s16 value2             = mMemoryBank.Get(source_bank, source_offset);

                s32 result = (s32)value1 + (s32)value2;
                result = (result > 32767) ? 32767 : result;

                mMemoryBank.Put(destination_bank, destination_offset, (u16)((s16)result));

                printf("PLUS2!(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)\n", destination_bank, source_bank, destination_offset, source_offset);

                i += 5;
            }
            break;



            // Saturated Subtraction (8-bit)
            case 0x78:
            {
                u8  destination_bank   = GetU8(i + 1) >> 4;
                u8  source_bank        = GetU8(i + 1) & 0x0F;
                u8  destination_offset = GetU8(i + 2);
                u8  source_offset      = GetU8(i + 3);

                u8  value1             = mMemoryBank.Get(destination_bank, destination_offset);
                u8  value2             = mMemoryBank.Get(source_bank, source_offset);

                u8  result = (value1 > value2) ? value1 - value2 : 0;

                mMemoryBank.Put(destination_bank, destination_offset, result);

                printf("MINUS!(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %02x)\n", destination_bank, source_bank, destination_offset, source_offset);

                i += 4;
            }
            break;



            // Saturated Subtraction (16-bit)
            case 0x79:
            {
                u8  destination_bank   = GetU8(i + 1) >> 4;
                u8  source_bank        = GetU8(i + 1) & 0x0F;
                u8  destination_offset = GetU8(i + 2);
                u16 source_offset      = GetU16LE(i + 3);

                s16 value1             = mMemoryBank.Get(destination_bank, (u16)destination_offset);
                s16 value2             = mMemoryBank.Get(source_bank, source_offset);

                s32 result = (s32)value1 - (s32)value2;
                result = (result < -32767) ? -32767 : result;

                mMemoryBank.Put(destination_bank, destination_offset, (u16)((s16)result));

                printf("MINUS2!(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)\n", destination_bank, source_bank, destination_offset, source_offset);

                i += 5;
            }
            break;



//case A lot of!!



            default:
            {
                printf("Unknown opcode %02x\n", *(mpBuffer + i));
                return -1;
            }
        }
    }
}



const u8
Script::GetU8(const u32& offset) const
{
    return static_cast<u8>(*(mpBuffer + offset));
}



const u16
Script::GetU16LE(const u32& offset) const
{
    return ((u8*)mpBuffer + offset)[0] | (((u8*)mpBuffer + offset)[1] << 8);
}



//============================= ACCESS     ===================================

bool
Script::IsWait(void) const
{
    return mWait;
}



void
Script::SetWait(const bool& wait)
{
    mWait = wait;
}
