// $Id: ScriptManager.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "Entity.h"
#include "ScriptManager.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

ScriptManager::ScriptManager(void)
{
}



ScriptManager::~ScriptManager(void)
{
    Clear();
}



//============================= OPERATIONS ===================================

void
ScriptManager::Clear(void)
{
    for (int i = 0; i < mEntities.size(); ++i)
    {
        delete mEntities[i];
    }
    mEntities.clear();
}



void
ScriptManager::Run(FieldModule* fieldModule)
{
    for (int i = 0; i < mEntities.size(); ++i)
    {
        mEntities[i]->Run(fieldModule);
    }
}



void
ScriptManager::RequestRun(const u8& entityId, const u8& priority, const u8& scriptId)
{
    mEntities[entityId]->RequestRun(priority, scriptId);
}



void
ScriptManager::PushEntity(Entity* pEntity)
{
    mEntities.push_back(pEntity);
}
