// $Id: ScriptManager.h 76 2006-08-25 18:41:20Z crazy_otaku $

/**
 * @brief Manager that handles different entity scripts.
 */

#ifndef SCRIPT_MANAGER_h
#define SCRIPT_MANAGER_h

#include "../../../common/TypeDefine.h"
#include "../../../common/utilites/NoCopy.h"

#include <vector>

class Entity;
class FieldModule;



class ScriptManager : public NoCopy<ScriptManager>
{
public:
// LIFECYCLE

    /**
     * @brief Default constructor.
     */
    ScriptManager(void);

    /**
     * @brief Default destructor.
     */
    virtual ~ScriptManager(void);

// OPERATIONS

    /**
     * @brief Clear data.
     */
    void Clear(void);

    /**
     * @brief Run scripts.
     *
     * @param fieldModule - pointer to this FieldModule object
     */
    void Run(FieldModule* fieldModule);

    /**
     * @brief Request to run scripts in entity.
     *
     * Request to run scripts in entity. Asynchronous , non-guaranteed. Call from REQ.
     * @param entityId - ID of the target entity.
     * @param priority - The priority at which we want to execute the remote script.
     * @param scriptId - ID of the specific member function of E to be executed.
     */
    void RequestRun(const u8& entityId, const u8& priority, const u8& scriptId);

    /**
     * @brief Add new entity to array.
     *
     * @param pModule - pointer to new module that we want to add.
     */
    void PushEntity(Entity* pEntity);

private:
    std::vector<Entity*> mEntities; /**< @brief array of entities */
};



#endif // SCRIPTS_MANAGER_h
