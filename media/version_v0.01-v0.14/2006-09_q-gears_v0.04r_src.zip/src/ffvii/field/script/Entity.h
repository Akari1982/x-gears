// $Id: Entity.h 79 2006-09-15 19:02:27Z crazy_otaku $

/**
 * @brief Entity object that contains script and may be linked to model on field.
 */

#ifndef ENTITY_h
#define ENTITY_h

#include "Script.h"
#include "ScriptManager.h"
#include "../../../common/TypeDefine.h"
#include "../../../common/utilites/NoCopy.h"
#include "../../../common/utilites/StdString.h"



class Entity : public NoCopy<Entity>
{
public:
// LIFECYCLE

    /**
     * @brief Default constructor.
     */
    Entity(void);

    /**
     * @brief Default destructor.
     */
    virtual ~Entity(void);

// OPERATIONS

    /**
     * @brief Run entity script.
     *
     * @param fieldModule - pointer to this FieldModule object
     */
    void Run(FieldModule* fieldModule);

    /**
     * @brief Request to run scripts in entity.
     *
     * Request to run scripts in entity. Asynchronous , non-guaranteed. Call from REQ.
     * @param priority - The priority at which we want to execute the remote script.
     * @param scriptId - ID of the specific member function of E to be executed.
     */
    void RequestRun(const u8& priority, const u8& scriptId);

    /**
     * @brief Add script in given slot.
     *
     * @param id     - id of loading script.
     * @param script - script to add.
     */
    void AddScript(const u8& id, Script* script);

// ACCESS

    /**
     * @brief Add name to entity.
     *
     * @param name - name to be set.
     */
    void SetName(const RString& name);

private:
    RString         mName;                /** name of entity */
    Script*         mScript[32];          /** scripts */

    bool            mInited;
    u32             mBaseOffset;

    struct ScriptQueueItem
    {
        s8  id;
        u32 position;
    };
    ScriptQueueItem mScriptQueue[8];
};



#endif // ENTITY_h
