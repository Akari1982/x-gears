// $Id: Menu.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "Menu.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

Menu::Menu(void)
{
    Init();
}



Menu::~Menu(void)
{
}



//============================= OPERATIONS ===================================

void
Menu::Init(void)
{
}



void
Menu::Draw(void)
{
}



void
Menu::Input(const InputEvent &input)
{
}



void
Menu::Update(const u32& deltaTime)
{
}
