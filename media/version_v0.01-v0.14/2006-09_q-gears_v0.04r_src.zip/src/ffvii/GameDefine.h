// $Id: GameDefine.h 81 2006-09-28 15:35:24Z crazy_otaku $

#ifndef GAME_DEFINE_H
#define GAME_DEFINE_H



#define APPLICATION_NAME "FFVII v0.04c"



#endif // GAME_DEFINE_H
