// $Id: InputHandler.h 93 2006-11-12 13:49:02Z einherjar $

#ifndef INPUTHANDLER_H
#define INPUTHANDLER_H



#include "../InputFilter.h"
#include "../../utilites/NoCopy.h"



class InputHandler : public NoCopy<InputHandler>
{
public:
    virtual      ~InputHandler() {}
    virtual void  Update() = 0;

protected:
                  InputHandler() {}
    void          ButtonPressed(Button b, bool Down);
};



#endif // INPUTHANDLER_H
