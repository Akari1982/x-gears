// $Id: InputFilter.cpp 118 2006-12-15 21:12:56Z crazy_otaku $

#include "InputFilter.h"
#include "InputUtils.h"
#include "handlers/InputHandlerSdl.h"

#include <vector>



InputFilter* INPUTFILTER = NULL;



InputFilter::InputFilter(void)
{
    m_InputHandler = new InputHandlerSDL();
    Reset();
}



InputFilter::~InputFilter(void)
{
    delete m_InputHandler;
}



void
InputFilter::Reset(void)
{
    for (int button = 0; button < MAX_BUTTONS; ++button)
    {
        ButtonPressed((enum Button)button, false);
    }
}



void
InputFilter::ButtonPressed(const Button& button, const bool& bDown)
{
    if (m_bButtonState[button] != bDown)
    {
        m_bButtonState[button] = bDown;
        m_vQueue.push_back(InputEvent(button, (m_bButtonState[button] == true) ? IET_FIRST_PRESS : IET_RELEASE));

        m_vHandledButton.push_back(button);
    }
}



void
InputFilter::Update(void)
{
    m_InputHandler->Update();

    for (u32 button = 0; button < MAX_BUTTONS; ++button)
    {
        if (m_bButtonState[button] == true)
        {
            std::vector<Button>::iterator p = find(m_vHandledButton.begin(), m_vHandledButton.end(), button);

            if (p == m_vHandledButton.end())
            {
                m_vQueue.push_back(InputEvent((enum Button)button, IET_REPEAT));
            }
        }
    }

    m_vHandledButton.clear();
}



void
InputFilter::GetInputEvents(InputEventArray& vInputEvents)
{
    vInputEvents = m_vQueue;

    m_vQueue.clear();
}
