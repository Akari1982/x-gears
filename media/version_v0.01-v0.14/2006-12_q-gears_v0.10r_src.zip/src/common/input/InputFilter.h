// $Id: InputFilter.h 118 2006-12-15 21:12:56Z crazy_otaku $

#ifndef INPUTFILTER_H
#define INPUTFILTER_H

#include <vector>

#include "InputUtils.h"
#include "../TypeDefine.h"
#include "../utilites/NoCopy.h"

class InputHandler;



enum InputEventType
{
    // The device was just pressed.
    IET_FIRST_PRESS,

    // The device is auto-repeating.
    IET_REPEAT,

    // The device is no longer pressed.  Exactly one IET_RELEASE event will be sent
    // for each IET_FIRST_PRESS.
    IET_RELEASE,
};



struct InputEvent
{
    InputEvent():
        button(KEY_INVALID),
        type(IET_FIRST_PRESS)
    {
    };

    InputEvent(Button b, InputEventType t):
        button(b),
        type(t)
    {
    };

    InputEventType type;
    Button         button;
};

typedef std::vector<InputEvent> InputEventArray;



class InputFilter : public NoCopy<InputFilter>
{
public:
             InputFilter(void);
    virtual ~InputFilter(void);

    void     ButtonPressed(const Button& button, const bool& bDown);
    void     Reset(void);
    void     Update(void);

    void     GetInputEvents(InputEventArray& vInputEvents);

private:
    bool                m_bButtonState[MAX_BUTTONS];
    std::vector<Button> m_vHandledButton;

    InputHandler*       m_InputHandler;

    InputEventArray     m_vQueue;
};



// global and accessable from anywhere in our program
extern InputFilter* INPUTFILTER;



#endif // INPUTFILTER_H
