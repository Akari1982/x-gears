// $Id: Timer.cpp 93 2006-11-12 13:49:02Z einherjar $

#include "Timer.h"



Timer::Timer()
{
}



Timer::Timer(const unsigned int &seconds):
    mSeconds(seconds)
{
}



Timer::~Timer()
{
}



unsigned int
Timer::GetDeltaTime()
{
    Timer* now = MakeTimer();
    unsigned int diff = now->mSeconds - mSeconds;
    mSeconds = now->mSeconds;
    delete now;
    return diff;
}
