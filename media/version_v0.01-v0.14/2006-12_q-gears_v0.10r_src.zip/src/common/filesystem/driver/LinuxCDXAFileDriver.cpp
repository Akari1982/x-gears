#include <cassert>
#include <cstdlib>
#include <unistd.h>
#include <sys/ioctl.h>
#include <fcntl.h>

#include <string>
#include <iostream>

#include "LinuxCDXAFileDriver.h"
#include "../../utilites/Logger.h"

// ----------------------------------------------------------------------------
//
// XA data (green, mode2 form1)
//
// | sync | head | sub |     data     | EDC | ECC  |
// |  12  |   4  |  8  |     2048     |  4  | 276  |
// | CD_XA_SYNC_HEAD   | CD_FRAMESIZE | CD_XA_TAIL |
//

typedef struct cdrom_msf0 cdrom_msf0_t;
typedef struct cdrom_msf cdrom_msf_t;

// lba = lsn + 150
// lsn = lba - 150

static void
msf0_to_lba(const cdrom_msf0_t &msf, unsigned long &lba)
{
  lba = (msf.minute * CD_SECS + msf.second) * CD_FRAMES + msf.frame;
}

static void
lba_to_msf(unsigned long lba, cdrom_msf_t &msf)
{
  msf.cdmsf_min0 = lba / CD_SECS / CD_FRAMES;
  msf.cdmsf_sec0 = (lba / CD_FRAMES) % CD_SECS;
  msf.cdmsf_frame0 = lba % CD_FRAMES;

  msf.cdmsf_min1 = (lba + 1) / CD_SECS / CD_FRAMES;
  msf.cdmsf_sec1 = ((lba + 1) / CD_FRAMES) % CD_SECS;
  msf.cdmsf_frame1 = (lba + 1) % CD_FRAMES;
}

static RString
iso_translate_name (const RString &name)
{
  if (0 < name.size())
    switch (name[0])
      {
      case 0:
	return ".";
      case 1:
	return "..";
      }

  RString result;

  // From linux kernel's isofs
  for (unsigned int i = 0; i < name.size(); ++i)
    if ('A' <= name[i] && name[i] <= 'Z')
      result += name[i]; // - 'A' + 'a'; // lower case
    else
      {
	// Drop trailing '.;1' (ISO 9660:1988 7.5.1 requires period)
	if (name[i] == '.'
	    && i == name.size() - 3
	    && name[i + 1] == ';' && name[i + 2] == '1')
	  break;

	// Drop trailing ';1'
	if (name[i] == ';'
	    && i == name.size() - 2
	    && name[i + 1] == '1')
	  break;

	// Convert remaining ';' to '.'
	// Also '/' to '.' (broken Acorn-generated ISO9660 images)
	if (name[i] == ';' || name[i] == '/')
	  result += '.';
	else
	  result += name[i];
      }

  return result;
}

// ----------------------------------------------------------------------------

LinuxCDXAFileDriver::LinuxCDXAFileDriver(const RString &device)
{
  if (!Mount(device))
    LOGGER->Log("Can't mount device %s", device.c_str());
}

LinuxCDXAFileDriver::~LinuxCDXAFileDriver()
{
  Unmount();
}

// ----------------------------------------------------------------------------


unsigned int
LinuxCDXAFileDriver::GetFileSize(const RString &filename)
{
  FileEntry *entry = Find("/" + filename);
  if (!entry)
    {
      LOGGER->Log("Can't find file %s", filename.c_str());
      return 0;
    }

  return entry->Size();
}

bool
LinuxCDXAFileDriver::ReadFile(const RString &filename, void *buffer,
			      const unsigned int start, const unsigned int length)
{
  FileEntry *entry = Find("/" + filename);
  if (!entry)
    {
      LOGGER->Log("Can't find file %s", filename.c_str());
      return false;
    }

  // Ensure inputs are coherent
  if (start + length <= entry->Size())
    {
      unsigned char raw_data[CD_FRAMESIZE_RAW] = { 0 }; // bzero

      // Compute first sector
      unsigned int entry_lba = first_track_lba_ + entry->Extent();
      entry_lba += start / CD_FRAMESIZE;

      // Setup first read
      unsigned int in_frame = start % CD_FRAMESIZE;
      unsigned int from_frame = std::min(CD_FRAMESIZE - in_frame, length);

      unsigned int nb_read = 0;
      while (nb_read < length)
	{
	  // Do read
	  lba_to_msf(entry_lba, (cdrom_msf_t &) raw_data); // tricky

	  if (ioctl(fd_, CDROMREADRAW, raw_data, raw_data) == -1)
	    {
	      LOGGER->Log("Problem during CD XA read");
	      return false;
	    }

	  unsigned char *data = raw_data + CD_XA_SYNC_HEAD; // XA mode 2 form 1

	  // Copy
	  std::memcpy((unsigned char *) buffer, data + in_frame, from_frame);

	  // Prepare next read
	  buffer += from_frame;
	  nb_read += from_frame;

	  in_frame = 0;
	  from_frame = std::min((unsigned) CD_FRAMESIZE, length - nb_read);

	  ++entry_lba;
	}
    }

  return true;
}

// ----------------------------------------------------------------------------

bool
LinuxCDXAFileDriver::Mount(const RString &device)
{
  bool status = false;

  //
  fd_ = ::open(device.c_str(), O_RDONLY);
  if (0 < fd_)
    {
      //
      status = ReadTOC(fd_, toc_header_, toc_entries_);
      if (status && 0 < toc_entries_.size())
	{
	  cdrom_tocentry_t *toc_entry = toc_entries_[0];

	  switch (toc_entry->cdte_format)
	    {
	    case CDROM_MSF: msf0_to_lba(toc_entry->cdte_addr.msf,first_track_lba_);
	      break;
	    case CDROM_LBA: first_track_lba_ = toc_entry->cdte_addr.lba;
	      break;
	    }

	  // ECMA-119: PVD is recorded starting at first track's LSN + 16
	  status = ReadPrimaryVolumeDescriptor(fd_, first_track_lba_ + 16,
					       primary_descriptor_);
	  if (status)
	    status = ReadFileTree(fd_, first_track_lba_,
				  primary_descriptor_,
				  file_entries_);
	}
    }

  return status;
}

bool
LinuxCDXAFileDriver::ReadTOC(int fd, cdrom_tochdr_t &toc_header,
			     std::vector<cdrom_tocentry_t *> &toc_entries) const
{
  if (ioctl(fd, CDROMREADTOCHDR, &toc_header) == -1)
    {
      LOGGER->Log("Problem during CD XA TOC header read");
      return false;
    }

  for (int i = toc_header.cdth_trk0; i <= toc_header.cdth_trk1; ++i)
    {
      cdrom_tocentry_t *toc_entry = new cdrom_tocentry_t();
      assert(toc_entry);

      toc_entries.push_back(toc_entry);

      toc_entry->cdte_format = CDROM_MSF;
      toc_entry->cdte_track = i;

      if (ioctl(fd, CDROMREADTOCENTRY, toc_entry) == -1)
	{
	  LOGGER->Log("Problem during CD XA TOC entry read");
	  return false;
	}
    }

  return true;
}

bool
LinuxCDXAFileDriver::ReadPrimaryVolumeDescriptor(int fd, int start_lba,
						 iso_primary_descriptor_t &primary_descriptor) const
{
  unsigned char primary_descriptor_buffer[CD_FRAMESIZE_RAW] = { 0 }; // bzero

  // Do read
  lba_to_msf(start_lba, (cdrom_msf_t &) primary_descriptor_buffer);

  if (ioctl(fd, CDROMREADRAW, primary_descriptor_buffer, primary_descriptor_buffer) == -1)
    {
      LOGGER->Log("Problem during CD XA PVD read");
      return false;
    }

  std::memcpy(&primary_descriptor,
	      primary_descriptor_buffer + CD_XA_SYNC_HEAD, // XA mode 2 form 1
	      sizeof(iso_primary_descriptor_t));

  return true;
}

bool
LinuxCDXAFileDriver::ReadFileTree(int fd, int first_track_lba, iso_primary_descriptor_t &primary_descriptor,
				  FileEntrySet &file_entries) const
{
  // Read root
  const iso_directory_record_t *root_directory_record = (iso_directory_record_t *)primary_descriptor.root_directory_record;
  const unsigned int root_extent = * (unsigned int *) &root_directory_record->extent;

  bool status = ReadDirectory(fd, first_track_lba + root_extent, *root_directory_record->length, "",
			      file_entries);

  // Read file tree
  for (FileEntrySet::iterator it(file_entries.begin()); it != file_entries.end() && status; ++it)
    if ((*it)->IsDirectory() &&
	(*it)->Name() != "." && (*it)->Name() != "..")
      status = ReadDirectory(fd, first_track_lba + (*it)->Extent(), (*it)->Size(), (*it)->Filename(),
			     file_entries);

  return status;
}


bool
LinuxCDXAFileDriver::ReadDirectory(int fd, int lba, unsigned int size, const RString &path,
				   FileEntrySet &file_entries) const
{
  int offset = 0;
  while (offset < size)
    {
      // Do read
      unsigned char raw_data[CD_FRAMESIZE_RAW] = { 0 }; // bzero

      lba_to_msf(lba, (cdrom_msf_t &) raw_data); // tricky

      if (ioctl(fd, CDROMREADRAW, raw_data, raw_data) == -1)
	{
	  LOGGER->Log("Problem during CD XA directory read");
	  return false;
	}

      unsigned char *data = raw_data + CD_XA_SYNC_HEAD; // XA mode 2 form 1

      // Process directory
      unsigned d = 0;
      while (d <= 2048 - sizeof(iso_directory_record_t)) // stay inside data frame
	{
	  iso_directory_record_t *iso_dir_rec = reinterpret_cast<iso_directory_record_t *>(data + d);
	  if (! *iso_dir_rec->length)
	    break;

	  //
	  FileEntry *file_entry = new FileEntry(path, *iso_dir_rec);
	  assert(file_entry);

	  file_entries.insert(file_entry);

	  // Next entry
	  d += *iso_dir_rec->length;
	}

      // Go to next sector, skipping padding if any (a directory
      // record cannot span on several sectors)
      offset = ((offset / 2048) + 1) * 2048;
      ++lba;
    }

  return true;
}

void // Never fail
LinuxCDXAFileDriver::Unmount()
{
  // Close file
  if (fd_ != -1)
    ::close(fd_);

  // Deep clean file entries (safe construction)
  FileEntrySet::iterator e(file_entries_.begin());
  while (e != file_entries_.end())
    {
      FileEntrySet::iterator curr(e);
      ++e;

      FileEntry *entry = *curr;
      file_entries_.erase(curr); // Constant time
      delete entry;
    }

  // Deep clean table of content
  for (std::vector<cdrom_tocentry_t *>::iterator
	 t(toc_entries_.begin()); t != toc_entries_.end(); ++t)
    {
      delete *t;
      *t = 0;
    }
}

// ----------------------------------------------------------------------------

LinuxCDXAFileDriver::FileEntry *
LinuxCDXAFileDriver::Find(const RString &path, const RString &name)
{
  FileEntry dumb(path, name);

  FileEntrySet::iterator e(file_entries_.find(&dumb));
  if (e != file_entries_.end())
    return *e;

  return 0;
}

LinuxCDXAFileDriver::FileEntry *
LinuxCDXAFileDriver::Find(const RString &filename)
{
  const unsigned int slash = filename.find_last_of('/');
  if (slash < filename.size())
    {
      const std::string path(filename, 0, slash);
      const std::string name(filename, slash + 1);
      return Find(RString(path), RString(name));
    }

  return 0;
}

// ----------------------------------------------------------------------------

std::ostream &
LinuxCDXAFileDriver::print(std::ostream &os)
{
  for (FileEntrySet::iterator
	 it(file_entries_.begin()); it != file_entries_.end(); ++it)
    {
      if ((*it)->IsDirectory())
	{
	  if ((*it)->Name() != "." && (*it)->Name() != "..")
	    continue;

	  os << "dr-xr-xr-x\t";
	}
      else
	os << "-r-xr-xr-x\t";

      os << (*it)->Size() << "\t" << (*it)->Filename() << std::endl;
    }

  return os;
}

// ----------------------------------------------------------------------------

LinuxCDXAFileDriver::
FileEntry::FileEntry(const RString &path,
		     iso_directory_record_t &dir_record):
  path_(path),
  dir_record_(dir_record),
  name_(iso_translate_name(RString(dir_record.name, *dir_record.name_len)))
{
}

LinuxCDXAFileDriver::
FileEntry::FileEntry(const RString &path, const RString &name):
  path_(path),
  name_(name)
{
}
