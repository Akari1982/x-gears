// $Id: MapFile.cpp 86 2006-10-23 21:44:13Z einherjar $

#include <cassert>
#include <iostream>

#include "../../common/display/math/Vector.h"
#include "../../common/display/math/VectorMath.h"
#include "../../common/display/math/Box.h"
#include "../../common/display/StaticMesh.h"

#include "../filesystem/GameFileSystem.h"
#include "../filesystem/FileStream.h"
#include "../filetypes/LzsFile.h"

#include "MapFile.h"
#include "WorldMesh.h"
#include "WorldCell.h"
#include "WorldMap.h"

//
MapFile::MapFile(const RString &path):
  mPath(path)
{
}

//
WorldMap *
MapFile::Read() const
{
  return ReadMap(mPath, 7, 9, 5);
}

static unsigned int sizeof_cell = 0xB800;

WorldMap *
MapFile::ReadMap(const RString &path, unsigned int nb_rows, unsigned int nb_cols, unsigned int nb_sup) const
{
  // Read map's cells
  WorldCellVector cells;

  uint8_t *cell_data=new uint8_t[sizeof_cell];
  const unsigned int nb_cells = nb_rows * nb_cols;
  for (unsigned int c = 0; c < nb_cells; ++c)
    if (GAMEFILESYSTEM->ReadFile(path, cell_data, c * sizeof_cell, sizeof_cell))
      {
	const unsigned int cell_tx = (c % nb_cols) * 4 * 8192;
	const unsigned int cell_tz = (c / nb_cols) * 4 * 8192;

	WorldCell *world_cell = ReadCell(cell_data, Vector3(cell_tx, 0.0, cell_tz));
	assert(world_cell);

	cells.push_back(world_cell);
      } // FIXME: else report failure

  // FIXME: Read supplementary cells, if any
  WorldCellVector supplementary_cells;

  delete cell_data;
  //
  return new WorldMap(cells, nb_rows, nb_cols,
		      supplementary_cells);
}

WorldCell *
MapFile::ReadCell(uint8_t *cell_data, const Vector3 &cell_translation) const
{
  // Read pointers to compressed meshes
  unsigned int compressed_mesh_offsets[17];
  for (unsigned int m = 0, i = 0; m < 16; ++m, i += 4)
    compressed_mesh_offsets[m] = cell_data[i] + 256 * (cell_data[i + 1] + 256 * (cell_data[i + 2] + 256 * cell_data[i + 3]));
  compressed_mesh_offsets[16] = sizeof_cell;

  // Read/uncompress meshes
  WorldMeshVector meshes;
  meshes.reserve(16);
  for (unsigned int c = 0; c < 16; ++c) // There are 4 * 4 meshes by cell
    {
      const unsigned int compressed_mesh_size = compressed_mesh_offsets[c + 1] - compressed_mesh_offsets[c];

      const unsigned int tx = (c % 4) * 8192;
      const unsigned int tz = (c / 4) * 8192;

      LzsFile lzsf(cell_data + compressed_mesh_offsets[c], 0, compressed_mesh_size);

      WorldMesh *world_mesh = ReadMesh(lzsf, Vector3(tx, 0.0, tz));
      assert(world_mesh);

      meshes.push_back(world_mesh);
    }

  return new WorldCell(meshes, cell_translation);
}

// Triangle as recorded in a .MAP file
class MapTriangle
{
public:
  MapTriangle():
    mV0(0), mV1(0), mV2(0),
    mWalk(0),
    mTexU0(0), mTexV0(0),
    mTexU1(0), mTexV1(0),
    mTexU2(0), mTexV2(0),
    mTexture(0)
  {}

  MapTriangle(uint8_t v0, uint8_t v1, uint8_t v2,
	      uint8_t walk,
	      uint8_t tu0, uint8_t tv0,
	      uint8_t tu1, uint8_t tv1,
	      uint8_t tu2, uint8_t tv2,
	      uint16_t texture):
    mV0(v0), mV1(v1), mV2(v2),
    mWalk(walk),
    mTexU0(tu0), mTexV0(tv0),
    mTexU1(tu1), mTexV1(tv1),
    mTexU2(tu2), mTexV2(tv2),
    mTexture(texture)
  {}

public:
  inline uint8_t GetVertexIdx(unsigned int v) const
  {
    switch (v)
      {
      case 0: return mV0;
      case 1: return mV1;
      case 2: return mV2;
      default: assert(0); break;
      };

    return 0;
  }

  inline Vector2 GetVertexUV(unsigned int v) const
  {
    switch (v)
      {
      case 0: return Vector2(mTexU0, mTexV0);
      case 1: return Vector2(mTexU1, mTexV1);
      case 2: return Vector2(mTexU2, mTexV2);
      default: assert(0); break;
      };
      
    return Vector2();
  }

  // Topology
protected:
  uint8_t mV0;
  uint8_t mV1;
  uint8_t mV2;

  // Attributes
protected:
  uint8_t mWalk;

  uint8_t mTexU0;
  uint8_t mTexV0;

  uint8_t mTexU1;
  uint8_t mTexV1;

  uint8_t mTexU2;
  uint8_t mTexV2;

  uint16_t mTexture;
};

WorldMesh *
MapFile::ReadMesh(LzsFile &lzsf, const Vector3 &mesh_translation) const
{
  typedef FileStream<LzsFile> LzsStream;
  LzsStream lzss(lzsf);

  // Header
  const unsigned int nb_triangles = lzss.GetU16LE();
  const unsigned int nb_vertices = lzss.GetU16LE();

  // Read triangle records
//   std::vector<MapTriangle> triangles;
  unsigned int *triangles_vertices = new unsigned int[nb_triangles * 3];
  for (unsigned int t = 0; t < nb_triangles; ++t)
    {
      const uint8_t v0 = lzss.GetU8();
      const uint8_t v1 = lzss.GetU8();
      const uint8_t v2 = lzss.GetU8();

      const uint8_t walkmap_status = lzss.GetU8();

      const uint8_t tex_u_0 = lzss.GetU8();
      const uint8_t tex_v_0 = lzss.GetU8();

      const uint8_t tex_u_1 = lzss.GetU8();
      const uint8_t tex_v_1 = lzss.GetU8();

      const uint8_t tex_u_2 = lzss.GetU8();
      const uint8_t tex_v_2 = lzss.GetU8();

      const uint16_t texture = lzss.GetU16LE();

      // Create triangle
//       triangles[t] = MapTriangle(v0, v1, v2,
// 				 walkmap_status,
// 				 tex_u_0, tex_v_0,
// 				 tex_u_1, tex_v_1,
// 				 tex_u_2, tex_v_2,
// 				 texture);

      const unsigned int t3 = t * 3;
      triangles_vertices[t3    ] = v0;
      triangles_vertices[t3 + 1] = v1;
      triangles_vertices[t3 + 2] = v2;
    }

  //
  Box3 bounding_box;

  // Read vertices records
//   std::vector<Vertex> vertices(nb_vertices);
  // - coordinates
  float *coords = new float[nb_vertices * 3];
  for (unsigned int v = 0; v < nb_vertices; ++v)
    {
      const int16_t x = lzss.GetS16LE();
      const int16_t y = lzss.GetS16LE();
      const int16_t z = lzss.GetS16LE();
      const int16_t w = lzss.GetS16LE();

//       vertices[v].p.x = float(x);
//       vertices[v].p.y = float(y);
//       vertices[v].p.z = float(z);

      const unsigned int v3 = v * 3;
      coords[v3    ] = float(x);
      coords[v3 + 1] = float(y);
      coords[v3 + 2] = float(z);

      //
      bounding_box.Insert(Vector3(coords[v3], coords[v3 + 1], coords[v3 + 2]));
    }
  // - normals
  float *normals = new float[nb_vertices * 3];
  for (unsigned int v = 0; v < nb_vertices; ++v)
    {
      const int16_t nx = lzss.GetU16LE();
      const int16_t ny = lzss.GetU16LE();
      const int16_t nz = lzss.GetU16LE();
      const int16_t nw = lzss.GetU16LE();

      Vector3 normal(nx, ny, nz);
      Vector3Normalize(normal, normal);

//       vertices[v].n = normal;

      const unsigned int v3 = v * 3;
      normals[v3    ] = normal.x;
      normals[v3 + 1] = normal.y;
      normals[v3 + 2] = normal.z;
    }

  // <<
  // float *tex_coords = new float[nb_vertices * 2];
  
  StaticMesh *mesh = new StaticMesh(nb_vertices, coords, 0, 0, 0, // normals, 0, tex_coords,
				    nb_triangles, triangles_vertices);
  assert(mesh);
  // >>

  // Reconstruct geometry
  WorldMesh *world_mesh = new WorldMesh(mesh_translation, bounding_box,
					mesh);
  assert(world_mesh);

//   // FIXME: sort by texture, and output triangle meshes _by texture_
//   world_mesh->GetGeometry().triangles.push_back(Geometry());
//   Geometry &geometry = * world_mesh->GetGeometry().triangles.begin();
//
//   for (std::vector<MapTriangle>::iterator t = triangles.begin(); t != triangles.end(); ++t)
//     for (unsigned int i = 0; i < 3; ++i)
//       {
// 	Vertex v = vertices[ t->GetVertexIdx(i) ];
// 	v.t = t->GetVertexUV(i);
// 	// v.c.r = 1.0; v.c.g = 1.0; v.c.b = 1.0; v.c.a = 1.0;
// 	geometry.vertexes.push_back(v);
//       }

  return world_mesh;
}
