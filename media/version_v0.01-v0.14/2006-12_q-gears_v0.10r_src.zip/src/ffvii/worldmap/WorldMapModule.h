// $Id: WorldMapModule.h 117 2006-12-15 21:10:57Z crazy_otaku $

#ifndef WORLD_MAP_MODULE_h
#define WORLD_MAP_MODULE_h

#include "../../common/display/actor/Actor.h"
#include "../../common/display/math/Vector.h"

class WorldMap;


class WorldMapModule : public Actor
{
public:
  WorldMapModule();
  virtual ~WorldMapModule();

public:
  virtual void Init();

  virtual void Draw();

  virtual void Input(const InputEvent& input);

  virtual void Update(const Uint32 deltaTime);

  // Geometry
protected:
  WorldMap *mWorldMap;

  // Camera
protected:
  Vector3 mTranslation;
  float mScale;
};

#endif //  WORLD_MAP_MODULE_h
