// $Id$

#include "WorldCell.h"

WorldCell::~WorldCell()
{
  for (WorldMeshVector::iterator m = mMeshes.begin(); m != mMeshes.end(); ++m)
    delete *m;
  mMeshes.clear();
}
