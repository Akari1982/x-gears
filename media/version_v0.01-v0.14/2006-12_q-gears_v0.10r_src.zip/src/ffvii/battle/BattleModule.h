// $Id: BattleModule.h 117 2006-12-15 21:10:57Z crazy_otaku $

#ifndef BATTLE_MODULE_h
#define BATTLE_MODULE_h

#include "../../common/display/actor/Actor.h"



class BattleModule : public Actor
{
public:
    BattleModule(void);

    virtual ~BattleModule(void);

    virtual void Init(void);

    virtual void Draw(void);

    virtual void Input(const InputEvent& input);

    virtual void Update(const Uint32 deltaTime);

    // we cant give id by reference because we may delete caller when clear map resources.
    void LoadBattle(const u16 id);

private:
    u16 mBattleId;
};



#endif // BATTLE_MODULE_h
