// $Id: BattleModule.cpp 117 2006-12-15 21:10:57Z crazy_otaku $

#include "../../common/display/Display.h"
#include "../../common/module/ModuleManager.h"
#include "../../common/utilites/Logger.h"

#include "BattleModule.h"
#include "../field/FieldModule.h"
#include "../kernel/Kernel.h"




BattleModule::BattleModule(void):
    mBattleId(0)
{
    Init();
}



BattleModule::~BattleModule(void)
{
}



void
BattleModule::Init()
{
}



void
BattleModule::Input(const InputEvent& input)
{
    switch (input.button)
    {
        case KEY_Cx:
        {
            MODULEMAN->PopTopModule();
            break;
        }
    }
}



void
BattleModule::Update(const Uint32 deltaTime)
{
}



void
BattleModule::Draw(void)
{
    RString string;
    string.Format("Placeholder for Battle module.\nLoad battle %d.\nPress X to continue.", mBattleId);
    KERNEL->DrawString(RStringToFFVIIString(string), 300, 100, F_WHITE);
}



void
BattleModule::LoadBattle(const u16 id)
{
    mBattleId = id;
}
