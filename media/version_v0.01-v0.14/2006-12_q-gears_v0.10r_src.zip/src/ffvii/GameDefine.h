// $Id: GameDefine.h 117 2006-12-15 21:10:57Z crazy_otaku $

#ifndef GAME_DEFINE_H
#define GAME_DEFINE_H



#define APPLICATION_NAME "FFVII v0.10"



#endif // GAME_DEFINE_H
