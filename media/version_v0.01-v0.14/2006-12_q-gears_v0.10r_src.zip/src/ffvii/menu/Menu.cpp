// $Id: Menu.cpp 117 2006-12-15 21:10:57Z crazy_otaku $

#include "Menu.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

Menu::Menu(void)
{
    Init();
}



Menu::~Menu(void)
{
}



//============================= OPERATIONS ===================================

void
Menu::Init(void)
{
}



void
Menu::Draw(void)
{
}



void
Menu::Input(const InputEvent &input)
{
}



void
Menu::Update(const Uint32 deltaTime)
{
}
