// $Id: DisplayTest.h 117 2006-12-15 21:10:57Z crazy_otaku $

#ifndef SCREENDISPLAYTEST_H
#define SCREENDISPLAYTEST_H

#include <vector>

#include "../../common/TypeDefine.h"
#include "../../common/display/3dTypes.h"
#include "../../common/display/actor/Actor.h"



class ScreenDisplayTest : public Actor
{
public:
    ScreenDisplayTest();
    virtual ~ScreenDisplayTest();

    virtual void Init();

    virtual void Input(const InputEvent &input);

    virtual void Update(const Uint32 delta_time);

    virtual void Draw();

private:
    int                 mRotation;
    int                 mTexId;

    std::vector<Vertex> mPoints;
    TotalGeometry       mPyramid;
    Geometry            mQuadsTex;
};



#endif // SCREENDISPLAYTEST_H
