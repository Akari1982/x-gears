// $Id: GameState.h 115 2006-12-15 21:05:15Z crazy_otaku $

#ifndef GAMESTATE_H
#define GAMESTATE_H
// The Gamestate Class : Contain all info about current game state

#include "../../common/display/3dTypes.h"
#include "../../common/utilites/NoCopy.h"

#include "Savemap.h"
#include "gui/FFVIIString.h"



// forward declaration
class Kernel;
class MemoryBank;



class Gamestate : public NoCopy<Gamestate>
{
    friend class Kernel;
    friend class MemoryBank;

public:
                       Gamestate(void);
    virtual           ~Gamestate(void);

    const Savemap&     GetSavemap(void) const;
    void               DumpSavemap(void);



    // memory bank handling
    void               MemoryBankPut(const u8& memoryBank, const u8& offset, const u8& value);
    void               MemoryBankPut(const u8& memoryBank, const u8& offset, const u16& value);
    u8                 MemoryBankGet(const u8& memoryBank, const u8& offset);
    u16                MemoryBankGet(const u8& memoryBank, const u16& offset);

    // map
    const u16&         CurrentFieldGet(void);
    void               CurrentFieldSet(const u16& currentMap);
    FFVIIString        CurrentFieldNameGet(void);
    void               CurrentFieldNameSet(FFVIIString name);

    // party
    void               PartyCharacterAdd(const u8& ubCharacter);
    void               PartyCharactersAdd(const u8& ubCharacter1, const u8& ubCharacter2, const u8& ubCharacter3);

    // player
    const Vector3&     PlayerPositionGet(void);
    void               PlayerPositionSet(const Vector3& coord);
    const bool&        PlayerPositionIsSet(void);
    void               PlayerPositionUnset(void);
    const u16&         PlayerTriangleGet(void);
    void               PlayerTriangleSet(const u16& triangle);
    const bool&        PlayerTriangleIsSet(void);
    void               PlayerTriangleUnset(void);


    // timer
    void               TimerStart(void);
    void               TimerStop(void);

    // battle
    const bool&        BattleLockGet(void);
    void               BattleLockSet(const bool& lock);



    void               Update(void);

private:
    ////////////////////////////////////////////////
    // global values
    Savemap                       mSavemap;

    // game timer
    bool                          mTimerStarted;

    // don't know where in the save map this can be.
    // so this is temp placement
    bool                          mBattleLock;
    ////////////////////////////////////////////////



    ////////////////////////////////////////////////
    // field module
    // temp memory bank 5/6
    u8*                           mpMemoryBank56;

    // player unit stats
    Vector3                       mPlayerPosition;
    bool                          mPlayerPositionSet;
    u16                           mPlayerTriangle;
    bool                          mPlayerTriangleSet;
    ////////////////////////////////////////////////
};



#endif // GAMESTATE_H
