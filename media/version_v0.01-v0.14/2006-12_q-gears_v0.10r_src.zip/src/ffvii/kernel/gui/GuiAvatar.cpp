// $Id: GuiAvatar.cpp 115 2006-12-15 21:05:15Z crazy_otaku $

#include "../../../common/display/3dTypes.h"
#include "../../../common/display/Display.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/Logger.h"

#include "GuiAvatar.h"
#include "../../filetypes/TimFile.h"



GuiAvatar::GuiAvatar()
{
    mAvatarTexId[ 0] = LoadAvatar("MENU/CLOUD.TIM");
    mAvatarTexId[ 1] = LoadAvatar("MENU/BARRE.TIM");
    mAvatarTexId[ 2] = LoadAvatar("MENU/TIFA.TIM");
    mAvatarTexId[ 3] = LoadAvatar("MENU/EARITH.TIM");
    mAvatarTexId[ 4] = LoadAvatar("MENU/RED.TIM");
    mAvatarTexId[ 5] = LoadAvatar("MENU/YUFI.TIM");
    mAvatarTexId[ 6] = LoadAvatar("MENU/KETC.TIM");
    mAvatarTexId[ 7] = LoadAvatar("MENU/BINS.TIM");
    mAvatarTexId[ 8] = LoadAvatar("MENU/CIDO.TIM");
    mAvatarTexId[ 9] = LoadAvatar("MENU/PCLOUD.TIM");
    mAvatarTexId[10] = LoadAvatar("MENU/PCEFI.TIM");
    mAvatarTexId[11] = LoadAvatar("MENU/CHOCO.TIM");



    Vertex point;
    point.p.x = 0.0f;  point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f;  point.t.y = 0.0f;
    mAvatarPoly.vertexes.push_back(point);
    point.p.x = 64.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 0.0f;
    mAvatarPoly.vertexes.push_back(point);
    point.p.x = 64.0f; point.p.y = -64.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 1.0f;
    mAvatarPoly.vertexes.push_back(point);
    point.p.x = 0.0f;  point.p.y = -64.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a =  1.0f;
    point.t.x = 0.0f;  point.t.y = 1.0f;
    mAvatarPoly.vertexes.push_back(point);
}



int
GuiAvatar::LoadAvatar(const RString &name)
{
    int ret = 0;

    TimFile* image;
    Surface* texture = NULL;

    // Cloud
    image = new TimFile(name);
    texture = image->GetSurface(0);
    delete image;

    if (texture != NULL)
    {
        SetSurfaceSize(texture, 64, 64);
        ret = DISPLAY->CreateTexture(texture);
        delete texture;
    }
    else
    {
        LOGGER->Log("Can't load avatar %s.", name.c_str());
    }

    return ret;
}



GuiAvatar::~GuiAvatar()
{
    for (int i = 0; i < 12; ++i)
    {
        DISPLAY->DeleteTexture(mAvatarTexId[i]);
    }
}



void
GuiAvatar::DrawAvatar(const int &x, const int &y, const unsigned char &avatar_id)
{
    DISPLAY->PushMatrix();
    DISPLAY->Translate(x, -y, 0);

    if (avatar_id < 12)
    {
        DISPLAY->SetTexture(mAvatarTexId[avatar_id]);
        DISPLAY->DrawQuads(mAvatarPoly);
        DISPLAY->UnsetTexture();
    }
    else
    {
        LOGGER->Log("Unidentify avatar id %d.", avatar_id);
    }

    DISPLAY->PopMatrix();
}
