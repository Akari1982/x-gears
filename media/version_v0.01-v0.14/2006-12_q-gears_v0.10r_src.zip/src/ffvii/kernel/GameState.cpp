// $Id: GameState.cpp 115 2006-12-15 21:05:15Z crazy_otaku $

#include <memory.h>

#include "GameState.h"
#include "Savemap.h"
#include "../../common/utilites/Logger.h"



Gamestate::Gamestate():
    ////////////////////////////////////////////////
    // global values
    mTimerStarted(false),
    mBattleLock(false),



    ////////////////////////////////////////////////
    // field module
    mpMemoryBank56(NULL),

    mPlayerPositionSet(false),
    mPlayerTriangleSet(false)
{
    mpMemoryBank56 = (u8*)malloc(sizeof(u8) * 256);
}



Gamestate::~Gamestate()
{
    free(mpMemoryBank56);
}



const Savemap&
Gamestate::GetSavemap() const
{
    return mSavemap;
}



void
Gamestate::DumpSavemap()
{
    LOGGER->Log("Checksum: %08x\n\n", mSavemap.Checksum);

    LOGGER->Log("Preview\n");

    LOGGER->Log("PreviewLeadCharacterLevel: %d", mSavemap.PreviewLeadCharacterLevel);
    LOGGER->Log("PreviewLeadCharacterPortrait: %02x", mSavemap.PreviewLeadCharacterPortrait);
    LOGGER->Log("PreviewSecondCharacterPortrait: %02x", mSavemap.PreviewSecondCharacterPortrait);
    LOGGER->Log("PreviewThirdCharacterPortrait: %02x", mSavemap.PreviewThirdCharacterPortrait);
    LOGGER->Log("PreviewLeadCharacterName[16] --- skip");
    LOGGER->Log("PreviewLeadCharacterCurrentHP: %d", mSavemap.PreviewLeadCharacterCurrentHP);
    LOGGER->Log("PreviewLeadCharacterMaxHP: %d", mSavemap.PreviewLeadCharacterMaxHP);
    LOGGER->Log("PreviewLeadCharacterCurrentMP: %d", mSavemap.PreviewLeadCharacterCurrentMP);
    LOGGER->Log("PreviewLeadCharacterMaxMP: %d", mSavemap.PreviewLeadCharacterMaxMP);
    LOGGER->Log("PreviewGilAmount: %d", mSavemap.PreviewGilAmount);
    LOGGER->Log("PreviewPlayedSeconds: %d", mSavemap.PreviewPlayedSeconds);
    LOGGER->Log("PreviewCurrentLocationName[32] --- skip\n\n");

    LOGGER->Log("Window RGB\n\n");

    LOGGER->Log("Character Record\n");
    for (int i = 0; i < 9; ++i)
    {
        switch (i)
        {
            case 0: LOGGER->Log("Cloud\n");  break;
            case 1: LOGGER->Log("Barret\n"); break;
            case 2: LOGGER->Log("Tifa\n"); break;
            case 3: LOGGER->Log("Aeris\n"); break;
            case 4: LOGGER->Log("RedXIII\n"); break;
            case 5: LOGGER->Log("Yuffie\n"); break;
            case 6: LOGGER->Log("CaitSith\n"); break;
            case 7: LOGGER->Log("Vinsent\n"); break;
            case 8: LOGGER->Log("Cid\n"); break;
        }

        LOGGER->Log("Id: %02x", mSavemap.Character[i].Id);
        LOGGER->Log("Level: %d", mSavemap.Character[i].Level);
        LOGGER->Log("Strength: %d", mSavemap.Character[i].Strength);
        LOGGER->Log("Vitality: %d", mSavemap.Character[i].Vitality);
        LOGGER->Log("Magic: %d", mSavemap.Character[i].Magic);
        LOGGER->Log("Spirit: %d", mSavemap.Character[i].Spirit);
        LOGGER->Log("Dexterity: %d", mSavemap.Character[i].Dexterity);
        LOGGER->Log("Luck: %d", mSavemap.Character[i].Luck);
        LOGGER->Log("StrengthBonus: %d", mSavemap.Character[i].StrengthBonus);
        LOGGER->Log("VitalityBonus: %d", mSavemap.Character[i].VitalityBonus);
        LOGGER->Log("MagicBonus: %d", mSavemap.Character[i].MagicBonus);
        LOGGER->Log("SpiritBonus: %d", mSavemap.Character[i].SpiritBonus);
        LOGGER->Log("DexterityBonus: %d", mSavemap.Character[i].DexterityBonus);
        LOGGER->Log("LuckBonus: %d", mSavemap.Character[i].LuckBonus);
        LOGGER->Log("CurrentLimitLevel: %d", mSavemap.Character[i].CurrentLimitLevel);
        LOGGER->Log("CurrentLimitBar: %d", mSavemap.Character[i].CurrentLimitBar);
        LOGGER->Log("Name --- skip");
        LOGGER->Log("EquippedWeapon: %02x", mSavemap.Character[i].EquippedWeapon);
        LOGGER->Log("EquippedArmor: %02x", mSavemap.Character[i].EquippedArmor);
        LOGGER->Log("EquippedAccessory: %02x", mSavemap.Character[i].EquippedAccessory);
        LOGGER->Log("StatusFlags: %02x", mSavemap.Character[i].StatusFlags);
        LOGGER->Log("RowFlags: %02x", mSavemap.Character[i].RowFlags);
        LOGGER->Log("LevelProgressBar: %02x", mSavemap.Character[i].LevelProgressBar);
        LOGGER->Log("LearnedLimitSkills: %04x", mSavemap.Character[i].LearnedLimitSkills);
        LOGGER->Log("NumberOfKills: %d", mSavemap.Character[i].NumberOfKills);
        LOGGER->Log("TimesUsedLimit11: %d", mSavemap.Character[i].TimesUsedLimit11);
        LOGGER->Log("TimesUsedLimit21: %d", mSavemap.Character[i].TimesUsedLimit21);
        LOGGER->Log("TimesUsedLimit31: %d", mSavemap.Character[i].TimesUsedLimit31);
        LOGGER->Log("CurrentHP: %d", mSavemap.Character[i].CurrentHP);
        LOGGER->Log("BaseHP: %d", mSavemap.Character[i].BaseHP);
        LOGGER->Log("CurrentMP: %d", mSavemap.Character[i].CurrentMP);
        LOGGER->Log("BaseMP: %d", mSavemap.Character[i].BaseMP);
        LOGGER->Log("Unknown1[4]: %02x %02x %02x %02x", mSavemap.Character[i].Unknown1[0], mSavemap.Character[i].Unknown1[1], mSavemap.Character[i].Unknown1[2], mSavemap.Character[i].Unknown1[3]);
        LOGGER->Log("MaximumHP: %d", mSavemap.Character[i].MaximumHP);
        LOGGER->Log("MaximumMP: %d", mSavemap.Character[i].MaximumMP);
        LOGGER->Log("CurrentEXP: %d", mSavemap.Character[i].CurrentEXP);
        LOGGER->Log("WeaponMateriaSlot: %08x %08x %08x %08x %08x %08x %08x %08x", mSavemap.Character[i].WeaponMateriaSlot1, mSavemap.Character[i].WeaponMateriaSlot2, mSavemap.Character[i].WeaponMateriaSlot3, mSavemap.Character[i].WeaponMateriaSlot4, mSavemap.Character[i].WeaponMateriaSlot5, mSavemap.Character[i].WeaponMateriaSlot6, mSavemap.Character[i].WeaponMateriaSlot7, mSavemap.Character[i].WeaponMateriaSlot8);
        LOGGER->Log("ArmorMateriaSlot: %08x %08x %08x %08x %08x %08x %08x %08x", mSavemap.Character[i].ArmorMateriaSlot1, mSavemap.Character[i].ArmorMateriaSlot2, mSavemap.Character[i].ArmorMateriaSlot3, mSavemap.Character[i].ArmorMateriaSlot4, mSavemap.Character[i].ArmorMateriaSlot5, mSavemap.Character[i].ArmorMateriaSlot6, mSavemap.Character[i].ArmorMateriaSlot7, mSavemap.Character[i].ArmorMateriaSlot8);
        LOGGER->Log("NextLevelEXP: %d\n\n", mSavemap.Character[i].NextLevelEXP);
    }

    LOGGER->Log("Slot1Char: %02x", mSavemap.Slot1Char);
    LOGGER->Log("Slot2Char: %02x", mSavemap.Slot2Char);
    LOGGER->Log("Slot3Char: %02x", mSavemap.Slot3Char);

    LOGGER->Log("GilAmount: %d", mSavemap.GilAmount);
    LOGGER->Log("PlayedSeconds: %d", mSavemap.PlayedSeconds);
    LOGGER->Log("Unknown2[16]: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x", mSavemap.Unknown2[0], mSavemap.Unknown2[1], mSavemap.Unknown2[2], mSavemap.Unknown2[3], mSavemap.Unknown2[4], mSavemap.Unknown2[5], mSavemap.Unknown2[6], mSavemap.Unknown2[7], mSavemap.Unknown2[8], mSavemap.Unknown2[9], mSavemap.Unknown2[10], mSavemap.Unknown2[11], mSavemap.Unknown2[12], mSavemap.Unknown2[13], mSavemap.Unknown2[14], mSavemap.Unknown2[15]);
    LOGGER->Log("CurrentMap: %d", mSavemap.CurrentMap);
    LOGGER->Log("CurrentField: %d", mSavemap.CurrentField);
    LOGGER->Log("Unknown3[2]: %02x %02x", mSavemap.Unknown3[0], mSavemap.Unknown3[1]);
    LOGGER->Log("MapLocationX: %d", mSavemap.MapLocationX);
    LOGGER->Log("MapLocationY: %d", mSavemap.MapLocationY);
    LOGGER->Log("MapLocationZ: %d", mSavemap.MapLocationZ);
    LOGGER->Log("Unknown4[4]: %02x %02x %02x %02x", mSavemap.Unknown4[0], mSavemap.Unknown4[1], mSavemap.Unknown4[2], mSavemap.Unknown4[3]);

    LOGGER->Log("\n\nConfig\n");

    LOGGER->Log("BattleSpeed: %02x", mSavemap.BattleSpeed);
    LOGGER->Log("BattleMessageSpeed: %02x", mSavemap.BattleMessageSpeed);
    LOGGER->Log("GeneralConfiguration: %04x", mSavemap.GeneralConfiguration);
    LOGGER->Log("UnknownFE[16]: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x", mSavemap.UnknownFE[0], mSavemap.UnknownFE[1], mSavemap.UnknownFE[2], mSavemap.UnknownFE[3], mSavemap.UnknownFE[4], mSavemap.UnknownFE[5], mSavemap.UnknownFE[6], mSavemap.UnknownFE[7], mSavemap.UnknownFE[8], mSavemap.UnknownFE[9], mSavemap.UnknownFE[10], mSavemap.UnknownFE[11], mSavemap.UnknownFE[12], mSavemap.UnknownFE[13], mSavemap.UnknownFE[14], mSavemap.UnknownFE[15]);
    LOGGER->Log("MessageSpeed: %02x", mSavemap.MessageSpeed);
    LOGGER->Log("UnknownFF[7]: %02x %02x %02x %02x %02x %02x %02x", mSavemap.UnknownFF[0], mSavemap.UnknownFF[1], mSavemap.UnknownFF[2], mSavemap.UnknownFF[3], mSavemap.UnknownFF[4], mSavemap.UnknownFF[5], mSavemap.UnknownFF[6]);
}



void
Gamestate::MemoryBankPut(const u8& memoryBank, const u8& offset, const u8& value)
{
    switch (memoryBank)
    {
        // savemap bank
        case 0x1 : case 0x2 : mSavemap.MemoryBank12[offset] = value; break;
        case 0x3 : case 0x4 : mSavemap.MemoryBank34[offset] = value; break;
        case 0x7 : case 0xF : mSavemap.MemoryBank7F[offset] = value; break;
        case 0xB : case 0xC : mSavemap.MemoryBankBC[offset] = value; break;
        case 0xD : case 0xE : mSavemap.MemoryBankDE[offset] = value; break;
        // temp bank
        case 0x5 : case 0x6 : mpMemoryBank56[offset] = value;                               break;
    }
}



void
Gamestate::MemoryBankPut(const u8& memoryBank, const u8& offset, const u16& value)
{
    if (offset == 255)
    {
        LOGGER->Log("Try to put u16 value in last byte in MemoryBank::Put();.");
        return;
    }

    u8 lower = static_cast<u8>(value & 0x00FF);
    u8 upper = static_cast<u8>(value >> 8);

    switch (memoryBank)
    {
        // savemap bank
        case 0x1 : case 0x2 : mSavemap.MemoryBank12[offset] = lower;
                              mSavemap.MemoryBank12[offset + 1] = upper; break;
        case 0x3 : case 0x4 : mSavemap.MemoryBank34[offset] = lower;
                              mSavemap.MemoryBank34[offset + 1] = upper; break;
        case 0x7 : case 0xF : mSavemap.MemoryBank7F[offset] = lower;
                              mSavemap.MemoryBank7F[offset + 1] = upper; break;
        case 0xB : case 0xC : mSavemap.MemoryBankBC[offset] = lower;
                              mSavemap.MemoryBankBC[offset + 1] = upper; break;
        case 0xD : case 0xE : mSavemap.MemoryBankDE[offset] = lower;
                              mSavemap.MemoryBankDE[offset + 1] = upper; break;
        // temp bank
        case 0x5 : case 0x6 : mpMemoryBank56[offset] = lower;
                              mpMemoryBank56[offset + 1] = upper;                               break;
    }
}



u8
Gamestate::MemoryBankGet(const u8& memoryBank, const u8& offset)
{
    u8 ret = 0;

    switch (memoryBank)
    {
        // savemap bank
        case 0x1 : case 0x2 : ret = mSavemap.MemoryBank12[offset]; break;
        case 0x3 : case 0x4 : ret = mSavemap.MemoryBank34[offset]; break;
        case 0x7 : case 0xF : ret = mSavemap.MemoryBank7F[offset]; break;
        case 0xB : case 0xC : ret = mSavemap.MemoryBankBC[offset]; break;
        case 0xD : case 0xE : ret = mSavemap.MemoryBankDE[offset]; break;
        // temp bank
        case 0x5 : case 0x6 : ret = mpMemoryBank56[offset];                                   break;
        // immediate value
        case 0x0 : ret = offset;
    }

    return ret;
}



u16
Gamestate::MemoryBankGet(const u8& memoryBank, const u16& offset)
{
    u16 ret = 0;

    if (memoryBank != 0 && offset == 255)
    {
        LOGGER->Log("Try to get u16 value from last byte in MemoryBank::Get();.");
        return ret;
    }

    u16 lower = 0;
    u16 upper = 0;

    switch (memoryBank)
    {
        // savemap bank
        case 0x1 : case 0x2 : lower = mSavemap.MemoryBank12[offset];
                              upper = mSavemap.MemoryBank12[offset + 1]; break;
        case 0x3 : case 0x4 : lower = mSavemap.MemoryBank34[offset];
                              upper = mSavemap.MemoryBank34[offset + 1]; break;
        case 0x7 : case 0xF : lower = mSavemap.MemoryBank7F[offset];
                              upper = mSavemap.MemoryBank7F[offset + 1]; break;
        case 0xB : case 0xC : lower = mSavemap.MemoryBankBC[offset];
                              upper = mSavemap.MemoryBankBC[offset + 1]; break;
        case 0xD : case 0xE : lower = mSavemap.MemoryBankDE[offset];
                              upper = mSavemap.MemoryBankDE[offset + 1]; break;
        // temp bank
        case 0x5 : case 0x6 : lower = mpMemoryBank56[offset];
                              upper = mpMemoryBank56[offset + 1];                               break;
        // immediate value
        case 0x0 :            ret = offset;
    }

    // swap bytes
    if (upper != 0 || lower != 0)
    {
        ret = (upper << 8) | (lower);
    }

    return ret;
}



const u16&
Gamestate::CurrentFieldGet(void)
{
    return mSavemap.CurrentField;
}



void
Gamestate::CurrentFieldSet(const u16& currentMap)
{
    mSavemap.CurrentField = currentMap;
}



FFVIIString
Gamestate::CurrentFieldNameGet(void)
{
    FFVIIString location_name;

    location_name.resize(24);

    std::copy(&(mSavemap.MemoryBankDE[104]),
              &(mSavemap.MemoryBankDE[104 + 24]),
              location_name.begin());

    return location_name;
}



void
Gamestate::CurrentFieldNameSet(FFVIIString name)
{
    for (u8 i = 0; i < 24; ++i)
    {
        if (i < name.size())
        {
            mSavemap.MemoryBankDE[i + 104] = name[i];
        }
        else
        {
            mSavemap.MemoryBankDE[i + 104] = 0x00;
        }
    }
}



void
Gamestate::PartyCharacterAdd(const u8& ubCharacter)
{
    if (ubCharacter != 0xFF &&
        ubCharacter != mSavemap.Slot1Char &&
        ubCharacter != mSavemap.Slot2Char &&
        ubCharacter != mSavemap.Slot3Char)
    {
        if (mSavemap.Slot1Char == 0xFF)
        {
            mSavemap.Slot1Char = ubCharacter;
        }
        else if (mSavemap.Slot2Char == 0xFF)
        {
            mSavemap.Slot2Char = ubCharacter;
        }
        else
        {
            mSavemap.Slot3Char = ubCharacter;
        }
    }
}



void
Gamestate::PartyCharactersAdd(const u8& ubCharacter1, const u8& ubCharacter2, const u8& ubCharacter3)
{
    mSavemap.Slot1Char = (ubCharacter1 == 0xFE) ? 0xFF : ubCharacter1;
    mSavemap.Slot2Char = (ubCharacter2 == 0xFE) ? 0xFF : ubCharacter2;
    mSavemap.Slot3Char = (ubCharacter3 == 0xFE) ? 0xFF : ubCharacter3;
}



const Vector3&
Gamestate::PlayerPositionGet(void)
{
    return mPlayerPosition;
}



void
Gamestate::PlayerPositionSet(const Vector3& coord)
{
    mPlayerPosition    = coord;
    mPlayerPositionSet = true;
}



const bool&
Gamestate::PlayerPositionIsSet(void)
{
    return mPlayerPositionSet;
}



void
Gamestate::PlayerPositionUnset(void)
{
    mPlayerPositionSet = false;
}



const u16&
Gamestate::PlayerTriangleGet(void)
{
    return mPlayerTriangle;
}



void
Gamestate::PlayerTriangleSet(const u16& triangle)
{
    mPlayerTriangle    = triangle;
    mPlayerTriangleSet = true;
}



const bool&
Gamestate::PlayerTriangleIsSet(void)
{
    return mPlayerTriangleSet;
}



void
Gamestate::PlayerTriangleUnset(void)
{
    mPlayerTriangleSet = false;
}



void
Gamestate::TimerStart(void)
{
    mTimerStarted = true;
}



void
Gamestate::TimerStop(void)
{
    mTimerStarted = false;
}



const bool&
Gamestate::BattleLockGet(void)
{
    return mBattleLock;
}



void
Gamestate::BattleLockSet(const bool& lock)
{
    mBattleLock = lock;
}



void
Gamestate::Update(void)
{
    // one second pass
    static unsigned char timer = 0;
    ++timer;
    if (timer == 100)
    {
        // move game time forward
        ++mSavemap.PlayedSeconds;
        timer = 0;



        // count down timer if enabled
        if (mTimerStarted == true)
        {
            // if seconds are ended but we have minutes or hours
            if (mSavemap.MemoryBank12[0x17] == 0 && (mSavemap.MemoryBank12[0x16] != 0 || mSavemap.MemoryBank12[0x15] != 0))
            {
                // if minutes are ended but we have hours
                if (mSavemap.MemoryBank12[0x16] == 0 && mSavemap.MemoryBank12[0x15] != 0)
                {
                    --mSavemap.MemoryBank12[0x15];
                    mSavemap.MemoryBank12[0x16] = 60;
                }

                --mSavemap.MemoryBank12[0x16];
                mSavemap.MemoryBank12[0x17] = 60;
            }

            // if we have seconds to go down
            if (mSavemap.MemoryBank12[0x17] != 0)
            {
                --(mSavemap.MemoryBank12[0x17]);
            }
            // else stop timer
            else
            {
                mTimerStarted = false;
            }
        }
    }
}
