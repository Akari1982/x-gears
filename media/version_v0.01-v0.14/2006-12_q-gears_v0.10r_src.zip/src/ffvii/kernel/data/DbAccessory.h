// $Id: DbAccessory.h 98 2006-11-21 21:46:28Z einherjar $

#ifndef DBACCESSORY_H
#define DBACCESSORY_H

#include "../../../common/TypeDefine.h"

struct DBAccessory
{
    u8 Unknown[16];
};

#endif
