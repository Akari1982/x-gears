// $Id: Database.cpp 94 2006-11-12 19:44:43Z crazy_otaku $

#include "Database.h"
#include "../../common/utilites/Logger.h"



// initializing of static member
std::vector<DBCommand>   Database::mCommands;
std::vector<DBAttack>    Database::mAttacks;
std::vector<DBItem>      Database::mItems;
std::vector<DBWeapon>    Database::mWeapons;
std::vector<DBArmor>     Database::mArmors;
std::vector<DBAccessory> Database::mAccessorys;
std::vector<DBMateria>   Database::mMaterias;

std::vector<FFVIIString> Database::mCommandDescriptions;
std::vector<FFVIIString> Database::mMagicDescriptions;
std::vector<FFVIIString> Database::mItemDescriptions;
std::vector<FFVIIString> Database::mWeaponDescriptions;
std::vector<FFVIIString> Database::mArmorDescriptions;
std::vector<FFVIIString> Database::mAccessoryDescriptions;
std::vector<FFVIIString> Database::mMateriaDescriptions;
std::vector<FFVIIString> Database::mKeyItemDescriptions;
std::vector<FFVIIString> Database::mCommandNames;
std::vector<FFVIIString> Database::mMagicNames;
std::vector<FFVIIString> Database::mItemNames;
std::vector<FFVIIString> Database::mWeaponNames;
std::vector<FFVIIString> Database::mArmorNames;
std::vector<FFVIIString> Database::mAccessoryNames;
std::vector<FFVIIString> Database::mMateriaNames;
std::vector<FFVIIString> Database::mKeyItemNames;
std::vector<FFVIIString> Database::mBattleText;
std::vector<FFVIIString> Database::mSummonNames;



Database::Database()
{
    mStringNull.push_back(0xFF);
}



Database::~Database()
{
}



const DBCommand &
Database::GetCommand(const int &id) const
{
    static DBCommand null;

    if (id < mCommands.size())
    {
        return mCommands[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Command from Database with id %d.", id);
        return null;
    }
}



const DBAttack &
Database::GetAttack(const int &id) const
{
    static DBAttack null;

    if (id < mAttacks.size())
    {
        return mAttacks[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Attack from Database with id %d.", id);
        return null;
    }
}



const DBItem &
Database::GetItem(const int &id) const
{
    static DBItem null;

    if (id < mItems.size())
    {
        return mItems[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Item from Database with id %d.", id);
        return null;
    }
}



const DBWeapon &
Database::GetWeapon(const int &id) const
{
    static DBWeapon null;

    if (id < mWeapons.size())
    {
        return mWeapons[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Weapon from Database with id %d.", id);
        return null;
    }
}



const DBArmor &
Database::GetArmor(const int &id) const
{
    static DBArmor null;

    if (id < mArmors.size())
    {
        return mArmors[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Armor from Database with id %d.", id);
        return null;
    }
}



const DBAccessory &
Database::GetAccessory(const int &id) const
{
    static DBAccessory null;

    if (id < mAccessorys.size())
    {
        return mAccessorys[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Accessory from Database with id %d.", id);
        return null;
    }
}



const DBMateria &
Database::GetMateria(const int &id) const
{
    static DBMateria null;

    if (id < mMaterias.size())
    {
        return mMaterias[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Materia from Database with id %d.", id);
        return null;
    }
}



const FFVIIString &
Database::GetCommandDescription(const int &id) const
{
    if (id < mCommandDescriptions.size())
    {
        return mCommandDescriptions[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Command Description from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetMagicDescription(const int &id) const
{
    if (id < mMagicDescriptions.size())
    {
        return mMagicDescriptions[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Magic Description from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetItemDescription(const int &id) const
{
    if (id < mItemDescriptions.size())
    {
        return mItemDescriptions[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Item Description from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetWeaponDescription(const int &id) const
{
    if (id < mWeaponDescriptions.size())
    {
        return mWeaponDescriptions[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Weapon Description from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetArmorDescription(const int &id) const
{
    if (id < mArmorDescriptions.size())
    {
        return mArmorDescriptions[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Armor Description from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetAccessoryDescription(const int &id) const
{
    if (id < mAccessoryDescriptions.size())
    {
        return mAccessoryDescriptions[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Accessory Description from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetMateriaDescription(const int &id) const
{
    if (id < mMateriaDescriptions.size())
    {
        return mMateriaDescriptions[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Materia Description from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetKeyItemDescription(const int &id) const
{
    if (id < mKeyItemDescriptions.size())
    {
        return mKeyItemDescriptions[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted KeyItem Description from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetCommandName(const int &id) const
{
    if (id < mCommandNames.size())
    {
        return mCommandNames[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Command Name from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetMagicName(const int &id) const
{
    if (id < mMagicNames.size())
    {
        return mMagicNames[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Magic Name from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetItemName(const int &id) const
{
    if (id < mItemNames.size())
    {
        return mItemNames[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Item Name from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetWeaponName(const int &id) const
{
    if (id < mWeaponNames.size())
    {
        return mWeaponNames[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Weapon Name from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetArmorName(const int &id) const
{
    if (id < mArmorNames.size())
    {
        return mArmorNames[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Armor Name from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetAccessoryName(const int &id) const
{
    if (id < mAccessoryNames.size())
    {
        return mAccessoryNames[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Accessory Name from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetMateriaName(const int &id) const
{
    if (id < mMateriaNames.size())
    {
        return mMateriaNames[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Materia Name from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetKeyItemName(const int &id) const
{
    if (id < mKeyItemNames.size())
    {
        return mKeyItemNames[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted KeyItem Name from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetBattleText(const int &id) const
{
    if (id < mBattleText.size())
    {
        return mBattleText[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Battle Text from Database with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString &
Database::GetSummonName(const int &id) const
{
    if (id < mSummonNames.size())
    {
        return mSummonNames[id];
    }
    else
    {
        LOGGER->Log("Tried to get unexisted Summon Name from Database with id %d.", id);
        return mStringNull;
    }
}



const int
Database::GetSizeOfCommands() const
{
    return mCommands.size();
}



const int
Database::GetSizeOfAttacks() const
{
    return mAttacks.size();
}



const int
Database::GetSizeOfWeapons() const
{
    return mWeapons.size();
}



const int
Database::GetSizeOfArmors() const
{
    return mArmors.size();
}



const int
Database::GetSizeOfAccessorys() const
{
    return mAccessorys.size();
}



const int
Database::GetSizeOfCommandDescriptions() const
{
    return mCommandDescriptions.size();
}



const int
Database::GetSizeOfMagicDescriptions() const
{
    return mMagicDescriptions.size();
}



const int
Database::GetSizeOfItemDescriptions() const
{
    return mItemDescriptions.size();
}



const int
Database::GetSizeOfWeaponDescriptions() const
{
    return mWeaponDescriptions.size();
}



const int
Database::GetSizeOfArmorDescriptions() const
{
    return mArmorDescriptions.size();
}



const int
Database::GetSizeOfAccessoryDescriptions() const
{
    return mAccessoryDescriptions.size();
}



const int
Database::GetSizeOfMateriaDescriptions() const
{
    return mMateriaDescriptions.size();
}



const int
Database::GetSizeOfKeyItemDescriptions() const
{
    return mKeyItemDescriptions.size();
}



const int
Database::GetSizeOfCommandNames() const
{
    return mCommandNames.size();
}



const int
Database::GetSizeOfMagicNames() const
{
    return mMagicNames.size();
}



const int
Database::GetSizeOfItemNames() const
{
    return mItemNames.size();
}



const int
Database::GetSizeOfWeaponNames() const
{
    return mWeaponNames.size();
}



const int
Database::GetSizeOfArmorNames() const
{
    return mArmorNames.size();
}



const int
Database::GetSizeOfAccessoryNames() const
{
    return mAccessoryNames.size();
}



const int
Database::GetSizeOfMateriaNames() const
{
    return mMateriaNames.size();
}



const int
Database::GetSizeOfKeyItemNames() const
{
    return mKeyItemNames.size();
}



const int
Database::GetSizeOfBattleTexts() const
{
    return mBattleText.size();
}



const int
Database::GetSizeOfSummonNames() const
{
    return mSummonNames.size();
}
