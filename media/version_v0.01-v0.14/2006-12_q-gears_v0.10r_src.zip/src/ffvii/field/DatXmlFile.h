// $Id: DatXmlFile.h 116 2006-12-15 21:08:47Z crazy_otaku $

#ifndef DAT_XML_FILE_h
#define DAT_XML_FILE_h

#include "../../common/filesystem/XmlFile.h"

#include "ObjectManager.h"
#include "WindowManager.h"



class DatXmlFile : public XmlFile
{
public:
    explicit DatXmlFile(const RString& file);
    virtual ~DatXmlFile(void);

    bool GetDialogs(WindowManager& windowManager);
    bool GetScripts(ObjectManager& objectManager);
    bool GetWalkMesh(ObjectManager& objectManager);
    bool GetGateway(ObjectManager& objectManager);
    bool GetEncounter(ObjectManager& objectManager);

private:
    bool       mNormalFile;

    xmlNodePtr mRootNode;
};



#endif // DAT_XML_FILE_h
