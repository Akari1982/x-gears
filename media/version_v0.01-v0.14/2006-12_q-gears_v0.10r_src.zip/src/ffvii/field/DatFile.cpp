// $Id: DatFile.cpp 116 2006-12-15 21:08:47Z crazy_otaku $

#include <vector>

#include "../../common/display/math/Matrix.h"
#include "../../common/display/math/MatrixMath.h"
#include "../../common/display/math/Vector.h"
#include "../../common/display/math/VectorMath.h"
#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "DatFile.h"
#include "Entity.h"

#include "../../common/display/Display.h"


DatFile::DatFile(const RString &file):
    LzsFile(file)
{
}



DatFile::DatFile(File *file, const u32 &offset, const u32 &length):
    LzsFile(file, offset, length)
{
}



DatFile::DatFile(u8* buffer, const u32 &offset, const u32 &length):
    LzsFile(buffer, offset, length)
{
}



DatFile::DatFile(File *file):
    LzsFile(file)
{
}



DatFile::~DatFile()
{
}



void
DatFile::GetScripts(ObjectManager& objectManager)
{
    // get sector 1 offset (scripts and dialog)
    u32 offset_to_sector       = 0x1C;

    u8  number_of_entity        = GetU8(offset_to_sector + 0x02);
    u16 string_offset           = GetU16LE(offset_to_sector + 0x04);
    u8  number_of_extra_offsets = GetU8(offset_to_sector + 0x06);

    u32 script_offset = 0x20 + number_of_entity * 0x08 + number_of_extra_offsets * 0x04 + number_of_entity * 0x40;
    u32 script_size = string_offset - script_offset;

    Script* script = new Script(mpBuffer + offset_to_sector + script_offset, script_size);
    Entity::SetScript(script);



    for (u8 i = 0; i < number_of_entity; ++i)
    {
        Entity* entity = new Entity();
        // get entity name
        RString name = RString(reinterpret_cast<char*>(mpBuffer) + offset_to_sector + 0x20 + i * 0x08, 0x08);
        entity->SetName(name);

        // run through all scripts and add them
        for (u8 j = 0; j < 31; ++j)
        {
            u32 entity_script_offset = GetU16LE(offset_to_sector + 0x20 + number_of_entity * 0x08 + number_of_extra_offsets * 0x04 + i * 0x40 + j * 0x02) - script_offset;

            entity->SetEntryPoint(j, entity_script_offset);
        }

        objectManager.PushEntity(entity);
    }
}



void
DatFile::GetDialogs(WindowManager& windowManager)
{
    // get sector 1 offset (scripts and dialog)
    u32 offset_to_sector  = 0x1C;
    u16 offset_to_dialogs = GetU16LE(offset_to_sector + 0x04);

    u16 number_of_dialogs = GetU16LE(offset_to_sector + offset_to_dialogs);

    for (u16 i = 0; i < number_of_dialogs; ++i)
    {
        // get offset of string data
        u32 offset = offset_to_sector + offset_to_dialogs + GetU16LE(offset_to_sector + offset_to_dialogs + 0x02 + i * 0x02);

        // read the string
        FFVIIString text;
        for (unsigned char temp = 0x00; temp != 0xFF; ++offset)
        {
            temp = GetU8(offset);

            if (temp == 0xF9)
            {
                printf("Opcode 0xF9.");
                // simple string compression, reference an earlier substring
                ++offset;
                int dist  = (GetU8(offset) & 0x3F) + 2;

                int count = (GetU8(offset) >> 6) * 2 + 4;
                for (int k = 0; (k < count) && (GetU8(offset - dist + k) != 0xFF); ++k)
                {
                    text.push_back(GetU8(offset - dist + k));
                }
            }
            else if (temp == 0xF8)
            {
                ++offset;
                ++offset;
                printf("Unknown opcode 0xF8.");
            }
            else
            {
                text.push_back(temp);
            }
        }

        windowManager.AddDialog(text);
    }
}



void
DatFile::GetBackground(BackgroundManager& backgroundManager)
{
    u32 offset_to_background = 0x1C + GetU32LE(0x08) - GetU32LE(0x00);
//LOGGER->Log("offset_to_background = %x, 0x1C + GetU32LE(0x0C) - GetU32LE(0x00) = %x", offset_to_background, 0x1C + GetU32LE(0x0C) - GetU32LE(0x00));
    u32 offset_to_1 = offset_to_background + 0x10;
    u32 offset_to_2 = offset_to_background + GetU32LE(offset_to_background + 0x00);
    u32 offset_to_3 = offset_to_background + GetU32LE(offset_to_background + 0x04);
    u32 offset_to_4 = offset_to_background + GetU32LE(offset_to_background + 0x08);
    u32 offset_to_5 = offset_to_background + GetU32LE(offset_to_background + 0x0C);

    u32 s1 = offset_to_1;
    u32 s2 = offset_to_2;
    u32 s3 = offset_to_3;
    u32 s4 = offset_to_4;

    u16 page_x =  GetU16LE(s3) & 0x0F;
    u16 page_y = (GetU16LE(s3) & 0x10) >> 0x04;
    s3 += 0x02;

    for (; s1 < offset_to_2; s1 += 0x06)
    {
        if (GetU16LE(s1) == 0x7FFE)
        {
            page_x =  GetU16LE(s3) & 0x0F;
            page_y = (GetU16LE(s3) & 0x10) >> 0x04;
            s3 += 0x02;
            s1 += 0x06;
        }
        if (GetU16LE(s1) == 0x7FFF)
        {
            s1 += 0x02;
            break; 
        }



        u16 sprite_num = GetU16LE(s1 + 0x04);

        for (u16 i = 0; i < sprite_num; ++i)
        {
            s16 dest_x =  GetU16LE(s2 + 0x00);
            s16 dest_y =  GetU16LE(s2 + 0x02);
            u8  src_x  =  GetU16LE(s2 + 0x04);
            u8  src_y  =  GetU16LE(s2 + 0x05);
            u8  clut   = (GetU16LE(s2 + 0x06) >> 6) & 0xF;

//            LOGGER->Log("Add layer 1 sprite to (%d %d) from (%d %d texpage_x %d, texpage_y %d) with clut %d", dest_x, dest_y, src_x, src_y, page_x, page_y, clut);
            backgroundManager.AddSpriteLayer1(dest_x, dest_y, src_x, src_y, clut, page_x, page_y);

            s2 += 0x08;
        }
    }



    for (; s1 < offset_to_2; s1 += 0x06)
    {
        if (GetU16LE(s1) == 0x7FFF)
        {
            break; 
        }



        u16 sprite_num = GetU16LE(s1 + 0x04);

        for (u16 i = 0; i < sprite_num; ++i)
        {
            s16 dest_x  = GetU16LE(s4 + 0x00);
            s16 dest_y  = GetU16LE(s4 + 0x02);
            u8  src_x   = GetU16LE(s4 + 0x04);
            u8  src_y   = GetU16LE(s4 + 0x05);
            u8  clut    = (GetU16LE(s4 + 0x06) >> 6) & 0xF;
            page_x      =  GetU16LE(s4 + 0x08) & 0x0F;
            page_y      = (GetU16LE(s4 + 0x08) & 0x10) >> 0x04;
            u8 blending = (GetU16LE(s4 + 0x08) & 0x60) >> 0x05;
            u8 group    = GetU8(s4 + 0x0C) & 0x0F;
            u8 layer    = GetU8(s4 + 0x0D);

//if (blending == 0 && clut == 9)
//{
//    LOGGER->Log("%08x%08x%08x%08x", GetU32LE(s4 + 0x00), GetU32LE(s4 + 0x04), GetU32LE(s4 + 0x08), GetU32LE(s4 + 0x0C));
//}
//            LOGGER->Log("Add layer 2 sprite to (%d %d) from (%d %d texpage_x %d, texpage_y %d) with clut %04x and blending %d. Anim group %d, layer %d.", dest_x, dest_y, src_x, src_y, page_x, page_y, GetU16LE(s4 + 0x06), blending, group, layer);
            backgroundManager.AddSpriteLayer2(dest_x, dest_y, src_x, src_y, clut, page_x, page_y, blending, group, layer);

            s4 += 0x0E;
        }
    }
}



void
DatFile::GetWalkMesh(ObjectManager& objectManager)
{
    // get sector 2 offset (walkmesh)
    u32 offset_to_walkmesh = 0x1C + GetU32LE(0x04) - GetU32LE(0x00);
    u32 number_of_poly = GetU32LE(offset_to_walkmesh);

    int start_walkmesh = offset_to_walkmesh + 0x04;
    int start_access   = offset_to_walkmesh + 0x04 + number_of_poly * 0x18;

    WalkMeshTriangle triangle;

    for (u32 i = 0; i < number_of_poly; ++i)
    {
        triangle.A.x =  static_cast<s16>(GetU16LE(start_walkmesh + 0x00));
        triangle.A.z =  static_cast<s16>(GetU16LE(start_walkmesh + 0x02));
        triangle.A.y =  static_cast<s16>(GetU16LE(start_walkmesh + 0x04));

        triangle.B.x =  static_cast<s16>(GetU16LE(start_walkmesh + 0x08));
        triangle.B.z =  static_cast<s16>(GetU16LE(start_walkmesh + 0x0A));
        triangle.B.y =  static_cast<s16>(GetU16LE(start_walkmesh + 0x0C));

        triangle.C.x =  static_cast<s16>(GetU16LE(start_walkmesh + 0x10));
        triangle.C.z =  static_cast<s16>(GetU16LE(start_walkmesh + 0x12));
        triangle.C.y =  static_cast<s16>(GetU16LE(start_walkmesh + 0x14));

        triangle.access[0] = GetU16LE(start_access + 0x00);
        triangle.access[1] = GetU16LE(start_access + 0x02);
        triangle.access[2] = GetU16LE(start_access + 0x04);

        objectManager.AddWalkMeshTriangle(triangle);

        // go to the next triangle
        start_walkmesh += 0x18;
        start_access   += 0x06;
    }
}



void
DatFile::GetCameraMatrix(CameraManager& camera)
{
    // get sector 4 offset (camera)
    u32 offset_to_camera = 0x1C + GetU32LE(0x0C) - GetU32LE(0x00);

//LOGGER->Log("offset_to_camera = %x, 0x1C + GetU32LE(0x10) - GetU32LE(0x00) = %x", offset_to_camera, 0x1C + GetU32LE(0x10) - GetU32LE(0x00));

    // get camera matrix (3 vectors)
    float vxx = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x00))) * 0.000244140625f; // divide by 4096
    float vxy = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x04))) * 0.000244140625f; // divide by 4096
    float vxz = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x02))) * 0.000244140625f; // divide by 4096

    float vyx = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x06))) * 0.000244140625f; // divide by 4096
    float vyy = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x0A))) * 0.000244140625f; // divide by 4096
    float vyz = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x08))) * 0.000244140625f; // divide by 4096

    float vzx = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x0C))) * 0.000244140625f; // divide by 4096
    float vzy = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x12))) * 0.000244140625f; // divide by 4096
    float vzz = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x0E))) * 0.000244140625f; // divide by 4096

    // get camera position in camera space
    s32 ox  = -(s32)(GetU32LE(offset_to_camera + 0x14));
    s32 oy  = -(s32)(GetU32LE(offset_to_camera + 0x18));
    s32 oz  = -(s32)(GetU32LE(offset_to_camera + 0x1C));

    float distance = GetU16LE(offset_to_camera + 0x24);



    // camera matrix
    Matrix mat(-vxx, vyx, vzx, 0,
               -vxy, vyy, vzy, 0,
               -vxz, vyz, vzz, 0,
                0,   0,   0,   1);
    camera.SetCameraMatrix(mat);
    camera.SetOrigin(Vector3(ox, oy, oz));



    // projection matrix
    float aspect = 640.0f/480.0f;
    float angley = atanf(320.0f / distance) * 1.5f;
    float znear  = 1;
    float zfar   = 100000;

    float ymax   =  znear * tanf(angley / 2);
    float ymin   = -ymax;
    float xmin   =  ymin * aspect;
    float xmax   =  ymax * aspect;

    camera.SetProjection(xmax, xmin, ymax, ymin);



    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log("Field camera vectors:              vxx = %f, vxy = %f, vxz = %f", vxx, vxy, vxz);
        LOGGER->Log("                                   vyx = %f, vyy = %f, vyz = %f", vyx, vyy, vyz);
        LOGGER->Log("                                   vzx = %f, vzy = %f, vzz = %f", vzx, vzy, vzz);
        LOGGER->Log("Camera position (in camera space): ox = %d, oy = %d, oz = %d", ox, oy, oz);
        LOGGER->Log("Camera distance:                   distance = %d", distance);
    }
}




void
DatFile::GetGateway(ObjectManager& objectManager)
{
    // get sector 5 triggers
    u32 offset_to_triggers = 0x1C + GetU32LE(0x10) - GetU32LE(0x00);

    u32 start_triggers = offset_to_triggers + 0x38;

    for (u8 i = 0; i < 12; ++i)
    {
        Vector3 point1  (static_cast<s16>(GetU16LE(start_triggers + 0x00)),
                         static_cast<s16>(GetU16LE(start_triggers + 0x04)),
                         static_cast<s16>(GetU16LE(start_triggers + 0x02)));
        Vector3 point2  (static_cast<s16>(GetU16LE(start_triggers + 0x06)),
                         static_cast<s16>(GetU16LE(start_triggers + 0x0A)),
                         static_cast<s16>(GetU16LE(start_triggers + 0x08)));
        Vector3 position(static_cast<s16>(GetU16LE(start_triggers + 0x0C)),
                         static_cast<s16>(GetU16LE(start_triggers + 0x10)),
                         static_cast<s16>(GetU16LE(start_triggers + 0x0E)));
        u16 map_id = GetU16LE(start_triggers + 0x12);

        objectManager.AddGateway(point1, point2, position, map_id);

        // go to the next gateway
        start_triggers += 0x18;
    }
}



void
DatFile::GetScreenRange(CameraManager& screen)
{
    // get sector 5 triggers
    u32 offset_to_triggers = 0x1C + GetU32LE(0x10) - GetU32LE(0x00);

    s16 min_x = GetU16LE(offset_to_triggers + 0x0C);
    s16 min_y = GetU16LE(offset_to_triggers + 0x0E);
    s16 max_x = GetU16LE(offset_to_triggers + 0x10);
    s16 max_y = GetU16LE(offset_to_triggers + 0x12);

    screen.SetScreenRange(max_x, min_x, max_y, min_y);

    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log("Screen range: x: max = %d", max_x);
        LOGGER->Log("                 min = %d", min_x);
        LOGGER->Log("              y: max = %d", max_y);
        LOGGER->Log("                 min = %d", min_y);
    }
}



void
DatFile::GetEncounter(ObjectManager& objectManager)
{
    // get sector 6 encounters
    u32 offset_to_encounters = 0x1C + GetU32LE(0x14) - GetU32LE(0x00);

    EncounterTable table;

    for (u8 i = 0; i < 2; ++i)
    {
        table.enabled                     = GetU8(offset_to_encounters + i * 0x18 + 0x00);
        table.rate                        = GetU8(offset_to_encounters + i * 0x18 + 0x01);

        table.standart_encounter[0].rate  = GetU16LE(offset_to_encounters + i * 0x18 + 0x02) >> 10;
        table.standart_encounter[0].scene = GetU16LE(offset_to_encounters + i * 0x18 + 0x02) & 0x03FF;
        table.standart_encounter[1].rate  = GetU16LE(offset_to_encounters + i * 0x18 + 0x04) >> 10;
        table.standart_encounter[1].scene = GetU16LE(offset_to_encounters + i * 0x18 + 0x04) & 0x03FF;
        table.standart_encounter[2].rate  = GetU16LE(offset_to_encounters + i * 0x18 + 0x06) >> 10;
        table.standart_encounter[2].scene = GetU16LE(offset_to_encounters + i * 0x18 + 0x06) & 0x03FF;
        table.standart_encounter[3].rate  = GetU16LE(offset_to_encounters + i * 0x18 + 0x08) >> 10;
        table.standart_encounter[3].scene = GetU16LE(offset_to_encounters + i * 0x18 + 0x08) & 0x03FF;
        table.standart_encounter[4].rate  = GetU16LE(offset_to_encounters + i * 0x18 + 0x0A) >> 10;
        table.standart_encounter[4].scene = GetU16LE(offset_to_encounters + i * 0x18 + 0x0A) & 0x03FF;
        table.standart_encounter[5].rate  = GetU16LE(offset_to_encounters + i * 0x18 + 0x0C) >> 10;
        table.standart_encounter[5].scene = GetU16LE(offset_to_encounters + i * 0x18 + 0x0C) & 0x03FF;

        table.special_encounter[0].rate      = GetU16LE(offset_to_encounters + i * 0x18 + 0x0E) >> 10;
        table.special_encounter[0].scene     = GetU16LE(offset_to_encounters + i * 0x18 + 0x0E) & 0x03FF;
        table.special_encounter[1].rate      = GetU16LE(offset_to_encounters + i * 0x18 + 0x10) >> 10;
        table.special_encounter[1].scene     = GetU16LE(offset_to_encounters + i * 0x18 + 0x10) & 0x03FF;
        table.special_encounter[2].rate      = GetU16LE(offset_to_encounters + i * 0x18 + 0x12) >> 10;
        table.special_encounter[2].scene     = GetU16LE(offset_to_encounters + i * 0x18 + 0x12) & 0x03FF;
        table.special_encounter[3].rate      = GetU16LE(offset_to_encounters + i * 0x18 + 0x14) >> 10;
        table.special_encounter[3].scene     = GetU16LE(offset_to_encounters + i * 0x18 + 0x14) & 0x03FF;

        objectManager.AddEncounterTable(table);
    }
}
