// $Id: Trigger.h 116 2006-12-15 21:08:47Z crazy_otaku $

#ifndef TRIGGER_h
#define TRIGGER_h

#include <ode/ode.h>

#include "../../common/display/3dTypes.h"

class FieldModule;



class Trigger
{
public:
                 Trigger(FieldModule* pFieldModule, const dGeomID& collision);
    virtual     ~Trigger(void);

    void         Draw(void);

    void         CheckCollision(const dGeomID& unitCollision);

    virtual void OnEnter(void) = 0;
    virtual void OnLeave(void) = 0;

protected:
    FieldModule* m_pFieldModule;

    bool         m_bEntered;

    dGeomID      m_Collision;
};



#endif // TRIGGER_h
