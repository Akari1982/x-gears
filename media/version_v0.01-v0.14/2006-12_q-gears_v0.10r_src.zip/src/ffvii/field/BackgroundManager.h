// $Id$

#ifndef BACKGROUND_MANAGER_h
#define BACKGROUND_MANAGER_h

#include "../../common/display/3dTypes.h"
#include "../../common/input/InputFilter.h"
#include "../../common/utilites/NoCopy.h"

#include "MimFile.h"

class FieldModule;



struct Sprite
{
    int tex_id;
    s16 x;
    s16 y;
    u8  blending;
};



class BackgroundManager : public NoCopy<BackgroundManager>
{
public:
    explicit BackgroundManager(FieldModule* pFieldModule);
    virtual ~BackgroundManager(void);

    void     Clear(void);
    void     DrawInPosition(const Vector3& move);
    void     DrawDebugInfo(void) const;
    bool     Input(const InputEvent& input);
    void     Update(const u32& deltaTime);

    void     ShowLayerReset(void);

    void     LoadBackground(const RString& name);
    void     AddSpriteLayer1(const s16& destX, const s16& destY, const u8& srcX, const u8& srcY, const u8& clut, const u8& pageX, const u8& pageY);
    void     AddSpriteLayer2(const s16& destX, const s16& destY, const u8& srcX, const u8& srcY, const u8& clut, const u8& pageX, const u8& pageY, const u8& blending, const u8& group, const u8& layer);
    void     UnloadBackground(void);

    void     BackgroundClear(const u8& group);
    void     BackgroundOn(const u8& group, const u8& layer);
    void     BackgroundOff(const u8& group, const u8& layer);

private:
    FieldModule*            mpFieldModule;  /**< @brief feed back to field module */

    std::vector<Surface*>   mSurfaces;

    Geometry                mSpritePoly;

    std::vector<Sprite>     m1stLayer;

    typedef std::vector<Sprite> Group;
    typedef std::vector<Group>  Layer;
    std::vector<Layer>      m2ndLayer;

    typedef std::vector<u8> ShowLayers;
    std::vector<ShowLayers> mGroup;



    // debug
    bool                    mShow1stLayer;
    bool                    mShow2ndLayer;
    bool                    mShowAlpha;    // enables/disables psx blend 01 sprites
};



#endif // BACKGROUND_MANAGER_h
