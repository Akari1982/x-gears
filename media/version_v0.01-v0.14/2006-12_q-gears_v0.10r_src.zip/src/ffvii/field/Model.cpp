// $Id: Model.cpp 94 2006-11-12 19:44:43Z crazy_otaku $

#include "../../common/display/Display.h"

#include "Model.h"



Model::Model(void)
{
    // direction line
    Vertex v;
    Color color(0.0f, 1.0f, 1.0f, 1.0f);
    v.c = color;
    v.p.x =   0.0f; v.p.y = 0.0f; v.p.z =   0.0f;
    mDirectionLine.push_back(v);
    v.p.x =   0.0f; v.p.y = 0.0f; v.p.z = -50.0f;
    mDirectionLine.push_back(v);
}



Model::~Model(void)
{
}



void
Model::Draw(void)
{
    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->SetLineWidth(2);
    DISPLAY->DrawLines(mDirectionLine);
    DISPLAY->SetPolygonMode(POLYGON_FILL);
}
