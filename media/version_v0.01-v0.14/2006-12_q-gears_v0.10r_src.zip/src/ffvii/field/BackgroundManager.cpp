// $Id$

#include "../../common/display/Display.h"
#include "../../common/utilites/Logger.h"

#include "BackgroundManager.h"
#include "../filetypes/LzsFile.h"
#include "../../common/display/surface/SurfaceSaveBmp.h"



BackgroundManager::BackgroundManager(FieldModule* pFieldModule):
    mpFieldModule(pFieldModule),

    mShow1stLayer(true),
    mShow2ndLayer(true),
    mShowAlpha(true)
{
    Vertex point;
    point.p.x = 0.0f;  point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f;  point.t.y = 0.0f;
    mSpritePoly.vertexes.push_back(point);
    point.p.x = 16.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 0.0f;
    mSpritePoly.vertexes.push_back(point);
    point.p.x = 16.0f; point.p.y = -16.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 1.0f;
    mSpritePoly.vertexes.push_back(point);
    point.p.x = 0.0f;  point.p.y = -16.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a =  1.0f;
    point.t.x = 0.0f;  point.t.y = 1.0f;
    mSpritePoly.vertexes.push_back(point);



    // for 2nd layer
    m2ndLayer.resize(256);
    for (u16 i = 0; i < m2ndLayer.size(); ++i)
    {
        m2ndLayer[i].resize(16);
    }

    ShowLayerReset();
}



BackgroundManager::~BackgroundManager(void)
{
    Clear();
}



void
BackgroundManager::Clear(void)
{
    // we must do it right after loading. but if we forgot do it we can do it here.
    UnloadBackground();
    ShowLayerReset();


    u32 i;
    for (i = 0; i < m1stLayer.size(); ++i)
    {
        DISPLAY->DeleteTexture(m1stLayer[i].tex_id);
    }
    m1stLayer.clear();

    for (i = 0; i < m2ndLayer.size(); ++i)
    {
        for (u32 j = 0; j < m2ndLayer[i].size(); ++j)
        {
            for (u32 k = 0; k < m2ndLayer[i][j].size(); ++k)
            {
                DISPLAY->DeleteTexture(m2ndLayer[i][j][k].tex_id);
            }
            m2ndLayer[i][j].clear();
        }
    }
}



void
BackgroundManager::DrawInPosition(const Vector3& move)
{
    if (mShow1stLayer == true)
    {
        DISPLAY->PushMatrix();
        DISPLAY->Scale(2.0f/640.0f, 2.0f/480.0f, 1.0f);
        DISPLAY->Translate(move.x, -move.y, 1.0f);
        DISPLAY->CameraPushMatrix();
        DISPLAY->CameraLoadIdentity();

        for (u32 i = 0; i < m1stLayer.size(); ++i)
        {
            DISPLAY->PushMatrix();
            DISPLAY->Translate(m1stLayer[i].x, -m1stLayer[i].y, 0);
            DISPLAY->SetTexture(m1stLayer[i].tex_id);
            DISPLAY->DrawQuads(mSpritePoly);
            DISPLAY->UnsetTexture();
            DISPLAY->PopMatrix();
        }
        DISPLAY->CameraPopMatrix();
        DISPLAY->PopMatrix();
    }



    if (mShow2ndLayer == true)
    {
        DISPLAY->PushMatrix();
        DISPLAY->Scale(2.0f/640.0f, 2.0f/480.0f, 1.0f);
        DISPLAY->Translate(move.x, -move.y, 1.0f);
        DISPLAY->CameraPushMatrix();
        DISPLAY->CameraLoadIdentity();

        // go through all layers
        for (u32 i = 0; i < m2ndLayer.size(); ++i)
        {
            // go through all groups
            for (u32 j = 0; j < m2ndLayer[i].size(); ++j)
            {
                if (mGroup[j][i] == 0 && j != 0)
                {
                    continue;
                }

                // render all sprites
                for (u32 k = 0; k < m2ndLayer[i][j].size(); ++k)
                {
                    BlendMode mode = (m2ndLayer[i][j][k].blending == 0) ? BLEND_PSX_0 : BLEND_PSX_1;

                    if (mShowAlpha != true && mode == BLEND_PSX_1)
                    {
                        continue;
                    }

                    DISPLAY->PushMatrix();
                    DISPLAY->Translate(m2ndLayer[i][j][k].x, -m2ndLayer[i][j][k].y, 0);
                    DISPLAY->SetTexture(m2ndLayer[i][j][k].tex_id);
                    mSpritePoly.blend = mode;
                    DISPLAY->DrawQuads(mSpritePoly);
                    DISPLAY->UnsetTexture();
                    DISPLAY->PopMatrix();
                }
            }
        }
        DISPLAY->CameraPopMatrix();
        DISPLAY->PopMatrix();
    }
}



void
BackgroundManager::DrawDebugInfo(void) const
{
}



bool
BackgroundManager::Input(const InputEvent &input)
{
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_C1:    mShow1stLayer = (mShow1stLayer) ? false : true; break;
            case KEY_C2:    mShow2ndLayer = (mShow2ndLayer) ? false : true; break;
            case KEY_C3:    mShowAlpha    = (mShowAlpha)    ? false : true; break;
        }
    }

    return false;
}



void
BackgroundManager::Update(const u32& deltaTime)
{
}



void
BackgroundManager::ShowLayerReset(void)
{
    // for 2nd layer animation
    mGroup.resize(256);
    for (u16 i = 0; i < mGroup.size(); ++i)
    {
        mGroup[i].resize(256);

        for (u16 j = 0; j < mGroup[i].size(); ++j)
        {
            mGroup[i][j] = 0;
        }
    }
}



void
BackgroundManager::LoadBackground(const RString& name)
{
    LzsFile lzs_file(name);
//    lzs_file.WriteFile("CHORACE.MIM_u.MIM");
    MimFile mim_file(&lzs_file);

    u16 clut_number = mim_file.GetNumberOfClut();

    mSurfaces.resize(clut_number);

    for (u16 i = 0; i < clut_number; ++i)
    {
        mSurfaces[i] = mim_file.GetSurface(i);
        //SurfaceUtils::SaveBMP("xxx.bmp", mSurfaces[i]);
    }
}



void
BackgroundManager::AddSpriteLayer1(const s16& destX, const s16& destY, const u8& srcX, const u8& srcY, const u8& clut, const u8& pageX, const u8& pageY)
{
    Surface* sub_image = CreateSubSurface(pageX * 128 + srcX, pageY * 256 + srcY, 16, 16, mSurfaces[clut]);

    Sprite sprite;
    sprite.tex_id = DISPLAY->CreateTexture(sub_image);
    sprite.x = destX;
    sprite.y = destY;
    m1stLayer.push_back(sprite);

    delete sub_image;
}



void
BackgroundManager::AddSpriteLayer2(const s16& destX, const s16& destY, const u8& srcX, const u8& srcY, const u8& clut, const u8& pageX, const u8& pageY, const u8& blending, const u8& group, const u8& layer)
{
    Surface* sub_image = CreateSubSurface(pageX * 128 + srcX, pageY * 256 + srcY, 16, 16, mSurfaces[clut]);

    Sprite sprite;
    sprite.tex_id   = DISPLAY->CreateTexture(sub_image);
    sprite.x        = destX;
    sprite.y        = destY;
    sprite.blending = blending;

    m2ndLayer[layer][group].push_back(sprite);

    delete sub_image;
}



void
BackgroundManager::UnloadBackground(void)
{
    for (u8 i = 0; i < mSurfaces.size(); ++i)
    {
        delete mSurfaces[i];
    }
    mSurfaces.clear();
}



void
BackgroundManager::BackgroundClear(const u8& group)
{
    for (u16 j = 0; j < mGroup[group].size(); ++j)
    {
        mGroup[group][j] = 0;
    }
}



void
BackgroundManager::BackgroundOn(const u8& group, const u8& layer)
{
    mGroup[group][layer + 1] = 1;
}



void
BackgroundManager::BackgroundOff(const u8& group, const u8& layer)
{
    mGroup[group][layer + 1] = 0;
}
