// $Id: Gateway.cpp 116 2006-12-15 21:08:47Z crazy_otaku $

#include "../../common/utilites/Logger.h"

#include "FieldModule.h"
#include "Gateway.h"



Gateway::Gateway(FieldModule* pFieldModule, const dGeomID& collision, const Vector3& position, const u16& mapId):
    Trigger(pFieldModule, collision),
    mPosition(position),
    mMapId(mapId)
{
}



Gateway::~Gateway(void)
{
}



void
Gateway::OnEnter(void)
{
    if (mMapId != 0x7FFF)
    {
        printf("Gateway activates. Load next Map %d\n", mMapId);

        KERNEL->GetGamestate().PlayerPositionSet(mPosition);
        KERNEL->GetGamestate().PlayerTriangleUnset();

        m_pFieldModule->RequestLoadMap(mMapId);
    }
    else
    {
        printf("Gateway inactive.\n");
    }
}



void
Gateway::OnLeave(void)
{
}
