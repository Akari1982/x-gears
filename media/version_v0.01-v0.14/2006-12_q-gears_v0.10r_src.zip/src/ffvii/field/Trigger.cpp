// $Id: Trigger.cpp 116 2006-12-15 21:08:47Z crazy_otaku $

#include "../../common/display/Display.h"
#include "../../common/utilites/Logger.h"

#include "FieldModule.h"
#include "Math.h"
#include "Trigger.h"



Trigger::Trigger(FieldModule* pFieldModule, const dGeomID& collision):
    m_pFieldModule(pFieldModule),

    m_bEntered(false),

    m_Collision(collision)
{
}



Trigger::~Trigger(void)
{
}



void
Trigger::Draw(void)
{
    dVector3 point1;
    dVector3 point2;
    dGeomRayGet(m_Collision, point1, point2);

    Vertex v;
    Color color(0.0f, 128.0f / 255.0f, 242.0f / 255.0f, 1.0f);
    v.c = color;

    std::vector<Vertex> line;
    line.resize(2);

    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->SetLineWidth(3);

    v.p.x = point1[0]; v.p.y = point1[1]; v.p.z = point1[2];
    line[0] = v;
    v.p.x = point1[0] + point2[0]; v.p.y = point1[1] + point2[1]; v.p.z = point1[2] + point2[2];
    line[1] = v;
    DISPLAY->DrawLines(line);

    DISPLAY->SetPolygonMode(POLYGON_FILL);
}



void
Trigger::CheckCollision(const dGeomID& unitCollision)
{
    dContact contact;
    int numc = dCollide(m_Collision, unitCollision, 1, &contact.geom, sizeof(dContact));

    if (m_bEntered == false && numc > 0)
    {
        OnEnter();
        m_bEntered = true;
    }
    else if (m_bEntered == true && numc == 0)
    {
        OnLeave();
        m_bEntered = false;
    }
}
