// $Id: Script.cpp 103 2006-11-26 07:19:38Z crazy_otaku $

#include <cassert>
#include <memory>

#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "Entity.h"
#include "Script.h"
#include "FieldModule.h"
#include "WindowManager.h"
#include "../kernel/Kernel.h"



// This is is handy to call opcodes by thier name, not number
// Note: little "x" replaces "!" in opcode to make enum happy
// "u" replaces "+" and "d" replaces "-" ; 2BYTE changed to TWOBYTE
// xNNx are undefined opcodes
enum
{
    RET,      REQ,      REQSW,    REQEW,    PREQ,     PRQSW,    PRQEW,    RETTO,    // 0x00 - 0x07
    JOIN,     SPLIT,    SPTYE,    GTPYE,    x0Cx,     x0Dx,     DSKCG,    SPECIAL,  // 0x08 - 0x0F
    JMPF,     JMPFL,    JMPB,     JMPBL,    IFUB,     IFUBL,    IFSW,     IFSWL,    // 0x10 - 0x17
    IFUW,     IFUWL,    x1Ax,     x1Bx,     x1Cx,     x1Dx,     x1Ex,     x1Fx,     // 0x18 - 0x1F
    MINIGAME, TUTOR,    BTMD2,    BTRLD,    WAIT,     NFADE,    BLINK,    BGMOVIE,  // 0x20 - 0x27
    KAWAI,    KAWIW,    PMOVA,    SLIP,     BGPDH,    BGSCR,    WCLS,     WSIZW,    // 0x28 - 0x2F
    IFKEY,    IFKEYON,  IFKEYOFF, UC,       PDIRA,    PTURA,    WSPCL,    WNUMB,    // 0x30 - 0x37
    STTIM,    GOLDu,    GOLDd,    CHGLD,    HMPMAX1,  HMPMAX2,  MHMMX,    HMPMAX3,  // 0x38 - 0x3F
    MESSAGE,  MPARA,    MPRA2,    MPNAM,    x44x,     MPu,      x46x,     MPd,      // 0x40 - 0x47
    ASK,      MENU,     MENU2,    BTLTB,    x4Cx,     HPu,      x4Ex,     HPd,      // 0x48 - 0x4F
    WINDOW,   WMOVE,    WMODE,    WREST,    WCLSE,    WROW,     GWCOL,    SWCOL,    // 0x50 - 0x57
    STITM,    DLITM,    CKITM,    SMTRA,    DMTRA,    CMTRA,    SHAKE,    NOP,      // 0x58 - 0x5F
    MAPJUMP,  SCRLO,    SCRLC,    SCRLA,    SCR2D,    SCRCC,    SCR2DC,   SCRLW,    // 0x60 - 0x67
    SCR2DL,   MPDSP,    VWOFT,    FADE,     FADEW,    IDLCK,    LSTMP,    SCRLP,    // 0x68 - 0x6F
    BATTLE,   BTLON,    BTLMD,    PGTDR,    GETPC,    PXYZI,    PLUSx,    PLUS2x,   // 0x70 - 0x77
    MINUSx,   MINUS2x,  INCx,     INC2x,    DECx,     DEC2x,    TLKON,    RDMSD,    // 0x78 - 0x7F
    SETBYTE,  SETWORD,  BITON,    BITOFF,   BITXOR,   PLUS,     PLUS2,    MINUS,    // 0x80 - 0x87
    MINUS2,   MUL,      MUL2,     DIV,      DIV2,     MOD,      MOD2,     AND,      // 0x88 - 0x8F
    AND2,     OR,       OR2,      XOR,      XOR2,     INC,      INC2,     DEC,      // 0x90 - 0x97
    DEC2,     RANDOM,   LBYTE,    HBYTE,    TWOBYTE,  SETX,     GETX,     SEARCHX,  // 0x98 - 0x9F
    PC,       CHAR,     DFANM,    ANIME1,   VISI,     XYZI,     XYI,      XYZ,      // 0xA0 - 0xA7
    MOVE,     CMOVE,    MOVA,     TURA,     ANIMW,    FMOVE,    ANIME2,   ANIMx1,   // 0xA8 - 0xAF
    CANIM1,   CANMx1,   MSPED,    DIR,      TURNGEN,  TURN,     DIRA,     GETDIR,   // 0xB0 - 0xB7
    GETAXY,   GETAI,    ANIMx2,   CANIM2,   CANMx2,   ASPED,    xBEx,     CC,       // 0xB8 - 0xBF
    JUMP,     AXYZI,    LADER,    OFST,     OFSTW,    TALKR,    SLIDR,    SOLID,    // 0xC0 - 0xC7
    PRTYP,    PRTYM,    PRTYE,    IFPRTYQ,  IFMEMBQ,  MMBud,    MMBLK,    MMBUK,    // 0xC8 - 0xCF
    LINE,     LINON,    MPJPO,    SLINE,    SIN,      COS,      TLKR2,    SLDR2,    // 0xD0 - 0xD7
    PMJMP,    PMJMP2,   AKAO2,    FCFIX,    CCANM,    ANIMB,    TURNW,    MPPAL,    // 0xD8 - 0xDF
    BGON,     BGOFF,    BGROL,    BGROL2,   BGCLR,    STPAL,    LDPAL,    CPPAL,    // 0xE0 - 0xE7
    RTPAL,    ADPAL,    MPPAL2,   STPLS,    LDPLS,    CPPAL2,   RTPAL2,   ADPAL2,   // 0xE8 - 0xEF
    MUSIC,    SOUND,    AKAO,     MUSVT,    MUSVM,    MULCK,    BMUSC,    CHMPH,    // 0xF0 - 0xF7
    PMVIE,    MOVIE,    MVIEF,    MVCAM,    FMUSC,    CMUSC,    CHMST,    GAMEOVER  // 0xF8 - 0xFF
};



enum
{
    FMSSP = 0xF8,
    AAMAT,
    AAITM,
    BTLLK,
    MOVLK,
    DFTNM,
    GLRST,
    RMITM
};



RString opcodes_names[256] = {
    "RET",       "REQ",       "REQSW",    "REQEW",   "PREQ",    "PRQSW",   "PRQEW",  "RETTO",    // 0x00 - 0x07
    "JOIN",      "SPLIT",     "SPTYE",    "GTPYE",   "",        "",        "DSKCG",  "SPECIAL",  // 0x08 - 0x0F
    "JMPF",      "JMPFL",     "JMPB",     "JMPBL",   "IFUB",    "IFUBL",   "IFSW",   "IFSWL",    // 0x10 - 0x17
    "IFUW",      "IFUWL",     "",         "",        "",        "",        "",       "",         // 0x18 - 0x1F
    "MINIGAME",  "TUTOR",     "BTMD2",    "BTRLD",   "WAIT",    "NFADE",   "BLINK",  "BGMOVIE",  // 0x18 - 0x1F
    "KAWAI",     "KAWIW",     "PMOVA",    "SLIP",    "BGPDH",   "BGSCR",   "WCLS",   "WSIZW",    // 0x28 - 0x2F
    "IFKEY",     "IFKEYON",   "IFKEYOFF", "UC",      "PDIRA",   "PTURA",   "WSPCL",  "WNUMB",    // 0x30 - 0x37
    "STTIM",     "GOLD+",     "GOLD-",    "CHGLD",   "HMPMAX1", "HMPMAX2", "MHMMX",  "HMPMAX3",  // 0x38 - 0x3F
    "MESSAGE",   "MPARA",     "MPRA2",    "MPNAM",   "",        "MP+",     "",       "MP-",      // 0x40 - 0x47
    "ASK",       "MENU",      "MENU2",    "BTLTB",   "",        "HP+",     "",       "HP-",
    "WINDOW",    "WMOVE",     "WMODE",    "WREST",   "WCLSE",   "WROW",    "GWCOL",  "SWCOL",
    "STITM",     "DLITM",     "CKITM",    "SMTRA",   "DMTRA",   "CMTRA",   "SHAKE",  "NOP",
    "MAPJUMP",   "SCRLO",     "SCRLC",    "SCRLA",   "SCR2D",   "SCRCC",   "SCR2DC", "SCRLW",
    "SCR2DL",    "MPDSP",     "VWOFT",    "FADE",    "FADEW",   "IDLCK",   "LSTMP",  "SCRLP",
    "BATTLE",    "BTLON",     "BTLMD",    "PGTDR",   "GETPC",   "PXYZI",   "PLUS!",  "PLUS2!",
    "MINUS!",    "MINUS2!",   "INC!",     "INC2!",   "DEC!",    "DEC2!",   "TLKON",  "RDMSD",
    "SETBYTE",   "SETWORD",   "BITON",    "BITOFF",  "BITXOR",  "PLUS",    "PLUS2",  "MINUS",
    "MINUS2",    "MUL",       "MUL2",     "DIV",     "DIV2",    "MOD",     "MOD2",   "AND",
    "AND2",      "OR",        "OR2",      "XOR",     "XOR2",    "INC",     "INC2",   "DEC",
    "DEC2",      "RANDOM",    "LBYTE",    "HBYTE",   "2BYTE",   "SETX",    "GETX",   "SEARCHX",
    "PC",        "CHAR",      "DFANM",    "ANIME1",  "VISI",    "XYZI",    "XYI",    "XYZ",
    "MOVE",      "CMOVE",     "MOVA",     "TURA",    "ANIMW",   "FMOVE",   "ANIME2", "ANIM!1",
    "CANIM1",    "CANM!1",    "MSPED",    "DIR",     "TURNGEN", "TURN",    "DIRA",   "GETDIR",
    "GETAXY",    "GETAI",     "ANIM!2",   "CANIM2",  "CANM!2",  "ASPED",   "",       "CC",
    "JUMP",      "AXYZI",     "LADER",    "OFST",    "OFSTW",   "TALKR",   "SLIDR",  "SOLID",
    "PRTYP",     "PRTYM",     "PRTYE",    "IFPRTYQ", "IFMEMBQ", "MMB+-",   "MMBLK",  "MMBUK",
    "LINE",      "LINON",     " MPJPO",    "SLINE",   "SIN",     "COS",     "TLKR2",  "SLDR2",
    "PMJMP",     "PMJMP2",    "AKAO2",    "FCFIX",   "CCANM",   "ANIMB",   "TURNW",  "MPPAL",
    "BGON",      "BGOFF",     "BGROL",    "BGROL2",  "BGCLR",   "STPAL",   "LDPAL",  "CPPAL",
    "RTPAL",     "ADPAL",     "MPPAL2",   "STPLS",   "LDPLS",   "CPPAL2",  "RTPAL2", "ADPAL2",
    "MUSIC",     "SOUND",     "AKAO",     "MUSVT",   "MUSVM",   "MULCK",   "BMUSC",  "CHMPH",
    "PMVIE",     "MOVIE",     "MVIEF",    "MVCAM",   "FMUSC",   "CMUSC",   "CHMST",  "GAMEOVER"
};



RString special_opcodes_names[8] = {
    "FMSSP",
    "AAMAT",
    "AAITM",
    "BTLLK",
    "MOVLK",
    "DFTNM",
    "GLRST",
    "RMITM"
};



u8 opcodes_size[256] = {
     1,  3,  3,  3,  3,  3,  3,  5,  2, 15,  6,  6,  0,  0,  0,  0, // 0x00 - 0x0F
     2,  3,  2,  3,  6,  7,  8,  9,  8,  9,  0,  0,  0,  0,  0,  0, // 0x10 - 0x1F
    11,  2,  5,  3,  3,  9,  2,  2,  0,  1,  2,  2,  5,  7,  2, 10, // 0x20 - 0x2F
     4,  4,  4,  2,  2,  4,  5,  8,  6,  6,  6,  4,  1,  1,  1,  1, // 0x30 - 0x3F
     3,  5,  6,  2,  0,  5,  0,  5,  7,  4,  2,  2,  0,  5,  0,  5, // 0x40 - 0x4F
    10,  6,  4,  2,  2,  3,  7,  7,  5,  5,  5,  7,  8, 10,  8,  1, // 0x50 - 0x5F
    10,  2,  5,  6,  6,  1,  9,  1,  9,  2,  7,  9,  1,  4,  3,  6, // 0x60 - 0x6F
     4,  2,  3,  4,  4,  8,  4,  5,  4,  5,  3,  4,  3,  4,  2,  3, // 0x70 - 0x7F
     4,  5,  4,  4,  4,  4,  5,  4,  5,  4,  5,  4,  5,  4,  5,  4, // 0x80 - 0x8F
     5,  4,  5,  4,  5,  3,  3,  3,  3,  3,  4,  5,  6,  7,  7, 11, // 0x90 - 0x9F
     2,  2,  3,  3,  2, 11,  9,  9,  6,  6,  2,  4,  1,  6,  3,  3, // 0xA0 - 0xAF
     5,  5,  4,  3,  6,  6,  2,  4,  5,  4,  3,  5,  5,  4,  0,  2, // 0xB0 - 0xBF
    11,  8, 15, 12,  1,  3,  3,  2,  2,  2,  4,  3,  3,  3,  2,  2, // 0xC0 - 0xCF
    13,  2,  2, 16, 10, 10,  4,  4,  3,  1, 15,  2,  4,  1,  1, 11, // 0xD0 - 0xDF
     4,  4,  3,  3,  3,  5,  5,  5,  7, 10, 10,  5,  5,  8,  8, 11, // 0xE0 - 0xEF
     2,  5, 14,  2,  2,  2,  2,  4,  2,  2,  3,  2,  2,  6,  3,  1  // 0xF0 - 0xFF
};



u8 special_opcodes_size[8] = {
    3, 1, 1, 2, 2, 3, 1, 1
};



u8*
OpcodesToRawScript(u8* pBuffer, const u32& bufferSize, u32& rawScriptSize)
{
    rawScriptSize = 0;
    u8* raw_script = NULL;

    raw_script = (u8*)malloc(rawScriptSize);
    u32 script_size = 0;
    u32 current_position = 0;



    for (unsigned int i = 0; i < bufferSize;)
    {
        u32 string_size = 0;
        // get the size of string
        while (pBuffer[i + string_size] != '\r' && pBuffer[i + string_size] != '\n' && i + string_size < bufferSize)
        {
            ++string_size;
        }



        // Read the string
        std::string line = "";
        char* temp_string = new char[string_size + 1];
        memcpy(temp_string, pBuffer + i, string_size);
        temp_string[string_size] = '\0';
        line = temp_string;
        delete[] temp_string;



        i += string_size;
        // skip '\r' or '\n' on the end of string and go to start of new string
        while (pBuffer[i] == '\r' || pBuffer[i] == '\n')
        {
            ++i;
        }



        // comments or empty string
        if (line[0] == '#' || line.size() == 0 || (line[0] == '/' && line[1] == '/'))
        {
            continue;
        }



        // add new opcode to raw.
        int equal_index = line.find(" ");
        if (equal_index != std::string::npos)
        {
            std::string opcode_name = line.substr(0, equal_index);

            // we skip space and ( and then read string after that
            std::string opcode_data = line.substr(equal_index + 2, line.size() - equal_index - 2);

            // search for opcode (if it finds nothing - it inserts RET opcode)
            u16 k = 0;
            for (; k < 256; ++k)
            {
                if (opcodes_names[k] == opcode_name)
                {
                    break;
                }
            }

            if (k != 256 && opcodes_size[k] != 0)
            {
                rawScriptSize += opcodes_size[k];
                raw_script = (u8*)realloc(raw_script, rawScriptSize);
                raw_script[current_position] = k;

                ++current_position;

                for (u8 j = 1; j < opcodes_size[k]; ++j)
                {
                    if (opcode_data.size() >= 3)
                    {
                        std::string value = opcode_data.substr(0, 2);
                        opcode_data       = opcode_data.substr(3, opcode_data.size() - 3);

                        u32 hex = 0;
                        sscanf(value.c_str(), "%02x", &hex);
                        raw_script[current_position] = (u8)hex;
                        ++current_position;
                    }
                    else
                    {
                        LOGGER->Log("Not enough arguments in opcode '%s'", opcodes_names[k].c_str());
                    }
                }
            }
            else
            {
                // search in special opcodes
                u16 s = 0;
                for (; s < 8; ++s)
                {
                    if (special_opcodes_names[s] == opcode_name)
                    {
                        break;
                    }
                }

                if (s != 8)
                {
                    rawScriptSize += special_opcodes_size[s] + 1;
                    raw_script = (u8*)realloc(raw_script, rawScriptSize);
                    raw_script[current_position] = 0x0F;
                    ++current_position;
                    raw_script[current_position] = s + 0xF8;
                    ++current_position;

                    for (u8 j = 1; j < special_opcodes_size[s]; ++j)
                    {
                        if (opcode_data.size() >= 3)
                        {
                            std::string value = opcode_data.substr(0, 2);
                            opcode_data       = opcode_data.substr(3, opcode_data.size() - 3);

                            u32 hex = 0;
                            sscanf(value.c_str(), "%02x", &hex);
                            raw_script[current_position] = (u8)hex;
                            ++current_position;
                        }
                        else
                        {
                            LOGGER->Log("Not enough arguments in opcode '%s'", special_opcodes_names[s].c_str());
                        }
                    }
                }
                else
                {
                    LOGGER->Log("Opcode '%s' not found!", opcode_name.c_str());
                }
            }
        }
        else
        {
            LOGGER->Log("Row '%s' incorrect! Must contain space.", line.c_str());
        }
    }



    return raw_script;
}


/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

Script::Script(u8* pBuffer, const u32& ulLength):
    m_pBuffer(NULL),
    m_ulLength(ulLength)
{
    assert(pBuffer != NULL);

    m_pBuffer = (u8*)malloc(sizeof(u8) * m_ulLength);
    memcpy(m_pBuffer, pBuffer, m_ulLength);
}



Script::~Script(void)
{
    free(m_pBuffer);
}



//============================= OPERATIONS ===================================

bool
Script::Run(FieldModule* pFieldModule, const s8& sbEntityId, u32& ulScriptPosition)
{
    // sanity check
    if (ulScriptPosition >= m_ulLength)
    {
        return true;
    }



    for (u8 opcount = 0; ulScriptPosition < m_ulLength; ++opcount)
    {
        if (opcount >= 20)
        {
            return false;
        }

        u8 opcode = GetU8(ulScriptPosition);

        switch (opcode)
        {
            // Return from subroutine
            case RET: // 0x00
            {
                ulScriptPosition += opcodes_size[opcode];

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s()", opcodes_names[opcode].c_str());
                }

                return true;
            }
            break;



            // Request remote execution (asynchronous , non-guaranteed)
            case REQ: // 0x01
            {
                u8 entity_id = GetU8(ulScriptPosition + 1);
                u8 priority  = GetU8(ulScriptPosition + 2) >> 5;
                u8 script_id = GetU8(ulScriptPosition + 2) & 0x1F;

                pFieldModule->mObjectManager.RequestRunEntity(entity_id, priority, script_id);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(entity_id = %d, priority = %d, script_id = %d)", opcodes_names[opcode].c_str(), entity_id, priority, script_id);
                }
            }
            break;



//case 0x02:
//case 0x03:
//case 0x04:
//case 0x05:
//case 0x06:
//case 0x07:
//case 0x08:
//case 0x09:
//case 0x0A:
//case 0x0B:
//case 0x0C:
//case 0x0D:
//case 0x0E:



            // Special Command
            case SPECIAL: // 0x0F
            {
                u8 special_opcode = GetU8(ulScriptPosition + 1);

                switch (special_opcode)
                {
                    case BTLLK:
                    {
                        u8 lock = GetU8(ulScriptPosition + 2);

                        KERNEL->GetGamestate().BattleLockSet(lock);

                        if (CONFIG->m_DumpScript == true)
                        {
                            LOGGER->Log("%s(lock = %02x)", special_opcodes_names[special_opcode - 0xF8].c_str(), lock);
                        }
                    }
                    break;



                    default:
                    {
                        LOGGER->Log("Unimplemented special opcode %02x", special_opcode);

                        if (special_opcodes_size[special_opcode] <= 0)
                        {
                            return true;
                        }
                    }
                }

                // move script position
                ulScriptPosition += special_opcodes_size[special_opcode - 0xF8] + 1;
            }
            break;



            // Jump ahead relative (8-bit)
            case JMPF: // 0x10
            {
                u8 jump = GetU8(ulScriptPosition + 1);

                ulScriptPosition += jump - 1;

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(jump = %02x)", opcodes_names[opcode].c_str(), jump);
                }
            }
            break;



            // Jump ahead relative (16-bit)
            case JMPFL: // 0x11
            {
                u16 jump = GetU16LE(ulScriptPosition + 1);

                ulScriptPosition += jump - 2;

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(jump = %04x)", opcodes_names[opcode].c_str(), jump);
                }
            }
            break;



            // Jump backward relative (8-bit)
            case JMPB: // 0x12
            {
                u8 jump = GetU8(ulScriptPosition + 1);

                ulScriptPosition -= jump + opcodes_size[opcode];

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(jump = %02x)", opcodes_names[opcode].c_str(), jump);
                }
            }
            break;



            // Jump back relative (16-bit)
            case JMPBL: // 0x13
            {
                u16 jump = GetU16LE(ulScriptPosition + 1);

                ulScriptPosition -= jump + opcodes_size[opcode];

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(jump = %04x)", opcodes_names[opcode].c_str(), jump);
                }
            }
            break;



            // Unsigned byte conditional with byte relative jump
            case IFUB: // 0x14
            {
                u8  memory_bank = GetU8(ulScriptPosition + 1) >> 4;
                u8  offset      = GetU8(ulScriptPosition + 2);
                u16 value1      = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);
                u16 value2      = GetU8(ulScriptPosition + 3);
                u8  relation    = GetU8(ulScriptPosition + 4);
                u8  jump        = GetU8(ulScriptPosition + 5);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  (value1 & (1 << value2)); break;
                    case 0x0A: result = !(value1 & (1 << value2)); break;
                    default: LOGGER->Log("Strange relation: %02x", relation);
                }

                if (result != true)
                {
                    ulScriptPosition += jump - 1;
                }

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(bank = %02x, offset = %02x, value2 = %02x, relation = %02x, jump = %02x)", opcodes_names[opcode].c_str(), memory_bank, offset, value2, relation, jump);
                }
            }
            break;



            // Unsigned byte conditional with long relative jump
            case IFUBL: // 0x15
            {
                u8  memory_bank = GetU8(ulScriptPosition + 1) >> 4;
                u8  offset      = GetU8(ulScriptPosition + 2);
                u16 value1      = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);
                u16 value2      = GetU8(ulScriptPosition + 3);
                u8  relation    = GetU8(ulScriptPosition + 4);
                u16 jump        = GetU16LE(ulScriptPosition + 5);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  (value1 & (1 << value2)); break;
                    case 0x0A: result = !(value1 & (1 << value2)); break;
                    default: LOGGER->Log("Strange relation: %02x", relation);
                }

                if (result != true)
                {
                    ulScriptPosition += jump - 2;
                }

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(bank = %02x, offset = %02x, value2 = %02x, relation = %02x, jump = %04x)", opcodes_names[opcode].c_str(), memory_bank, offset, value2, relation, jump);
                }
            }
            break;



            // Signed word conditional with byte relative jump
            case IFSW: // 0x16
            {
                u8  memory_bank = GetU8(ulScriptPosition + 1) >> 4;
                u16 offset      = GetU16LE(ulScriptPosition + 2);
                s16 value1      = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);
                s16 value2      = GetU16LE(ulScriptPosition + 4);
                u8  relation    = GetU8(ulScriptPosition + 6);
                u8  jump        = GetU8(ulScriptPosition + 7);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  (value1 & (1 << value2)); break;
                    case 0x0A: result = !(value1 & (1 << value2)); break;
                    default: LOGGER->Log("Strange relation: %02x", relation);
                }

                if (result != true)
                {
                    ulScriptPosition += jump - 1;
                }

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(bank = %02x, offset = %04x, value2 = %04x, relation = %02x, jump = %02x)", opcodes_names[opcode].c_str(), memory_bank, offset, value2, relation, jump);
                }
            }
            break;



            // Signed word conditional with long relative jump
            case IFSWL: // 0x17
            {
                u8  memory_bank = GetU8(ulScriptPosition + 1) >> 4;
                u16 offset      = GetU16LE(ulScriptPosition + 2);
                s16 value1      = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);
                s16 value2      = GetU16LE(ulScriptPosition + 4);
                u8  relation    = GetU8(ulScriptPosition + 6);
                u16 jump        = GetU16LE(ulScriptPosition + 7);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  (value1 & (1 << value2)); break;
                    case 0x0A: result = !(value1 & (1 << value2)); break;
                    default: LOGGER->Log("Strange relation: %02x", relation);
                }

                if (result != true)
                {
                    ulScriptPosition += jump - 2;
                }

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(bank = %02x, offset = %04x, value2 = %04x, relation = %02x, jump = %04x)", opcodes_names[opcode].c_str(), memory_bank, offset, value2, relation, jump);
                }
            }
            break;



            // Unsigned word conditional with byte relative jump
            case IFUW: // 0x18
            {
                u8  memory_bank = GetU8(ulScriptPosition + 1) >> 4;
                u16 offset      = GetU16LE(ulScriptPosition + 2);
                u16 value1      = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);
                u16 value2      = GetU16LE(ulScriptPosition + 4);
                u8  relation    = GetU8(ulScriptPosition + 6);
                u8  jump        = GetU8(ulScriptPosition + 7);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  (value1 & (1 << value2)); break;
                    case 0x0A: result = !(value1 & (1 << value2)); break;
                    default: LOGGER->Log("Strange relation: %02x", relation);
                }

                if (result == true)
                {
                    ulScriptPosition += jump - 1;
                }

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(bank = %02x, offset = %04x, value2 = %04x, relation = %02x, jump = %02x)", opcodes_names[opcode].c_str(), memory_bank, offset, value2, relation, jump);
                }
            }
            break;



            // Unsigned word conditional with long relative jump
            case IFUWL: // 0x19
            {
                u8  memory_bank = GetU8(ulScriptPosition + 1) >> 4;
                u16 value1      = KERNEL->GetGamestate().MemoryBankGet(memory_bank, GetU16LE(ulScriptPosition + 2));
                u16 value2      = GetU16LE(ulScriptPosition + 4);
                u8  relation    = GetU8(ulScriptPosition + 6);
                u16 jump        = GetU16LE(ulScriptPosition + 7);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  (value1 & (1 << value2)); break;
                    case 0x0A: result = !(value1 & (1 << value2)); break;
                    default: LOGGER->Log("Strange relation: %02x", relation);
                }

                if (result != true)
                {
                    ulScriptPosition += jump - 2;
                }

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(bank = %02x, value1 = %04x, value2 = %04x, relation = %02x, jump = %04x)", opcodes_names[opcode].c_str(), memory_bank, value1, value2, relation, jump);
                }
            }
            break;



//case 0x1A:
//case 0x1B:
//case 0x1C:
//case 0x1D:
//case 0x1E:
//case 0x1F:

//case 0x20:
//case 0x21:
//case 0x22:
//case 0x23:



            // Wait specified number of frames
            case WAIT: // 0x24
            {
                u16 frames_to_wait = GetU16LE(ulScriptPosition + 1);

                pFieldModule->mObjectManager.SetFramesToWait(sbEntityId, frames_to_wait);

                ulScriptPosition += opcodes_size[opcode];

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(frames = %02x)", opcodes_names[opcode].c_str(), frames_to_wait);
                }

                return false;
            }
            break;



//case 0x25:
//case 0x26:
//case 0x27:
//case 0x28:
//case 0x29:
//case 0x2A:
//case 0x2B:
//case 0x2C:
//case 0x2D:
//case 0x2E:
//case 0x2F:
//case 0x30:
//case 0x31:
//case 0x32:



            // Character movability
            case UC: // 0x33
            {
                u8 movability = GetU8(ulScriptPosition + 1);

                pFieldModule->mObjectManager.SetPlayerCharacrerMovability(movability);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(movability = %02x)", opcodes_names[opcode].c_str(), movability);
                }
            }
            break;



//case 0x34:
//case 0x35:



            // Window Special
            case WSPCL: // 0x36
            {
                u8 window_id = GetU8(ulScriptPosition + 1);
                u8 type      = GetU8(ulScriptPosition + 2);
                u8 x         = GetU8(ulScriptPosition + 3);
                u8 y         = GetU8(ulScriptPosition + 4);

                pFieldModule->mWindowManager.SetSpecialStyle(window_id, x, y, type);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(id = %02x, type = %02x, x = %02x, y = %02x)", opcodes_names[opcode].c_str(), window_id, x, y, type);
                }
            }
            break;



            // Set Number
            case WNUMB: // 0x37
            {
                // need to be fixed
                u8  memory_bank_1 = GetU8(ulScriptPosition + 1) >> 4;
                u8  memory_bank_2 = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  window_id     = GetU8(ulScriptPosition + 2);
                u32 digit         = KERNEL->GetGamestate().MemoryBankGet(memory_bank_1, GetU16LE(ulScriptPosition + 3)) | (KERNEL->GetGamestate().MemoryBankGet(memory_bank_2, GetU16LE(ulScriptPosition + 5)) << 16);
                u8  digit_number  = GetU8(ulScriptPosition + 7);

                pFieldModule->mWindowManager.SetSpecialNumber(window_id, digit, digit_number);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(mb1 = %02x, mb2 = %02x, w_id = %02x, digit = %08x, num = %02x)", opcodes_names[opcode].c_str(), memory_bank_1, memory_bank_2, window_id, digit, digit_number);
                }
            }
            break;



            // Set Timer
            case STTIM: // 0x38
            {
                // need to be fixed
                u8  memory_bank_1 = GetU8(ulScriptPosition + 1) >> 4;
                u8  memory_bank_2 = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  memory_bank_3 = GetU8(ulScriptPosition + 2) & 0x0F;
                u8  hours         = KERNEL->GetGamestate().MemoryBankGet(memory_bank_1, GetU8(ulScriptPosition + 3));
                u8  minutes       = KERNEL->GetGamestate().MemoryBankGet(memory_bank_2, GetU8(ulScriptPosition + 4));
                u8  seconds       = KERNEL->GetGamestate().MemoryBankGet(memory_bank_3, GetU8(ulScriptPosition + 5));

                // set timer in memory bank
                KERNEL->GetGamestate().MemoryBankPut(0x01, 0x15, hours);
                KERNEL->GetGamestate().MemoryBankPut(0x01, 0x16, minutes);
                KERNEL->GetGamestate().MemoryBankPut(0x01, 0x17, seconds);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(hours = %02x, minutes = %02x, seconds = %02x)", opcodes_names[opcode].c_str(), hours, minutes, seconds);
                }
            }
            break;



//case 0x39:
//case 0x3A:
//case 0x3B:
//case 0x3C:
//case 0x3D:
//case 0x3E:
//case 0x3F:



            // Open a message
            case MESSAGE: // 0x40
            {
                u8 memory_bank = 0;
                u8 window_id   = GetU8(ulScriptPosition + 1);
                u8 dialog_id   = GetU8(ulScriptPosition + 2);
                u8 first       = 0;
                u8 last        = 0;
                u8 offset      = 0;

                // set syncronize with window
                pFieldModule->mObjectManager.SetWait(sbEntityId, true);
                pFieldModule->mWindowManager.ShowMessage(window_id, dialog_id, first, last, memory_bank, offset, sbEntityId);

                ulScriptPosition += opcodes_size[opcode];

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(w_id = %02x, d_id = %02x)", opcodes_names[opcode].c_str(), window_id, dialog_id);
                }

                return false;
            }
            break;



//case 0x41:
//case 0x42:



            // Set dialog as map name
            case MPNAM: // 0x43
            {
                u8 dialog_id   = GetU8(ulScriptPosition + 1);

                pFieldModule->mWindowManager.SetMapName(dialog_id);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(dialog_id = %02x)", opcodes_names[opcode].c_str(), dialog_id);
                }
            }
            break;



//case 0x44:
//case 0x45:
//case 0x46:
//case 0x47:



            // Open a choice dialog box
            case ASK: // 0x48
            {
                u8 memory_bank = GetU8(ulScriptPosition + 1);
                u8 window_id   = GetU8(ulScriptPosition + 2);
                u8 dialog_id   = GetU8(ulScriptPosition + 3);
                u8 first       = GetU8(ulScriptPosition + 4);
                u8 last        = GetU8(ulScriptPosition + 5);
                u8 offset      = GetU8(ulScriptPosition + 6);

                // set syncronize with window
                pFieldModule->mObjectManager.SetWait(sbEntityId, true);
                pFieldModule->mWindowManager.ShowMessage(window_id, dialog_id, first, last, memory_bank, offset, sbEntityId);

                ulScriptPosition += opcodes_size[opcode];

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(bank = %02x, w_id = %02x, d_id = %02x, 1st = %02x, last = %02x, offset = %02x)", opcodes_names[opcode].c_str(), memory_bank, window_id, dialog_id, first, last, offset);
                }

                return false;
            }
            break;



//case 0x49:



            // Main menu accessibility
            case MENU2: // 0x4A
            {
                u8 menu_disabled = GetU8(ulScriptPosition + 1);

                pFieldModule->m_bMenuAccess = (menu_disabled == 0) ? true : false;

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(menu_disabled = %02x)", opcodes_names[opcode].c_str(), menu_disabled);
                }
            }
            break;



            // Switches battle table
            case BTLTB: // 0x4B
            {
                u8 encounter_table = GetU8(ulScriptPosition + 1);

                pFieldModule->mObjectManager.SetEncounterTable(encounter_table);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(encounter_table = %02x)", opcodes_names[opcode].c_str(), encounter_table);
                }
            }
            break;



//case 0x4C:
//case 0x4D:
//case 0x4E:
//case 0x4F:



            // Initializes a windowpane
            case WINDOW: // 0x50
            {
                u8  id     = GetU8(ulScriptPosition + 1);
                u16 x      = GetU16LE(ulScriptPosition + 2);
                u16 y      = GetU16LE(ulScriptPosition + 4);
                u16 width  = GetU16LE(ulScriptPosition + 6);
                u16 height = GetU16LE(ulScriptPosition + 8);

                pFieldModule->mWindowManager.SetWindow(id, x, y, width, height);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(id = %02x, x = %04x, y = %04x, width = %04x, height = %04x)", opcodes_names[opcode].c_str(), id, x, y, width, height);
                }
            }
            break;



//case 0x51:



            // Change window mode
            case WMODE: // 0x52
            {
                u8 id    = GetU8(ulScriptPosition + 1);
                u8 style = GetU8(ulScriptPosition + 2);
                u8 cbc   = GetU8(ulScriptPosition + 3);

                pFieldModule->mWindowManager.SetWindowStyle(id, style, cbc);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(id = %02x, style = %02x, cbc = %02x)", opcodes_names[opcode].c_str(), id, style, cbc);
                }
            }
            break;



            // Reset window
            case WREST: // 0x53
            {
                u8 id = GetU8(ulScriptPosition + 1);

                pFieldModule->mWindowManager.ResetWindow(id);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(id = %02x)", opcodes_names[opcode].c_str(), id);
                }
            }
            break;



//case 0x54:
//case 0x55:
//case 0x56:
//case 0x57:
//case 0x58:
//case 0x59:
//case 0x5A:
//case 0x5B:
//case 0x5C:
//case 0x5D:
//case 0x5E:



            // No operation
            case NOP: // 0x5F
            {
                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s()", opcodes_names[opcode].c_str());
                }
            }
            break;



            // Load another map
            case MAPJUMP: // 0x60
            {
                u16 map_id    = GetU16LE(ulScriptPosition + 1);

                float x       = static_cast<s16>(GetU16LE(ulScriptPosition + 3));
                float z       = static_cast<s16>(GetU16LE(ulScriptPosition + 5));
                float y       = static_cast<s16>(GetU16LE(ulScriptPosition + 7));

                u8  direction = GetU8(ulScriptPosition + 9);

                KERNEL->GetGamestate().PlayerPositionSet(Vector3(x, y, z));
                KERNEL->GetGamestate().PlayerTriangleUnset();

                pFieldModule->RequestLoadMap(map_id);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(id = %04x, x = %f, y = %f, z = %f, dir = %02x)", opcodes_names[opcode].c_str(), map_id, x, y, z, direction);
                }
            }
            break;



//case 0x61:
//case 0x62:
//case 0x63:



            // Scroll 2D
            case SCR2D: // 0x64
            {
                u8  memory_bank_x = GetU8(ulScriptPosition + 1) >> 4;
                u16 offset_x      = GetU16LE(ulScriptPosition + 2);
                s16 x             = KERNEL->GetGamestate().MemoryBankGet(memory_bank_x, offset_x);

                u8  memory_bank_y = GetU8(ulScriptPosition + 1) & 0x0F;
                u16 offset_y      = GetU16LE(ulScriptPosition + 4);
                s16 y             = KERNEL->GetGamestate().MemoryBankGet(memory_bank_y, offset_y);

                pFieldModule->m_CameraManager.ScrollToCoordsInstant(x, y);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(x = %d, y = %d)", opcodes_names[opcode].c_str(), x, y);
                }
            }
            break;



//case 0x65:



            // Scroll 2D Smooth
            case SCR2DC: // 0x66
            {
                u8  memory_bank = GetU8(ulScriptPosition + 1) >> 4;
                u16 offset      = GetU16LE(ulScriptPosition + 3);
                s16 x           = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);

                    memory_bank = GetU8(ulScriptPosition + 1) & 0x0F;
                    offset      = GetU16LE(ulScriptPosition + 5);
                s16 y           = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);

                    memory_bank = GetU8(ulScriptPosition + 2) & 0x0F;
                    offset      = GetU16LE(ulScriptPosition + 7);
                u16 speed       = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);

                pFieldModule->m_CameraManager.ScrollToCoordsSmooth(x, y, speed);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(x = %d, y = %d, speed = %d)", opcodes_names[opcode].c_str(), x, y, speed);
                }
            }
            break;



            // Wait for scroll
            case SCRLW: // 0x67
            {
                pFieldModule->mObjectManager.SetWait(sbEntityId, true);
                pFieldModule->m_CameraManager.AddWaitForScroll(sbEntityId);

                ulScriptPosition += opcodes_size[opcode];

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s()", opcodes_names[opcode].c_str());
                }

                return false;
            }
            break;



            // Scroll 2D Linear
            case SCR2DL: // 0x68
            {
                u8  memory_bank = GetU8(ulScriptPosition + 1) >> 4;
                u16 offset      = GetU16LE(ulScriptPosition + 3);
                s16 x           = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);

                    memory_bank = GetU8(ulScriptPosition + 1) & 0x0F;
                    offset      = GetU16LE(ulScriptPosition + 5);
                s16 y           = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);

                    memory_bank = GetU8(ulScriptPosition + 2) & 0x0F;
                    offset      = GetU16LE(ulScriptPosition + 7);
                u16 speed       = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);

                pFieldModule->m_CameraManager.ScrollToCoordsLinear(x, y, speed);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(x = %d, y = %d, speed = %d)", opcodes_names[opcode].c_str(), x, y, speed);
                }
            }
            break;



//case 0x69:
//case 0x6A:



            // Fade
            case FADE: // 0x6B
            {
                u8 red   = KERNEL->GetGamestate().MemoryBankGet(GetU8(ulScriptPosition + 1) >> 4,   GetU8(ulScriptPosition + 3));
                u8 green = KERNEL->GetGamestate().MemoryBankGet(GetU8(ulScriptPosition + 1) & 0x0F, GetU8(ulScriptPosition + 4));
                u8 blue  = KERNEL->GetGamestate().MemoryBankGet(GetU8(ulScriptPosition + 2) & 0x0F, GetU8(ulScriptPosition + 5));

                u8 speed = GetU8(ulScriptPosition + 6);
                u8 type  = GetU8(ulScriptPosition + 7);
                u8 start = GetU8(ulScriptPosition + 8);

                Color color(red / 256.0f, green / 256.0f, blue / 256.0f, 1.0f);

                pFieldModule->Fade(speed, start, color, type);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(red = %x, green = %x, blue = %x, speed = %x, type = %x, start = %x)", opcodes_names[opcode].c_str(), red, green, blue, speed, type, start);
                }
            }
            break;



            // Wait for fade
            case FADEW: // 0x6C
            {
                pFieldModule->mObjectManager.SetWait(sbEntityId, true);
                pFieldModule->AddWaitForFade(sbEntityId);

                ulScriptPosition += opcodes_size[opcode];

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s()", opcodes_names[opcode].c_str());
                }

                return false;
            }
            break;



            // Triangle Boundary
            case IDLCK: // 0x6D
            {
                u16 id    = GetU16LE(ulScriptPosition + 1);
                u8  lock  = GetU8(ulScriptPosition + 3);

                pFieldModule->mObjectManager.SetTriangleAccess(id, lock);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(id = %04x, lock = %02x)", opcodes_names[opcode].c_str(), id, lock);
                }
            }
            break;



//case 0x6E:
//case 0x6F:



            case BATTLE: // 0x70
            {
                u8  bank      = GetU8(ulScriptPosition + 1) & 0x0F;
                u16 offset    = GetU16LE(ulScriptPosition + 2);

                u16 battle_id = KERNEL->GetGamestate().MemoryBankGet(bank, offset);

                pFieldModule->LoadBattle(battle_id);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(bank = %02x, offset = %04x)", opcodes_names[opcode].c_str(), bank, offset);
                }
            }



            // enable or disable battle on current field
            case BTLON: // 0x71
            {
                u8  disable = GetU8(ulScriptPosition + 1);

                pFieldModule->mObjectManager.DisableEncounter(disable);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(disable = %02x)", opcodes_names[opcode].c_str(), disable);
                }
            }



//case 0x72:
//case 0x73:
//case 0x74:
//case 0x75:



            // Saturated Addition (8-bit)
            case PLUSx: // 0x76
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u8  value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);
                u8  value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                u16 result = (u16)value1 + (u16)value2;
                result = (result > 0xFF) ? 0xFF : result;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, (u8)result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %02x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Saturated Addition (16-bit)
            case PLUS2x: // 0x77
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u16 source_offset      = GetU16LE(ulScriptPosition + 3);

                s16 value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, (u16)destination_offset);
                s16 value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                s32 result = (s32)value1 + (s32)value2;
                result = (result > 32767) ? 32767 : result;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, (u16)((s16)result));

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Saturated Subtraction (8-bit)
            case MINUSx: // 0x78
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u8  value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);
                u8  value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                u8  result = (value1 > value2) ? value1 - value2 : 0;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %02x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Saturated Subtraction (16-bit)
            case MINUS2x: // 0x79
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u16 source_offset      = GetU16LE(ulScriptPosition + 3);

                s16 value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, (u16)destination_offset);
                s16 value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                s32 result = (s32)value1 - (s32)value2;
                result = (result < -32767) ? -32767 : result;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, (u16)((s16)result));

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Saturated Increment (8-bit)
            case INCx: // 0x7A
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);

                u8 value = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);

                value = (value >= 0xFF) ? 0xFF : value + 1;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, value);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, destination_offset = %02x)", opcodes_names[opcode].c_str(), destination_bank, destination_offset);
                }
            }
            break;



            // Saturated Increment (16-bit)
            case INC2x: // 0x7B
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) & 0x0F;
                u16 destination_offset = GetU8(ulScriptPosition + 2);

                s16 value              = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);

                value = (value >= 32767) ? 32767 : value + 1;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, (u8)destination_offset, (u16)value);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, destination_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, destination_offset);
                }
            }
            break;



            // Saturated Decrement (8-bit)
            case DECx: // 0x7C
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);

                u8 value = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);

                value = (value <= 0x00) ? 0x00 : value - 1;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, value);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, destination_offset = %02x)", opcodes_names[opcode].c_str(), destination_bank, destination_offset);
                }
            }
            break;



            // Saturated Decrement (16-bit)
            case DEC2x: // 0x7D
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) & 0x0F;
                u16 destination_offset = GetU8(ulScriptPosition + 2);

                s16 value              = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);

                value = (value <= -32767) ? -32767 : value - 1;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, (u8)destination_offset, (u16)value);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, destination_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, destination_offset);
                }
            }
            break;



//case 0x7E



            // Seed Random Generator (16-bit)
            case RDMSD: // 0x7F
            {
                u8  source_bank   = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  source_offset = GetU8(ulScriptPosition + 2);

                s8  value         = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                srand(value);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(source_bank = %02x, source_offset = %02x)", opcodes_names[opcode].c_str(), source_bank, source_offset);
                }
            }
            break;



            // Assignment (8 bit)
            case SETBYTE: // 0x80
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u8  value              = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, value);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Assignment (16 bit)
            case SETWORD: // 0x81
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u16 source_offset      = GetU16LE(ulScriptPosition + 3);

                u16 value              = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, value);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %04x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Set Bit (8 bit)
            case BITON: // 0x82
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u8  value              = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);
                u8  shift              = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                value |= 1 << shift;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, value);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(value = %02x, shift = %02x)", opcodes_names[opcode].c_str(), value, shift);
                }
            }
            break;



            // Reset Bit (8 bit)
            case BITOFF: // 0x83
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u8  value              = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);
                u8  shift              = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                value &= ~(1 << shift);

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, value);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(value = %02x, shift = %02x)", opcodes_names[opcode].c_str(), value, shift);
                }
            }
            break;



            // Toggle Bit (8 bit)
            case BITXOR: // 0x84
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u8  value              = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);
                u8  shift              = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                value ^= 1 << shift;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, value);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %04x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Addition (8-bit)
            case PLUS: // 0x85
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u16 value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);
                u16 value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                u16 result = value1 + value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, (u8)result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %04x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Addition (16-bit)
            case PLUS2: // 0x86
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u16 source_offset      = GetU16LE(ulScriptPosition + 3);

                s32 value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, (u16)destination_offset);
                s32 value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                s32 result = value1 + value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, (u16)((s16)result));

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %04x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Subtraction (8-bit)
            case MINUS: // 0x87
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u8  value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);
                u8  value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                u8  result = value1 - value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %02x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Subtraction (16-bit)
            case MINUS2: // 0x88
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u16 source_offset      = GetU16LE(ulScriptPosition + 3);

                s32 value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, (u16)destination_offset);
                s32 value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                s32 result = value1 - value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, (u16)((s16)result));

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Multiplication (8-bit)
            case MUL: // 0x89
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u8  value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);
                u8  value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                u8  result = value1 * value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %02x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Multiplication (16-bit)
            case MUL2: // 0x8A
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u16 source_offset      = GetU16LE(ulScriptPosition + 3);

                s32 value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, (u16)destination_offset);
                s32 value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                s32 result = value1 * value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, (u16)((s16)result));

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Division (8-bit)
            case DIV: // 0x8B
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u8  value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);
                u8  value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                u8  result = value1 / value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %02x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Division (16-bit)
            case DIV2: // 0x8C
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u16 source_offset      = GetU16LE(ulScriptPosition + 3);

                s32 value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, (u16)destination_offset);
                s32 value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                s32 result = value1 / value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, (u16)((s16)result));

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Modulus (8-bit)
            case MOD: // 0x8D
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u8  value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);
                u8  value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                u8  result = value1 % value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %02x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Modulus (16-bit)
            case MOD2: // 0x8E
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u16 source_offset      = GetU16LE(ulScriptPosition + 3);

                s32 value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, (u16)destination_offset);
                s32 value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                s32 result = value1 % value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, (u16)((s16)result));

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Bit-wise And (8-bit)
            case AND: // 0x8F
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u8  value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);
                u8  value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                u8  result = value1 & value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %02x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Bit-wise And (16-bit)
            case AND2: // 0x90
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u16 source_offset      = GetU16LE(ulScriptPosition + 3);

                u16 value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, (u16)destination_offset);
                u16 value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                u16 result = value1 & value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Bit-wise Or (8-bit)
            case OR: // 0x91
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u8  value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);
                u8  value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                u8  result = value1 | value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %02x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Bit-wise Or (16-bit)
            case OR2: // 0x92
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u16 source_offset      = GetU16LE(ulScriptPosition + 3);

                u16 value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, (u16)destination_offset);
                u16 value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                u16 result = value1 | value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Bit-wise Xor (8-bit)
            case XOR: // 0x93
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u8  value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);
                u8  value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                u8  result = value1 ^ value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %02x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Bit-wise Xor (16-bit)
            case XOR2: // 0x94
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u16 source_offset      = GetU16LE(ulScriptPosition + 3);

                u16 value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, (u16)destination_offset);
                u16 value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                u16 result = value1 ^ value2;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Increment (8-bit)
            case INC: // 0x95
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);

                u8 value = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);

                ++value;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, value);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, destination_offset = %02x)", opcodes_names[opcode].c_str(), destination_bank, destination_offset);
                }
            }
            break;



            // Increment (16-bit)
            case INC2: // 0x96
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) & 0x0F;
                u16 destination_offset = GetU8(ulScriptPosition + 2);

                s16 value              = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);

                ++value;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, (u8)destination_offset, (u16)value);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, destination_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, destination_offset);
                }
            }
            break;



            // Decrement (8-bit)
            case DEC: // 0x97
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);

                u8 value = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);

                --value;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, value);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, destination_offset = %02x)", opcodes_names[opcode].c_str(), destination_bank, destination_offset);
                }
            }
            break;



            // Decrement (16-bit)
            case DEC2: // 0x98
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) & 0x0F;
                u16 destination_offset = GetU8(ulScriptPosition + 2);

                s16 value              = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);

                --value;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, (u8)destination_offset, (u16)value);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, destination_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, destination_offset);
                }
            }
            break;



            // Random (8bit)
            case RANDOM: // 0x99
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);

                u8  value              = (rand() >> 8) & 0xFF;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank,destination_offset,value);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, destination_offset = %02x)", opcodes_names[opcode].c_str(), destination_bank, destination_offset);
                }
            }
            break;



            // Low byte
            case LBYTE: // 0x9A
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u16 value              = KERNEL->GetGamestate().MemoryBankGet(source_bank, (u16)source_offset);
                u8  result             = value & 0xFF;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // High byte
            case HBYTE: // 0x9B
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 2);
                u8  source_offset      = GetU8(ulScriptPosition + 3);

                u16 value              = KERNEL->GetGamestate().MemoryBankGet(source_bank, (u16)source_offset);
                u8  result             = (value >> 8) & 0xFF;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source_bank, destination_offset, source_offset);
                }
            }
            break;



            // Word from 2 bytes
            case TWOBYTE: // 0x9C
            {
                u8  destination_bank   = GetU8(ulScriptPosition + 1) >> 4;
                u8  source1_bank       = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  source2_bank       = GetU8(ulScriptPosition + 2) & 0x0F;
                u8  destination_offset = GetU8(ulScriptPosition + 3);
                u8  source1_offset     = GetU8(ulScriptPosition + 4);
                u8  source2_offset     = GetU8(ulScriptPosition + 5);

                u8  value1             = KERNEL->GetGamestate().MemoryBankGet(source1_bank, source1_offset);
                u8  value2             = KERNEL->GetGamestate().MemoryBankGet(source2_bank, source2_offset);

                u16 result = value1 | (value2 << 8);

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, result);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(destination_bank = %02x, source1_bank = %02x, source2_bank = %02x, destination_offset = %02x, source1_offset = %04x, source2_offset = %04x)", opcodes_names[opcode].c_str(), destination_bank, source1_bank, source2_bank, destination_offset, source1_offset, source2_offset);
                }
            }
            break;



//case 0x9D
//case 0x9E
//case 0x9F



            // Define Playable character
            case PC: // 0xA0
            {
                s8 pc_id = GetU8(ulScriptPosition + 1);

                pFieldModule->mObjectManager.SetPlayerCharacter(sbEntityId, pc_id);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(pc_id = %02x)", opcodes_names[opcode].c_str(), pc_id);
                }
            }
            break;



            // Character definition
            case CHAR: // 0xA1
            {
                u8 character_id = GetU8(ulScriptPosition + 1);

                pFieldModule->mObjectManager.SetCharacter(sbEntityId, character_id);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(character_id = %02x)", opcodes_names[opcode].c_str(), character_id);
                }
            }
            break;



//case 0xA2
//case 0xA3
//case 0xA4



            // Place Object 
            case XYZI: // 0xA5
            {
                u8  memory_bank_1 = GetU8(ulScriptPosition + 1) >> 4;
                u8  memory_bank_2 = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  memory_bank_3 = GetU8(ulScriptPosition + 2) >> 4;
                u8  memory_bank_4 = GetU8(ulScriptPosition + 2) & 0x0F;
                float x      = static_cast<s16>(KERNEL->GetGamestate().MemoryBankGet(memory_bank_1, GetU16LE(ulScriptPosition + 3)));
                float z      = static_cast<s16>(KERNEL->GetGamestate().MemoryBankGet(memory_bank_2, GetU16LE(ulScriptPosition + 5)));
                float y      = static_cast<s16>(KERNEL->GetGamestate().MemoryBankGet(memory_bank_3, GetU16LE(ulScriptPosition + 7)));
                u16 triangle = KERNEL->GetGamestate().MemoryBankGet(memory_bank_4, GetU16LE(ulScriptPosition + 9));

                pFieldModule->mObjectManager.SetPositionByXYZTriangle(sbEntityId, Vector3(x, y, z), triangle);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(x = %f, y = %f, z = %f, triangle = %04x)", opcodes_names[opcode].c_str(), x, y, z, triangle);
                }
            }
            break;



//case 0xA6
//case 0xA7
//case 0xA8
//case 0xA9
//case 0xAA
//case 0xAB
//case 0xAC
//case 0xAD
//case 0xAE
//case 0xAF
//case 0xB0
//case 0xB1
//case 0xB2



            // Set direction
            case DIR: // 0xB3
            {
                u8  direction = KERNEL->GetGamestate().MemoryBankGet(GetU8(ulScriptPosition + 1), GetU8(ulScriptPosition + 2));

                pFieldModule->mObjectManager.SetDirection(sbEntityId, direction);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(direction = %02x)", opcodes_names[opcode].c_str(), direction);
                }
            }
            break;



//case 0xB4
//case 0xB5
//case 0xB6
//case 0xB7
//case 0xB8



            // Get Entity Triangle ID
            case GETAI: // 0xB9
            {
                u8 memory_bank = GetU8(ulScriptPosition + 1) & 0x0F;
                s8 entity_id   = GetU8(ulScriptPosition + 2);
                u8 offset      = GetU8(ulScriptPosition + 3);

                u16 triangle_id = pFieldModule->mObjectManager.GetEntityTriangleId(entity_id);

                KERNEL->GetGamestate().MemoryBankPut(memory_bank, offset, triangle_id);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(entity_id = %02x, triangle_id = %d)", opcodes_names[opcode].c_str(), entity_id, triangle_id);
                }
            }
            break;



//case 0xBA
//case 0xBB
//case 0xBC
//case 0xBD
//case 0xBE



            // Swich playable character to entity
            case CC: // 0xBF
            {
                s8 entity_id = GetU8(ulScriptPosition + 1);

                pFieldModule->mObjectManager.SetPlayerCharacterToEntity(entity_id);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(entity_id = %02x)", opcodes_names[opcode].c_str(), entity_id);
                }
            }
            break;



//case 0xC0
//case 0xC1



            // Ladder
            case LADER: // 0xC2
            {
                u8  memory_bank_1 = GetU8(ulScriptPosition + 1) >> 4;
                u8  memory_bank_2 = GetU8(ulScriptPosition + 1) & 0x0F;
                u8  memory_bank_3 = GetU8(ulScriptPosition + 2) >> 4;
                u8  memory_bank_4 = GetU8(ulScriptPosition + 2) & 0x0F;
                float x      = static_cast<s16>(KERNEL->GetGamestate().MemoryBankGet(memory_bank_1, GetU16LE(ulScriptPosition + 3)));
                float z      = static_cast<s16>(KERNEL->GetGamestate().MemoryBankGet(memory_bank_2, GetU16LE(ulScriptPosition + 5)));
                float y      = static_cast<s16>(KERNEL->GetGamestate().MemoryBankGet(memory_bank_3, GetU16LE(ulScriptPosition + 7)));
                u16 triangle = KERNEL->GetGamestate().MemoryBankGet(memory_bank_4, GetU16LE(ulScriptPosition + 9));

                pFieldModule->mObjectManager.SetEntityToLadder(sbEntityId, Vector3(x, y, z), triangle);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(x = %f, y = %f, z = %f, triangle = %04x)", opcodes_names[opcode].c_str(), x, y, z, triangle);
                }
            }
            break;



//case 0xC3
//case 0xC4
//case 0xC5
//case 0xC6
//case 0xC7



            // Set party character
            case PRTYP: // 0xC8
            {
                u8 character = GetU8(ulScriptPosition + 1);

                // add party character
                KERNEL->GetGamestate().PartyCharacterAdd(character);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(char = %02x)", opcodes_names[opcode].c_str(), character);
                }
            }
            break;



//case 0xC9



            // Set direction
            case PRTYE: // 0xCA
            {
                u8 character1 = GetU8(ulScriptPosition + 1);
                u8 character2 = GetU8(ulScriptPosition + 2);
                u8 character3 = GetU8(ulScriptPosition + 3);

                // add party character
                KERNEL->GetGamestate().PartyCharactersAdd(character1, character2, character3);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(char1 = %02x, char2 = %02x, char3 = %02x)", opcodes_names[opcode].c_str(), character1, character2, character3);
                }
            }
            break;



//case 0xCB
//case 0xCC
//case 0xCD
//case 0xCE
//case 0xCF



            // Line Definition
            case LINE: // 0xD0
            {
                float x1 = static_cast<s16>(GetU16LE(ulScriptPosition + 1));
                float z1 = static_cast<s16>(GetU16LE(ulScriptPosition + 3));
                float y1 = static_cast<s16>(GetU16LE(ulScriptPosition + 5));

                float x2 = static_cast<s16>(GetU16LE(ulScriptPosition + 7));
                float z2 = static_cast<s16>(GetU16LE(ulScriptPosition + 9));
                float y2 = static_cast<s16>(GetU16LE(ulScriptPosition + 11));

                pFieldModule->mObjectManager.AddLine(sbEntityId, Vector3(x1, y1, z1), Vector3(x2, y2, z2));

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(x1 = %d, y1 = %d, z1 = %d, x2 = %d, y2 = %d, z2 = %d)", opcodes_names[opcode].c_str(), x1, y1, z1, x2, y2, z2);
                }
            }
            break;



            // Line Switch on/off
            case LINON: // 0x33
            {
                u8 check = GetU8(ulScriptPosition + 1);

                pFieldModule->mObjectManager.SetLineCheck(check);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(check = %02x)", opcodes_names[opcode].c_str(), check);
                }
            }
            break;



//case 0xD2
//case 0xD3
//case 0xD4
//case 0xD5
//case 0xD6
//case 0xD7
//case 0xD8
//case 0xD9
//case 0xDA
//case 0xDB
//case 0xDC
//case 0xDD
//case 0xDE
//case 0xDF



            // Background on
            case BGON: // 0xE0
            {
                u8 group = KERNEL->GetGamestate().MemoryBankGet(GetU8(ulScriptPosition + 1) >> 4,   GetU8(ulScriptPosition + 2));
                u8 layer = KERNEL->GetGamestate().MemoryBankGet(GetU8(ulScriptPosition + 1) & 0x0F, GetU8(ulScriptPosition + 3));

                pFieldModule->mBackgroundManager.BackgroundOn(group, layer);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(group = %02x, layer = %02x)", opcodes_names[opcode].c_str(), group, layer);
                }
            }
            break;



            // Background off
            case BGOFF: // 0xE1
            {
                u8 group = KERNEL->GetGamestate().MemoryBankGet(GetU8(ulScriptPosition + 1) >> 4,   GetU8(ulScriptPosition + 2));
                u8 layer = KERNEL->GetGamestate().MemoryBankGet(GetU8(ulScriptPosition + 1) & 0x0F, GetU8(ulScriptPosition + 3));

                pFieldModule->mBackgroundManager.BackgroundOff(group, layer);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(group = %02x, layer = %02x)", opcodes_names[opcode].c_str(), group, layer);
                }
            }
            break;



//case 0xE2
//case 0xE3



            // Background clear
            case BGCLR: // 0xE4
            {
                u8 group = KERNEL->GetGamestate().MemoryBankGet(GetU8(ulScriptPosition + 1), GetU8(ulScriptPosition + 2));

                pFieldModule->mBackgroundManager.BackgroundClear(group);

                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("%s(group = %02x)", opcodes_names[opcode].c_str(), group);
                }
            }
            break;



//case 0xE5
//case 0xE6
//case 0xE7
//case 0xE8
//case 0xE9
//case 0xEA
//case 0xEB
//case 0xEC
//case 0xED
//case 0xEE
//case 0xEF
//case 0xF0
//case 0xF1
//case 0xF2
//case 0xF3
//case 0xF4
//case 0xF5
//case 0xF6
//case 0xF7
//case 0xF8
//case 0xF9
//case 0xFA
//case 0xFB
//case 0xFC
//case 0xFD
//case 0xFE
//case 0xFF



            default:
            {
                LOGGER->Log("Unimplemented opcode %02x (%s)", opcode, opcodes_names[opcode].c_str());

                if (opcodes_size[opcode] <= 0)
                {
                    return true;
                }
            }
        }



        // move script position
        ulScriptPosition += opcodes_size[opcode];
    }

    return true;
}



const u8
Script::GetU8(const u32& offset) const
{
    return static_cast<u8>(*(m_pBuffer + offset));
}



const u16
Script::GetU16LE(const u32& offset) const
{
    return ((u8*)m_pBuffer + offset)[0] | (((u8*)m_pBuffer + offset)[1] << 8);
}
