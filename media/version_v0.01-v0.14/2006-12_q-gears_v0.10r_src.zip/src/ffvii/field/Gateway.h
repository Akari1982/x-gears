// $Id: Gateway.h 116 2006-12-15 21:08:47Z crazy_otaku $

#ifndef GATEWAY_h
#define GATEWAY_h

#include "../../common/TypeDefine.h"

#include "Trigger.h"



class Gateway : public Trigger
{
public:
             Gateway(FieldModule* pFieldModule, const dGeomID& collision, const Vector3& position, const u16& mapId);
    virtual ~Gateway(void);

    void     OnEnter(void);
    void     OnLeave(void);

private:
    Vector3      mPosition;
    u16          mMapId;
};



#endif // GATEWAY_h
