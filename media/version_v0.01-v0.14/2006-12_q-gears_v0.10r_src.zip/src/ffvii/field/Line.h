// $Id$

#ifndef LINE_h
#define LINE_h

#include "../../common/TypeDefine.h"

#include "Trigger.h"



class Line : public Trigger
{
public:
             Line(FieldModule* pFieldModule, const dGeomID& collision, const s8& sbEntityId);
    virtual ~Line(void);

    void     OnEnter(void);
    void     OnLeave(void);

private:
    s8       m_sbEntityId;
};



#endif // LINE_h
