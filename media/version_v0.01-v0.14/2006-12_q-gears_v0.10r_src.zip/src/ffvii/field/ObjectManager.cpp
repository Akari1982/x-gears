// $Id$

#include "../../common/display/Display.h"
#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "FieldModule.h"
#include "ObjectManager.h"
#include "Math.h"
#include "../kernel/Kernel.h"



ObjectManager::ObjectManager(FieldModule* pFieldModule):
    m_pFieldModule(pFieldModule),

    m_bPlayerCharacterMovable(true),
    m_bLineCheck(true),

    m_bEncounterDisabled(false),
    m_ulDangerCounter(0),

    m_bDisplayCollisions(true),
    m_bDisplayWalkmesh(true)
{
    m_Space = dSimpleSpaceCreate(0);
}



ObjectManager::~ObjectManager(void)
{
    Clear();

    dSpaceDestroy(m_Space);

    Entity::DeleteScript();
}



void
ObjectManager::Clear(void)
{
    // clear entitys
    for (s8 i = 0; i < m_vpEntitys.size(); ++i)
    {
        delete m_vpEntitys[i];
    }
    m_vpEntitys.clear();

    m_bPlayerCharacterMovable = true;
    m_bLineCheck              = true;


    m_vWalkMesh.clear();



    m_vGateways.clear();
    m_vLines.clear();



    m_vEncounters.clear();
    m_bEncounterDisabled = false;



    // clear ode space (collision)
    dSpaceDestroy(m_Space);
    m_Space = dSimpleSpaceCreate(0);
}



void
ObjectManager::Draw(void)
{
    if (m_bDisplayWalkmesh == true)
    {
        std::vector<Vertex> line;
        line.resize(2);

        Vertex v;
        Color color_grant(217.0f / 255.0f, 217.0f / 255.0f, 217.0f / 255.0f, 1.0f);
        Color color_deny(191.0f / 255.0f, 0.0f, 0.0f, 1.0f);
        Color color_point(0.0f, 0.0f, 217.0f / 255.0f, 1.0f);

        DISPLAY->SetPolygonMode(POLYGON_LINE);
        DISPLAY->SetLineWidth(1);
        DISPLAY->SetPointSize(3);

        for (u8 i = 0; i < m_vWalkMesh.size(); ++i)
        {
            // if this triangle is accessible
            // if we allowed to cross border
            // and if triangle to which we can cross is allowed
            v.c = (m_vWalkMesh[i].accessible == true && m_vWalkMesh[i].access[0] != 0xFFFF && m_vWalkMesh[m_vWalkMesh[i].access[0]].accessible == true) ? color_grant : color_deny;
            v.p.x = m_vWalkMesh[i].A.x; v.p.y = m_vWalkMesh[i].A.y; v.p.z = m_vWalkMesh[i].A.z;
            line[0] = v;
            v.p.x = m_vWalkMesh[i].B.x; v.p.y = m_vWalkMesh[i].B.y; v.p.z = m_vWalkMesh[i].B.z;
            line[1] = v;
            DISPLAY->DrawLines(line);
            line[0].c = color_point;
            line[1].c = color_point;
            DISPLAY->DrawPoints(line);

            v.c = (m_vWalkMesh[i].accessible == true && m_vWalkMesh[i].access[1] != 0xFFFF && m_vWalkMesh[m_vWalkMesh[i].access[1]].accessible == true) ? color_grant : color_deny;
            v.p.x = m_vWalkMesh[i].B.x; v.p.y = m_vWalkMesh[i].B.y; v.p.z = m_vWalkMesh[i].B.z;
            line[0] = v;
            v.p.x = m_vWalkMesh[i].C.x; v.p.y = m_vWalkMesh[i].C.y; v.p.z = m_vWalkMesh[i].C.z;
            line[1] = v;
            DISPLAY->DrawLines(line);
            line[0].c = color_point;
            line[1].c = color_point;
            DISPLAY->DrawPoints(line);

            v.c = (m_vWalkMesh[i].accessible == true && m_vWalkMesh[i].access[2] != 0xFFFF && m_vWalkMesh[m_vWalkMesh[i].access[2]].accessible == true) ? color_grant : color_deny;
            v.p.x = m_vWalkMesh[i].A.x; v.p.y = m_vWalkMesh[i].A.y; v.p.z = m_vWalkMesh[i].A.z;
            line[0] = v;
            v.p.x = m_vWalkMesh[i].C.x; v.p.y = m_vWalkMesh[i].C.y; v.p.z = m_vWalkMesh[i].C.z;
            line[1] = v;
            DISPLAY->DrawLines(line);
            line[0].c = color_point;
            line[1].c = color_point;
            DISPLAY->DrawPoints(line);
        }

        DISPLAY->SetPolygonMode(POLYGON_FILL);
    }



    // draw character
    for (s8 i = 0; i < m_vpEntitys.size(); ++i)
    {
        if (m_vpEntitys[i]->IsActionEnabled() == true)
        {
            m_vpEntitys[i]->Draw();

            if (m_bDisplayCollisions == true)
            {
                m_vpEntitys[i]->DrawCollision();
            }
        }
    }



    // draw triggers
    for (u8 i = 0; i < m_vGateways.size(); ++i)
    {
        m_vGateways[i].Draw();
    }



    // draw lines
    for (u8 i = 0; i < m_vLines.size(); ++i)
    {
        m_vLines[i].Draw();
    }
}



void
ObjectManager::DrawDebugInfo(void)
{
    RString temp;

    s8 pc = GetPlayerEntity();
    if (pc != -1)
    {
        Vector3 pos = m_vpEntitys[pc]->GetPosition();
        u16     tri = m_vpEntitys[pc]->GetTriangle();
        u8      dir = m_vpEntitys[pc]->GetDirection();

        temp.Format("x(%f) y(%f) z(%f)", pos.x, pos.y, pos.z);
        KERNEL->DrawString(RStringToFFVIIString(temp), 10, 10, F_WHITE);
        temp.Format("triangle = %d", tri);
        KERNEL->DrawString(RStringToFFVIIString(temp), 10, 25, F_WHITE);
        temp.Format("direction = %d", dir);
        KERNEL->DrawString(RStringToFFVIIString(temp), 10, 40, F_WHITE);
    }

    temp.Format("danger counter = %d", m_ulDangerCounter);
    KERNEL->DrawString(RStringToFFVIIString(temp), 10, 65, F_WHITE);
}



bool
ObjectManager::Input(const InputEvent &input)
{
    bool ret = false;


    if (m_bPlayerCharacterMovable == true)
    {
        // handle moving
        static float step = 20.0f;
        Vector3 next_step(0.0f, 0.0f, 0.0f);

        if (input.type == IET_REPEAT)
        {
            switch (input.button)
            {
                case KEY_UP:    next_step.z =  step; ret = true; break;
                case KEY_DOWN:  next_step.z = -step; ret = true; break;
                case KEY_LEFT:  next_step.x = -step; ret = true; break;
                case KEY_RIGHT: next_step.x =  step; ret = true; break;
            }
        }

        s8 pc = GetPlayerEntity();
        if ((next_step.x != 0.0f || next_step.z != 0.0f) && pc != -1)
        {
            // if we can do something
            if (m_vpEntitys[pc]->IsActionEnabled() == true)
            {
                if (m_vpEntitys[pc]->IsOnLadder() == false)
                {
                    // if we make move
                    if (SetNextStep(pc, next_step, false) == true)
                    {
                        CheckTriggers(pc);
                        CheckEncounters();
                    }
                }
                else
                {
                    SetNextLadderStep(pc, next_step);
                }
            }
        }
    }



    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_C4:    m_bDisplayWalkmesh   = (m_bDisplayWalkmesh) ? false : true; break;
            case KEY_C5:    m_bDisplayCollisions = (m_bDisplayCollisions) ? false : true; break;

            case KEY_Cx:
            {
                for (s8 i = 0; i < m_vpEntitys.size(); ++i)
                {
                    if (m_vpEntitys[i]->IsTalkable() == true)
                    {
                        m_vpEntitys[i]->RequestRun(0, 1);
                        ret = true;
                        break;
                    }
                }
            }
            break;
        }
    }
}



void
ObjectManager::Update(const u32& ulDeltaTime)
{
    s8 i;

    for (i = 0; i < m_vpEntitys.size(); ++i)
    {
        m_vpEntitys[i]->Run(m_pFieldModule, i);
    }



    // ode collision
    // update collision position
    for (i = 0; i < m_vpEntitys.size(); ++i)
    {
        if (m_vpEntitys[i]->IsActionEnabled() == true)
        {
            Vector3 pos = m_vpEntitys[i]->GetPosition();
            float   dir = m_vpEntitys[i]->GetDirection();

            dGeomSetPosition(m_vpEntitys[i]->GetCollision()    , pos.x, pos.y, pos.z);
            dGeomSetPosition(m_vpEntitys[i]->GetCollisionTalk(), pos.x, pos.y, pos.z);
            dMatrix3 rot;
            dRFromAxisAndAngle(rot, 0, 1, 0, (dir / 255.0f) * 2 * 3.1415926);
            dGeomSetRotation(m_vpEntitys[i]->GetCollision(),     rot);
            dGeomSetRotation(m_vpEntitys[i]->GetCollisionTalk(), rot);
        }
    }



    // check talk
    dContact contact;
    s8 pc = GetPlayerEntity();

    if (pc != -1)
    {
        for (i = 0; i < m_vpEntitys.size(); ++i)
        {
            if (i != pc && m_vpEntitys[i]->IsActionEnabled() == true && m_vpEntitys[pc]->IsActionEnabled() == true)
            {
                m_vpEntitys[i]->CheckCollisionTalk(m_vpEntitys[pc]);
            }
        }
    }
}



void
ObjectManager::PushEntity(Entity* pEntity)
{
    m_vpEntitys.push_back(pEntity);
}



void
ObjectManager::AddWalkMeshTriangle(const WalkMeshTriangle& triangle)
{
    m_vWalkMesh.push_back(triangle);
}



void
ObjectManager::AddGateway(const Vector3& point1, const Vector3& point2, const Vector3& position, const u16& mapId)
{
    dGeomID ray = dCreateRay(m_Space, 1);
    dGeomRaySet(ray, point1.x, point1.y, point1.z, point2.x - point1.x, point2.y - point1.y, point2.z - point1.z);

    m_vGateways.push_back(Gateway(m_pFieldModule, ray, position, mapId));
}



void
ObjectManager::AddEncounterTable(const EncounterTable& encounterTable)
{
    // if this table is enabled - disable all others
    if (encounterTable.enabled == true)
    {
        for (u8 i = 0; i < m_vEncounters.size(); ++i)
        {
            m_vEncounters[i].enabled = false;
        }
    }

    m_vEncounters.push_back(encounterTable);
}



void
ObjectManager::RequestRunEntity(const s8& sbEntityId, const u8& ubPriority, const u8& ubScriptId)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::RequestRunEntity: Request to run entity with Id larger than number of entity.");
        return;
    }

    m_vpEntitys[sbEntityId]->RequestRun(ubPriority, ubScriptId);
}



void
ObjectManager::SetFramesToWait(const s8& sbEntityId, const u16& usWait)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::SetFramesToWait: Request to wait entity with Id larger than number of entity.");
        return;
    }

    m_vpEntitys[sbEntityId]->SetFramesToWait(usWait);
}



void
ObjectManager::SetPlayerCharacrerMovability(const bool& bMovability)
{
    m_bPlayerCharacterMovable = !bMovability;
}



void
ObjectManager::SetEncounterTable(const u8& ubEncounterTable)
{
    if (ubEncounterTable >= m_vEncounters.size())
    {
        LOGGER->Log("ObjectManager::SetEncounterTable: Tried set mActiveEncounter greater than current mEncounters number.");
        return;
    }

    // enable this table, disable others
    for (u8 i = 0; i < m_vEncounters.size(); ++i)
    {
        if (i == ubEncounterTable)
        {
            m_vEncounters[i].enabled = true;
        }
        else
        {
            m_vEncounters[i].enabled = false;
        }
    }
}



void
ObjectManager::SetTriangleAccess(const u16& usTriangleId, const u8& ubLock)
{
    if (usTriangleId >= m_vWalkMesh.size())
    {
        LOGGER->Log("ObjectManager::SetTriangleAccess: Tried set access to triangle that are not in walkmesh.");
        return;
    }

    m_vWalkMesh[usTriangleId].accessible = (ubLock == 1) ? false : true;
}



void
ObjectManager::DisableEncounter(const bool& bDisable)
{
    m_bEncounterDisabled = bDisable;
}



void
ObjectManager::SetPlayerCharacter(const s8& sbEntityId, const s8& sbPlayerCharacter)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::SetPlayerCharacter: Tried set player character to entity with Id larger than number of entity.");
        return;
    }

    m_vpEntitys[sbEntityId]->SetPlayerCharacter(sbPlayerCharacter);



    // we always play as 0 PC for now
    if (sbPlayerCharacter == 0)
    {
        // load position from gamestate
        if (KERNEL->GetGamestate().PlayerPositionIsSet() == true)
        {
            m_vpEntitys[sbEntityId]->SetPosition(KERNEL->GetGamestate().PlayerPositionGet());

            if (KERNEL->GetGamestate().PlayerTriangleIsSet() == true)
            {
                m_vpEntitys[sbEntityId]->SetTriangle(KERNEL->GetGamestate().PlayerTriangleGet());
                FixEntityPosition(sbEntityId);
            }
            else
            {
                SetPositionByXZ(sbEntityId, m_vpEntitys[sbEntityId]->GetPosition());
            }
        }
        else
        {
            m_vpEntitys[sbEntityId]->SetPositionFixed(false);
        }
    }
}



void
ObjectManager::SetCharacter(const s8& sbEntityId, const s8& sbCharacterId)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::SetCharacter: Tried set character to entity with Id larger than number of entity.");
        return;
    }

    dGeomID collision      = dCreateBox(m_Space, 40, 50, 40);
    dGeomID collision_talk = dCreateBox(m_Space, 60, 60, 60);

    m_vpEntitys[sbEntityId]->SetModelId(sbCharacterId);
    m_vpEntitys[sbEntityId]->SetCollision(collision);
    m_vpEntitys[sbEntityId]->SetCollisionTalk(collision_talk);
}



void
ObjectManager::SetPositionByXYZTriangle(const s8& sbEntityId, const Vector3& coords, const u16& usTriangleId)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::SetPositionByXYZTriangle: Tried set position to entity with Id larger than number of entity.");
        return;
    }

    if (m_vpEntitys[sbEntityId]->IsPositionFixed() == true)
    {
        return;
    }

    m_vpEntitys[sbEntityId]->SetPosition(coords);
    m_vpEntitys[sbEntityId]->SetTriangle(usTriangleId);
    FixEntityPosition(sbEntityId);
}



void
ObjectManager::SetDirection(const s8 sbEntityId, const u8 ubDirection)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::SetDirection: Tried set direction to entity with Id larger than number of entity.");
        return;
    }

    m_vpEntitys[sbEntityId]->SetDirection(ubDirection);
}



const u16
ObjectManager::GetEntityTriangleId(const s8 sbEntityId)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::GetEntityTriangleId: Tried get triangle id from entity with Id larger than number of entity.");
        return 0;
    }

    return m_vpEntitys[sbEntityId]->GetTriangle();
}



void
ObjectManager::SetPlayerCharacterToEntity(const s8 sbEntityId)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::SetPlayerCharacterToEntity: Tried set player character to entity with Id larger than number of entity.");
        return;
    }

    if (m_vpEntitys[sbEntityId]->IsActionEnabled() == true)
    {
        for (u8 i = 0; i < m_vpEntitys.size(); ++i)
        {
            if (m_vpEntitys[i]->GetPlayerCharacter() == 0)
            {
                m_vpEntitys[i]->SetPlayerCharacter(-1);
            }

            if (i == sbEntityId)
            {
                m_vpEntitys[i]->SetPlayerCharacter(0);
            }
        }
    }
}



void
ObjectManager::SetEntityToLadder(const s8 sbEntityId, const Vector3& endPoint, const u16 usEndTriangle)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::SetEntityToLadder: Tried set change mode to ladder to entity with Id larger than number of entity.");
        return;
    }

    m_vpEntitys[sbEntityId]->SetOnLadder(true);
    m_vpEntitys[sbEntityId]->SetLadder(endPoint, usEndTriangle);
}



void
ObjectManager::AddLine(const s8 sbEntityId, const Vector3& point1, const Vector3& point2)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::AddLine: Tried add line to entity with Id larger than number of entity.");
        return;
    }

    dGeomID ray = dCreateRay(m_Space, 1);
    dGeomRaySet(ray, point1.x, point1.y, point1.z, point2.x - point1.x, point2.y - point1.y, point2.z - point1.z);

    m_vLines.push_back(Line(m_pFieldModule, ray, sbEntityId));
}



void
ObjectManager::SetLineCheck(const bool bCheck)
{
    m_bLineCheck = bCheck;
}



void
ObjectManager::SetPositionByXZ(const s8 sbEntityId, const Vector3& coords)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::SetPositionByXZ: Tried set position to entity with Id larger than number of entity.");
        return;
    }

    if (m_vpEntitys[sbEntityId]->IsPositionFixed() == true)
    {
        return;
    }

    // we search for the highest triangle
    // here we store highest Y value;
    Vector3 highest_point(0.0f, -10000.0f, 0.0f);
    u32     highest_triangle_id = 0;
    bool    highest_find = false;

    Vector3 point1 = coords;

    Vector3 point2;
    point2.x = point1.x + 10000.0f;
    point2.y = point1.y;
    point2.z = point1.z;

    for (u32 i = 0; i < m_vWalkMesh.size() ; ++i)
    {
        point1.y = point_elevation(point1, m_vWalkMesh[i].A, m_vWalkMesh[i].B, m_vWalkMesh[i].C);
        point2.y = point_elevation(point2, m_vWalkMesh[i].A, m_vWalkMesh[i].B, m_vWalkMesh[i].C);

        u8 check = 0;
        // if we cross line 1
        if (line_crossing(point1, point2, m_vWalkMesh[i].A, m_vWalkMesh[i].B) == true)
        {
            ++check;
        }
        // if we cross line 2
        if (line_crossing(point1, point2, m_vWalkMesh[i].B, m_vWalkMesh[i].C) == true)
        {
            ++check;
        }
        // if we cross line 3
        if (line_crossing(point1, point2, m_vWalkMesh[i].A, m_vWalkMesh[i].C) == true)
        {
            ++check;
        }



        // we are in triangle only if we cross one side
        if (check == 1)
        {
            if (highest_point.y < point1.y)
            {
                // store highest Y
                highest_point       = point1;
                highest_triangle_id = i;
                highest_find        = true;
            }
        }
    }



    if (highest_find == true)
    {
        m_vpEntitys[sbEntityId]->SetPosition(highest_point);
        m_vpEntitys[sbEntityId]->SetTriangle(highest_triangle_id);
        FixEntityPosition(sbEntityId);
    }
}



void
ObjectManager::SetWait(const s8 sbEntityId, const bool bWait)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::SetWait: Tried set wait to entity with Id larger than number of entity.");
        return;
    }

    m_vpEntitys[sbEntityId]->SetWait(bWait);
}

    

const bool
ObjectManager::SetNextStep(const s8 sbEntityId, const Vector3& moveVector, const bool bSlide)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::SetNextStep: Tried to move entity with Id larger than number of entity.");
        return false;
    }

    if (m_vpEntitys[sbEntityId]->IsActionEnabled() != true)
    {
        LOGGER->Log("ObjectManager::SetNextStep: Tried set move entity that are not ActionEnabled.");
        return false;
    }

    // if we are not moving anywhere
    if (moveVector.x == 0.0f && moveVector.z == 0.0f)
    {
        return false;
    }

    u16 triangle = m_vpEntitys[sbEntityId]->GetTriangle();
    u16 prev_triangle = 0xFFFE; // number of triangles never must be such great

    Vector3 start_point = m_vpEntitys[sbEntityId]->GetPosition();
    Vector3 end_point(start_point.x + moveVector.x,
                      start_point.y + moveVector.y,
                      start_point.z + moveVector.z);

    for (;;)
    {
        Vector3 A = m_vWalkMesh[triangle].A;
        Vector3 B = m_vWalkMesh[triangle].B;
        Vector3 C = m_vWalkMesh[triangle].C;



        // check if we cross board of current triangle
        u8 cross = 0x00;
        // if we cross line 1
        if      (line_crossing(start_point, end_point, A, B) == true && m_vWalkMesh[triangle].access[0] != prev_triangle)
        {
            cross = 0x01;
        }
        // if we cross line 2
        else if (line_crossing(start_point, end_point, B, C) == true && m_vWalkMesh[triangle].access[1] != prev_triangle)
        {
            cross = 0x02;
        }
        // if we cross line 3
        else if (line_crossing(start_point, end_point, A, C) == true && m_vWalkMesh[triangle].access[2] != prev_triangle)
        {
            cross = 0x03;
        }

        // if we do not cross border
        if (cross == 0x00)
        {
            end_point.y = point_elevation(end_point, A, B, C);

            if (CONFIG->mDumpSpecificGameData == true)
            {
                LOGGER->Log("final triangle = %d", triangle);
            }

            // check ode collision
            // update collision position
            dGeomSetPosition(m_vpEntitys[sbEntityId]->GetCollision(), end_point.x, end_point.y, end_point.z);

            dContact contact;
            int numc = 0;

            for (s8 i = 0; i < m_vpEntitys.size(); ++i)
            {
                if (i == sbEntityId || m_vpEntitys[i]->IsSolid() == false)
                {
                    continue;
                }

                if (m_vpEntitys[i]->IsActionEnabled() == true && m_vpEntitys[sbEntityId]->CheckCollision(m_vpEntitys[i]) == true)
                {
                    ++numc;
                    break;
                }
            }

            if (numc == 0)
            {
                m_vpEntitys[sbEntityId]->SetTriangle(triangle);
                m_vpEntitys[sbEntityId]->SetPosition(end_point);
                // store new place in gamestate
                KERNEL->GetGamestate().PlayerPositionSet(end_point);
                KERNEL->GetGamestate().PlayerTriangleSet(triangle);

                return true;
            }

            return false;
        }
        else
        {
            // if board can be crossed
            if (m_vWalkMesh[triangle].accessible == true &&
                m_vWalkMesh[triangle].access[cross - 1] != 0xFFFF &&
                m_vWalkMesh[m_vWalkMesh[triangle].access[cross - 1]].accessible == true)
            {
                // if line crosses corner of the triangle move final point a bit and recheck all things
                if (point_on_line(A, start_point, end_point) == true ||
                    point_on_line(B, start_point, end_point) == true ||
                    point_on_line(C, start_point, end_point) == true)
                {
                    if (CONFIG->mDumpSpecificGameData == true)
                    {
                        LOGGER->Log("We try to cross corner of triangle");
                    }
                    end_point.z += 0.01f;
                    end_point.x += 0.01f;
                    continue;
                }

                prev_triangle = triangle;
                triangle      = m_vWalkMesh[triangle].access[cross - 1];

                if (CONFIG->mDumpSpecificGameData == true)
                {
                    LOGGER->Log("cross = %d, prev_triangle = %d, triangle = %d", cross, prev_triangle, triangle);
                }
            }
            else
            {
                if (bSlide == false)
                {
                    Vector3 sp1 = (cross == 1 || cross == 3) ? A : B;
                    Vector3 sp2 = (cross == 1) ? B : C;

                    if (CONFIG->mDumpSpecificGameData == true)
                    {
                        LOGGER->Log("we met border");
                    }
                    Vector3 new_move = get_projection_on_line(moveVector, sp1, sp2);

                    if (CONFIG->mDumpSpecificGameData == true)
                    {
                        LOGGER->Log("we slide");
                    }

                    return SetNextStep(sbEntityId, new_move, true);
                }
                else
                {
                    if (CONFIG->mDumpSpecificGameData == true)
                    {
                        LOGGER->Log("we met border");
                        LOGGER->Log("we can't slide");
                    }

                    return false;
                }
            }
        }
    }
}



void
ObjectManager::SetNextLadderStep(const s8 sbEntityId, const Vector3& moveVector)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::SetNextStep: Tried to move entity with Id larger than number of entity.");
        return;
    }

    if (m_vpEntitys[sbEntityId]->IsActionEnabled() != true)
    {
        LOGGER->Log("ObjectManager::SetNextStep: Tried set move entity that are not ActionEnabled.");
        return;
    }

    // if we are not moving anywhere
    if (moveVector.z == 0.0f)
    {
        return;
    }

    Vector3 start_point   = m_vpEntitys[sbEntityId]->GetLadderStart();
    Vector3 current_point = m_vpEntitys[sbEntityId]->GetPosition();
    Vector3 end_point     = m_vpEntitys[sbEntityId]->GetLadderEnd();

    u8 finish_end   = 0;
    u8 finish_start = 0;

    float step;

    // x moving
    step = (end_point.x - start_point.x) / 100;
    if (start_point.x == current_point.x && moveVector.z < 0)
    {
        ++finish_start;
    }
    if (end_point.x == current_point.x && moveVector.z > 0)
    {
        ++finish_end;
    }
    if (moveVector.z > 0)
    {
        current_point.x += step;
        current_point.x = ((current_point.x > end_point.x && step > 0) || (current_point.x < end_point.x && step < 0)) ? end_point.x : current_point.x;
    }
    else if (moveVector.z < 0)
    {
        current_point.x -= step;
        current_point.x = ((current_point.x < start_point.x && step > 0) || (current_point.x < start_point.x && step < 0)) ? start_point.x : current_point.x;
    }



    // y moving
    step = (end_point.y - start_point.y) / 100;
    if (start_point.y == current_point.y && moveVector.z < 0)
    {
        ++finish_start;
    }
    if (end_point.y == current_point.y && moveVector.z > 0)
    {
        ++finish_end;
    }
    if (moveVector.z > 0)
    {
        current_point.y += step;
        current_point.y = ((current_point.y > end_point.y && step > 0) || (current_point.y < end_point.y && step < 0)) ? end_point.y : current_point.y;
    }
    else if (moveVector.z < 0)
    {
        current_point.y -= step;
        current_point.y = ((current_point.y < start_point.y && step > 0) || (current_point.y < start_point.y && step < 0)) ? start_point.y : current_point.y;
    }



    // z moving
    step = (end_point.z - start_point.z) / 100;
    if (start_point.z == current_point.z && moveVector.z < 0)
    {
        ++finish_start;
    }
    if (end_point.z == current_point.z && moveVector.z > 0)
    {
        ++finish_end;
    }
    if (moveVector.z > 0)
    {
        current_point.z += step;
        current_point.z = ((current_point.z > end_point.z && step > 0) || (current_point.z < end_point.z && step < 0)) ? end_point.z : current_point.z;
    }
    else if (moveVector.z < 0)
    {
        current_point.z -= step;
        current_point.z = ((current_point.z < start_point.z && step > 0) || (current_point.z < start_point.z && step < 0)) ? start_point.z : current_point.z;
    }



    if (finish_start == 3)
    {
        m_vpEntitys[sbEntityId]->SetPosition(start_point);
        m_vpEntitys[sbEntityId]->SetTriangle(m_vpEntitys[sbEntityId]->GetLadderTriangleStart());
        m_vpEntitys[sbEntityId]->SetOnLadder(false);
    }
    else if (finish_end == 3)
    {
        m_vpEntitys[sbEntityId]->SetPosition(end_point);
        m_vpEntitys[sbEntityId]->SetTriangle(m_vpEntitys[sbEntityId]->GetLadderTriangleEnd());
        m_vpEntitys[sbEntityId]->SetOnLadder(false);
    }
    else
    {
        m_vpEntitys[sbEntityId]->SetPosition(current_point);
    }
}



void
ObjectManager::CheckTriggers(const s8 sbEntityId)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::CheckTriggers: Tried check triggers  with entity with Id larger than number of entity.");
        return;
    }

    for (u8 i = 0; i < m_vGateways.size(); ++i)
    {
        m_vGateways[i].CheckCollision(m_vpEntitys[sbEntityId]->GetCollision());
    }

    // check entity lines
    if (m_bLineCheck == true)
    {
        for (u8 i = 0; i < m_vLines.size(); ++i)
        {
            m_vLines[i].CheckCollision(m_vpEntitys[sbEntityId]->GetCollision());
        }
    }
}



void
ObjectManager::CheckEncounters(void)
{
    // if battle locked
    if (KERNEL->GetGamestate().BattleLockGet() == true || m_bEncounterDisabled == true)
    {
        return;
    }



    for (u8 j = 0; j < m_vEncounters.size(); ++j)
    {
        // if field encounter not active
        if (m_vEncounters[j].enabled != true || m_vEncounters[j].rate == 0xFF)
        {
            continue;
        }

        m_ulDangerCounter += 1024 / (m_vEncounters[j].rate + 1);

        // check encounter
        if (rand() % 255 < m_ulDangerCounter / 256)
        {
            u16 battle = 0;

            // check special encounter
            for (u8 i = 0; i < 4; ++i)
            {
                if (rand() % 64 < m_vEncounters[j].special_encounter[i].rate)
                {
                    battle = m_vEncounters[j].special_encounter[i].scene;
                    break;
                }
            }



            // check standard encounter
            if (battle == 0)
            {
                u8 chance = rand() % 64;
                u8 chance_sum = 0;

                for (u8 i = 0; i < 6; ++i)
                {
                    if (m_vEncounters[j].standart_encounter[i].rate + chance_sum > chance)
                    {
                        battle = m_vEncounters[j].standart_encounter[i].scene;
                        break;
                    }

                    chance_sum += m_vEncounters[j].standart_encounter[i].rate;
                }
            }



            LOGGER->Log("Encount battle %d from table %d", battle, j);
            m_pFieldModule->LoadBattle(battle);
            return;
        }
    }
}



const s8
ObjectManager::GetPlayerEntity(void)
{
    for (s8 i = 0; i < m_vpEntitys.size(); ++i)
    {
        // we only play as character 0
        if (m_vpEntitys[i]->GetPlayerCharacter() == 0)
        {
            return i;
        }
    }

    return -1;
}



void
ObjectManager::FixEntityPosition(const s8 sbEntityId)
{
    if (sbEntityId >= m_vpEntitys.size())
    {
        LOGGER->Log("ObjectManager::FixEntityPosition: Tried fix position to entity with Id larger than number of entity.");
        return;
    }

    // fix Entity position
    m_vpEntitys[sbEntityId]->SetPositionFixed(true);
    // store player position set in gamestate
    s8 pc = GetPlayerEntity();
    if (sbEntityId == pc)
    {
        KERNEL->GetGamestate().PlayerPositionSet(m_vpEntitys[pc]->GetPosition());
        KERNEL->GetGamestate().PlayerTriangleSet(m_vpEntitys[pc]->GetTriangle());
    }
}
