// $Id: FieldModule.h 116 2006-12-15 21:08:47Z crazy_otaku $

#ifndef FIELDSCREEN_H
#define FIELDSCREEN_H

#include <string>
#include <vector>

#include "../../common/display/3dTypes.h"
#include "../../common/display/actor/Actor.h"

#include "BackgroundManager.h"
#include "CameraManager.h"
#include "DatFile.h"
#include "ObjectManager.h"
#include "WindowManager.h"
#include "../kernel/Kernel.h"

// forward declaration
class Script;



class FieldModule : public Actor
{
friend class Script;
friend class Line;
friend class CameraManager;
friend class WindowManager;
friend class ObjectManager;

public:
                 FieldModule();
    virtual     ~FieldModule();

    virtual void Init();
    virtual void Input(const InputEvent &input);
    virtual void Update(const Uint32 delta_time);
    virtual void Draw();

    void         RequestLoadMap(const u16& id);
    void         LoadBattle(const u16& id);

    // 0x6B FADE
    void         Fade(const u8& speed, const u8& start, const Color& color, const u8& type);
    // 0x6C FADEW
    void         AddWaitForFade(const s8& sbEntityId);

private:
    void         LoadMap(const u16& id);

    void         DrawDebugInfo(void) const;
    void         DrawPosibleActions(void) const;

private:
    std::vector<Vertex>     mAxis;

    // engine managing
    bool                    mViewDebugInfo;



    // map loading related
    u16                     mRequestMapId;
    bool                    mRequestLoadMap;
    bool                    m_bMenuAccess;

    // map related
    ObjectManager           mObjectManager;
    WindowManager           mWindowManager;
    BackgroundManager       mBackgroundManager;
    CameraManager           m_CameraManager;



    // fade (move this somewhere)
    s16                     mFadeAlpha;
    s16                     mFadeSpeed;
    bool                    mFadeIn;
    Color                   mFadeColor;
    std::vector<s8>         m_vWaitingForFade;
};



#endif // FIELDSCREEN_H
