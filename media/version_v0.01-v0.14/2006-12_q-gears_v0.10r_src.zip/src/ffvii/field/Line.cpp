// $Id$

#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "FieldModule.h"
#include "Line.h"



Line::Line(FieldModule* pFieldModule, const dGeomID& collision, const s8& sbEntityId):
    Trigger(pFieldModule, collision),
    m_sbEntityId(sbEntityId)
{
}



Line::~Line(void)
{
}



void
Line::OnEnter(void)
{
    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log("We entered line for entity with id = %d", m_sbEntityId);
    }

    m_pFieldModule->mObjectManager.RequestRunEntity(m_sbEntityId, 0, 3);
}



void
Line::OnLeave(void)
{
    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log("We leave line for entity with id = %d", m_sbEntityId);
    }

    m_pFieldModule->mObjectManager.RequestRunEntity(m_sbEntityId, 0, 4);
}
