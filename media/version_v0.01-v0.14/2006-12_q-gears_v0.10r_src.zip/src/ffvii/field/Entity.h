// $Id: Entity.h 94 2006-11-12 19:44:43Z crazy_otaku $

#ifndef ENTITY_h
#define ENTITY_h

#include <ode/ode.h>

#include "../../common/TypeDefine.h"
#include "../../common/display/3dTypes.h"
#include "../../common/utilites/NoCopy.h"
#include "../../common/utilites/StdString.h"

#include "Script.h"

class FieldModule;

struct ScriptQueueItem
{
    s8  id;
    u32 position;
};



class Entity : public NoCopy<Entity>
{
public:
                   Entity(void);
    virtual       ~Entity(void);

    void           Draw(void) const;
    void           DrawCollision(void) const;

    const bool     IsActionEnabled(void) const;

    const bool     CheckCollision(Entity* pEntity);
    void           CheckCollisionTalk(Entity* pEntity);

    // name related
    void           SetName(const RString& name);
    const RString& GetName(void) const;

    // script related
    static void    SetScript(Script* pScript);
    void           SetEntryPoint(const u8 id, const u32 entryPoint);
    static void    DeleteScript(void);
    void           Run(FieldModule* pFieldModule, const s8 sbEntityId);
    void           Init(FieldModule* pFieldModule, const s8 sbEntityId);
    void           RequestRun(const u8 priority, const u8 scriptId);
    void           SetWait(const bool bWait);
    void           SetFramesToWait(const u16 usWait);

    // model related
    void           SetModelId(const s8 sbModelId);
    const s8       GetModelId(void) const;
    void           SetVisible(const bool bVisible);
    const bool     IsVisible(void) const;

    // solid related
    void           SetCollision(const dGeomID& collision);
    const dGeomID& GetCollision(void) const;
    void           SetSolid(const bool bSolid);
    const bool     IsSolid(void) const;

    // talk related
    void           SetCollisionTalk(const dGeomID& collision);
    const dGeomID& GetCollisionTalk(void) const;
    const bool     IsTalkable(void) const;

    // position related
    void           SetPositionFixed(const bool bFixed);
    const bool     IsPositionFixed(void) const;
    void           SetPosition(const Vector3& position);
    const Vector3& GetPosition(void) const;
    void           SetTriangle(const u16 usTriangle);
    const u16      GetTriangle(void) const;
    void           SetDirection(const u8 ubDirection);
    const u8       GetDirection(void) const;

    // player character related
    void           SetPlayerCharacter(const s8 sbPlayerCharacter);
    const s8       GetPlayerCharacter(void) const;

    // ladder related
    void           SetOnLadder(const bool bOnLadder);
    const bool     IsOnLadder(void) const;
    void           SetLadder(const Vector3& ladderEnd, const u16 usEndTriangle);
    const Vector3& GetLadderStart(void) const;
    const u16      GetLadderTriangleStart(void) const;
    const Vector3& GetLadderEnd(void) const;
    const u16      GetLadderTriangleEnd(void) const;

private:
    // name of entity
    RString         m_sName;

    // script related
    static Script*  m_pScript;
    u32             m_aulEntryPoints[32];
    ScriptQueueItem m_aScriptQueue[8];
    bool            m_bInited;
    bool            m_bWait;
    u16             m_usFramesToWait;

    // model related
    s8              m_sbModelId;
    bool            m_bVisible;

    // solid related
    dGeomID         m_Collision;
    bool            m_bSolid;

    // talk related
    dGeomID         m_CollisionTalk;
    // we can talk with unit (seted and unseted in collision check).
    // Used only first true talkable in stack.
    bool            m_bTalkable;

    // position related
    bool            m_bPositionFixed;
    Vector3         m_Position;
    u16             m_usTriangle;
    u8              m_ubDirection;

    // player character related
    s8              m_sbPlayerCharacter;

    // ladder related
    bool            m_bOnLadder;
    Vector3         m_LadderStart;
    u16             m_usLadderTriangleStart;
    Vector3         m_LadderEnd;
    u16             m_usLadderTriangleEnd;
};



#endif // ENTITY_h
