// $Id$

#ifndef ENTITY_MANAGER_h
#define ENTITY_MANAGER_h

#include <vector>
#include <ode/ode.h>

#include "../../common/TypeDefine.h"
#include "../../common/input/InputFilter.h"
#include "../../common/utilites/NoCopy.h"

#include "Gateway.h"
#include "Entity.h"
#include "Line.h"

class FieldModule;



struct EncounterTable
{
    EncounterTable(void):
        enabled(0),
        rate(0)
    {
        for (u8 i = 0; i < 6; ++i)
        {
            standart_encounter[i].rate  = 0;
            standart_encounter[i].scene = 0;
        }

        for (u8 i = 0; i < 4; ++i)
        {
            special_encounter[i].rate  = 0;
            special_encounter[i].scene = 0;
        }
    }

    struct Encounter
    {
        u8  rate;
        u16 scene;
    };

    bool      enabled;
    u8        rate;

    Encounter standart_encounter[6];
    Encounter special_encounter[4];
};



struct WalkMeshTriangle
{
    WalkMeshTriangle(void):
        accessible(true)
    {
    }

    Vector3 A;
    Vector3 B;
    Vector3 C;

    u16    access[3];
    bool   accessible;
};



class ObjectManager : public NoCopy<ObjectManager>
{
public:
    explicit   ObjectManager(FieldModule* pFieldModule);
    virtual   ~ObjectManager(void);

    void       Clear(void);
    void       Draw(void);
    void       DrawDebugInfo(void);
    bool       Input(const InputEvent& input);
    void       Update(const u32& ulDeltaTime);

    void       PushEntity(Entity* pEntity);

    void       AddWalkMeshTriangle(const WalkMeshTriangle& triangle);
    void       AddGateway(const Vector3& point1, const Vector3& point2, const Vector3& position, const u16& mapId);
    void       AddEncounterTable(const EncounterTable& encounterTable);

    // script
    // 0x01 REQ
    void       RequestRunEntity(const s8& sbEntityId, const u8& ubPriority, const u8& ubScriptId);
    // 0x24 WAIT
    void       SetFramesToWait(const s8& sbEntityId, const u16& usWait);
    // 0x33 UC
    void       SetPlayerCharacrerMovability(const bool& bMovability);
    // 0x4B BTLTB
    void       SetEncounterTable(const u8& ubEncounterTable);
    // 0x6D IDLCK
    void       SetTriangleAccess(const u16& usTriangleId, const u8& ubLock);
    // 0x71 BTLON
    void       DisableEncounter(const bool& bDisable);
    // 0xA0 PC
    void       SetPlayerCharacter(const s8& sbEntityId, const s8& sbPlayerCharacter);
    // 0xA1 CHAR
    void       SetCharacter(const s8& sbEntityId, const s8& sbCharacterId);
    // 0xA5 XYZI
    void       SetPositionByXYZTriangle(const s8& sbEntityId, const Vector3& coords, const u16& usTriangleId);
    // 0xB3 DIR
    void       SetDirection(const s8 sbEntityId, const u8 ubDirection);
    // 0xB9 GETAI
    const u16  GetEntityTriangleId(const s8 sbEntityId);
    // 0xBF CC
    void       SetPlayerCharacterToEntity(const s8 sbEntityId);
    // 0xC2 LADER
    void       SetEntityToLadder(const s8 sbEntityId, const Vector3& endPoint, const u16 usEndTriangle);
    // 0xD0 LINE
    void       AddLine(const s8 sbEntityId, const Vector3& point1, const Vector3& point2);
    // 0xD1 LINON
    void       SetLineCheck(const bool bCheck);

    void       SetPositionByXZ(const s8 sbEntityId, const Vector3& coords);
    void       SetWait(const s8 sbEntityId, const bool bWait);
    
private:
    const bool SetNextStep(const s8 sbEntityId, const Vector3& moveVector, const bool bSlide);
    void       SetNextLadderStep(const s8 sbEntityId, const Vector3& moveVector);
    void       CheckTriggers(const s8 sbEntityId);
    void       CheckEncounters(void);

    const s8   GetPlayerEntity(void);
    void       FixEntityPosition(const s8 sbEntityId);

private:
    // feed back to field module
    FieldModule*                  m_pFieldModule;



    std::vector<WalkMeshTriangle> m_vWalkMesh;



    std::vector<Gateway>          m_vGateways;
    std::vector<Line>             m_vLines;



    // entitys
    // vector of entitys
    std::vector<Entity*>          m_vpEntitys;

    // collision detection
    dSpaceID                      m_Space;

    bool                          m_bPlayerCharacterMovable;
    bool                          m_bLineCheck;



    // encounters
    std::vector<EncounterTable>   m_vEncounters;
    bool                          m_bEncounterDisabled;
    u32                           m_ulDangerCounter;



    // debug
    bool                          m_bDisplayCollisions;
    bool                          m_bDisplayWalkmesh;
};



#endif // ENTITY_MANAGER_h
