// $Id: DatFile.h 116 2006-12-15 21:08:47Z crazy_otaku $

#ifndef DATFILE_H
#define DATFILE_H

#include <vector>

#include "../../common/display/3dTypes.h"
#include "../../common/display/math/Matrix.h"
#include "../../common/utilites/StdString.h"

#include "BackgroundManager.h"
#include "CameraManager.h"
#include "ObjectManager.h"
#include "WindowManager.h"
#include "../filetypes/LzsFile.h"
#include "../filesystem/File.h"



class DatFile : public LzsFile
{
public:
    explicit DatFile(const RString &file);
    explicit DatFile(File* file);
    DatFile(File* file, const u32 &offset, const u32 &length);
    DatFile(u8* buffer, const u32 &offset, const u32 &length);
    virtual ~DatFile();

    void GetScripts(ObjectManager& objectManager);
    void GetDialogs(WindowManager& windowManager);
    void GetBackground(BackgroundManager& backgroundManager);
    void GetWalkMesh(ObjectManager& objectManager);
    void GetCameraMatrix(CameraManager& cam);
    void GetGateway(ObjectManager& objectManager);
    void GetScreenRange(CameraManager& screen);
    void GetEncounter(ObjectManager& objectManager);
};



#endif // DATFILE_H
