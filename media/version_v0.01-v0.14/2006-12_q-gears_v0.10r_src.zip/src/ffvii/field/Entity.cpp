// $Id: Entity.cpp 94 2006-11-12 19:44:43Z crazy_otaku $

#include "../../common/display/Display.h"
#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "Entity.h"



Script*  Entity::m_pScript(NULL);



Entity::Entity(void):
    m_sName(""),

    m_bInited(false),
    m_bWait(false),
    m_usFramesToWait(0),

    m_sbModelId(-1),
    m_bVisible(true),

    m_bSolid(true),

    m_bTalkable(false),

    m_bPositionFixed(false),
    m_Position(0.0f, 0.0f, 0.0f),
    m_usTriangle(0),
    m_ubDirection(0),

    m_sbPlayerCharacter(-1),

    m_bOnLadder(false),
    m_LadderStart(0.0f, 0.0f, 0.0f),
    m_usLadderTriangleStart(0),
    m_LadderEnd(0.0f, 0.0f, 0.0f),
    m_usLadderTriangleEnd(0)
{
    // initialize queue
    for (u8 i = 0; i < 8; ++i)
    {
        // -1 means no script
        m_aScriptQueue[i].id       = -1;
        m_aScriptQueue[i].position = 0;
    }

    // init and base scripts are always in priority 8
    m_aScriptQueue[7].id       = 0;
}



Entity::~Entity(void)
{
}



void
Entity::Draw(void) const
{
    if (IsVisible() == true)
    {
        DISPLAY->PushMatrix();
        DISPLAY->Translate(m_Position.x, m_Position.y, m_Position.z);
        DISPLAY->RotateY(360 * m_ubDirection / 255);
//        m_pModel->Draw();
        DISPLAY->PopMatrix();
    }
}



void
Entity::DrawCollision(void) const
{
    const dReal* pos = dGeomGetPosition(m_Collision);
    const dReal* rot = dGeomGetRotation(m_Collision);
    dVector3 sides;
    dGeomBoxGetLengths(m_Collision, sides);

    DISPLAY->PushMatrix();
    Matrix matrix(rot[0], rot[4], rot[8], 0, rot[1], rot[5], rot[9], 0, rot[2], rot[6], rot[10], 0, pos[0], pos[1], pos[2], 1);
    DISPLAY->PreMultMatrix(matrix);

    Geometry quads;
    quads.vertexes.resize(16);

    Vertex v;
    Color color(0.0f, 1.0f, 1.0f, 1.0f);
    v.c = color;

    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->SetLineWidth(1);

    float lx = sides[0] / 2.0f;
    float ly = sides[1] / 2.0f;
    float lz = sides[2] / 2.0f;

    v.p.x =  lx; v.p.y =  ly; v.p.z =  lz; quads.vertexes[ 0] = v;
    v.p.x =  lx; v.p.y =  ly; v.p.z = -lz; quads.vertexes[ 1] = v;
    v.p.x =  lx; v.p.y = -ly; v.p.z = -lz; quads.vertexes[ 2] = v;
    v.p.x =  lx; v.p.y = -ly; v.p.z =  lz; quads.vertexes[ 3] = v;

    v.p.x =  lx; v.p.y =  ly; v.p.z = -lz; quads.vertexes[ 4] = v;
    v.p.x = -lx; v.p.y =  ly; v.p.z = -lz; quads.vertexes[ 5] = v;
    v.p.x = -lx; v.p.y = -ly; v.p.z = -lz; quads.vertexes[ 6] = v;
    v.p.x =  lx; v.p.y = -ly; v.p.z = -lz; quads.vertexes[ 7] = v;

    v.p.x = -lx; v.p.y =  ly; v.p.z = -lz; quads.vertexes[ 8] = v;
    v.p.x = -lx; v.p.y =  ly; v.p.z =  lz; quads.vertexes[ 9] = v;
    v.p.x = -lx; v.p.y = -ly; v.p.z =  lz; quads.vertexes[10] = v;
    v.p.x = -lx; v.p.y = -ly; v.p.z = -lz; quads.vertexes[11] = v;

    v.p.x = -lx; v.p.y =  ly; v.p.z =  lz; quads.vertexes[12] = v;
    v.p.x =  lx; v.p.y =  ly; v.p.z =  lz; quads.vertexes[13] = v;
    v.p.x =  lx; v.p.y = -ly; v.p.z =  lz; quads.vertexes[14] = v;
    v.p.x = -lx; v.p.y = -ly; v.p.z =  lz; quads.vertexes[15] = v;

    DISPLAY->DrawQuads(quads);
    DISPLAY->SetPolygonMode(POLYGON_FILL);
    DISPLAY->PopMatrix();
}



const bool
Entity::IsActionEnabled(void) const
{
    return (m_sbModelId != -1) && (m_bVisible == true) && (m_bPositionFixed == true);
}



const bool
Entity::CheckCollision(Entity* pEntity)
{
    dContact contact;
    int numc = dCollide(m_Collision, pEntity->GetCollision(), 1, &contact.geom, sizeof(dContact));

    if (numc > 0)
    {
        return true;
    }
    return false;
}



void
Entity::CheckCollisionTalk(Entity* pEntity)
{
    dContact contact;

    int numc = dCollide(m_CollisionTalk, pEntity->GetCollisionTalk(), 1, &contact.geom, sizeof(dContact));

    m_bTalkable = (numc > 0) ? true : false;
}



void
Entity::SetName(const RString& name)
{
    m_sName = name;
}



const RString&
Entity::GetName(void) const
{
    return m_sName;
}



void
Entity::SetScript(Script* pScript)
{
    m_pScript = pScript;
}



void
Entity::SetEntryPoint(const u8 id, const u32 entryPoint)
{
    if (id >= 32)
    {
        LOGGER->Log("Entity::SetEntryPoint: Tried to set entry point to id larger or equal 32.");
        return;
    }

    m_aulEntryPoints[id] = entryPoint;
}



void
Entity::DeleteScript(void)
{
    if (m_pScript != NULL)
    {
        delete m_pScript;
    }
    m_pScript = NULL;
}



void
Entity::Run(FieldModule* pFieldModule, const s8 sbEntityId)
{
    // if we syncronize with something
    if (m_bWait == true || m_usFramesToWait > 0)
    {
        if (m_usFramesToWait > 0)
        {
            --m_usFramesToWait;
        }

        return;
    }



    // if we not inited
    if (m_bInited == false)
    {
        Init(pFieldModule, sbEntityId);
    }
    else
    {
        for (int i = 0; i < 8; ++i)
        {
            if (m_aScriptQueue[i].id != -1)
            {
                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log("Script %02x from entity %s with priority %d started.", m_aScriptQueue[i].id, m_sName.c_str(), i);
                }

                bool finish = m_pScript->Run(pFieldModule, sbEntityId, m_aScriptQueue[i].position);

                // if script finished it work
                if (finish)
                {
                    if (CONFIG->m_DumpScript == true)
                    {
                        LOGGER->Log("Script %02x from entity %s with priority %d finished.", m_aScriptQueue[i].id, m_sName.c_str(), i);
                    }

                    if (i == 7)
                    {
                        // if we run base script
                        m_aScriptQueue[i].position = m_aulEntryPoints[0];
                    }
                    else
                    {
                        m_aScriptQueue[i].id       = -1;
                        m_aScriptQueue[i].position = 0;
                    }
                }
                else
                {
                    if (CONFIG->m_DumpScript == true)
                    {
                        LOGGER->Log("Script %02x from entity %s with priority %d waiting.", m_aScriptQueue[i].id, m_sName.c_str(), i);
                    }
                }

                break;
            }
        }
    }
}



void
Entity::Init(FieldModule* pFieldModule, const s8 sbEntityId)
{
    if (CONFIG->m_DumpScript == true)
    {
        LOGGER->Log("Run Init script from entity %s.", m_sName.c_str());
    }

    if (m_pScript->Run(pFieldModule, sbEntityId, m_aulEntryPoints[0]) == true)
    {
        m_bInited = true;
        m_aScriptQueue[7].position = m_aulEntryPoints[0];
    }
}



void
Entity::RequestRun(const u8 priority, const u8 scriptId)
{
    if (m_aScriptQueue[priority].id == -1)
    {
        m_aScriptQueue[priority].id       = scriptId;
        m_aScriptQueue[priority].position = m_aulEntryPoints[scriptId];
    }
}



void
Entity::SetWait(const bool bWait)
{
    m_bWait = bWait;
}



void
Entity::SetFramesToWait(const u16 usWait)
{
    m_usFramesToWait = usWait;
}



void
Entity::SetModelId(const s8 sbModelId)
{
    m_sbModelId = sbModelId;
}



const s8
Entity::GetModelId(void) const
{
    return m_sbModelId;
}



void
Entity::SetVisible(const bool bVisible)
{
    m_bVisible = bVisible;
}



const bool
Entity::IsVisible(void) const
{
    return m_bVisible;
}



void
Entity::SetCollision(const dGeomID& collision)
{
    m_Collision = collision;
}



const dGeomID&
Entity::GetCollision(void) const
{
    return m_Collision;
}



void
Entity::SetSolid(const bool bSolid)
{
    m_bSolid = bSolid;
}



const bool
Entity::IsSolid(void) const
{
    return m_bSolid;
}



void
Entity::SetCollisionTalk(const dGeomID& collision)
{
    m_CollisionTalk = collision;
}



const dGeomID&
Entity::GetCollisionTalk(void) const
{
    return m_CollisionTalk;
}



const bool
Entity::IsTalkable(void) const
{
    return m_bTalkable;
}



void
Entity::SetPositionFixed(const bool bFixed)
{
    m_bPositionFixed = bFixed;
}



const bool
Entity::IsPositionFixed(void) const
{
    return m_bPositionFixed;
}



void
Entity::SetPosition(const Vector3& position)
{
    m_Position = position;
}



const Vector3&
Entity::GetPosition(void) const
{
    return m_Position;
}



void
Entity::SetTriangle(const u16 usTriangle)
{
    m_usTriangle = usTriangle;
}



const u16
Entity::GetTriangle(void) const
{
    return m_usTriangle;
}



void
Entity::SetDirection(const u8 ubDirection)
{
    m_ubDirection = ubDirection;
}



const u8
Entity::GetDirection(void) const
{
    return m_ubDirection;
}



void
Entity::SetPlayerCharacter(const s8 sbPlayerCharacter)
{
    m_sbPlayerCharacter = sbPlayerCharacter;
}



const s8
Entity::GetPlayerCharacter(void) const
{
    return m_sbPlayerCharacter;
}



void
Entity::SetOnLadder(const bool bOnLadder)
{
    m_bOnLadder = bOnLadder;
}



const bool
Entity::IsOnLadder(void) const
{
    return m_bOnLadder;
}



void
Entity::SetLadder(const Vector3& ladderEnd, const u16 usEndTriangle)
{
    m_LadderStart           = m_Position;
    m_usLadderTriangleStart = m_usTriangle;
    m_LadderEnd             = ladderEnd;
    m_usLadderTriangleEnd   = usEndTriangle;
}



const Vector3&
Entity::GetLadderStart(void) const
{
    return m_LadderStart;
}



const u16
Entity::GetLadderTriangleStart(void) const
{
    return m_usLadderTriangleStart;
}



const Vector3&
Entity::GetLadderEnd(void) const
{
    return m_LadderEnd;
}



const u16
Entity::GetLadderTriangleEnd(void) const
{
    return m_usLadderTriangleEnd;
}
