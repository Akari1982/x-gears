#ifndef ACTOR_H
#define ACTOR_H



#include "../3dtypes.h"
#include "../math/vector.h"

#include <string>



class Actor
{
    public:
                           Actor();
                           Actor(const Actor &cpy);
        virtual           ~Actor();

        const std::string &GetName() const;
        virtual void       SetName(const std::string &name);


                void       Draw();                  // calls BeginDraw, DrawPrimitives, EndDraw
                void       BeginDraw();             // pushes transform onto world matrix stack
        virtual void       SetGlobalRenderStates(); // actor should call this at beginning of their DrawPrimitives()
        virtual void       DrawPrimitives() = 0;    // Derivatives should override
                void       EndDraw();               // pops transform from world matrix stack

        // render states
        virtual void       SetBlendMode(BlendMode mode);
        virtual void       SetZTestMode(ZTestMode mode);
        virtual void       SetCullMode(CullMode mode);
        virtual void       SetPolygonMode(PolygonMode mode);



    private:
                void       InitDefaults();



    protected:
        std::string mName;

        // render states
        BlendMode   mBlendMode;
        ZTestMode   mZTestMode;
        CullMode    mCullMode;
        PolygonMode mPolygonMode;
};



#endif
