#include "vectormath.h"

#include <math.h>



void
Vec2Normalize(Vector2 *Out, const Vector2 *V)
{
    float scale = 1.0f / sqrtf(V->x * V->x + V->y * V->y);
    Out->x = V->x * scale;
    Out->y = V->y * scale;
}



void
Vec3Normalize(Vector3 *Out, const Vector3 *V)
{
    float scale = 1.0f / sqrtf(V->x * V->x + V->y * V->y + V->z * V->z);
    Out->x = V->x * scale;
    Out->y = V->y * scale;
    Out->z = V->z * scale;
}



void
Vec4Transform(Vector4 *Out, const Vector4 *V, const Matrix *M)
{
    const Matrix &a  = *M;
    const Vector4 &v = *V;

    *Out = Vector4(
        a.m[0][0] * v.x + a.m[1][0] * v.y + a.m[2][0] * v.z + a.m[3][0] * v.w,
        a.m[0][1] * v.x + a.m[1][1] * v.y + a.m[2][1] * v.z + a.m[3][1] * v.w,
        a.m[0][2] * v.x + a.m[1][2] * v.y + a.m[2][2] * v.z + a.m[3][2] * v.w,
        a.m[0][3] * v.x + a.m[1][3] * v.y + a.m[2][3] * v.z + a.m[3][3] * v.w);
}