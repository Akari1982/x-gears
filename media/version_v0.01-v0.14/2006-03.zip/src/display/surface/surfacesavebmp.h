#ifndef SURFACESAVEBMP_H
#define SURFACESAVEBMP_H



#include "surface.h"

#include <string>



namespace SurfaceUtils
{
    bool
    SaveBMP(const std::string &file, Surface *&surface);
};



#endif
