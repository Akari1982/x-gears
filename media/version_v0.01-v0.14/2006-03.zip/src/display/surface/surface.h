#ifndef SURFACE_H
#define SURFACE_H



#include <string>



struct Surface
{
     Surface();
     Surface(const Surface &cpy);
    ~Surface();

    unsigned char *pixels;
    int            width;
    int            height;
};



Surface *CreateSurface(int width, int height);
Surface *CreateSurfaceFrom( int width, int height, unsigned char *pixels);

void     SetSurfaceSize(Surface *&surface, int width, int height);



#endif
