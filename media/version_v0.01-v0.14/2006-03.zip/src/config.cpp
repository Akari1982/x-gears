#include <cstdlib>
#include <stdio.h>
#include <string.h>

#include "config.h"
#include "define.h"
#include "resource/filesystem/realfilesystem.h"



Config* CONFIG = NULL; // global and accessable from anywhere in our program



Config::Config() :
    GAME_CD    (""),

    LOG_TO_DISK(false)
{
    ReadConfig(DEFAULT_CONFIG);
}



Config::~Config()
{
}



void
Config::ReadConfig(const std::string &file)
{
    unsigned int config_size = REALFILESYSTEM->GetFileSizeInBytes(file);

    unsigned char *buffer = (unsigned char *)malloc(sizeof(unsigned char) * config_size);

    REALFILESYSTEM->ReadFile(file, buffer, 0, config_size);

    for (unsigned int i = 0; i < config_size; i++)
    {
        unsigned int string_size = 0;
        // get the size of string
        while (buffer[i + string_size] != '\r' && buffer[i + string_size] != '\n' && i + string_size < config_size)
        {
            string_size++;
        }

        // Read the string
        std::string line = "";
        char* temp_string = new char[string_size];
        memcpy(temp_string, buffer + i, string_size);
        temp_string[string_size] = '\0';
        line = temp_string;
        delete temp_string;

        // comments and empty row
        if (line.size() == 0 ||
            line[0] == '#' ||
            line.size() > 1 && line[0] == '/' && line[1] == '/')
        {
            i += string_size;
            continue;
        }

        // New value.
        int equal_index = line.find("=");
        if (equal_index != std::string::npos)
        {
            std::string name  = line.substr(0, equal_index);
            std::string value = line.substr(equal_index + 1, line.size() - equal_index - 1);

            if (name.size())
            {
                if      (name == "GAME_CD")     {GAME_CD     = value;                           }
                else if (name == "LOG_TO_DISK") {LOG_TO_DISK = (value == "true") ? true : false;}
            }
        }

        i += string_size;
        // skip '\r' or '\n' on the end of string and go to start of new string
        while (buffer[i] == '\r' || buffer[i + string_size + 1] == '\n')
        {
            i++;
        }
    }



    free(buffer);
}
