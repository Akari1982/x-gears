#include "fieldwithchar.h"
#include "../file.h"
#include "../../display/3dtypes.h"
#include "../../display/display.h"
#include "../../log.h"

// temp
#include "../../utilites/math.h"



FieldWithChar::FieldWithChar():
    mCharacter(),
    mEnableXP(false),
    mEnableXM(false),
    mEnableZP(false),
    mEnableZM(false),
    mX(0.0f),
    mY(0.0f),
    mZ(0.0f)
{
}



FieldWithChar::~FieldWithChar()
{
}




void
FieldWithChar::Load(const File *file)
{
    Model::Load(file);
    SetToFirst();
    CheckAvailability();
}



void
FieldWithChar::DrawPrimitives()
{
    Update();

    Model::DrawPrimitives();

    DISPLAY->PushMatrix();
    DISPLAY->Translate(mX, mY, mZ);
    mCharacter.DrawPrimitives();
    DISPLAY->PopMatrix();
}



void
FieldWithChar::Input(const InputEvent &input)
{
    switch (input.button)
    {
        case KEY_UP:
        {
            mEnableZP = (input.type == IET_FIRST_PRESS) ? true : false;
            break;
        }
        case KEY_DOWN:
        {
            mEnableZM = (input.type == IET_FIRST_PRESS) ? true : false;
            break;
        }
        case KEY_LEFT:
        {
            mEnableXP = (input.type == IET_FIRST_PRESS) ? true : false;
            break;
        }
        case KEY_RIGHT:
        {
            mEnableXM = (input.type == IET_FIRST_PRESS) ? true : false;
            break;
        }
    }
}



bool
FieldWithChar::CheckAvailability()
{
    float x1, y1, z1, x2, y2, z2, x3, y3, z3;

    for (std::vector<Vertex>::iterator i = mMeshes.geometry[0].Triangles.begin(); i != mMeshes.geometry[0].Triangles.end();)
    {
        x1 = (*i).p.x; y1 = (*i).p.y; z1 = (*i).p.z; ++i;
        x2 = (*i).p.x; y2 = (*i).p.y; z2 = (*i).p.z; ++i;
        x3 = (*i).p.x; y3 = (*i).p.y; z3 = (*i).p.z; ++i;
        if (point_in_triangle(mX, mZ, x1, z1, x2, z2, x3, z3))
        {
            // set Y coord
            mY = point_elevation(mX, mZ, x1, y1, z1, x2, y2, z2, x3, y3, z3);

            return true;
        }
    }

    return false;
}



void
FieldWithChar::Update()
{
    static int step = 10;

    if (mEnableZP == true)
    {
        mZ += step;
        if (!CheckAvailability())
        {
            mZ -= step;
        }
    }

    if (mEnableZM == true)
    {
        mZ -= step;
        if (!CheckAvailability())
        {
            mZ += step;
        }
    }

    if (mEnableXP == true)
    {
        mX += step;
        if (!CheckAvailability())
        {
            mX -= step;
        }
    }

    if (mEnableXM == true)
    {
        mX -= step;
        if (!CheckAvailability())
        {
            mX += step;
        }
    }
}



void
FieldWithChar::SetToFirst()
{
    std::vector<Vertex>::iterator i = mMeshes.geometry[0].Triangles.begin();
    if (i != mMeshes.geometry[0].Triangles.end())
    {
        mX = (*(i + 1)).p.x;
        mY = (*(i + 1)).p.y;
        mZ = (*(i + 1)).p.z;
    }
}
