#include "realfilesystem.h"

#include <windows.h>



RealFileSystem *REALFILESYSTEM = NULL;



RealFileSystem::RealFileSystem()
{
    MountFileSystem();
}



RealFileSystem::~RealFileSystem()
{
}



void
RealFileSystem::MountFileSystem()
{
    mRoot = "./";
}



void
RealFileSystem::GetDirListing(const std::string &path, std::vector<std::string> &listing, const bool &dirs)
{
    std::string sPath = mRoot + path;
    // erase last "/" if exist
    if (sPath.size() > 0 && sPath[sPath.size() - 1] == '/')
    {
        sPath.erase(sPath.size() - 1);
    }
    // add search mask
    sPath += "/*";

    WIN32_FIND_DATA fd;

    HANDLE hFind = FindFirstFile(sPath.c_str(), &fd);

    if (hFind == INVALID_HANDLE_VALUE)
    {
        return;
    }

    do
    {
        if (!strcmp(fd.cFileName, ".") || !strcmp(fd.cFileName, ".."))
        {
            continue;
        }

        // if we want dirs skip files
        if (dirs && !(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
        {
            continue;
        }
        // if we want files skip dirs
        else if (!dirs && !!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
        {
            continue;
        }
        // get file name
        else
        {
            listing.push_back(fd.cFileName);
        }
    }
    while (FindNextFile(hFind, &fd));

    FindClose(hFind);
}



RealFileSystem::FileType
RealFileSystem::GetFileType(const std::string &path)
{
    std::string sPath = mRoot + path;

    unsigned int type = GetFileAttributes(sPath.c_str());

    if (type == 0)
    {
        return TYPE_NONE;
    }

    if (type & FILE_ATTRIBUTE_DIRECTORY)
    {
        return TYPE_DIR;
    }

    return TYPE_FILE;
}



bool
RealFileSystem::IsAFile(const std::string &path)
{
    return (GetFileType(path) == TYPE_FILE);
}



bool
RealFileSystem::IsADirectory(const std::string &path)
{
    return (GetFileType(path) == TYPE_DIR);
}



bool
RealFileSystem::DoesFileExist(const std::string &path)
{
    std::string sPath = mRoot + path;

    HANDLE hFile = CreateFile(sPath.c_str(), 0, 0, NULL, OPEN_EXISTING, 0, NULL);

    if (hFile == INVALID_HANDLE_VALUE)
    {
        return false;
    }

    CloseHandle(hFile);
    return true;
}



unsigned int
RealFileSystem::GetFileSizeInBytes(const std::string &path)
{
    std::string sPath = mRoot + path;

    HANDLE hFile = CreateFile(sPath.c_str(), 0, 0, NULL, OPEN_EXISTING, 0, NULL);

    if (hFile == INVALID_HANDLE_VALUE)
    {
        return 0;
    }

    unsigned int size = GetFileSize(hFile, NULL);
    CloseHandle(hFile);

    return size;
}



bool
RealFileSystem::ReadFile(const std::string &path, void *buffer, unsigned int start, unsigned int length)
{
    std::string sPath = mRoot + path;

    HANDLE hFile = CreateFile(sPath.c_str(), GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);

    if (hFile == INVALID_HANDLE_VALUE)
    {
        return false;
    }

    SetFilePointer(hFile, start, NULL, FILE_BEGIN);

    unsigned long temp;
    bool result = (::ReadFile(hFile, buffer, length, &temp, NULL) != 0);

    CloseHandle(hFile);

    return result;
}



bool
RealFileSystem::WriteFile(const std::string &path, void *buffer, int start, unsigned int length)
{
    std::string sPath = mRoot + path;

    HANDLE hFile = CreateFile(sPath.c_str(), GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, 0, NULL);

    if (hFile == INVALID_HANDLE_VALUE)
    {
        return false;
    }

    SetFilePointer(hFile, start, NULL, FILE_BEGIN);

    unsigned long temp;
    bool result (::WriteFile(hFile, buffer, length, &temp, NULL) != 0);

    CloseHandle(hFile);

    return result;
}



bool
RealFileSystem::WriteNewFile(const std::string &path, void *buffer, int start, unsigned int length)
{
    RemoveFile(path);
    return !!(WriteFile(path, buffer, start, length));
}



bool
RealFileSystem::RemoveFile(const std::string &path)
{
    std::string sPath = mRoot + path;

    return !!(::DeleteFile(sPath.c_str()));
}
