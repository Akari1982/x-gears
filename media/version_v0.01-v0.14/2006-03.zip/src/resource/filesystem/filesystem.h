#ifndef FILESYSTEM_H
#define FILESYSTEM_H



#include <string>
#include <vector>



class FileSystem
{
    public:
                             FileSystem();

        virtual             ~FileSystem();

        virtual void         MountFileSystem() = 0;

        virtual void         GetDirListing(const std::string &path, std::vector<std::string> &listing, const bool &dirs) = 0;

        enum FileType
        {
            TYPE_FILE,
            TYPE_DIR,
            TYPE_NONE
        };
        virtual FileType     GetFileType(const std::string &path) = 0;

        virtual bool         IsAFile(const std::string &path) = 0;

        virtual bool         IsADirectory(const std::string &path) = 0;

        virtual bool         DoesFileExist(const std::string &path) = 0;

        virtual unsigned int GetFileSizeInBytes(const std::string &path) = 0;

        virtual bool         ReadFile(const std::string &path, void *buffer, unsigned int start, unsigned int length) = 0;
        virtual bool         WriteFile(const std::string &path, void *buffer, int start, unsigned int length) = 0;
        virtual bool         RemoveFile(const std::string &path) = 0;



    protected:
        std::string mRoot;
};



#endif // FILESYSTEM_H
