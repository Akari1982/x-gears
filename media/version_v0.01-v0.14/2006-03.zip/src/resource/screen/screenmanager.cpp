#include "screenmanager.h"
#include "screen.h"
#include "../../display/display.h"
#include "../../utilites/utilites.h"



ScreenManager* SCREENMAN = NULL;



ScreenManager::ScreenManager()
{
}



ScreenManager::~ScreenManager()
{
    for (int i = 0; i < mScreens.size(); i++)
    {
        SAFE_DELETE(mScreens[i]);
    }
}



void
ScreenManager::Draw()
{
    DISPLAY->BeginFrame();

    for (int i = 0; i < mScreens.size(); i++) // Draw all screens bottom to top
    {
        mScreens[i]->Draw();
    }

    DISPLAY->EndFrame();
}



void
ScreenManager::Input(const InputEvent &input)
{
    mScreens[mScreens.size() - 1]->Input(input);
}



void
ScreenManager::PushScreen(Screen *screen)
{
    mScreens.push_back(screen);
}
