#ifndef SCREENMANAGER_H
#define SCREENMANAGER_H



#include "screen.h"
#include "../../input/inputfilter.h"

#include <string>
#include <vector>



class ScreenManager
{
    public:
              ScreenManager();
             ~ScreenManager();

        void  Draw();
        void  Input(const InputEvent &input);

        // Main screen stack management
        void  PushScreen(Screen *screen);



    private:
        std::vector<Screen *> mScreens;
};



extern ScreenManager* SCREENMAN;



#endif // SCREENMANAGER_H
