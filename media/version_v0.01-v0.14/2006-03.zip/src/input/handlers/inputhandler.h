#ifndef INPUTHANDLER_H
#define INPUTHANDLER_H



#include "../inputfilter.h"



class InputHandler
{
    public:
                      InputHandler() {}
        virtual      ~InputHandler() {}
        virtual void  Update() {}



    protected:
        void          ButtonPressed(Button b, bool Down);
};



// this need to be rewritten
// we may want to have different input devices with different handlers
// this may to be done through InputManager that collect all Handlers
InputHandler *
MakeInputHandler();



#endif // INPUTHANDLER_H
