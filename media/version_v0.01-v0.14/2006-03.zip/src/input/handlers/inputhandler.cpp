#include "inputhandler.h"
#include "../inputfilter.h"



void
InputHandler::ButtonPressed(Button b, bool Down)
{
    INPUTFILTER->ButtonPressed(b, Down);
}
