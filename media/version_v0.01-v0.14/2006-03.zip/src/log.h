#ifndef LOG_H
#define LOG_H



#include <string>



// The Log Class : Useful to write debug or info messages
class Logger
{
    public:
        // Constructor, opens log file for writing.
             Logger(const std::string &logFile);

        // Destructor, closes log file.
            ~Logger();

        // Enters a message in the log. The message will be timestamped.
        void Log(const char *log_text, ...);

    private:
        std::string mLogFile;
};



extern Logger *LOGGER;



#endif