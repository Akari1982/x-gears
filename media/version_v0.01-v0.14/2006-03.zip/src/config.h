#ifndef CONFIG_H
#define CONFIG_H



#include <string>



class Config
{
    public:
             Config();
            ~Config();

        void ReadConfig(const std::string &file);

    public:
        // Programm
        std::string GAME_CD;

        // Game

        // Debug:
        bool        LOG_TO_DISK;
};



extern Config* CONFIG; // global and accessable from anywhere in our program



#endif // CONFIG_H
