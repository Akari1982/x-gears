#ifndef NOCOPY
#define NOCOPY



template <typename T>
class NoCopy
{
public:
    NoCopy() {}
    virtual ~NoCopy() {}

private:
    NoCopy(const NoCopy &copy);
    NoCopy& operator=(const NoCopy &copy);
};



#endif // NOCOPY
