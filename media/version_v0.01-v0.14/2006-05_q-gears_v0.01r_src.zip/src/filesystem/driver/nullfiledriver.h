/*
 *  $Id: nullfiledriver.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef NULLFILEDRIVER_H
#define NULLFILEDRIVER_H


#include "filedriver.h"
#include <string>



class NullFileDriver : public FileDriver
{
public:
             NullFileDriver();
    virtual ~NullFileDriver();

    virtual unsigned int GetFileSize(const std::string &path);
    virtual bool         ReadFile(const std::string &path, const void* buffer, const unsigned int start, const unsigned int length);
};



#endif // NULLFILEDRIVER_H
