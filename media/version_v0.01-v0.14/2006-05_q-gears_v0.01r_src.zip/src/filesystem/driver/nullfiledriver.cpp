/*
 *  $Id: nullfiledriver.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "nullfiledriver.h"
#include "../../logger.h"



NullFileDriver::NullFileDriver()
{
}



NullFileDriver::~NullFileDriver()
{
}



unsigned int
NullFileDriver::GetFileSize(const std::string &path)
{
    LOGGER->Log("Tried to get size of file %s", path.c_str());
    return 0;
}

bool
NullFileDriver::ReadFile(const std::string &path, const void* buffer, const unsigned int start, const unsigned int length)
{
    LOGGER->Log("Tried to read file %s", path.c_str());
    return false;
}
