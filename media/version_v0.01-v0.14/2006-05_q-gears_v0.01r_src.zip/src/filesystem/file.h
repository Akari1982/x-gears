/*
 *  $Id: file.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef FILE_H
#define FILE_H


#include "../utilites/nocopy.h"
#include <string>



class File : public NoCopy<File>
{
public:
    typedef unsigned char      u8;
    typedef unsigned short int u16;
    typedef unsigned long  int u32;

    typedef signed   char      s8;
    typedef signed   short int s16;
    typedef signed   long  int s32;

    explicit          File(const std::string &file);
    explicit          File(File* file);
                      File(File* file, u32 offset, u32 length);
                      File(u8* buffer, u32 offset, u32 length);
    virtual          ~File();

    void              WriteFile(const std::string &file);
    const std::string GetFileName();
    const u32         GetFileSize();

    // fill given buffer with part of mBuffer
    void              GetFileBuffer(u8 *buffer, u32 start, u32 length);

protected:
    // utility functions returns value with given offset
    const u8          GetU8(const u32 offset);
    const u16         GetU16LE(const u32 offset);
    const u32         GetU32LE(const u32 offset);

protected:
    // filename
    const std::string mFileName;
    // loaded file buffer
    u8*               mBuffer;
    // size of buffer
    u32               mBufferSize;
};



#endif // FILE_H
