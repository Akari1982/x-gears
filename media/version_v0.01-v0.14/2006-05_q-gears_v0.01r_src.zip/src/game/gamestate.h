/*
 *  $Id: gamestate.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef GAMESTATE_H
#define GAMESTATE_H
// The Gamestate Class : Contain all info about current game state



#include "savemap.h"
#include "../utilites/nocopy.h"



class Gamestate : public NoCopy<Gamestate>
{
public:
    Gamestate();

    virtual ~Gamestate();

    const Savemap& GetSavemap() const;

    void SetSavemap(const char* buffer);

    void DumpSavemap();

    void Update();

private:
    static Savemap mSavemap;
};



// Visible from every part of programm
extern Gamestate* GAMESTATE;



#endif // GAMESTATE_H
