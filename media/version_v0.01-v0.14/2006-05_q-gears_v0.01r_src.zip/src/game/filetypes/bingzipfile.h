/*
 *  $Id: bingzipfile.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef BINGZIPFILE_H
#define BINGZIPFILE_H

#include "../../filesystem/file.h"

#include <string>



class BinGZipFile : public File
{
public:
    explicit          BinGZipFile(const std::string &file);
    explicit          BinGZipFile(File* file);
                      BinGZipFile(File* file, u32 offset, u32 length);
                      BinGZipFile(u8* buffer, u32 offset, u32 length);
    virtual          ~BinGZipFile();

    File*             ExtractGZip(int file_number);

    // get number of files in archive
    int               GetNumberOfFiles();

private:
    // read file and get "number_of_files" in archive
    void              InnerGetNumberOfFiles();
    // get offset of file in bin archive
    int               InnerGetFileOffset(int file_number);

private:
    // number of files in archive
    int mNumberOfFiles;
};



#endif
