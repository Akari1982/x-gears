/*
 *  $Id: lzsfile.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef LZSFILE_H
#define LZSFILE_H

#include "../../filesystem/file.h"

#include <string>



class LzsFile : public File
{
public:
    explicit          LzsFile(const std::string &file);
    explicit          LzsFile(File* file);
                      LzsFile(File* file, u32 offset, u32 length);
                      LzsFile(u8* buffer, u32 offset, u32 length);
    virtual          ~LzsFile();

private:
    void              ExtractLzs();
};



#endif
