/*
 *  $Id: bingzipfile.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include <string>
#include <cassert>
#include <zlib.h>

#include "bingzipfile.h"
#include "../../logger.h"



BinGZipFile::BinGZipFile(const std::string &file):
    File(file),
    mNumberOfFiles(0)
{
    InnerGetNumberOfFiles();
}



BinGZipFile::BinGZipFile(File *file, u32 offset, u32 length):
    File(file, offset, length),
    mNumberOfFiles(0)
{
    InnerGetNumberOfFiles();
}



BinGZipFile::BinGZipFile(u8* buffer, u32 offset, u32 length):
    File(buffer, offset, length),
    mNumberOfFiles(0)
{
    InnerGetNumberOfFiles();
}



BinGZipFile::BinGZipFile(File *file):
    File(file),
    mNumberOfFiles(0)
{
    InnerGetNumberOfFiles();
}



BinGZipFile::~BinGZipFile()
{
}



File*
BinGZipFile::ExtractGZip(int file_number)
{
    int extract_size = 256 * 1024;
    u8* extract_buffer = (u8*)malloc(extract_size);

    int ret;
    z_stream strm;

    int offset = InnerGetFileOffset(file_number);
    strm.zalloc    = Z_NULL;               /* used to allocate the internal state */
    strm.zfree     = Z_NULL;               /* used to free the internal state */
    strm.opaque    = Z_NULL;               /* private data object passed to zalloc and zfree */
    strm.next_in   = mBuffer + offset;     /* next input byte */
    strm.avail_in  = mBufferSize;          /* number of bytes available at next_in */
    strm.next_out  = extract_buffer;       /* next output byte should be put there */
    strm.avail_out = extract_size;         /* remaining free space at next_out */

    ret = inflateInit2(&strm, 15 + 32);

    if (ret != Z_OK)
    {
        switch (ret)
        {
            case Z_MEM_ERROR:
                inflateEnd(&strm);
                LOGGER->Log("Warning: inflateInit2 - Z_MEM_ERROR in file %s", mFileName.c_str());
                break;
            case Z_STREAM_ERROR:
                inflateEnd(&strm);
                LOGGER->Log("Warning: inflateInit2 - Z_STREAM_ERROR in file %s", mFileName.c_str());
                break;
            default:
                inflateEnd(&strm);
                LOGGER->Log("Warning: inflateInit2 - unknown error in file %s", mFileName.c_str());
        }
        return NULL;
    }

    do
    {
        if (strm.next_out == NULL)
        {
            inflateEnd(&strm);
            LOGGER->Log("Warning: strm.next_out == NULL in file %s", mFileName.c_str());
            return NULL;
        }

        ret = inflate(&strm, Z_NO_FLUSH);
        assert(ret != Z_STREAM_ERROR);

        switch (ret)
        {
            case Z_NEED_DICT:
                inflateEnd(&strm);
                LOGGER->Log("Warning: inflate - Z_NEED_DICT in file %s", mFileName.c_str());
                return NULL;
            case Z_DATA_ERROR:
                inflateEnd(&strm);
                LOGGER->Log("Warning: inflate - Z_DATA_ERROR in file %s", mFileName.c_str());
                return NULL;
            case Z_MEM_ERROR:
                inflateEnd(&strm);
                LOGGER->Log("Warning: inflate - Z_MEM_ERROR in file %s", mFileName.c_str());
                return NULL;
        }

        if (ret != Z_STREAM_END)
        {
            extract_buffer = (u8*)realloc(extract_buffer, extract_size * 2);

            if (extract_buffer == NULL)
            {
                inflateEnd(&strm);
                LOGGER->Log("Warning: extract_buffer == NULL in file %s", mFileName.c_str());
                return NULL;
            }

            strm.next_out = (u8*)extract_buffer + extract_size;
            strm.avail_out = extract_size;
            extract_size *= 2;
        }
    }
    while (ret != Z_STREAM_END);

    extract_size = extract_size - strm.avail_out;
    (void)inflateEnd(&strm);

    if (ret != Z_STREAM_END)
    {
        LOGGER->Log("Warning: ret != Z_STREAM_END in file %s", mFileName.c_str());
        return NULL;
    }

    File* file = new File(extract_buffer, 0, extract_size);
    delete extract_buffer;
    return file;
}



int
BinGZipFile::GetNumberOfFiles()
{
    return mNumberOfFiles;
}



void
BinGZipFile::InnerGetNumberOfFiles()
{
    mNumberOfFiles = 0;

    for (int pointer = 0; pointer < mBufferSize;)
    {
        int temp = GetU16LE(pointer);
        pointer += 6;

        // condition for gzip header
        if (GetU32LE(pointer) == 0x00088B1F && GetU32LE(pointer + 4) == 0x00000000)
        {
            ++mNumberOfFiles;
        }

        pointer += temp;
    }

    if (mNumberOfFiles == 0)
    {
        LOGGER->Log("Warning: %s isn't archive. number_of_files == 0", mFileName.c_str());
    }
}



int
BinGZipFile::InnerGetFileOffset(int file_number)
{
    int current_file = 0;

    for (int pointer = 0; pointer < mBufferSize;)
    {
        int temp = GetU16LE(pointer);
        pointer += 6;

        // condition for gzip header
        if (GetU32LE(pointer) == 0x00088B1F && GetU32LE(pointer + 4) == 0x00000000)
        {
            if (file_number == current_file)
            {
                return pointer;
            }
        }

        ++current_file;
        pointer += temp;
    }

    return 0;
}
