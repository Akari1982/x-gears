/*
 *  $Id: logger.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "logger.h"
#include "filesystem/realfilesystem.h"
#include "utilites/utilites.h"  //for linux itoa support
#include <stdarg.h>
#include <time.h>



Logger* LOGGER = NULL; // global and accessable from anywhere in our program



Logger::Logger(const RString &logFileName):
    mLogFile(logFileName)
{
    REALFILESYSTEM->RemoveFile(mLogFile);
}



Logger::~Logger()
{
}



void Logger::Log(const char* logText, ...)
{
    RString buf;

    // Use a temporary buffer to fill in the variables
    va_list ap;
    va_start(ap, logText);
    buf.FormatV(logText, ap);
    va_end(ap);

    // Get the current system time
    time_t t;
    time(&t);

    // Print the log entry
    RString string;
    string.Format("[%02d:%02d:%02d] %s\n", (int)(((t / 60) / 60) % 24), (int)((t / 60) % 60), (int)(t % 60), buf.c_str());

    REALFILESYSTEM->WriteFile(mLogFile, string.c_str(), string.size());

    // Delete temporary buffer
    delete[] buf;
}
