/*
 *  $Id: screenmanager.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "screenmanager.h"
#include "screen.h"
#include "splash.h"
#include "../display/display.h"
#include "../utilites/utilites.h"
#include "../logger.h"


ScreenManager* SCREENMAN = NULL;



ScreenManager::ScreenManager()
{
    ScreenSplash* screen = new ScreenSplash();
    PushScreen(screen);
}



ScreenManager::~ScreenManager()
{
    for (int i = 0; i < mScreensToDelete.size(); ++i)
    {
        delete mScreensToDelete[i];
    }

    for (int i = 0; i < mScreens.size(); ++i)
    {
        delete mScreens[i];
    }
}



void
ScreenManager::Draw()
{
    DISPLAY->BeginFrame();

    for (int i = 0; i < mScreens.size(); ++i)
    {
        mScreens[i]->Draw();
    }

    DISPLAY->EndFrame();
}



void
ScreenManager::Input(const InputEvent &input)
{
    if (!mScreens.size())
    {
        return;
    }
    mScreens[mScreens.size() - 1]->Input(input);
}



void
ScreenManager::Update()
{
    for (int i = 0; i < mScreensToDelete.size(); ++i)
    {
        delete mScreensToDelete[i];
    }
    mScreensToDelete.clear();
}



void
ScreenManager::PushScreen(Screen *screen)
{
    mScreens.push_back(screen);
}



void
ScreenManager::PopTopScreen()
{
    if (mScreens.size() > 0)
    {
        mScreensToDelete.push_back(mScreens[mScreens.size() - 1]);
        mScreens.pop_back();
    }
}
