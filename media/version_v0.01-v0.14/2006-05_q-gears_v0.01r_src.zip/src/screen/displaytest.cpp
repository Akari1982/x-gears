#include "displaytest.h"
#include "../display/display.h"
#include "../display/surface/surfaceload.h"
#include "../game/filetypes/bingzipfile.h"
#include "../game/filetypes/timfile.h"
#include "../logger.h"

#include <string>



ScreenDisplayTest::ScreenDisplayTest():
    mRotation(0),
    mTexId(0)
{
    Init();
}



ScreenDisplayTest::~ScreenDisplayTest()
{
    DISPLAY->DeleteTexture(mTexId);
}



void
ScreenDisplayTest::Init()
{
    Vertex point;

    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
    DISPLAY->SetAlphaTest(true);
    DISPLAY->SetBlendMode(BLEND_NORMAL);
    DISPLAY->SetCullMode(CULL_NONE);

    DISPLAY->LoadLookAt(50, Vector3(10, 5, 5), Vector3(0, 0, 0), Vector3(0, 1, 0));

    point.p.x = -5.0f; point.p.y =  0.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    mPoints.push_back(point);
    point.p.x =  5.0f; point.p.y =  0.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y = -5.0f; point.p.z =  0.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y =  5.0f; point.p.z =  0.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y =  0.0f; point.p.z = -5.0f;
    point.c.r =  0.0f; point.c.g =  0.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y =  0.0f; point.p.z =  5.0f;
    point.c.r =  0.0f; point.c.g =  0.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    mPoints.push_back(point);

    Vertex tr[3];
    Vertex qu[4];
    Geometry geom;
    geom.TexEnabled = false;

    tr[0].p.x = -1.0f; tr[0].p.y =  0.0f; tr[0].p.z =  1.0f;
    tr[0].c.r =  1.0f; tr[0].c.g =  0.0f; tr[0].c.b =  0.0f; tr[0].c.a =  1.0f;
    tr[1].p.x = -1.0f; tr[1].p.y =  0.0f; tr[1].p.z =  3.0f;
    tr[1].c.r =  0.0f; tr[1].c.g =  0.0f; tr[1].c.b =  1.0f; tr[1].c.a =  1.0f;
    tr[2].p.x = -2.0f; tr[2].p.y =  2.0f; tr[2].p.z =  2.0f;
    tr[2].c.r =  0.0f; tr[2].c.g =  1.0f; tr[2].c.b =  0.0f; tr[2].c.a =  1.0f;
    geom.AddTriangle(tr);

    tr[0].p.x = -1.0f; tr[0].p.y =  0.0f; tr[0].p.z =  1.0f;
    tr[0].c.r =  1.0f; tr[0].c.g =  0.0f; tr[0].c.b =  0.0f; tr[0].c.a =  1.0f;
    tr[1].p.x = -3.0f; tr[1].p.y =  0.0f; tr[1].p.z =  1.0f;
    tr[1].c.r =  1.0f; tr[1].c.g =  1.0f; tr[1].c.b =  0.0f; tr[1].c.a =  1.0f;
    tr[2].p.x = -2.0f; tr[2].p.y =  2.0f; tr[2].p.z =  2.0f;
    tr[2].c.r =  0.0f; tr[2].c.g =  1.0f; tr[2].c.b =  0.0f; tr[2].c.a =  1.0f;
    geom.AddTriangle(tr);

    tr[0].p.x = -3.0f; tr[0].p.y =  0.0f; tr[0].p.z =  3.0f;
    tr[0].c.r =  1.0f; tr[0].c.g =  0.0f; tr[0].c.b =  0.0f; tr[0].c.a =  1.0f;
    tr[1].p.x = -3.0f; tr[1].p.y =  0.0f; tr[1].p.z =  1.0f;
    tr[1].c.r =  1.0f; tr[1].c.g =  1.0f; tr[1].c.b =  0.0f; tr[1].c.a =  1.0f;
    tr[2].p.x = -2.0f; tr[2].p.y =  2.0f; tr[2].p.z =  2.0f;
    tr[2].c.r =  0.0f; tr[2].c.g =  1.0f; tr[2].c.b =  0.0f; tr[2].c.a =  1.0f;
    geom.AddTriangle(tr);

    tr[0].p.x = -3.0f; tr[0].p.y =  0.0f; tr[0].p.z =  3.0f;
    tr[0].c.r =  1.0f; tr[0].c.g =  0.0f; tr[0].c.b =  0.0f; tr[0].c.a =  1.0f;
    tr[1].p.x = -1.0f; tr[1].p.y =  0.0f; tr[1].p.z =  3.0f;
    tr[1].c.r =  0.0f; tr[1].c.g =  0.0f; tr[1].c.b =  1.0f; tr[1].c.a =  1.0f;
    tr[2].p.x = -2.0f; tr[2].p.y =  2.0f; tr[2].p.z =  2.0f;
    tr[2].c.r =  0.0f; tr[2].c.g =  1.0f; tr[2].c.b =  0.0f; tr[2].c.a =  1.0f;
    geom.AddTriangle(tr);

    qu[0].p.x = -1.0f; qu[0].p.y =  0.0f; qu[0].p.z =  1.0f;
    qu[0].c.r =  1.0f; qu[0].c.g =  0.0f; qu[0].c.b =  0.0f; qu[0].c.a =  1.0f;
    qu[1].p.x = -3.0f; qu[1].p.y =  0.0f; qu[1].p.z =  1.0f;
    qu[1].c.r =  1.0f; qu[1].c.g =  1.0f; qu[1].c.b =  0.0f; qu[1].c.a =  1.0f;
    qu[2].p.x = -3.0f; qu[2].p.y =  0.0f; qu[2].p.z =  3.0f;
    qu[2].c.r =  1.0f; qu[2].c.g =  0.0f; qu[2].c.b =  0.0f; qu[2].c.a =  1.0f;
    qu[3].p.x = -1.0f; qu[3].p.y =  0.0f; qu[3].p.z =  3.0f;
    qu[3].c.r =  0.0f; qu[3].c.g =  0.0f; qu[3].c.b =  1.0f; qu[3].c.a =  1.0f;
    geom.AddQuad(qu);

    mPyramid.GeometryVector.push_back(geom);

//    Surface* texture = SurfaceUtils::LoadFile("data/test_tex.bmp");
    BinGZipFile* file = new BinGZipFile("data/WINDOW.BIN");
    File* data1 = file->ExtractGZip(0);
    delete file;
    TimFile* image = new TimFile(data1);
    delete data1;
    Surface* texture = image->GetSurface(7);

    if (texture != NULL)
    {
        mTexId = DISPLAY->CreateTexture(texture);
        delete texture;
    }
    else
    {
        LOGGER->Log("Can't load texture.");
    }

    point.p.x =  0.5f; point.p.y = -1.0f; point.p.z =  4.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  0.0f; point.t.y =  0.0f;
    mQuadsTex.push_back(point);
    point.p.x =  4.5f; point.p.y = -1.0f; point.p.z =  4.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  0.0f; point.t.y =  1.0f;
    mQuadsTex.push_back(point);
    point.p.x =  4.5f; point.p.y = -1.0f; point.p.z = -4.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  1.0f; point.t.y =  1.0f;
    mQuadsTex.push_back(point);
    point.p.x =  0.5f; point.p.y = -1.0f; point.p.z = -4.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  1.0f; point.t.y =  0.0f;
    mQuadsTex.push_back(point);
}



void
ScreenDisplayTest::Input(const InputEvent &input)
{
}



void
ScreenDisplayTest::Draw()
{
    DISPLAY->SetPointSize(3);
    DISPLAY->DrawPoints(mPoints);
    DISPLAY->SetLineWidth(1);
    DISPLAY->DrawLines(mPoints);

    DISPLAY->PushMatrix();
    DISPLAY->RotateX(mRotation);
    DISPLAY->DrawTotalGeometry(mPyramid);
    DISPLAY->PopMatrix();
    ++mRotation;

    DISPLAY->SetAlphaTest(false);
    DISPLAY->SetBlendMode(BLEND_DISABLED);
//    DISPLAY->TextureTranslate(0.01f, 0.0f);
    DISPLAY->SetTexture(mTexId);
    DISPLAY->DrawQuads(mQuadsTex);
    DISPLAY->UnsetTexture();
    DISPLAY->SetBlendMode(BLEND_NORMAL);
    DISPLAY->SetAlphaTest(true);
}
