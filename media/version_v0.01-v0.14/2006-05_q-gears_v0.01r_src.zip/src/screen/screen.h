/*
 *  $Id: screen.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef SCREEN_H
#define SCREEN_H



#include "../input/inputfilter.h"
#include "../utilites/nocopy.h"

#include <string>



class Screen : public NoCopy<Screen>
{
public:
    Screen();
    virtual ~Screen();

    virtual void Init() = 0;

    virtual void Input(const InputEvent &input) = 0;

    virtual void Draw() = 0;
};



#endif
