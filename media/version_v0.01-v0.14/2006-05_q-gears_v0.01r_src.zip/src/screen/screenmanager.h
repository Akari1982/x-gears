/*
 *  $Id: screenmanager.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef SCREENMANAGER_H
#define SCREENMANAGER_H



#include "screen.h"
#include "../input/inputfilter.h"
#include "../utilites/nocopy.h"

#include <string>
#include <vector>



class ScreenManager : public NoCopy<ScreenManager>
{
public:
             ScreenManager();
    virtual ~ScreenManager();

    void     Draw();
    void     Input(const InputEvent &input);
    void     Update();

    // Main screen stack management
    void     PushScreen(Screen* screen);
    void     PopTopScreen();

private:
    std::vector<Screen*> mScreens;
    std::vector<Screen*> mScreensToDelete;
};



extern ScreenManager* SCREENMAN;



#endif // SCREENMANAGER_H
