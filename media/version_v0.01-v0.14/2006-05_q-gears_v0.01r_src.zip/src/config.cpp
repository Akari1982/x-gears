/*
 *  $Id: config.cpp.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "config.h"
#include "define.h"
#include "logger.h"
#include "filesystem/realfilesystem.h"



Config* CONFIG = NULL; // global and accessable from anywhere in our program



Config::Config():
    mLogToDisk(false)
{
    ReadConfig(DEFAULT_CONFIG);
}



Config::~Config()
{
}



void
Config::ReadConfig(const std::string &file)
{
    unsigned int config_size = REALFILESYSTEM->GetFileSize(file);

    unsigned char* buffer = (unsigned char*)malloc(sizeof(unsigned char) * config_size);

    if (!REALFILESYSTEM->ReadFile(file, buffer, 0, config_size))
    {
        LOGGER->Log("Cant read config file: %s", file.c_str());
    }


    for (unsigned int i = 0; i < config_size; ++i)
    {
        unsigned int string_size = 0;
        // get the size of string
        while (buffer[i + string_size] != '\r' && buffer[i + string_size] != '\n' && i + string_size < config_size)
        {
            ++string_size;
        }

        // Read the string
        std::string line = "";
        char* temp_string = new char[string_size + 1];
        memcpy(temp_string, buffer + i, string_size);
        temp_string[string_size] = '\0';
        line = temp_string;

        delete temp_string;

        // comments and empty row
        if (line.size() == 0 || line[0] == '#' || line.size() > 1 && line[0] == '/' && line[1] == '/')
        {
            i += string_size;
            continue;
        }

        // New value.
        int equal_index = line.find("=");
        if (equal_index != std::string::npos)
        {
            std::string name  = line.substr(0, equal_index);
            std::string value = line.substr(equal_index + 1, line.size() - equal_index - 1);

            if (name.size())
            {
                if (name == "LOG_TO_DISK") {mLogToDisk = (value == "true") ? true : false;}
            }
        }

        i += string_size;

        // skip '\r' or '\n' on the end of string and go to start of new string
        while (buffer[i] == '\r' || buffer[i + string_size + 1] == '\n')
        {
            ++i;
        }
    }

    free(buffer);
}
