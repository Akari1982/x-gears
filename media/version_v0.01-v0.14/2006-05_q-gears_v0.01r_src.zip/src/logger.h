/*
 *  $Id: logger.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef LOGGER_H
#define LOGGER_H
// The Log Class : Useful to write debug or info messages


#include "utilites/nocopy.h"
#include "utilites/stdstring.h"



class Logger : public NoCopy<Logger>
{
public:
    // Constructor, opens log file for writing.
    explicit Logger(const RString &logFileName);

    // Destructor, closes log file.
    virtual ~Logger();

    // Enters a message in the log. The message will be timestamped.
    void Log(const char* logText, ...);

private:
    RString mLogFile;
};



// Visible from every part of programm
extern Logger *LOGGER;



#endif // LOGGER_H
