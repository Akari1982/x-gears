/*
 *  $Id: surfaceload.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef SURFACELOAD_H
#define SURFACELOAD_H



#include "surface.h"

#include <string>



namespace SurfaceUtils
{
    enum OpenResult
    {
        OPEN_OK,
        OPEN_UNKNOWN_FILE_FORMAT = 1,
        OPEN_FATAL_ERROR = 2,
    };

    Surface *LoadFile(const std::string &file);
}



#endif
