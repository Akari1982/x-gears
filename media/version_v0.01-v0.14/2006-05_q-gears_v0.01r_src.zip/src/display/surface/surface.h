/*
 *  $Id: surface.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef SURFACE_H
#define SURFACE_H



#include <string>



struct Surface
{
    Surface();
    Surface(const Surface &copy);
    Surface& operator =(const Surface &copy);
    ~Surface();


    unsigned char *pixels;
    int            width;
    int            height;
};



Surface* CreateSurface(int width, int height);
Surface* CreateSurfaceFrom( int width, int height, unsigned char* pixels);

void     SetSurfaceSize(Surface *&surface, int width, int height);



#endif
