/*
 *  $Id: main.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "main.h"

#include "config.h"
#include "define.h"
#include "logger.h"
#include "display/displayogl.h"
//#include "display/surface/surfaceload.h"
//#include "display/surface/surfacesavebmp.h"
#include "filesystem/file.h"
#include "filesystem/gamefilesystem.h"
#include "filesystem/realfilesystem.h"
#include "input/inputfilter.h"
#include "game/filetypes/bingzipfile.h"
#include "game/filetypes/lzsfile.h"
#include "game/filetypes/timfile.h"
#include "game/gamestate.h"
#include "game/savemap.h"
#include "screen/splash.h"
#include "screen/screenmanager.h"
#include "utilites/utilites.h"

#include <stdio.h>



// game state
unsigned char state;



void
HandleInputEvents()
{
    INPUTFILTER->Update();

    static InputEventArray input_event_attay;
    input_event_attay.clear();
    INPUTFILTER->GetInputEvents(input_event_attay);

    for (int i = 0; i < input_event_attay.size(); i++)
    {
        SCREENMAN->Input(input_event_attay[i]);
    }
}



int
main(int argc, char *argv[])
{
    REALFILESYSTEM = new RealFileSystem();
    GAMEFILESYSTEM = new GameFileSystem();
    LOGGER         = new Logger(DEFAULT_LOG);
    CONFIG         = new Config();
    DISPLAY        = DisplayOGL::MakeDisplay();
    SCREENMAN      = new ScreenManager();
    INPUTFILTER    = new InputFilter();
    GAMESTATE      = new Gamestate();



/*
    BinGZipFile* file = new BinGZipFile("data/WINDOW.BIN");
    File* data1 = file->ExtractGZip(0);
    delete file;
    TimFile* image = new TimFile(data1);
    delete data1;
    Surface* sImage = image->GetSurface(0);
    SurfaceUtils::SaveBMP("data/WIN1.bmp", sImage);
    delete sImage;
    delete image;

    Surface* img = SurfaceUtils::LoadFile("data/splash.bmp");
    SurfaceUtils::SaveBMP("data/WIN1.bmp", img);
    delete img;
*/


    state = GAME;
    while (state != EXIT)
    {
        SCREENMAN->Update();
        SCREENMAN->Draw();
        HandleInputEvents();
        GAMESTATE->Update();
    }



    SAFE_DELETE(GAMESTATE)
    SAFE_DELETE(INPUTFILTER)
    SAFE_DELETE(SCREENMAN)
    SAFE_DELETE(DISPLAY)
    SAFE_DELETE(CONFIG)
    SAFE_DELETE(LOGGER)
    SAFE_DELETE(GAMEFILESYSTEM)
    SAFE_DELETE(REALFILESYSTEM)

    return 0;
}
