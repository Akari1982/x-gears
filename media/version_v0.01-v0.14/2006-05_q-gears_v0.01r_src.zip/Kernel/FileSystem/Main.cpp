#include "Main.h"
#include <stdio.h>
#include <memory.h>

#define	ISO_PF(A, T, F)	ISO_PrintField(A, T, (char *)&F, sizeof(F))

void OutField(char *Dest, char *Source, int MaxLen)
{
	int	Index = 0;
	//printf("OF: MaxField Size = %d\n", MaxLen);
	while((Index < MaxLen)&&
		(*Source != 0)&&
		(*Source != ' '))
	{
		*Dest++ = *Source++;
	}
	// always null terminate
	*Dest = 0;
}

void ISO_PrintField(char *Program, char *Text, void *Source, int Size)
{
	char Buff[128];
	
	OutField(Buff, (char *)Source, Size);
	printf(
		"%s: %s\t'%s'\n",
		Program,
		Text,
		Buff
		);
}


int main(int argc, char **argv)
{
	ISO	*Image = NULL;
	// if we have arguements
	if(argc > 1)
	{
		ISO_PrimaryVDesc *PVD;
		ISO_BootRec9660		*BootRec;
		
		printf("%s: Image File = %s\n", argv[0], argv[1]);
		// assume the second arguement is an ISO file
		// first create the image object
		Image = new ISO;
		printf("%s: Setting path\n", argv[0]);
		// now set the image objects path
		Image->Path(argv[1]);
		printf("%s: Getting Primary Volume Descriptor Sector\n", argv[0]);
		// now get the primary volume descriptor		
		PVD = (ISO_PrimaryVDesc *)Image->Sector(ISO_VOLDESC_SECTOR);
		// is this the primary volumedescriptor?
		switch(PVD->Type)
		{
			case 0:	// boot record!
				// all right now the Boot information
				//BootRec = (ISO_BootRec9660 *)Image->Sector(
				break;
			case 1: // primary volume descriptor
				// print various important fields
				printf("%s: Printing Volume Descriptor Fields\n", argv[0]);
				ISO_PF(argv[0], "CD nfo: ", PVD->ID);
				// system ID
				ISO_PF(argv[0], "System ", PVD->SystemID);
				// disk ID
				ISO_PF(argv[0], "Volume ID", PVD->VolumeID);
				printf("%s: Volume Size\t%d sectors\n", argv[0], PVD->VolSpaceSize[0]);
				printf(
					"%s: Disk Size\t%dM\n",
					argv[0], 
					PVD->VolSpaceSize[0] * PVD->LogicalBlockSize[0] / (1024 * 1024)
					);
				ISO_PF(argv[0], "Vol Set ID", PVD->VolSetID);
				ISO_PF(argv[0], "Publisher", PVD->Publisher);
				ISO_PF(argv[0], "Data Preparer", PVD->DataPrep);
				ISO_PF(argv[0], "Application", PVD->Application);
				ISO_PF(argv[0], "Copyright File", PVD->CopyRightF);
				ISO_PF(argv[0], "Abstract File", PVD->AbstractF);
				ISO_PF(argv[0], "Biblio File", PVD->BibloF);
				ISO_PF(argv[0], "Volume Creation", PVD->VolumeCreation);
				break;
		}
		// delete the allocated image now
		delete Image;
	}
	else
		printf("%s: Nothing to do\r\n", argv[0]);
	return 0;
}
