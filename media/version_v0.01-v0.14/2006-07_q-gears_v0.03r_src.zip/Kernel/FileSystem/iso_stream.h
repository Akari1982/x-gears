#ifndef ISO_STREAM_H_
#define ISO_STREAM_H_
#include "ISO.h"
#include <istream.h>

class iso_streambuf : public streambuf
{
};

class iso_stream : public istream
{
	public:
		iso_stream();
	private:
		iso_streambuf	iso_sb;
};

#endif /*ISO_STREAM_H_*/
