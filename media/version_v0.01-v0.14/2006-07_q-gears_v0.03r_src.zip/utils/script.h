#ifndef SCRIPT_H
#define SCRIPT_H

#include <stdio.h>

void dumpscript(FILE *fp, int beg_addr, int end_addr);
                                                                                
#endif /* SCRIPT_H */

