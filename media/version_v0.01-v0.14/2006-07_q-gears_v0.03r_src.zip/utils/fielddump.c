/* Fielddump, a program to print the Fieldscript files for Final Fantasy 7.*/

/* Usage:  fielddump [fieldfile] */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "script.h"

typedef uint16_t u16;
typedef uint32_t u32;

void display_usage(void);
int get_mips_u32(void);
int get_mips_u16(void);


FILE *fp;		/* field file handle */
FILE *outfp;	/* file handle for dumped field script */
char output_filename[12];	/* The name of the decompiled fieldscript file */


int count, count2;  /* Loops, you know, for kids ^_^ */

/* used to keep the scripts from repeating */
int script_at = 0;
int script_to = 0;
int last_script = 0;
int curr_script = 0;
int next_script = 0;

/* This is the length of the header for the PC verision of the game.
If I remeber, the PSX's header is different,
so adjust this accordingly if you want to make a PSX script dumper */ 
int header_length=4;


u32 unknown1;    
char nEntities;		/* Number of entities */
char unknown2;		/* Number of character entities (?) */
u16 wStringOffset;	/* Offset to dialog strings */
u16 nExtraOffsets;	/* An optional number of extra offsets... unknown */
u16 unknown4[4];
char szCreator[8];	/* Field creator */
char szName[8];		/* Field name */


main(int argc, char *argv[])
{
	int script_offset;
	

	if (argc < 2)
		{
		display_usage();
		exit (1);
		}

	if (( fp = fopen( argv[1], "r" )) == NULL)
		{
		fprintf( stderr, "Error opening file %s\n", argv[1]);
		exit(1);
		}

	/* Now to see if it's a PC field file */
	fseek(fp,0,SEEK_SET);
	if (get_mips_u32() != 9)
		{
		fprintf(stderr, "Fielddump - By Halkun\n\n");
		fprintf( stderr, "ERROR: Header seems incorrect.\n");
		fprintf( stderr, "Did you uncompress the file first?\n");
		fprintf( stderr, "Are you using a PC Fieldfile?\n\n");
		exit(1);
		}

	/* Jump to the beginning to the fieldscript */
	fseek(fp,4,SEEK_SET);
	script_offset=get_mips_u32();
	fseek(fp,script_offset,SEEK_SET);	
	printf("Script found at location 0x%x\n",script_offset);
	printf("Script is 0x%x bytes long\n\n",get_mips_u16()); 

	/* This reads in the fieldscript header, I should make this a whole
	other function, but as I adore globals, and can't dynamically allocate
	struct memebers in C, it looks like this mess is required. */
	unknown1=get_mips_u32();
	printf("unknown1=%x\n",unknown1);
	nEntities=getc(fp);
	printf("nEntities=%x\n",nEntities);
	unknown2=getc(fp);
	printf("Unknown2=%x\n",unknown2);
	wStringOffset=get_mips_u16()+header_length+script_offset;
	printf("wStringOffset=%x\n",wStringOffset);
	nExtraOffsets=get_mips_u16();
	printf("nExtraOffsets=%x\n",nExtraOffsets);
	fread (unknown4,1,8,fp);
	fread (szCreator,1,8,fp);
	printf ("szCreator=%s\n",szCreator);
	fread (szName,1,8,fp);
	printf ("szName=%s\n",szName);

	/* Get entity names */
	char szEntities[nEntities][8];
	fread(szEntities,nEntities,8,fp);	
	for (count =0;count<nEntities;count++)
	{
	printf ("entity number %d=%s\n",count,szEntities[count]);
	}
	
	/* get the pointer to any extra segments that are needed */
	u32 dwExtraOffsets[nExtraOffsets];
    for (count =0;count<nExtraOffsets;count++)
	{
		dwExtraOffsets[count]=get_mips_u16()+header_length+script_offset;
		
		/* This is a bug, but I have to jump up two positions. I think my
		MIPS convert thingy is off however the data I'm skipping are zeros
		anyway (I hope!) */
		fseek(fp,2,SEEK_CUR);
    }

	/* now load the entity script pointers */
	u16 vEntityScripts[nEntities][32];
	for (count=0;count<nEntities;count++)
	{
		for (count2=0;count2<32;count2++)
		{
			vEntityScripts[count][count2]=get_mips_u16()+header_length+script_offset;
		}
	}	


	
	/* Ok, now we have what we need to start dumping the script
	I shouldn't make this part of main(), hell, it shouldn't even
	be in this *FILE*  but now I've *TOTALLY* screwed up my 
	variable scope above so I need to make everything local ^_^

	...sorry guys! */
	
	/******************************************************************/
	/* DUMPING THE FIELDSCRIPT STARTS HERE IN THE MIDDLE OF THIS MESS */
	/******************************************************************/


	/* append .scp to the end of the field file name to make the script file */
	strcpy(output_filename,argv[1]);
	strcat(output_filename,".scp");

	if ((outfp = fopen(output_filename, "w" )) == NULL)
		{
		fprintf( stderr, "Error opening file %s\n", output_filename);
		exit(1);
		}

	/* Print header */
	fprintf(outfp, "# Final Fantasy 7 Field Script\n");
	fprintf(outfp, "# Original Name: %s\n",argv[1]);
	fprintf(outfp, "# Created by: %s\n",szCreator);
	fprintf(outfp, "#\n");
	fprintf(outfp, "# Internal filename: %s\n",szName);
	fprintf(outfp, "#\n");
	fprintf(outfp, "\n");
	fprintf(outfp, "\n");
	fprintf(outfp, "\n");
	count2=0;
	/* now to go through all the entities and drop some code on thier ass */
	/* (Holy crap dude, it's like 2:00am now! ) */
	/* ================= */
	/* As a revision to the above comment, the code below is most likely */
	/* *very* broken I've already found a varible that I never used.*/
	/* To tell the truth, I don't even know what it's doing ^_^ */

	for (count=0;count<nEntities;count++)
	{
		
	fprintf(outfp,"#################### Entity %d (%s) ####################\n\nENTITY(%d) = %s\n\n",count,szEntities[count],count,szEntities[count]);
		for (count2=0;count2<32;count2++)
		{
		/* look at the current script, is it the same as the last script? */
			curr_script = vEntityScripts[count][count2];
			if (curr_script == last_script)
			{
				/* yes it is so we need to bump up the "to count" */
				script_to++;

				/* now check the next script and see if that's the same too */
				/* first we have to see if we are jumping to a new entity */
				/* If we are, then obviously it's a different script */
				if (count2 == 31)
				{
					/* The next script is a new entity, so we need to write an
					"alias" script */
					fprintf(outfp,"alias %s (script %d to 31)\n\n",szEntities[count],script_at-1);
					script_to=0;   /* now reset script_to */
				}
				/* now, what about if we are in the middle of an entity and the
				next script is different? */
				if (count2 != 31)
				{
					next_script=vEntityScripts[count][count2+1];
					if (next_script != curr_script)
					{
						fprintf(outfp,"alias %s (script %d to %d)\n\n",szEntities[count],script_at-1,++script_to);
						script_at++;
					} 
				}
			}			
			else
			{
				next_script=vEntityScripts[count][count2+1];
				fprintf(outfp,"%s (script %d)\n{\n",szEntities[count],script_at);
				dumpscript(outfp,curr_script,next_script);
//				fprintf(outfp,"dumpscript(%x,%x);\n",curr_script,next_script);
				fprintf(outfp,"}\n\n");
				script_at++;
				last_script = curr_script;
			}
		}	
	script_at=0;
	}
	fclose (outfp);
}


void display_usage(void)
{
      fprintf(stderr, "Fielddump - By Halkun\n\n");
      fprintf(stderr, "ERROR: No Field file was given\n\nProper usage:\n" );
      fprintf(stderr, "fielddump [fieldfile]\n");
      fprintf(stderr, "where [fieldfile] is an uncompressed PC field file\n\n");
}


int get_mips_u32(void)
{
	int n=0; 
	unsigned char ch;
	/* Char 0 */
	ch = getc(fp);
	n = (ch << 16);

	/* Char 1 */
	ch = getc(fp);
	n |= (ch << 24);

	/* Char 2 */
	ch = getc(fp);
	n |= ch;
	
	/* Char 3 */
	ch = getc(fp);
	n |= (ch << 8);

	return(n);
}


int get_mips_u16(void)
{
	int n=0; 
	unsigned char ch;

	/* Char 0 */
	ch = getc(fp);
	n |= ch;
	/* Char 1 */
	ch = getc(fp);
	n |= (ch << 8);
	return(n);
}
