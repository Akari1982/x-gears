#include "script.h"

/*
	Holy twisted code Batman! I had to get out of that main(); routine QUICK!
	This should make things nice and modular with little damage to the main
	program. That is, if I don't make *THIS* a train-wreck of code in the
	process
*/

/* This is is handy to call opcodes by thier name, not number */
/* Note: little "x" replaces "!" in opcode to make enum happy */
/* "u" replaces "+" and "d" replaces "-" ; 2BYTE changed to TWOBYTE */
/* xNNx are undefined opcodes */

enum
{
RET,      REQ,      REQSW,    REQEW,    PREQ,     PRQSW,    PRQEW,    RETTO,
JOIN,     SPLIT,    SPTYE,    GTPYE,    x0Cx,     x0Dx,     DSKCG,    SPECIAL,
JMPF,     JMPFL,    JMPB,     JMPBL,    IFUB,     IFUBL,    IFSW,     IFSWL,
IFUW,     IFUWL,    x1Ax,     x1Bx,     x1Cx,     x1Dx,     x1Ex,     x1Fx,
MINIGAME, TUTOR,    BTMD2,    BTRLD,    WAIT,     NFADE,    BLINK,    BGMOVIE,
KAWAI,    KAWIW,    PMOVA,    SLIP,     BGPDH,    BGSCR,    WCLS,     WSIZW, 
IFKEY,    IFKEYON,  IFKEYOFF, UC,       PDIRA,    PTURA,    WSPCL,    WNUMB, 
STTIM,    GOLDu,    GOLDd,    CHGLD,    HMPMAX1,  HMPMAX2,  MHMMX,    HMPMAX3, 
MESSAGE,  MPARA,    MPRA2,    MPNAM,    x44x,     MPu,      x46x,     MPd,
ASK,      MENU,     MENU2,    BTLTB,    x4C,      HPu,      x4Ex,     HPd,
WINDOW,   WMOVE,    WMODE,    WREST,    WCLSE,    WROW,     GWCOL,    SWCOL, 
STITM,    DLITM,    CKITM,    SMTRA,    DMTRA,    CMTRA,    SHAKE,    NOP, 
MAPJUMP,  SCRLO,    SCRLC,    SCRLA,    SCR2D,    SCRCC,    SCR2DC,   SCRLW, 
SCR2DL,   MPDSP,    VWOFT,    FADE,     FADEW,    IDLCK,    LSTMP,    SCRLP, 
BATTLE,   BTLON,    BTLMD,    PGTDR,    GETPC,    PXYZI,    PLUSx,    PLUS2x, 
MINUSx,   MINUS2x,  INCx,     INC2x,    DECx,     DEC2x,    TLKON,    RDMSD, 
SETBYTE,  SETWORD,  BITON,    BITOFF,   BITXOR,   PLUS,     PLUS2,    MINUS, 
MINUS2,   MUL,      MUL2,     DIV,      DIV2,     MOD,      MOD2,     AND, 
AND2,     OR,       OR2,      XOR,      XOR2,     INC,      INC2,     DEC, 
DEC2,     RANDOM,   LBYTE,    HBYTE,    TWOBYTE,  SETX,     GETX,     SEARCHX,
PC,       CHAR,     DFANM,    ANIME1,   VISI,     XYZI,     XYI,      XYZ,
MOVE,     CMOVE,    MOVA,     TURA,     ANIMW,    FMOVE,    ANIME2,   ANIMx1,
CANIM1,   CANMx1,   MSPED,    DIR,      TURNGEN,  TURN,     DIRA,     GETDIR, 
GETAXY,   GETAI,    ANIMx2,   CANIM2,   CANMx2,   ASPED,    xBEx,     CC,
JUMP,     AXYZI,    LADER,    OFST,     OFSTW,    TALKR,    SLIDR,    SOLID, 
PRTYP,    PRTYM,    PRTYE,    IFPRTYQ,  IFMEMBQ,  MMBud,    MMBLK,    MMBUK, 
LINE,     LINON,    MPJPO,    SLINE,    SIN,      COS,      TLKR2,    SLDR2, 
PMJMP,    PMJMP2,   AKAO2,    FCFIX,    CCANM,    ANIMB,    TURNW,    MPPAL, 
BGON,     BGOFF,    BGROL,    BGROL2,   BGCLR,    STPAL,    LDPAL,    CPPAL, 
RTPAL,    ADPAL,    MPPAL2,   STPLS,    LDPLS,    CPPAL2,   RTPAL2,   ADPAL2, 
MUSIC,    SOUND,    AKAO,     MUSVT,    MUSVM,    MULCK,    BMUSC,    CHMPH, 
PMVIE,    MOVIE,    MVIEF,    MVCAM,    FMUSC,    CMUSC,    CHMST,    GAMEOVER 
};


void dumpscript(FILE *fp, int beg_addr, int end_addr)
{
fprintf(fp,"dumpscript(%x,%x);\n",beg_addr,end_addr);
} 
