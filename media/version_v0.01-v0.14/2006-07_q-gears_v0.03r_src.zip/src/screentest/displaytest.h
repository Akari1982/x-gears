/*
 *  $Id: displaytest.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef SCREENDISPLAYTEST_H
#define SCREENDISPLAYTEST_H



#include "../module/screen.h"
#include "../display/3dtypes.h"

#include <vector>



class ScreenDisplayTest : public Screen
{
public:
    ScreenDisplayTest();
    virtual ~ScreenDisplayTest();

    virtual void Init();

    virtual void Input(const InputEvent &input);

    virtual void Update(const unsigned int &delta_time);

    virtual void Draw();

private:
    int mRotation;
    int mTexId;

    std::vector<Vertex> mPoints;
    TotalGeometry mPyramid;
    std::vector<Vertex> mQuadsTex;
};



#endif // SCREENDISPLAYTEST_H
