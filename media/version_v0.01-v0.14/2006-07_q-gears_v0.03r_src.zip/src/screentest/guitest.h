/*
 *  $Id: guitest.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef GUITEST_H
#define GUITEST_H



#include "../module/screen.h"
#include "../display/3dtypes.h"
#include "../game/kernel/gui/battlefont.h"
#include "../game/kernel/gui/ffviistring.h"
#include "../game/kernel/gui/guipointer.h"

#include <vector>



class GuiTest : public Screen
{
public:
    GuiTest();
    virtual ~GuiTest();

    virtual void Init();

    virtual void Input(const InputEvent &input);

    virtual void Update(const unsigned int &delta_time);

    virtual void Draw();

private:
    void         DrawStatus();

private:
    int         mStartY;
    int         mTotalPos;
    int         mPointerPos;
    PointerType mPointerType;

    int         mTimer;
    bool        mTest1;

    int         mTest3First;
    int         mTest3Cur;
    int         mTest3Last;

    FFVIIString mFFString;
};



#endif // GUITEST_H
