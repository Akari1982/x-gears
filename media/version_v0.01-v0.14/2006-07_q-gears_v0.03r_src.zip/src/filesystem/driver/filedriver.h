/*
 *  $Id: filedriver.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef FILEDRIVER_H
#define FILEDRIVER_H


#include "../../utilites/nocopy.h"

#include <string>



class FileDriver : NoCopy<FileDriver>
{
public:
             FileDriver();
    virtual ~FileDriver();

    virtual unsigned int GetFileSize(const std::string &path) = 0;
    virtual bool         ReadFile(const std::string &path, const void* buffer, const unsigned int start, const unsigned int length) = 0;
};



#endif // FILEDRIVER_H
