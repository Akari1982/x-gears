/*
 *  $Id: filedriver.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "filedriver.h"



FileDriver::FileDriver()
{
}



FileDriver::~FileDriver()
{
}
