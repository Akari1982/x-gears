/*
 *  $Id: gamefilesystem.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "gamefilesystem.h"



GameFileSystem *GAMEFILESYSTEM = NULL;



GameFileSystem::GameFileSystem()
{
}



GameFileSystem::~GameFileSystem()
{
}



unsigned int
GameFileSystem::GetFileSize(const std::string &path)
{
    return mFileDriver.GetFileSize(path);
}



bool
GameFileSystem::ReadFile(const std::string &path, const void* buffer, const unsigned int start, const unsigned int length)
{
    return mFileDriver.ReadFile(path, buffer, start, length);
}
