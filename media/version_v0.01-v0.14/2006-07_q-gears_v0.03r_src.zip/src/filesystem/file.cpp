// $Id: File.cpp, v 1.1 2006/04/17 00:00:01 Exp $

#include <cassert>
#include <string>

#include "File.h"

#include "gamefilesystem.h"
#include "realfilesystem.h"
#include "../utilites/logger.h"




/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

File::File(const RString& file):
    mpBuffer(NULL),
    mBufferSize(0),
    mFileName(file)
{
    mBufferSize = REALFILESYSTEM->GetFileSize(mFileName);

    mpBuffer = (u8*)malloc(sizeof(u8) * mBufferSize);

    if (!REALFILESYSTEM->ReadFile(mFileName, mpBuffer, 0, mBufferSize))
    {
        LOGGER->Log("Warning: %s not found!", mFileName.c_str());
    }
}



File::File(File* pFile, const u32& offset, const u32& length):
    mpBuffer(NULL),
    mBufferSize(length)
{
    assert(pFile != NULL);

    mFileName = pFile->GetFileName();

    mpBuffer = (u8 *)malloc(sizeof(u8) * mBufferSize);
    pFile->GetFileBuffer(mpBuffer, offset, mBufferSize);
}



File::File(u8* pBuffer, const u32& offset, const u32& length):
    mpBuffer(NULL),
    mBufferSize(length),
    mFileName("BUFFER")
{
    assert(pBuffer != NULL);

    mpBuffer = (u8*)malloc(sizeof(u8) * mBufferSize);
    memcpy(mpBuffer, pBuffer, mBufferSize);
}



File::File(File* pFile)
{
    assert(pFile != NULL);

    mBufferSize = pFile->GetFileSize();
    mFileName   = pFile->GetFileName();

    mpBuffer = (u8*)malloc(sizeof(u8) * mBufferSize);
    pFile->GetFileBuffer(mpBuffer, 0, mBufferSize);
}


File::~File(void)
{
    free(mpBuffer);
}



//============================= OPERATIONS ===================================

void
File::WriteFile(const RString& file) const
{
    REALFILESYSTEM->WriteNewFile(file, mpBuffer, mBufferSize);
}



//============================= ACCESS     ===================================

const RString&
File::GetFileName(void) const
{
    return mFileName;
}



const u32&
File::GetFileSize(void) const
{
    return mBufferSize;
}



void
File::GetFileBuffer(u8* pBuffer, const u32& start, const u32& length) const
{
    memcpy(pBuffer, mpBuffer + start, length);
}



const u8
File::GetU8(const u32& offset) const
{
    return static_cast<u8>(*(mpBuffer + offset));
}



const u16
File::GetU16LE(const u32& offset) const
{
    return ((u8*)mpBuffer + offset)[0] | (((u8*)mpBuffer + offset)[1] << 8);
}



const u32
File::GetU32LE(const u32& offset) const
{
    return ((u8*)mpBuffer + offset)[0] | (((u8*)mpBuffer + offset)[1] << 8) | (((u8*)mpBuffer + offset)[2] << 16) | (((u8*)mpBuffer + offset)[3] << 24);
}
