/*
 *  $Id: main.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "main.h"

#include "define.h"
#include "display/displayogl.h"
#include "filesystem/file.h"
#include "filesystem/gamefilesystem.h"
#include "filesystem/realfilesystem.h"
#include "input/inputfilter.h"
#include "game/kernel/kernel.h"
#include "module/ModuleManager.h"
#include "utilites/config.h"
#include "utilites/logger.h"
#include "utilites/utilites.h"
#include "utilites/timer/timer.h"
#include "utilites/timer/timersdl.h"

#include <stdio.h>



// game state
unsigned char state;



void
HandleInputEvents()
{
    INPUTFILTER->Update();

    static InputEventArray input_event_attay;
    input_event_attay.clear();
    INPUTFILTER->GetInputEvents(input_event_attay);

    for (int i = 0; i < input_event_attay.size(); i++)
    {
        MODULEMAN->Input(input_event_attay[i]);
    }
}



int
main(int argc, char *argv[])
{
    REALFILESYSTEM = new RealFileSystem();
    GAMEFILESYSTEM = new GameFileSystem();
    LOGGER         = new Logger(DEFAULT_LOG);
    CONFIG         = new Config();
    DISPLAY        = DisplayOGL::MakeDisplay();
    MODULEMAN      = new ModuleManager();
    INPUTFILTER    = new InputFilter();
    KERNEL         = new Kernel();

    TimerSDL::InitTimer();



    Timer* timer_logic = MakeTimer();
    Timer* timer_draw  = MakeTimer();
    unsigned int delta_logic = 0;
    unsigned int delta_draw  = 0;

    state = GAME;
    while (state != EXIT)
    {
        // Handle all necessary game logic
        if (delta_logic > 10)
        {
            HandleInputEvents();
            KERNEL->Update();
            MODULEMAN->Update(delta_logic);
            delta_logic = 0;
        }

        if (delta_draw > 32)
        {
            MODULEMAN->Draw();
            delta_draw = 0;
        }

        delta_logic += timer_logic->GetDeltaTime();
        delta_draw  += timer_draw->GetDeltaTime();
    }

    delete timer_logic;
    delete timer_draw;
    TimerSDL::QuitTimer();

    SAFE_DELETE(KERNEL)
    SAFE_DELETE(INPUTFILTER)
    SAFE_DELETE(MODULEMAN)
    SAFE_DELETE(DISPLAY)
    SAFE_DELETE(CONFIG)
    SAFE_DELETE(LOGGER)
    SAFE_DELETE(GAMEFILESYSTEM)
    SAFE_DELETE(REALFILESYSTEM)

    return 0;
}
