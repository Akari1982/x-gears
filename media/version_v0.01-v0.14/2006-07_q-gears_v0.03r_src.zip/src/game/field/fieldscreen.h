/*
 *  $Id: fieldscreen.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef FIELDSCREEN_H
#define FIELDSCREEN_H



#include "datfile.h"
#include "model.h"
#include "../../module/screen.h"
#include "../../display/3dtypes.h"

#include <string>
#include <vector>



class FieldScreen : public Screen
{
public:
    FieldScreen();
    virtual ~FieldScreen();

    virtual void Init();

    virtual void Input(const InputEvent &input);

    virtual void Update(const unsigned int &delta_time);

    virtual void Draw();

private:
    void DrawDebugInfo(void) const;
    void DrawPosibleActions(void) const;

    Vector3 GetWalkMeshCoords(const unsigned int& triangleIndex);
    Vector3 GetNextStep(const Vector3& moveVector, const Vector3& ignorePoint1 = Vector3(0.0f, 0.0f, 0.0f), const Vector3& ignorePoint2 = Vector3(0.0f, 0.0f, 0.0f));

private:
    std::vector<AccessPool> mAccessPool;
    std::vector<Vertex>     mAccess;

    std::vector<Vertex>     mWalkMesh;
    float                   mScale;

    Matrix                  mMatrix;

    std::vector<Vertex>     mAxis;

    Model                   mCharModel;
    Vector3                 mVectorPos;
    bool                    mMoveForward;
    bool                    mMoveBack;
    bool                    mMoveLeft;
    bool                    mMoveRight;
    unsigned int            mCurrentTriangle;


    // engine managing
    bool                    mViewDebugInfo;
    bool                    mViewAxis;
    bool                    mViewFromCamera;
    bool                    mViewWalkMesh;
    bool                    mViewAccess;
};



#endif // FIELDSCREEN_H
