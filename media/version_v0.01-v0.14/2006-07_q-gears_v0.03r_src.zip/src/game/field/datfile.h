/*
 *  $Id: datfile.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef DATFILE_H
#define DATFILE_H



#include "../filetypes/lzsfile.h"
#include "../../filesystem/file.h"
#include "../../display/3dtypes.h"
#include "../../display/math/matrix.h"
#include "../../utilites/stdstring.h"

#include <vector>



struct AccessPool
{
    unsigned short access[3];
};



class DatFile : public LzsFile
{
public:
    explicit DatFile(const RString &file);
    explicit DatFile(File* file);
    DatFile(File* file, const u32 &offset, const u32 &length);
    DatFile(u8* buffer, const u32 &offset, const u32 &length);
    virtual ~DatFile();

    void GetWalkMesh(std::vector<Vertex>& walkmesh, std::vector<Vertex>& accessGeom, std::vector<AccessPool>& accessPool);
    void GetCameraMatrix(Matrix &camera);
};



#endif // DATFILE_H
