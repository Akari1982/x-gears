/*
 *  $Id: datfile.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "datfile.h"
#include "../../display/math/matrix.h"
#include "../../display/math/matrixmath.h"
#include "../../display/math/vector.h"
#include "../../display/math/vectormath.h"
#include "../../utilites/config.h"
#include "../../utilites/logger.h"

#include <vector>



DatFile::DatFile(const RString &file):
    LzsFile(file)
{
}



DatFile::DatFile(File *file, const u32 &offset, const u32 &length):
    LzsFile(file, offset, length)
{
}



DatFile::DatFile(u8* buffer, const u32 &offset, const u32 &length):
    LzsFile(buffer, offset, length)
{
}



DatFile::DatFile(File *file):
    LzsFile(file)
{
}



DatFile::~DatFile()
{
}



void
DatFile::GetWalkMesh(std::vector<Vertex>& walkmesh, std::vector<Vertex>& accessGeom, std::vector<AccessPool>& accessPool)
{
    // get sector 2 offset (walkmesh)
    u32 offset_to_walkmesh = 0x1C + GetU32LE(0x04) - GetU32LE(0x00);
    u32 number_of_poly = GetU32LE(offset_to_walkmesh);

    int start_walkmesh = offset_to_walkmesh + 0x04;
    int start_access   = offset_to_walkmesh + 0x04 + number_of_poly * 0x18;

    for (u32 i = 0; i < number_of_poly; ++i)
    {
        Vertex v;

        v.p.x =  static_cast<s16>(GetU16LE(start_walkmesh + 0x00));
        v.p.z =  static_cast<s16>(GetU16LE(start_walkmesh + 0x02));
        v.p.y =  static_cast<s16>(GetU16LE(start_walkmesh + 0x04));
        v.c.r = 1.0f; v.c.g = 1.0f; v.c.b = 1.0f; v.c.a = 1.0f;
        walkmesh.push_back(v);
        v.p.x =  static_cast<s16>(GetU16LE(start_walkmesh + 0x08));
        v.p.z =  static_cast<s16>(GetU16LE(start_walkmesh + 0x0A));
        v.p.y =  static_cast<s16>(GetU16LE(start_walkmesh + 0x0C));
        v.c.r = 1.0f; v.c.g = 1.0f; v.c.b = 1.0f; v.c.a = 1.0f;
        walkmesh.push_back(v);
        v.p.x =  static_cast<s16>(GetU16LE(start_walkmesh + 0x10));
        v.p.z =  static_cast<s16>(GetU16LE(start_walkmesh + 0x12));
        v.p.y =  static_cast<s16>(GetU16LE(start_walkmesh + 0x14));
        v.c.r = 1.0f; v.c.g = 1.0f; v.c.b = 1.0f; v.c.a = 1.0f;
        walkmesh.push_back(v);



        Vertex point;
        AccessPool access;
        access.access[0] = GetU16LE(start_access + 0x00);
        access.access[1] = GetU16LE(start_access + 0x02);
        access.access[2] = GetU16LE(start_access + 0x04);

        if (access.access[0] == 0xFFFF)
        {
            point = walkmesh[i * 3 + 0]; point.c.g = 0.0f; point.c.b = 0.0f; accessGeom.push_back(point);
            point = walkmesh[i * 3 + 1]; point.c.g = 0.0f; point.c.b = 0.0f; accessGeom.push_back(point);
        }

        if (access.access[1] == 0xFFFF)
        {
            point = walkmesh[i * 3 + 1]; point.c.g = 0.0f; point.c.b = 0.0f; accessGeom.push_back(point);
            point = walkmesh[i * 3 + 2]; point.c.g = 0.0f; point.c.b = 0.0f; accessGeom.push_back(point);
        }

        if (access.access[2] == 0xFFFF)
        {
            point = walkmesh[i * 3 + 2]; point.c.g = 0.0f; point.c.b = 0.0f; accessGeom.push_back(point);
            point = walkmesh[i * 3 + 0]; point.c.g = 0.0f; point.c.b = 0.0f; accessGeom.push_back(point);
        }

        accessPool.push_back(access);



        // go to the next triangle
        start_walkmesh += 0x18;
        start_access   += 0x06;
    }
}



void
DatFile::GetCameraMatrix(Matrix &camera)
{
    // get sector 4 offset (camera)
    u32 offset_to_camera = 0x1C + GetU32LE(0x0C) - GetU32LE(0x00);
    u32 offset_to_next   = 0x1C + GetU32LE(0x10) - GetU32LE(0x00);

    // get camera matrix (3 vectors)
    float vxx = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x00))) * 0.000244140625f; // divide by 4096
    float vxy = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x04))) * 0.000244140625f; // divide by 4096
    float vxz = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x02))) * 0.000244140625f; // divide by 4096

    float vyx = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x06))) * 0.000244140625f; // divide by 4096
    float vyy = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x0A))) * 0.000244140625f; // divide by 4096
    float vyz = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x08))) * 0.000244140625f; // divide by 4096

    float vzx = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x0C))) * 0.000244140625f; // divide by 4096
    float vzy = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x10))) * 0.000244140625f; // divide by 4096
    float vzz = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x0E))) * 0.000244140625f; // divide by 4096

    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log("Field camera: vxx = %f, vxy = %f, vxz = %f", vxx, vxy, vxz);
        LOGGER->Log("              vyx = %f, vyy = %f, vyz = %f", vyx, vyy, vyz);
        LOGGER->Log("              vzx = %f, vzy = %f, vzz = %f", vzx, vzy, vzz);
    }

    // camera matrix
    Matrix mat(-vxx, vyx, vzx, 0,
               -vxy, vyy, vzy, 0,
               -vxz, vyz, vzz, 0,
                0,   0,   0,   1);



    // get camera position in world
    s32 ox  = -static_cast<s32>(GetU32LE(offset_to_camera + 0x14));
    s32 oy  = -static_cast<s32>(GetU32LE(offset_to_camera + 0x18));
    s32 oz  = -static_cast<s32>(GetU32LE(offset_to_camera + 0x1C));

    float tx = ox * vxx + oy * vyx + oz * vzx;
    float ty = ox * vxy + oy * vyy + oz * vzy;
    float tz = ox * vxz + oy * vyz + oz * vzz;

    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log("Field camera position:tx = %f, ty = %f, tz = %f", tx, ty, tz);
    }

    // camera position
    Matrix mat2;
    MatrixTranslation(mat2, tx, ty, tz);



    // set camera
    MatrixMultiply(camera, mat, mat2);
}
