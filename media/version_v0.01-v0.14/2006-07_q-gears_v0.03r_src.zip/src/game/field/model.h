#ifndef MODEL_H
#define MODEL_H



#include "../../display/3dtypes.h"
#include "../../utilites/nocopy.h"



class Model : public NoCopy<Model>
{
public:
    Model();
    virtual ~Model();

    void DrawModel();

    void SetCoords(const Vector3& coords);

private:
    std::vector<Vertex> mDefaultGeom;

    Vector3             mCoords;
};



#endif
