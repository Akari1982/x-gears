/*
 *  $Id: fieldscreen.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "fieldscreen.h"
#include "datfile.h"
#include "../kernel/kernel.h"
#include "../../display/display.h"
#include "../../utilites/config.h"
#include "../../utilites/logger.h"
#include "../../utilites/math.h"



FieldScreen::FieldScreen():
    mScale(1.0f),
    mViewDebugInfo(true),
    mViewAxis(true),
    mViewFromCamera(true),
    mViewWalkMesh(true),
    mViewAccess(true),

    mMoveForward(false),
    mMoveBack(false),
    mMoveLeft(false),
    mMoveRight(false)
{
    Init();
}



FieldScreen::~FieldScreen()
{
}



void
FieldScreen::Init()
{
    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
    DISPLAY->SetAlphaTest(true);
    DISPLAY->SetBlendMode(BLEND_NORMAL);
    DISPLAY->SetCullMode(CULL_NONE);

    Vertex point;
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 0.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 500.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 0.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 1.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 500.0f; point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 1.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 0.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 500.0f;
    point.c.r = 0.0f;   point.c.g = 0.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    mAxis.push_back(point);



    DatFile *dat = new DatFile(CONFIG->mField);

    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log("Load field %s", dat->GetFileName().c_str());
    }

    dat->GetWalkMesh(mWalkMesh, mAccess, mAccessPool);
    dat->GetCameraMatrix(mMatrix);
    delete dat;



    mCurrentTriangle = 1;
    mVectorPos = GetWalkMeshCoords(mCurrentTriangle);
    mCharModel.SetCoords(mVectorPos);
}



void
FieldScreen::Input(const InputEvent &input)
{
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_UP:    mMoveForward = true;                                break;
            case KEY_DOWN:  mMoveBack    = true;                                break;
            case KEY_LEFT:  mMoveRight   = true;                                break;
            case KEY_RIGHT: mMoveLeft    = true;                                break;

            case KEY_Cs:    mScale += 0.01f;                                    break;
            case KEY_Cd:    mScale -= 0.01f;                                    break;

            case KEY_Ci:    mViewDebugInfo  = (mViewDebugInfo)  ? false : true; break;
            case KEY_Ck:    mViewFromCamera = (mViewFromCamera) ? false : true; break;
            case KEY_Cx:    mViewAxis       = (mViewAxis)       ? false : true; break;
            case KEY_Cw:    mViewWalkMesh   = (mViewWalkMesh)   ? false : true; break;
            case KEY_Ca:    mViewAccess     = (mViewAccess)     ? false : true; break;
        }
    }

    if (input.type == IET_RELEASE)
    {
        switch (input.button)
        {
            case KEY_UP:    mMoveForward = false;                               break;
            case KEY_DOWN:  mMoveBack    = false;                               break;
            case KEY_LEFT:  mMoveRight   = false;                               break;
            case KEY_RIGHT: mMoveLeft    = false;                               break;
        }
    }
}



void
FieldScreen::Update(const unsigned int &delta_time)
{
    static float step = 5.0f;
    Vector3 next_step(0.0f, 0.0f, 0.0f);

    if (mMoveForward)
    {
        next_step.z =  step;
    }

    if (mMoveBack)
    {
        next_step.z = -step;
    }

    if (mMoveLeft)
    {
        next_step.x =  step;
    }

    if (mMoveRight)
    {
        next_step.x = -step;
    }

    mVectorPos = GetNextStep(next_step);
    mCharModel.SetCoords(mVectorPos);
}



void
FieldScreen::DrawDebugInfo(void) const
{
    RString temp_string;

    // draw current triangle
    temp_string.Format("Current Triangle: %02d", mCurrentTriangle);
    KERNEL->DrawString(RStringToFFVIIString(temp_string), 400, 10, F_WHITE);

    // draw current coords
    temp_string.Format("Current Position: x:%f", mVectorPos.x);
    KERNEL->DrawString(RStringToFFVIIString(temp_string), 400, 25, F_WHITE);
    temp_string.Format("y:%f", mVectorPos.y);
    KERNEL->DrawString(RStringToFFVIIString(temp_string), 505, 40, F_WHITE);
    temp_string.Format("z:%f", mVectorPos.z);
    KERNEL->DrawString(RStringToFFVIIString(temp_string), 505, 55, F_WHITE);
}



void
FieldScreen::DrawPosibleActions(void) const
{
    KERNEL->DrawString(RStringToFFVIIString("Press 'S'/'D' button to scale walkmesh"),        350, 385, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'I' button to show/hide debug info"),      350, 400, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'W' button to show/hide walkmesh"),        350, 415, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'A' button to show/hide access border"),   350, 430, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'K' button to swich to/from camera view"), 350, 445, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'X' button to show/hide axis"),            350, 460, F_WHITE);
}



void
FieldScreen::Draw()
{
    DISPLAY->CameraPushMatrix();

    // set camera
    if (mViewFromCamera == true)
    {
        DISPLAY->LoadCameraMatrix(mMatrix);
    }
    else
    {
        DISPLAY->LoadLookAt(50, Vector3(-500, 200, 900), Vector3(0, 0, 0), Vector3(0, 1, 0));
    }

    // draw axis
    if (mViewAxis == true)
    {
        DISPLAY->SetPointSize(3);
        DISPLAY->DrawPoints(mAxis);
        DISPLAY->SetLineWidth(1);
        DISPLAY->DrawLines(mAxis);
    }

    // draw walkmesh
    if (mViewWalkMesh == true)
    {
        DISPLAY->PushMatrix();
        DISPLAY->SetLineWidth(1);
        DISPLAY->Scale(mScale, mScale, mScale);
        DISPLAY->SetPolygonMode(POLYGON_LINE);
        DISPLAY->DrawTriangles(mWalkMesh);
        DISPLAY->SetPolygonMode(POLYGON_FILL);
        DISPLAY->PopMatrix();
    }

    // draw access
    if (mViewAccess == true)
    {
        DISPLAY->PushMatrix();
        DISPLAY->SetLineWidth(2);
        DISPLAY->Scale(mScale, mScale, mScale);
        DISPLAY->SetPolygonMode(POLYGON_LINE);
        DISPLAY->DrawLines(mAccess);
        DISPLAY->SetPolygonMode(POLYGON_FILL);
        DISPLAY->PopMatrix();
    }

    // draw character
    DISPLAY->PushMatrix();
    DISPLAY->Scale(mScale, mScale, mScale);
    mCharModel.DrawModel();
    DISPLAY->PopMatrix();

    // draw debug info
    if (mViewDebugInfo == true)
    {
        DrawDebugInfo();
    }

    DrawPosibleActions();
}



Vector3
FieldScreen::GetWalkMeshCoords(const unsigned int& triangleIndex)
{
    Vector3 coords;

    float x1 = mWalkMesh[triangleIndex * 3 + 0].p.x;
    float y1 = mWalkMesh[triangleIndex * 3 + 0].p.y;
    float z1 = mWalkMesh[triangleIndex * 3 + 0].p.z;

    float x2 = mWalkMesh[triangleIndex * 3 + 1].p.x;
    float y2 = mWalkMesh[triangleIndex * 3 + 1].p.y;
    float z2 = mWalkMesh[triangleIndex * 3 + 1].p.z;

    float x3 = mWalkMesh[triangleIndex * 3 + 2].p.x;
    float y3 = mWalkMesh[triangleIndex * 3 + 2].p.y;
    float z3 = mWalkMesh[triangleIndex * 3 + 2].p.z;

    // get points of line that crosses in center of triangle
    float xc1 = x1 + (x2 - x1) * 0.5f;
    float zc1 = z1 + (z2 - z1) * 0.5f;

    float xc2 = x1 + (x3 - x1) * 0.5f;
    float zc2 = z1 + (z3 - z1) * 0.5f;

    // find coords of point in center of triangle
    float t = ((zc1 - zc2) * (x2 - xc1) - (xc1 - xc2) * (z2 - zc1)) / (( x3 - xc1) * (z2 - zc2) - ( z3 - zc1) * (x2 - xc2));

    float x = xc1 + (x3 - xc1) * t;
    float z = zc1 + (z3 - zc1) * t;

    coords.x = x;
    coords.y = point_elevation(x, z, x1 , y1, z1, x2, y2, z2, x3, y3, z3);
    coords.z = z;

    return coords;
}



Vector3
FieldScreen::GetNextStep(const Vector3& moveVector, const Vector3& ignorePoint1, const Vector3& ignorePoint2)
{
    // if we are not moving anywhere
    if (moveVector.x == 0.0f && moveVector.y == 0.0f && moveVector.z == 0.0f)
    {
        return mVectorPos;
    }

    Vector3 A(mWalkMesh[mCurrentTriangle * 3 + 0].p.x,
              mWalkMesh[mCurrentTriangle * 3 + 0].p.y,
              mWalkMesh[mCurrentTriangle * 3 + 0].p.z);
    Vector3 B(mWalkMesh[mCurrentTriangle * 3 + 1].p.x,
              mWalkMesh[mCurrentTriangle * 3 + 1].p.y,
              mWalkMesh[mCurrentTriangle * 3 + 1].p.z);
    Vector3 C(mWalkMesh[mCurrentTriangle * 3 + 2].p.x,
              mWalkMesh[mCurrentTriangle * 3 + 2].p.y,
              mWalkMesh[mCurrentTriangle * 3 + 2].p.z);

    Vector3 point_in_triangle = find_point_in_triangle(moveVector, mVectorPos, A, B, C);



    // check if we cross current triangle
    Vector3 crossPoint(0.0f, 0.0f, 0.0f);
    float crossLength = 0.0f;
    int crossSide = find_triangle_crossing(crossPoint, crossLength, mVectorPos, point_in_triangle, A, B, C, ignorePoint1, ignorePoint2);

    // if we not cross any triangle border
    if (crossSide == 0)
    {
        return point_in_triangle;
    }
    // if we try to cross triangle border
    else
    {
        int access_triangle = mAccessPool[mCurrentTriangle].access[crossSide - 1];

        Vector3 sp1 = (crossSide == 1 || crossSide == 3) ? A : B;
        Vector3 sp2 = (crossSide == 1) ? B : C;

        // if we met border - then slide
        if (access_triangle == 0xFFFF)
        {
            Vector3 new_move = get_projection_on_line(moveVector, sp1, sp2);
            return GetNextStep(new_move);
        }

        mVectorPos = crossPoint;
        mCurrentTriangle = access_triangle;

        // get new move vector
        float t = crossLength / sqrtf(moveVector.x * moveVector.x + moveVector.y * moveVector.y + moveVector.z * moveVector.z);
        Vector3 new_move(0.0f, 0.0f, 0.0f);
        new_move.x = moveVector.x * t;
        new_move.z = moveVector.z * t;

        return GetNextStep(new_move, sp1, sp2);
    }
}
