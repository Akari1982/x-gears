#include "model.h"
#include "../../display/display.h"



Model::Model()
{
    mCoords.x = 0.0f;
    mCoords.y = 0.0f;
    mCoords.z = 0.0f;

    Vertex point;
    point.p.x = -1.0f; point.p.y =  0.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  0.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  0.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x = -1.0f; point.p.y =  0.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);

    point.p.x = -1.0f; point.p.y =  3.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  3.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  3.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x = -1.0f; point.p.y =  3.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);

    point.p.x = -1.0f; point.p.y =  3.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  3.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  0.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x = -1.0f; point.p.y =  0.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);

    point.p.x = -1.0f; point.p.y =  3.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  3.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  0.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x = -1.0f; point.p.y =  0.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
}



Model::~Model()
{
}



void
Model::DrawModel()
{
    DISPLAY->PushMatrix();
    DISPLAY->SetLineWidth(2);
    DISPLAY->Translate(mCoords.x, mCoords.y, mCoords.z);
    DISPLAY->Scale(30.0f, 30.0f, 30.0f);
    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->DrawQuads(mDefaultGeom);
    DISPLAY->SetPolygonMode(POLYGON_FILL);
    DISPLAY->PopMatrix();
}



void
Model::SetCoords(const Vector3& coord)
{
    mCoords = coord;
}
