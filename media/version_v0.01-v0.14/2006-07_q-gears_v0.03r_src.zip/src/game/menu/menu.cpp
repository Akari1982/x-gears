#include "menu.h"



Menu::Menu()
{
    Init();
}



Menu::~Menu()
{
}



void
Menu::Init()
{
}



void
Menu::Input(const InputEvent &input)
{
}



void
Menu::Update(const unsigned int &delta_time)
{
}



void
Menu::Draw()
{
}
