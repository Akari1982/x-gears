/*
 *  $Id: partymenu.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef PARTYMENU_H
#define PARTYMENU_H



#include "menu.h"



class PartyMenu : public Menu
{
public:
                 PartyMenu();
    virtual     ~PartyMenu();

    virtual void Init();

    virtual void Input(const InputEvent &input);

    virtual void Update(const unsigned int &delta_time);

    virtual void Draw();

private:
    void         DrawCharInfo(const unsigned int &slot_char, const int &x, const int &y);

private:
    bool mStartLive;
    bool mStartDie;
    int mStep;

    int mMenuStartY;
    int mMenuX;
    int mMenuY;
    int mMenuFinishY;

    int mPartyStartX;
    int mPartyX;
    int mPartyY;
    int mPartyFinishX;

    int mTimeStartX;
    int mTimeX;
    int mTimeY;
    int mTimeFinishX;

    int mLocationStartY;
    int mLocationX;
    int mLocationY;
    int mLocationFinishY;

    // local copy of timer
    unsigned int mTimer;
    bool         mTimerColon;
};



#endif // PARTYMENU_H
