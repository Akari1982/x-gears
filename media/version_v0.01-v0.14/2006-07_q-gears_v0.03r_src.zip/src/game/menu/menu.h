/*
 *  $Id: menu.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef MENU_H
#define MENU_H



#include "../../module/screen.h"



class Menu : public Screen
{
public:
                 Menu();
    virtual     ~Menu();

    virtual void Init();

    virtual void Input(const InputEvent &input);

    virtual void Update(const unsigned int &delta_time);

    virtual void Draw();
};



#endif // MENU_H
