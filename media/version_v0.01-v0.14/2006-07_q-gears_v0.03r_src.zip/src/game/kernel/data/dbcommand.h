/*
 *  $Id: dbcommand.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef DBCOMMAND_H
#define DBCOMMAND_H



typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;



struct DBCommand
{
    u8 Unknown[16];
};




#endif
