/*
 *  $Id: dbweapon.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef DBWEAPON_H
#define DBWEAPON_H



typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;



struct DBWeapon
{
    u8 Unknown[44];
};




#endif
