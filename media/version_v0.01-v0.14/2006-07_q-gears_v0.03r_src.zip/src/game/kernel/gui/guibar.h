/*
 *  $Id: guibar.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef GUIBAR_H
#define GUIBAR_H



#include "../../../display/3dtypes.h"
#include "../../../display/surface/surface.h"
#include "../../../utilites/nocopy.h"



enum BarType {HP_BAR, MP_BAR};



class GuiBar : public NoCopy<GuiBar>
{
public:
             GuiBar();
    virtual ~GuiBar();

    void     DrawBar(const int &x, const int &y, const unsigned int &cur, const unsigned int &max, const BarType &type);

private:
    std::vector<Vertex> mPolyHP;
    std::vector<Vertex> mPolyMP;
    std::vector<Vertex> mPolyBack;
    std::vector<Vertex> mPolyUnder;
};



#endif
