/*
 *  $Id: guislash.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef GUISLASH_H
#define GUISLASH_H



#include "../../../display/3dtypes.h"
#include "../../../display/surface/surface.h"
#include "../../../utilites/nocopy.h"



class GuiSlash : public NoCopy<GuiSlash>
{
public:
             GuiSlash(Surface* image);
    virtual ~GuiSlash();

    void     DrawSlash(const int &x, const int &y);

private:
    int                 mTexId;
    std::vector<Vertex> mPoly;
};



#endif
