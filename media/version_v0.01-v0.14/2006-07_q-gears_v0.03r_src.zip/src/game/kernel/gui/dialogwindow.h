/*
 *  $Id: dialogwindow.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef DIALOGWINDOW_H
#define DIALOGWINDOW_H



#include "../../../display/3dtypes.h"
#include "../../../display/surface/surface.h"
#include "../../../utilites/nocopy.h"



class DialogWindow : public NoCopy<DialogWindow>
{
public:
             DialogWindow(Surface* image);

    virtual ~DialogWindow();

    void     DrawWindow(const int &x, const int &y, const int &width, const int &height);

private:
    float               mBorderWidth;
    float               mBorderHeight;

    int                 mWindowTexId[9];
    std::vector<Vertex> mWindowPoly;
};



#endif
