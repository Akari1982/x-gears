/*
 *  $Id: guibarexp.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef GUIBAREXP_H
#define GUIBAREXP_H



#include "../../../display/3dtypes.h"
#include "../../../display/surface/surface.h"
#include "../../../utilites/nocopy.h"



enum BarExpType {EXP_BAR, LIMIT_BAR, SADNESS_LIMIT_BAR, FURY_LIMIT_BAR};



class GuiBarExp : public NoCopy<GuiBarExp>
{
public:
             GuiBarExp(Surface* image);
    virtual ~GuiBarExp();

    void     DrawBarExp(const int &x, const int &y, const unsigned int &cur, const unsigned int &max, const BarExpType &type);

private:
    int                 mTexId;
    std::vector<Vertex> mPoly;
    std::vector<Vertex> mPolyOverlay;
};



#endif
