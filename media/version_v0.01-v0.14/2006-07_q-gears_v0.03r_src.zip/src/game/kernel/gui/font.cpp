#include <vector>
#include <map>
#include <utility>

#include "font.h"
#include "../../../display/display.h"
#include "../../../display/surface/surface.h"
#include "../../../utilites/logger.h"
#include "../../../utilites/stdstring.h"



Font::Font(Surface* image_gray,
           Surface* image_blue,
           Surface* image_white,
           File* font_padding):
    mLetterWidth  (12),
    mLetterHeight (12),
    mLetterSpacing(-8),
    mRowSpacing   (0)

{
    int offset = 0;

    for (int y = 0; y < 132; y += mLetterHeight)
    {
        for (int x = 0; x < 252; x += mLetterWidth)
        {
            Surface* font;
            FontStat stat;
            stat.Width   = (font_padding->GetU8(offset)) & 0x1F;
            stat.Padding = (font_padding->GetU8(offset)) >> 5;
            offset++;

            font = CreateSubSurface(x, y, mLetterWidth, mLetterHeight, image_gray);
            SetSurfaceSize(font, 16, 16);
            stat.TexId = DISPLAY->CreateTexture(font);
            mFontGrayTexId.push_back(stat);
            delete font;

            font = CreateSubSurface(x, y, mLetterWidth, mLetterHeight, image_blue);
            SetSurfaceSize(font, 16, 16);
            stat.TexId = DISPLAY->CreateTexture(font);
            mFontBlueTexId.push_back(stat);
            delete font;

            font = CreateSubSurface(x, y, mLetterWidth, mLetterHeight, image_white);
            SetSurfaceSize(font, 16, 16);
            stat.TexId = DISPLAY->CreateTexture(font);
            mFontWhiteTexId.push_back(stat);
            delete font;
        }
    }

    // change the size because we resized texture
    mLetterWidth  = 16;
    mLetterHeight = 16;

    Vertex point;
    point.p.x =  0.0f;        point.p.y =  0.0f;          point.p.z =  0.0f;
    point.c.r =  1.0f;        point.c.g =  1.0f;          point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  0.0f;        point.t.y =  0.0f;
    mFontPoly.push_back(point);
    point.p.x = mLetterWidth; point.p.y =  0.0f;          point.p.z =  0.0f;
    point.c.r =  1.0f;        point.c.g =  1.0f;          point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  1.0f;        point.t.y =  0.0f;
    mFontPoly.push_back(point);
    point.p.x = mLetterWidth; point.p.y = -mLetterHeight; point.p.z =  0.0f;
    point.c.r =  1.0f;        point.c.g =  1.0f;          point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  1.0f;        point.t.y =  1.0f;
    mFontPoly.push_back(point);
    point.p.x =  0.0f;        point.p.y = -mLetterHeight; point.p.z =  0.0f;
    point.c.r =  1.0f;        point.c.g =  1.0f;          point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  0.0f;        point.t.y =  1.0f;
    mFontPoly.push_back(point);
}



Font::~Font()
{
    int i;

    for (i = 0; i < mFontGrayTexId.size(); ++i)
    {
        DISPLAY->DeleteTexture(mFontGrayTexId[i].TexId);
        DISPLAY->DeleteTexture(mFontBlueTexId[i].TexId);
        DISPLAY->DeleteTexture(mFontWhiteTexId[i].TexId);
    }
}



void
Font::DrawString(const FFVIIString &string, const int &x, const int &y, const FontColor &color)
{
    DISPLAY->Translate(x, -y, 0);
    DISPLAY->PushMatrix();

    for (int i = 0; i < string.size(); ++i)
    {
        // choice
             if (string[i] == 0xE0)
        {
            DISPLAY->Translate(10, 0, 0);
        }
        // tab
        else if (string[i] == 0xE1)
        {
            DISPLAY->Translate(10, 0, 0);
        }
        // new line
        else if (string[i] == 0xE7)
        {
            DISPLAY->PopMatrix();
            DISPLAY->Translate(0, -(mLetterHeight + mRowSpacing), 0);
            DISPLAY->PushMatrix();
        }
        // new window (but this needs to be hanbled in field module so this is for testing)
        else if (string[i] == 0xE8)
        {
            DISPLAY->PopMatrix();
            DISPLAY->Translate(0, -(mLetterHeight + mRowSpacing), 0);
            DISPLAY->PushMatrix();
        }
        // end of dialog
        else if (string[i] == 0xFF)
        {
            break;
        }
        else
        {
            if (string[i] < mFontGrayTexId.size())
            {
                switch (color)
                {
                    case F_GRAY :
                        DISPLAY->SetTexture(mFontGrayTexId[string[i]].TexId);
                        break;
                    case F_BLUE:
                        DISPLAY->SetTexture(mFontBlueTexId[string[i]].TexId);
                        break;
                    case F_WHITE:
                        DISPLAY->SetTexture(mFontWhiteTexId[string[i]].TexId);
                        break;
                    default:
                        LOGGER->Log("Unidentify font color %d.", static_cast<int>(color));
                        break;
                }

                DISPLAY->DrawQuads(mFontPoly);
                DISPLAY->UnsetTexture();
                DISPLAY->Translate(mFontGrayTexId[string[i]].Width + mFontGrayTexId[string[i]].Padding, 0, 0);
            }
            else
            {
                LOGGER->Log("Warning: Letter '0x%02x' not found in this font", string[i]);
            }
        }
    }

    DISPLAY->PopMatrix();
}
