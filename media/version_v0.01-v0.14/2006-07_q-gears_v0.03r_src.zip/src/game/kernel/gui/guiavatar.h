/*
 *  $Id: guiavatar.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef GUIAVATAR_H
#define GUIAVATAR_H



#include "../../../display/3dtypes.h"
#include "../../../display/surface/surface.h"
#include "../../../utilites/nocopy.h"
#include "../../../utilites/stdstring.h"



class GuiAvatar : public NoCopy<GuiAvatar>
{
public:
             GuiAvatar();
    virtual ~GuiAvatar();

    void     DrawAvatar(const int &x, const int &y, const unsigned char &avatar_id);

private:
    int      LoadAvatar(const RString &name);

private:
    int                 mAvatarTexId[12];
    std::vector<Vertex> mAvatarPoly;
};



#endif
