/*
 *  $Id: guidigit.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef GUIDIGIT_H
#define GUIDIGIT_H



#include "../../../display/3dtypes.h"
#include "../../../display/surface/surface.h"
#include "../../../utilites/nocopy.h"
#include "../../../utilites/stdstring.h"

#include <map>
#include <vector>



class GuiDigit : public NoCopy<GuiDigit>
{
public:
             GuiDigit(Surface* image);

    virtual ~GuiDigit();

    void     DrawDigit(const int &x, const int &y, const RString &string);

private:
    std::map<int, int>  mDigitTexId;
    std::vector<Vertex> mDigitPoly;
};



#endif
