/*
 *  $Id: font.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef FONT_H
#define FONT_H



#include "ffviistring.h"
#include "../../../display/3dtypes.h"
#include "../../../display/surface/surface.h"
#include "../../../filesystem/file.h"
#include "../../../utilites/nocopy.h"

#include <vector>
#include <map>
#include <utility>



enum FontColor {F_GRAY, F_BLUE, F_WHITE};



class Font : public NoCopy<Font>
{
public:
             Font(Surface* image_gray,
                  Surface* image_blue,
                  Surface* image_white,
                  File* font_padding);

    virtual ~Font();

    void     DrawString(const FFVIIString &string, const int &x, const int &y, const FontColor &color);

protected:
    int mLetterWidth;
    int mLetterHeight;
    int mLetterSpacing;
    int mRowSpacing;

    struct FontStat
    {
        int TexId;
        int Padding;
        int Width;
    };

    std::vector<FontStat> mFontGrayTexId;
    std::vector<FontStat> mFontBlueTexId;
    std::vector<FontStat> mFontWhiteTexId;
    std::vector<Vertex>     mFontPoly;
};



#endif
