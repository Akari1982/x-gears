/*
 *  $Id: guipointer.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef GUIPOINTER_H
#define GUIPOINTER_H



#include "../../../display/3dtypes.h"
#include "../../../display/surface/surface.h"
#include "../../../utilites/nocopy.h"



enum PointerType {TO_LEFT, TO_RIGHT, TO_RIGHT_CROSS};



class GuiPointer : public NoCopy<GuiPointer>
{
public:
             GuiPointer(Surface* image, Surface* image2);

    virtual ~GuiPointer();

    void     DrawPointer(const int &x, const int &y, const PointerType &type);

private:
    int                 mPointerTexId[3];
    std::vector<Vertex> mPointerPoly;
};



#endif
