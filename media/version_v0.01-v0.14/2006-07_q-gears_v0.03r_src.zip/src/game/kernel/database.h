/*
 *  $Id: database.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef DATABASE_H
#define DATABASE_H



#include "data/dbaccessory.h"
#include "data/dbarmor.h"
#include "data/dbattack.h"
#include "data/dbcommand.h"
#include "data/dbitem.h"
#include "data/dbmateria.h"
#include "data/dbweapon.h"
#include "gui/ffviistring.h"
#include "../../utilites/nocopy.h"



// forward declaration
class Kernel;



class Database : public NoCopy<Database>
{
    friend class Kernel;

public:
                       Database();
    virtual           ~Database();

    const DBCommand &  GetCommand             (const int &id) const;
    const DBAttack &   GetAttack              (const int &id) const;
    const DBItem &     GetItem                (const int &id) const;
    const DBWeapon &   GetWeapon              (const int &id) const;
    const DBArmor &    GetArmor               (const int &id) const;
    const DBAccessory &GetAccessory           (const int &id) const;
    const DBMateria &  GetMateria             (const int &id) const;

    const FFVIIString &GetCommandDescription  (const int &id) const;
    const FFVIIString &GetMagicDescription    (const int &id) const;
    const FFVIIString &GetItemDescription     (const int &id) const;
    const FFVIIString &GetWeaponDescription   (const int &id) const;
    const FFVIIString &GetArmorDescription    (const int &id) const;
    const FFVIIString &GetAccessoryDescription(const int &id) const;
    const FFVIIString &GetMateriaDescription  (const int &id) const;
    const FFVIIString &GetKeyItemDescription  (const int &id) const;
    const FFVIIString &GetCommandName         (const int &id) const;
    const FFVIIString &GetMagicName           (const int &id) const;
    const FFVIIString &GetItemName            (const int &id) const;
    const FFVIIString &GetWeaponName          (const int &id) const;
    const FFVIIString &GetArmorName           (const int &id) const;
    const FFVIIString &GetAccessoryName       (const int &id) const;
    const FFVIIString &GetMateriaName         (const int &id) const;
    const FFVIIString &GetKeyItemName         (const int &id) const;
    const FFVIIString &GetBattleText          (const int &id) const;
    const FFVIIString &GetSummonName          (const int &id) const;

    const int GetSizeOfCommands               () const;
    const int GetSizeOfAttacks                () const;
    const int GetSizeOfItems                  () const;
    const int GetSizeOfWeapons                () const;
    const int GetSizeOfArmors                 () const;
    const int GetSizeOfAccessorys             () const;
    const int GetSizeOfMaterias               () const;

    const int GetSizeOfCommandDescriptions    () const;
    const int GetSizeOfMagicDescriptions      () const;
    const int GetSizeOfItemDescriptions       () const;
    const int GetSizeOfWeaponDescriptions     () const;
    const int GetSizeOfArmorDescriptions      () const;
    const int GetSizeOfAccessoryDescriptions  () const;
    const int GetSizeOfMateriaDescriptions    () const;
    const int GetSizeOfKeyItemDescriptions    () const;
    const int GetSizeOfCommandNames           () const;
    const int GetSizeOfMagicNames             () const;
    const int GetSizeOfItemNames              () const;
    const int GetSizeOfWeaponNames            () const;
    const int GetSizeOfArmorNames             () const;
    const int GetSizeOfAccessoryNames         () const;
    const int GetSizeOfMateriaNames           () const;
    const int GetSizeOfKeyItemNames           () const;
    const int GetSizeOfBattleTexts            () const;
    const int GetSizeOfSummonNames            () const;

private:
    static std::vector<DBCommand>   mCommands;
    static std::vector<DBAttack>    mAttacks;
    static std::vector<DBItem>      mItems;
    static std::vector<DBWeapon>    mWeapons;
    static std::vector<DBArmor>     mArmors;
    static std::vector<DBAccessory> mAccessorys;
    static std::vector<DBMateria>   mMaterias;

    // kernel text
    static std::vector<FFVIIString> mCommandDescriptions;
    static std::vector<FFVIIString> mMagicDescriptions;
    static std::vector<FFVIIString> mItemDescriptions;
    static std::vector<FFVIIString> mWeaponDescriptions;
    static std::vector<FFVIIString> mArmorDescriptions;
    static std::vector<FFVIIString> mAccessoryDescriptions;
    static std::vector<FFVIIString> mMateriaDescriptions;
    static std::vector<FFVIIString> mKeyItemDescriptions;
    static std::vector<FFVIIString> mCommandNames;
    static std::vector<FFVIIString> mMagicNames;
    static std::vector<FFVIIString> mItemNames;
    static std::vector<FFVIIString> mWeaponNames;
    static std::vector<FFVIIString> mArmorNames;
    static std::vector<FFVIIString> mAccessoryNames;
    static std::vector<FFVIIString> mMateriaNames;
    static std::vector<FFVIIString> mKeyItemNames;
    static std::vector<FFVIIString> mBattleText;
    static std::vector<FFVIIString> mSummonNames;
    FFVIIString                     mStringNull;
};



#endif
