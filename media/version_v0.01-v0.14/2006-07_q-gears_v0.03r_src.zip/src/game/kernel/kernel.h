/*
 *  $Id: kernel.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef KERNEL_H
#define KERNEL_H



#include "database.h"
#include "gamestate.h"
#include "gui/battlefont.h"
#include "gui/dialogwindow.h"
#include "gui/font.h"
#include "gui/ffviistring.h"
#include "gui/guiavatar.h"
#include "gui/guibar.h"
#include "gui/guibarexp.h"
#include "gui/guicounter.h"
#include "gui/guidigit.h"
#include "gui/guipointer.h"
#include "gui/guislash.h"
#include "../../utilites/nocopy.h"
#include "../../utilites/stdstring.h"



class Kernel : public NoCopy<Kernel>
{
public:
                     Kernel();
    virtual         ~Kernel();

    void             Init();
    void             Update();

    const Database  &GetDatabase();
    const Gamestate &GetGamestate();

    void             DrawAvatar(const int &x, const int &y, const unsigned char &avatar_id);
    void             DrawBar(const int &x, const int &y, const unsigned int &cur, const unsigned int &max, const BarType &type);
    void             DrawBarExp(const int &x, const int &y, const unsigned int &cur, const unsigned int &max, const BarExpType &type);
    void             DrawBattleString(const RString &string, const int &x, const int &y, const BattleFontColor &color);
    void             DrawCounter(const int &x, const int &y, const RString &string);
    void             DrawDigit(const int &x, const int &y, const RString &string);
    void             DrawPointer(const int &x, const int &y, const PointerType &type);
    void             DrawSlash(const int &x, const int &y);
    void             DrawString(const FFVIIString &string, const int &x, const int &y, const FontColor &color);
    void             DrawWindow(const int &x, const int &y, const int &width, const int &height);

    void             LoadSavemap(File* file);

private:
    void             InitDatabase();
    void             LoadKernelString(std::vector<FFVIIString> &string_vector, File* &file);
    void             InitGraphics();

    void             SetFrontScreen();
    void             UnsetFrontScreen();

private:
    Gamestate     mGamestate;
    Database      mDatabase;

    GuiAvatar*    mGuiAvatar;
    GuiBar*       mGuiBar;
    GuiBarExp*    mGuiBarExp;
    GuiCounter*   mGuiCounter;
    GuiDigit*     mGuiDigit;
    GuiPointer*   mGuiPointer;
    GuiSlash*     mGuiSlash;
    BattleFont*   mBattleFont;
    Font*         mFont;
    DialogWindow* mWindow;
};



// Visible from every part of programm
extern Kernel *KERNEL;



#endif // KERNEL_H
