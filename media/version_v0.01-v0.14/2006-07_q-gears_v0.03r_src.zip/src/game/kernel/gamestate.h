/*
 *  $Id: gamestate.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef GAMESTATE_H
#define GAMESTATE_H
// The Gamestate Class : Contain all info about current game state



#include "savemap.h"
#include "../../utilites/nocopy.h"



// forward declaration
class Kernel;



class Gamestate : public NoCopy<Gamestate>
{
    friend class Kernel;

public:
             Gamestate();
    virtual ~Gamestate();

    const Savemap& GetSavemap() const;

    void DumpSavemap();

    void Update();

private:
    static Savemap mSavemap;
};



#endif // GAMESTATE_H
