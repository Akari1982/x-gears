// $Id: WorldMapModule.cpp, v 1.1 2006/04/17 00:00:01 Exp $

#include "WorldMapModule.h"
#include "../kernel/kernel.h"
#include "../../display/display.h"
#include "../../utilites/logger.h"



WorldMapModule::WorldMapModule(void)
{
    Init();
}



WorldMapModule::~WorldMapModule(void)
{
}



void
WorldMapModule::Init()
{
}



void
WorldMapModule::Input(const InputEvent& input)
{
}



void
WorldMapModule::Update(const unsigned int& deltaTime)
{
}



void
WorldMapModule::Draw(void)
{
    KERNEL->DrawString(RStringToFFVIIString("Placeholder for WorldMap module.\nJust as Halkun want ^_^"), 300, 100, F_WHITE);
}
