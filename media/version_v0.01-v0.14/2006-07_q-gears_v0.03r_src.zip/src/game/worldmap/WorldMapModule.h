/*
 *  $Id: WorldMapModule.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef WORLD_MAP_MODULE_h
#define WORLD_MAP_MODULE_h



#include "../../module/screen.h"




class WorldMapModule : public Screen
{
public:
    WorldMapModule(void);
    virtual ~WorldMapModule(void);

    virtual void Init(void);

    virtual void Draw(void);

    virtual void Input(const InputEvent& input);

    virtual void Update(const unsigned int &deltaTime);


};



#endif //  WORLD_MAP_MODULE_h
