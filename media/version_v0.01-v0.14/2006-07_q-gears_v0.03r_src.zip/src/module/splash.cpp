#include "splash.h"
#include "ModuleManager.h"
#include "../display/display.h"
#include "../display/surface/surfaceload.h"
#include "../game/field/fieldscreen.h"
#include "../screentest/displaytest.h"
#include "../utilites/logger.h"

#include <string>



ScreenSplash::ScreenSplash():
    mTexId(0)
{
    Init();
}



ScreenSplash::~ScreenSplash()
{
    DISPLAY->DeleteTexture(mTexId);
}



void
ScreenSplash::Init()
{
    Vertex point;

    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
    DISPLAY->SetAlphaTest(true);
    DISPLAY->SetBlendMode(BLEND_NORMAL);
    DISPLAY->SetCullMode(CULL_NONE);

    Surface* texture = SurfaceUtils::LoadFile("data/splash.bmp");
    if (texture != NULL)
    {
        mTexId = DISPLAY->CreateTexture(texture);
        delete texture;
    }
    else
    {
        LOGGER->Log("Can't load texture.");
    }

    point.p.x = -1.0f; point.p.y = -1.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  0.0f; point.t.y =  1.0f;
    mQuadsTex.push_back(point);
    point.p.x = -1.0f; point.p.y =  1.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  0.0f; point.t.y =  0.0f;
    mQuadsTex.push_back(point);
    point.p.x =  1.0f; point.p.y =  1.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  1.0f; point.t.y =  0.0f;
    mQuadsTex.push_back(point);
    point.p.x =  1.0f; point.p.y = -1.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  1.0f; point.t.y =  1.0f;
    mQuadsTex.push_back(point);
}



void
ScreenSplash::Input(const InputEvent &input)
{
    switch (input.button)
    {
        case KEY_SPACE:
        {
            MODULEMAN->PopTopModule();

            ScreenDisplayTest* screen1 = new ScreenDisplayTest();
            MODULEMAN->PushModule(screen1);
//            GuiTest* screen2 = new GuiTest();
//            SCREENMAN->PushScreen(screen2);
            break;
        }
    }
}



void
ScreenSplash::Update(const unsigned int &delta_time)
{
}



void
ScreenSplash::Draw()
{
    DISPLAY->SetTexture(mTexId);
    DISPLAY->DrawQuads(mQuadsTex);
    DISPLAY->UnsetTexture();
}
