// $Id: ModuleManager.cpp, v 1.1 2006/04/17 00:00:01 Exp $

#include "ModuleManager.h"
#include "screen.h"
#include "splash.h"
#include "../display/display.h"
#include "../utilites/utilites.h"
#include "../utilites/logger.h"



ModuleManager* MODULEMAN = NULL;



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

ModuleManager::ModuleManager(void)
{
    ScreenSplash* screen = new ScreenSplash();
    PushModule(screen);
}



ModuleManager::~ModuleManager(void)
{
    for (int i = 0; i < mModulesToDelete.size(); ++i)
    {
        delete mModulesToDelete[i];
    }

    for (int i = 0; i < mModules.size(); ++i)
    {
        delete mModules[i];
    }
}



//============================= OPERATIONS ===================================

void
ModuleManager::Draw(void)
{
    DISPLAY->BeginFrame();

    for (int i = 0; i < mModules.size(); ++i)
    {
        mModules[i]->Draw();
    }

    DISPLAY->EndFrame();
}



void
ModuleManager::Input(const InputEvent& input)
{
    if (!mModules.size())
    {
        return;
    }
    mModules[mModules.size() - 1]->Input(input);
}



void
ModuleManager::Update(const u32& deltaTime)
{
    for (int i = 0; i < mModulesToDelete.size(); ++i)
    {
        delete mModulesToDelete[i];
    }
    mModulesToDelete.clear();

    for (int i = 0; i < mModules.size(); ++i)
    {
        mModules[i]->Update(deltaTime);
    }
}



void
ModuleManager::PushModule(Screen* pModule)
{
    mModules.push_back(pModule);
}



void
ModuleManager::PopTopModule()
{
    if (mModules.size() > 0)
    {
        mModulesToDelete.push_back(mModules[mModules.size() - 1]);
        mModules.pop_back();
    }
}
