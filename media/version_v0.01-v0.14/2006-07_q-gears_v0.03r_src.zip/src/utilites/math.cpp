#include "math.h"
#include "../display/math/vectormath.h"



int
find_triangle_crossing(Vector3& crossPoint, float& crossLength,
                       const Vector3& p11, const Vector3& p12, // our line
                       const Vector3& A, const Vector3& B, const Vector3& C,
                       const Vector3& ignore1, const Vector3& ignore2)
{
    int ret = 0;

//printf("ignore1 x:%f y:%f z:%f\n", ignore1.x, ignore1.y, ignore1.z);
//printf("ignore2 x:%f y:%f z:%f\n", ignore2.x, ignore2.y, ignore2.z);
//printf("A       x:%f y:%f z:%f\n", A.x, A.y, A.z);
//printf("B       x:%f y:%f z:%f\n", B.x, B.y, B.z);
//printf("C       x:%f y:%f z:%f\n", C.x, C.y, C.z);

    // if we cross line 1
    if (!((ignore1 == A && ignore2 == B) || (ignore1 == B && ignore2 == A)) && line_crossing(crossPoint, p11, p12, A, B) == true)
    {
        ret = 1;
    }
    // if we cross line 2
    else if (!((ignore1 == B && ignore2 == C) || (ignore1 == C && ignore2 == B)) && line_crossing(crossPoint, p11, p12, B, C) == true)
    {
        ret = 2;
    }
    // if we cross line 3
    else if (!((ignore1 == A && ignore2 == C) || (ignore1 == C && ignore2 == A)) && line_crossing(crossPoint, p11, p12, A, C) == true)
    {
        ret = 3;
    }
//printf("ret = %d\n", ret);
    // get length of line
    crossLength = sqrtf((p11.x - crossPoint.x) * (p11.x - crossPoint.x) +
                        (p11.y - crossPoint.y) * (p11.y - crossPoint.y) +
                        (p11.z - crossPoint.z) * (p11.z - crossPoint.z));

    return ret;
}



Vector3
find_point_in_triangle(const Vector3& moveVector, const Vector3& curPoint,
                       const Vector3& A, const Vector3& B, const Vector3& C)
{
    // if we are not moving anywhere
    if (moveVector.x == 0.0f && moveVector.y == 0.0f && moveVector.z == 0.0f)
    {
        return curPoint;
    }

    // set second plane coords
    float x21 = curPoint.x;
    float y21 = curPoint.y;
    float z21 = curPoint.z;
    float x22 = curPoint.x + moveVector.x;
    float y22 = curPoint.y + moveVector.y;
    float z22 = curPoint.z + moveVector.z;
    float x23 = curPoint.x;
    float y23 = curPoint.y + 1.0f;
    float z23 = curPoint.z;

    // get length of line
    float l = sqrtf((x22 - x21) * (x22 - x21) + (y22 - y21) * (y22 - y21) + (z22 - z21) * (z22 - z21));

    float A1 = A.y * (B.z - C.z) + B.y * (C.z - A.z) + C.y * (A.z - B.z);
    float B1 = A.z * (B.x - C.x) + B.z * (C.x - A.x) + C.z * (A.x - B.x);
    float C1 = A.x * (B.y - C.y) + B.x * (C.y - A.y) + C.x * (A.y - B.y);
    float D1 = A.x * (B.y * C.z - C.y * B.z) + B.x * (C.y * A.z - A.y * C.z) + C.x * (A.y * B.z - B.y * A.z);

    float A2 = y21 * (z22 - z23) + y22 * (z23 - z21) + y23 * (z21 - z22);
    float B2 = z21 * (x22 - x23) + z22 * (x23 - x21) + z23 * (x21 - x22);
    float C2 = x21 * (y22 - y23) + x22 * (y23 - y21) + x23 * (y21 - y22);
    float D2 = x21 * (y22 * z23 - y23 * z22) + x22 * (y23 * z21 - y21 * z23) + x23 * (y21 * z22 - y22 * z21);

    float x = 0.0f;
    float y = 0.0f;
    float z = 0.0f;

    if (moveVector.x != 0)
    {
        y = -(C1 * D2 - D1 * C2) / (C2 * B1 - C1 * B2);
        z = -(D1 * B2 - B1 * D2) / (C2 * B1 - C1 * B2);
    }
    else if (moveVector.z != 0)
    {
        x = -(D1 * B2 - B1 * D2) / (A2 * B1 - A1 * B2);
        y = -(A1 * D2 - D1 * A2) / (A2 * B1 - A1 * B2);
    }

    // get time when we reach point
    float t = l / sqrtf((x - x21) * (x - x21) + (y - y21) * (y - y21) + (z - z21) * (z - z21));

    // fix t acording to direction of moving and start position of vector
    if (curPoint.x >= 0 && curPoint.z >= 0)
    {
        t = (moveVector.x > 0 || (moveVector.x == 0 && moveVector.z > 0)) ? -t : t;
    }
    else if (curPoint.x < 0 && curPoint.z >= 0)
    {
        t = (moveVector.x < 0 || (moveVector.x == 0 && moveVector.z > 0)) ? -t : t;
    }
    else if (curPoint.x >= 0 && curPoint.z < 0)
    {
        t = (moveVector.x > 0 || (moveVector.x == 0 && moveVector.z < 0)) ? -t : t;
    }
    else if (curPoint.x < 0 && curPoint.z < 0)
    {
        t = (moveVector.x < 0 || (moveVector.x == 0 && moveVector.z < 0)) ? -t : t;
    }

    // get final point
    Vector3 ret;
    ret.x = x21 + (x - x21) * t;
    ret.y = y21 + (y - y21) * t;
    ret.z = z21 + (z - z21) * t;
    return ret;
}




float
point_elevation(const float &point_x, const float &point_z,
                const float &x1, const float &y1, const float &z1,
                const float &x2, const float &y2, const float &z2,
                const float &x3, const float &y3, const float &z3)
{
    float A = y1 * (z2 - z3) + y2 * (z3 - z1) + y3 * (z1 - z2);
    float B = z1 * (x2 - x3) + z2 * (x3 - x1) + z3 * (x1 - x2);
    float C = x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2);
    float D = x1 * (y2 * z3 - y3 * z2) + x2 * (y3 * z1 - y1 * z3) + x3 * (y1 * z2 - y2 * z1);

    return (D - C * point_z - A * point_x) / B;
}



bool
line_crossing(Vector3& crossPoint,
              const Vector3& p11, const Vector3& p12, // 1st line coords (our vector)
              const Vector3& p21, const Vector3& p22) // 2nd line coords (triangle side)
{
    float D  = (p12.z - p11.z) * (p21.x - p22.x) - (p21.z - p22.z) * (p12.x - p11.x);
    float D1 = (p12.z - p11.z) * (p21.x - p11.x) - (p21.z - p11.z) * (p12.x - p11.x);
    float D2 = (p21.z - p11.z) * (p21.x - p22.x) - (p21.z - p22.z) * (p21.x - p11.x);

    // if lines are the same
    if ((D == 0) && (D1 == 0) && (D2 == 0))
    {
        return false;
    }

    // if lines are paralel
    if (D == 0)
    {
        return false;
    }

    // find time
    float t1 = D2 / D;
    float t2 = D1 / D;

    // if our line ends on triangle border - we cross the line otherwise not
    // so we check 0 < t1 instead of 0 <= t1
    if ((0 < t1) && (t1 <= 1) && (0 <= t2) && (t2 <= 1))
    {
        crossPoint.x = p11.x + (p12.x - p11.x) * (t1 - 0.01f);
        crossPoint.y = p11.y + (p12.y - p11.y) * (t1 - 0.01f);
        crossPoint.z = p11.z + (p12.z - p11.z) * (t1 - 0.01f);
    }
    else
    {
        return false;
    }

    return true;
}



Vector3
get_projection_on_line(const Vector3& moveVector,
                       const Vector3& sp1, const Vector3& sp2)
{
    Vector2 v(0.0f, 0.0f);
    v.x = sp2.x - sp1.x;
    v.y = sp2.z - sp1.z;
    Vector2Normalize(v, v);

    v *= moveVector.x * v.x + moveVector.z * v.y;
    Vector3 ret(v.x, 0.0f, v.y);
    return ret;
}
