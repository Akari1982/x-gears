/*
 *  $Id: utilites.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include <string.h>
#include "utilites.h"



int
power_of_two(int input)
{
    int value = 1;
    while ( value < input ) value <<= 1;
    return value;
}
