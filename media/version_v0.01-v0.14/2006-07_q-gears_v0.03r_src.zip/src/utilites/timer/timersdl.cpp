/*
 *  $Id: timer.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "timersdl.h"
#include "../logger.h"

#include <SDL/SDL.h>



bool TimerSDL::mTimerInited = false;



void
TimerSDL::InitTimer()
{
    if (mTimerInited == false)
    {
        if (SDL_InitSubSystem(SDL_INIT_TIMER) == -1)
        {
            LOGGER->Log("SDL_INIT_TIMER failed: %s", SDL_GetError());
        }
        else
        {
            mTimerInited = true;
            LOGGER->Log("SDL_INIT_TIMER initialized");
        }
    }
}



void
TimerSDL::QuitTimer()
{
    if (mTimerInited == true)
    {
        mTimerInited = false;
        SDL_QuitSubSystem(SDL_INIT_TIMER);
    }
}



Timer*
MakeTimer()
{
    return new TimerSDL();
}


Timer*
MakeTimer(const unsigned int &seconds)
{
    return new TimerSDL(seconds);
}



TimerSDL::TimerSDL():
    Timer()
{
    InitTimer();
    mSeconds = GetTime();
}



TimerSDL::TimerSDL(const unsigned int &seconds):
    Timer(seconds)
{
}



TimerSDL::~TimerSDL()
{
}



unsigned int
TimerSDL::GetTime()
{
    unsigned int time = 0;

    if (mTimerInited == true)
    {
       time = SDL_GetTicks();
    }

    return time;
}
