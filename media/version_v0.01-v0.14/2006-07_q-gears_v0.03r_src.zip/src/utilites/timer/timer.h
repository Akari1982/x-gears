/*
 *  $Id: timer.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef TIMER_H
#define TIMER_H




#include "../nocopy.h"



class Timer : public NoCopy<Timer>
{
public:
    virtual             ~Timer();

    unsigned int         GetDeltaTime();

protected:
                         Timer();
                         Timer(const unsigned int &seconds);
    virtual unsigned int GetTime() = 0;

public:
    unsigned int mSeconds;
};



Timer* MakeTimer();



Timer* MakeTimer(const unsigned int &seconds);



#endif
