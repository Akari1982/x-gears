/*
 *  $Id: windowsdl.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef WINDOWSDL_H
#define WINDOWSDL_H
// The WindowSDL Class : Implementation of window



#include "window.h"



class WindowSDL : public Window
{
public:
    ~WindowSDL();

    static Window* MakeWindow();

    void SwapBuffers();

    void Update();

private:
    WindowSDL();
};



#endif // WINDOWSDL_H
