/*
 *  $Id: surfaceloadbmp.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef SURFACELOADBMP_H
#define SURFACELOADBMP_H



#include "surfaceload.h"

#include <string>



namespace SurfaceUtils
{
    OpenResult
    LoadBMP(const std::string &file, Surface* &img);
};



#endif
