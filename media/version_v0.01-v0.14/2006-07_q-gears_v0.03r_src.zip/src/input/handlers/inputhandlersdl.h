/*
 *  $Id: inputhandlersdl.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef INPUTHANDLERSDL_H
#define INPUTHANDLERSDL_H



#include "inputhandler.h"



class InputHandlerSDL: public InputHandler
{
public:
     InputHandlerSDL();
    ~InputHandlerSDL();

    void  Update();
};



#endif // INPUTHANDLERSDL_H
