/*
 *  $Id: define.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef DEFINE_H
#define DEFINE_H



#define APPLICATION_NAME "FFVII v0.03c"

#define DEFAULT_LOG      "game.log"
#define DEFAULT_CONFIG   "config.ini"



#endif // DEFINE_H
