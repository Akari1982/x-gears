// $Id: TimFile.h 76 2006-08-25 18:41:20Z crazy_otaku $

/**
 * @brief Class for tim images.
 */

#ifndef TIM_FILE_h
#define TIM_FILE_h

#include "../../common/display/surface/Surface.h"
#include "../../common/utilites/StdString.h"

#include "../filesystem/File.h"



class TimFile : public File
{
public:
// LIFECYCLE

    /**
     * @brief A constructor.
     *
     * Read file from given path into memory.
     * @note after creation in buffer stored unarchived file.
     * @param file - path to file that we want to open.
     */
    explicit TimFile(const RString& file);

    /**
     * @brief A constructor.
     *
     * Create completle copy of given file.
     * @note after creation in buffer stored unarchived file.
     * @param pFile - object that we want to copy.
     */
    explicit TimFile(File* pFile);

    /**
     * @brief A constructor.
     *
     * Create partitial copy of given file.
     * @note after creation in buffer stored unarchived file.
     * @param pFile  - object that we want to copy.
     * @param offset - offset from where we want to copy data.
     * @param length - size of data that we want ot copy.
     */
    TimFile(File* pFile, const u32& offset, const u32& length);

    /**
     * @brief A constructor.
     *
     * Create partitial copy of given buffer.
     * @note after creation in buffer stored unarchived file.
     * @param pBuffer - buffer from which we want to create new file.
     * @param offset  - offset from where we want to copy data.
     * @param length  - size of data that we want ot copy.
     */
    TimFile(u8* pBuffer, const u32& offset, const u32& length);

    /**
     * @brief A destructor.
     */
    virtual ~TimFile(void);

// OPERATIONS

    /**
     * @brief Create surface from tim file with given CLUT index.
     *
     * Create surface from tim file with given CLUT index.
     * @return pointer to new surface object.
     * If some error is occured then NULL pointer will be returned.
     * @warning returned pointer must be deleted to prevent memory leak.
     * @param clutNumber - number of CLUT which you want to use when extracting surface.
     * If value is greater than real number of CLUT in image then NULL pointer is returned.
     */
    Surface* GetSurface(const u32& clutNumber);

// ACCESS

    /**
     * @brief Get number of CLUT in image.
     *
     * @return number of CLUT in image.
     */
    const u32& GetNumberOfClut(void) const;

private:
// OPERATIONS

    /**
     * @brief Set mClutNumber attribute.
     *
     * Get image CLUT numbers and set mClutNumber attribute.
     */
    void InnerGetNumberOfClut(void);

private:
    /**
     * @brief Struct describes first tim header.
     */
    struct TimHeader
    {
        u32 id_tag;           /**< @brief tim id tag */
        u32 id_tag_clut;      /**< @brief tim clut id tag */
        u32 header2_offset;   /**< @brief offset for second header */
        u16 x;                /**< @brief x position of CLUT in VRAM */
        u16 y;                /**< @brief y position of CLUT in VRAM */
        u16 number_of_colors; /**< @brief number of colors in CLUT */
        u16 number_of_clut;   /**< @brief number of CLUT */
    };

    /**
     * @brief Struct describes second tim header.
     */
    struct TimHeader2
    {
        u32 data_size;        /**< @brief size of image data */
        u16 x;                /**< @brief x position of image in VRAM */
        u16 y;                /**< @brief y position of image in VRAM */
        u16 width;            /**< @brief width of image (width in VRAM) */
        u16 height;           /**< @brief height of image */
    };

    /**
     * @brief Struct for CLUT colors.
     */
    struct Clut
    {
        u8 r;                 /**< @brief red color in CLUT */
        u8 g;                 /**< @brief green color in CLUT */
        u8 b;                 /**< @brief blue color in CLUT */
        u8 a;                 /**< @brief alpha in CLUT */
    };

    u32 mClutNumber; /**< @brief number of CLUT in image */
};



#endif
