// $Id: HrcFile.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "../../../common/utilites/Logger.h"

#include "HrcFile.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

HrcFile::HrcFile(const RString& file):
    File(file)
{
}



HrcFile::HrcFile(File* pFile):
    File(pFile)
{
}



HrcFile::HrcFile(File* pFile, const u32& offset, const u32& length):
    File(pFile, offset, length)
{
}



HrcFile::HrcFile(u8* pBuffer, const u32& offset, const u32& length):
    File(pBuffer, offset, length)
{
}



HrcFile::~HrcFile(void)
{
}



//============================= OPERATIONS ===================================

void
HrcFile::GetHierarchy(HrcArray& hrc)
{
    hrc.clear();

    for (u16 i = 0; GetU32LE(i) != 0xFFFEFFFE; i += 0x04)
    {
        hrc.push_back(std::make_pair(GetU16LE(i), GetU16LE(i + 0x02)));
    }
}
