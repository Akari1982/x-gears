// $Id: ModuleManager.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "ModuleManager.h"
#include "Module.h"
#include "Splash.h"
#include "../display/Display.h"
#include "../utilites/Utilites.h"
#include "../utilites/Logger.h"



ModuleManager* MODULEMAN = NULL;



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

ModuleManager::ModuleManager(void)
{
    Splash* module = new Splash();
    PushModule(module);
}



ModuleManager::~ModuleManager(void)
{
    for (int i = 0; i < mModulesToDelete.size(); ++i)
    {
        delete mModulesToDelete[i];
    }

    for (int i = 0; i < mModules.size(); ++i)
    {
        delete mModules[i];
    }
}



//============================= OPERATIONS ===================================

void
ModuleManager::Draw(void)
{
    DISPLAY->BeginFrame();

    for (int i = 0; i < mModules.size(); ++i)
    {
        mModules[i]->Draw();
    }

    DISPLAY->EndFrame();
}



void
ModuleManager::Input(const InputEvent& input)
{
    if (!mModules.size())
    {
        return;
    }
    mModules[mModules.size() - 1]->Input(input);
}



void
ModuleManager::Update(const u32& deltaTime)
{
    for (int i = 0; i < mModulesToDelete.size(); ++i)
    {
        delete mModulesToDelete[i];
    }
    mModulesToDelete.clear();

    for (int i = 0; i < mModules.size(); ++i)
    {
        mModules[i]->Update(deltaTime);
    }
}



void
ModuleManager::PushModule(Module* pModule)
{
    mModules.push_back(pModule);
}



void
ModuleManager::PopTopModule(void)
{
    if (mModules.size() > 0)
    {
        mModulesToDelete.push_back(mModules[mModules.size() - 1]);
        mModules.pop_back();
    }
}
