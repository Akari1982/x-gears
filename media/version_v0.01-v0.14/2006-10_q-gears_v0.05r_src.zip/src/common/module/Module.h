// $Id: Module.h 76 2006-08-25 18:41:20Z crazy_otaku $
/**
 * @brief Module abstract class.
 */

#ifndef MODULE_h
#define MODULE_h

#include "../TypeDefine.h"
#include "../input/InputFilter.h"
#include "../utilites/NoCopy.h"



class Module : public NoCopy<Module>
{
public:
// LIFECYCLE

    /**
     * @brief Default constructor.
     */
    Module(void);

    /**
     * @brief Default destructor.
     */
    virtual ~Module(void);

// OPERATIONS

    /**
     * @brief Init module.
     *
     * Implementation of this method init module start data.
     */
    virtual void Init(void) = 0;

    /**
     * @brief Draw module.
     *
     * Implementation of this method draw module data.
     */
    virtual void Draw(void) = 0;

    /**
     * @brief Handles input.
     *
     * Implementation of this method handles input data.
     * @param input - single input event.
     */
    virtual void Input(const InputEvent& input) = 0;

    /**
     * @brief Handles update.
     *
     * Implementation of this method handles update data with sertain amount of time.
     * @param deltaTime - time passed from last call.
     */
    virtual void Update(const u32& deltaTime) = 0;
};



#endif // MODULE_h
