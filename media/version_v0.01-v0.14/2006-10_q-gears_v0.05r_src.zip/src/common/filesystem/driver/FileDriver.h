// $Id: FileDriver.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef FILEDRIVER_H
#define FILEDRIVER_H


#include "../../utilites/NoCopy.h"
#include "../../utilites/StdString.h"




class FileDriver : NoCopy<FileDriver>
{
public:
             FileDriver();
    virtual ~FileDriver();

    virtual unsigned int GetFileSize(const RString &path) = 0;
    virtual bool         ReadFile(const RString &path, const void* buffer, const unsigned int start, const unsigned int length) = 0;
};



#endif // FILEDRIVER_H
