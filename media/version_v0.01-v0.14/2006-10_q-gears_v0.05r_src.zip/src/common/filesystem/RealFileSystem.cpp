// $Id: RealFileSystem.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "RealFileSystem.h"
#include "../utilites/Logger.h"

#include <stdio.h>



RealFileSystem *REALFILESYSTEM = NULL;



RealFileSystem::RealFileSystem()
{
}



RealFileSystem::~RealFileSystem()
{
}



unsigned int
RealFileSystem::GetFileSize(const RString &path)
{
    FILE* file = fopen(path.c_str(), "rb");

    if (file == NULL)
    {
        LOGGER->Log("Can't open file %s", path.c_str());
        return 0;
    }

    // set cursor to end of file
    fseek(file, 0, SEEK_END);
    unsigned int size = ftell(file);
    fclose(file);
    return size;
}



bool
RealFileSystem::ReadFile(const RString &path, const void* buffer, const unsigned int start, const unsigned int length)
{
    FILE* file = fopen(path.c_str(), "rb");

    if (file == NULL)
    {
        LOGGER->Log("Can't open file %s", path.c_str());
        return false;
    }

    fseek(file, start, SEEK_SET);
    fread(const_cast<void*>(buffer), sizeof(char), length, file);
    fclose(file);

    return true;
}



bool
RealFileSystem::WriteFile(const RString &path, const void* buffer, const unsigned int length)
{
    FILE* file = fopen(path.c_str(), "ab");

    if (file == NULL)
    {
        return false;
    }

    fwrite(buffer, sizeof(char), length, file);
    fclose(file);

    return true;
}



bool
RealFileSystem::WriteNewFile(const RString &path, const void* buffer, unsigned int length)
{
    RemoveFile(path);
    return !!(WriteFile(path, buffer, length));
}



bool
RealFileSystem::RemoveFile(const RString &path)
{
    return (remove(path.c_str()) == 0);
}
