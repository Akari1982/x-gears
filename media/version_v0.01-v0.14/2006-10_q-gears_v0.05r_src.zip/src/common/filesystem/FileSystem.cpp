// $Id: FileSystem.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "FileSystem.h"



FileSystem::FileSystem()
{
}



FileSystem::~FileSystem()
{
}
