// $Id: Math.h 83 2006-10-08 06:55:30Z crazy_otaku $

#ifndef MATH_H
#define MATH_H

#include "../display/3dTypes.h"

#include <math.h>



float   point_elevation(const Vector3& point, const Vector3& A, const Vector3& B, const Vector3& C);



bool    line_crossing(const Vector3& p11, const Vector3& p12, const Vector3& p21, const Vector3& p22);



Vector3 get_projection_on_line(const Vector3& moveVector, const Vector3& sp1, const Vector3& sp2);



#endif // MATH_H
