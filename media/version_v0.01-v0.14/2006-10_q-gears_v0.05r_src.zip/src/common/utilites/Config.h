// $Id: Config.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef CONFIG_H
#define CONFIG_H
// The Config Class : Implements basic config file



#include "NoCopy.h"
#include "StdString.h"
#include <string>



class Config : public NoCopy<Config>
{
public:
    Config();

    virtual ~Config();

    void ReadConfig(const std::string &file);

public:
    // Debug:
    bool    mDumpSpecificGameData;

    RString mField;
    RString mGameCD;
};



extern Config* CONFIG; // global and accessable from anywhere in our program



#endif // CONFIG_H
