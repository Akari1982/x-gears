// $Id: Timer.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "Timer.h"



Timer::Timer()
{
}



Timer::Timer(const unsigned int &seconds):
    mSeconds(seconds)
{
}



Timer::~Timer()
{
}



unsigned int
Timer::GetDeltaTime()
{
    Timer* now = MakeTimer();
    unsigned int diff = now->mSeconds - mSeconds;
    mSeconds = now->mSeconds;
    delete now;
    return diff;
}
