// $Id: Timer.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef TIMER_H
#define TIMER_H



#include "../NoCopy.h"



class Timer : public NoCopy<Timer>
{
public:
    virtual             ~Timer();

    unsigned int         GetDeltaTime();

protected:
                         Timer();
                         Timer(const unsigned int &seconds);
    virtual unsigned int GetTime() = 0;

public:
    unsigned int mSeconds;
};



Timer* MakeTimer();



Timer* MakeTimer(const unsigned int &seconds);



#endif
