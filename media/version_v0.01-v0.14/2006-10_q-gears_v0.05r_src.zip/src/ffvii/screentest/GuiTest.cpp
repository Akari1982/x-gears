// $Id: GuiTest.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "GuiTest.h"
#include "../kernel/Kernel.h"
#include "../kernel/Kernel.h"
#include "../kernel/gui/FFVIIString.h"
#include "../kernel/gui/GuiPointer.h"
#include "../../common/module/ModuleManager.h"
#include "../../common/utilites/Logger.h"



GuiTest::GuiTest()
{
    Init();
}



GuiTest::~GuiTest()
{
}



void
GuiTest::Init()
{
    mPointerPos  = 1;
    mTotalPos    = 3;
    mStartY      = 35;
    mPointerType = TO_RIGHT;

    mTest1       = false;
    mTimer       = 0;

    mTest3First  = 0;
    mTest3Cur    = 0;
    mTest3Last   = 18;

    unsigned char rawData[210] = {
        0xB2, 0x33, 0x4F, 0x4D, 0x45, 0x00, 0x33, 0x48, 0x49, 0x4E, 0x52, 0x41, 0x00, 0x53, 0x4F, 0x4C, 
        0x44, 0x49, 0x45, 0x52, 0x53, 0x00, 0x57, 0x45, 0x4E, 0x54, 0x00, 0x55, 0x50, 0x00, 0x54, 0x4F, 
        0x00, 0x2D, 0x54, 0x0E, 0x00, 0x23, 0x4F, 0x52, 0x45, 0x4C, 0x0E, 0xE7, 0xE1, 0x34, 0x48, 0x45, 
        0x59, 0x00, 0x53, 0x41, 0x49, 0x44, 0x00, 0x54, 0x48, 0x45, 0x59, 0x07, 0x52, 0x45, 0x00, 0x43, 
        0x4F, 0x4C, 0x4C, 0x45, 0x43, 0x54, 0x49, 0x4E, 0x47, 0x00, 0x28, 0x55, 0x47, 0x45, 0x00, 0x2D, 
        0x41, 0x54, 0x45, 0x52, 0x49, 0x41, 0xE7, 0xE1, 0x54, 0x4F, 0x00, 0x42, 0x4C, 0x4F, 0x57, 0x00, 
        0x55, 0x50, 0x00, 0x2D, 0x45, 0x54, 0x45, 0x4F, 0x52, 0x01, 0xB3, 0xE8, 0xB2, 0x39, 0x41, 0x00, 
        0x54, 0x48, 0x49, 0x4E, 0x4B, 0x00, 0x54, 0x48, 0x45, 0x59, 0x00, 0x43, 0x41, 0x4E, 0x00, 0x52, 
        0x45, 0x41, 0x4C, 0x4C, 0x59, 0x00, 0x44, 0x4F, 0x00, 0x49, 0x54, 0x1F, 0xE7, 0xE1, 0x29, 0x07, 
        0x4C, 0x4C, 0x00, 0x42, 0x45, 0x54, 0x00, 0x54, 0x48, 0x45, 0x00, 0x52, 0x45, 0x41, 0x43, 0x54, 
        0x4F, 0x52, 0x00, 0x44, 0x45, 0x53, 0x54, 0x52, 0x4F, 0x59, 0x53, 0x00, 0x45, 0x56, 0x45, 0x52, 
        0x59, 0x54, 0x48, 0x49, 0x4E, 0x47, 0xE7, 0xE1, 0x45, 0x56, 0x45, 0x4E, 0x00, 0x42, 0x45, 0x46, 
        0x4F, 0x52, 0x45, 0x00, 0x2D, 0x45, 0x54, 0x45, 0x4F, 0x52, 0x00, 0x48, 0x49, 0x54, 0x53, 0x01, 
        0xB3, 0xFF,
    };

    mFFString.resize(210);
    std::copy(&rawData[0], &rawData[210], mFFString.begin());
}



void
GuiTest::Input(const InputEvent &input)
{
    switch (input.button)
    {
        case KEY_Cz:
        {
            MODULEMAN->PopTopModule();
            break;
        }
        case KEY_UP:
        {
            if (input.type == IET_FIRST_PRESS && mPointerPos > 1)
            {
                mPointerPos--;
            }
            break;
        }
        case KEY_DOWN:
        {
            if (input.type == IET_FIRST_PRESS && mPointerPos < mTotalPos)
            {
                mPointerPos++;
            }
            break;
        }
        case KEY_LEFT:
        {
            if (input.type != IET_FIRST_PRESS)
            {
                break;
            }

            switch (mPointerPos)
            {
                case 1 : mTest1 = true;                                   break;
                case 3 : mTest3Cur -= (mTest3Cur == mTest3First) ? 0 : 1; break;
            }
            break;
        }
        case KEY_RIGHT:
        {
            if (input.type != IET_FIRST_PRESS)
            {
                break;
            }

            switch (mPointerPos)
            {
                case 1 : mTest1 = false;                                  break;
                case 3 : mTest3Cur += (mTest3Cur == mTest3Last) ? 0 : 1;  break;
            }
            break;
        }
    }
}



void
GuiTest::Update(const u32& delta_time)
{
    if (mTest1 != false)
    {
        mTimer += delta_time;
    }



    if (mPointerPos == 2 && mPointerType != TO_RIGHT_CROSS)
    {
        mPointerType = TO_RIGHT_CROSS;
    }
    else
    {
        mPointerType = TO_RIGHT;
    }
}



void
GuiTest::Draw()
{
    KERNEL->DrawWindow(10, 2, 195, 23, false);
    KERNEL->DrawString(RStringToFFVIIString("Testing example of FFVII GUI."), 20, 9, F_WHITE);

    KERNEL->DrawWindow(10, 25, 195, 125, false);
    KERNEL->DrawPointer(20, mStartY + (mPointerPos - 1) * 20, mPointerType);



    // TEST1
    KERNEL->DrawString(RStringToFFVIIString("Test1"), 50, mStartY, F_BLUE);
    FontColor color1, color2;
    if (mTest1 == false)
    {
        color1 = F_GRAY;
        color2 = F_WHITE;
    }
    else
    {
        color1 = F_WHITE;
        color2 = F_GRAY;
    }
    KERNEL->DrawString(RStringToFFVIIString("True"), 120, mStartY, color1);
    KERNEL->DrawString(RStringToFFVIIString("False"), 160, mStartY, color2);
    // Timer
    RString timer_string;
    timer_string.Format("%04d:%02d", (mTimer / 1000) / 60, (mTimer / 1000) % 60);
    KERNEL->DrawCounter(20, 160, timer_string);



    // TEST2
    KERNEL->DrawString(RStringToFFVIIString("Test2"), 50, mStartY + 20, F_BLUE);



    // TEST3
    KERNEL->DrawString(RStringToFFVIIString("Test3"), 50, mStartY + 40, F_BLUE);
    for (int i = mTest3First; i <= mTest3Last; ++i)
    {
        RString string;
        string.Format("%d", i);

        if (i == mTest3Cur)
        {
            KERNEL->DrawString(RStringToFFVIIString(string), 120 + (i % 4) * 20, mStartY + 40 + (i / 4) * 15, F_WHITE);
        }
        else
        {
            KERNEL->DrawString(RStringToFFVIIString(string), 120 + (i % 4) * 20, mStartY + 40 + (i / 4) * 15, F_GRAY);
        }
    }
    RString header = "";
    // draw string itself
    switch (mTest3Cur)
    {
        case 1:
        {
            header = "Command Description";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfCommandDescriptions() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfCommandDescriptions(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetCommandDescription(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 2:
        {
            header = "Magic Description";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfMagicDescriptions() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfMagicDescriptions(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetMagicDescription(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 3:
        {
            header = "Item Description";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfItemDescriptions() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfItemDescriptions(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetItemDescription(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 4:
        {
            header = "Weapon Description";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfWeaponDescriptions() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfWeaponDescriptions(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetWeaponDescription(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 5:
        {
            header = "Armor Description";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfArmorDescriptions() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfArmorDescriptions(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetArmorDescription(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 6:
        {
            header = "Accessory Description";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfAccessoryDescriptions() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfAccessoryDescriptions(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetAccessoryDescription(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 7:
        {
            header = "Materia Description";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfMateriaDescriptions() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfMateriaDescriptions(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetMateriaDescription(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 8:
        {
            header = "Key Item Description";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfKeyItemDescriptions() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfKeyItemDescriptions(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetKeyItemDescription(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 9:
        {
            header = "Command Name";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfCommandNames() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfCommandNames(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetCommandName(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 10:
        {
            header = "Magic Name";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfMagicNames() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfMagicNames(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetMagicName(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 11:
        {
            header = "Item Name";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfItemNames() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfItemNames(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetItemName(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 12:
        {
            header = "Weapon Name";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfWeaponNames() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfWeaponNames(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetWeaponName(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 13:
        {
            header = "Armor Name";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfArmorNames() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfArmorNames(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetArmorName(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 14:
        {
            header = "Accessory Name";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfAccessoryNames() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfAccessoryNames(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetAccessoryName(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 15:
        {
            header = "Materia Name";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfMateriaNames() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfMateriaNames(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetMateriaName(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 16:
        {
            header = "Key Item Name";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfKeyItemNames() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfKeyItemNames(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetKeyItemName(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 17:
        {
            header = "Battle Text";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfBattleTexts() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfBattleTexts(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetBattleText(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;

        case 18:
        {
            header = "Summon Name";
            KERNEL->DrawWindow(270, 25, 350, 20 + KERNEL->GetDatabase().GetSizeOfSummonNames() * 12, false);
            for (int i = 0; i < KERNEL->GetDatabase().GetSizeOfSummonNames(); ++i)
            {
                RString number;
                number.Format("%02d", i);
                KERNEL->DrawString(RStringToFFVIIString(number), 280, 35 + i * 12, F_WHITE);
                KERNEL->DrawString(KERNEL->GetDatabase().GetSummonName(i), 300, 35 + i * 12, F_WHITE);
            }
        }
        break;
    }
    if (mTest3Cur != 0)
    {
        // draw header
        KERNEL->DrawWindow(270, 2, 350, 23, false);
        KERNEL->DrawString(RStringToFFVIIString(header), 280, 9, F_WHITE);
    }



    // testing real ffvii string
    KERNEL->DrawString(mFFString, 20, 190, F_WHITE);
}
