// $Id: DisplayTest.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef SCREENDISPLAYTEST_H
#define SCREENDISPLAYTEST_H

#include "../../common/TypeDefine.h"
#include "../../common/module/Module.h"
#include "../../common/display/3dTypes.h"

#include <vector>



class ScreenDisplayTest : public Module
{
public:
    ScreenDisplayTest();
    virtual ~ScreenDisplayTest();

    virtual void Init();

    virtual void Input(const InputEvent &input);

    virtual void Update(const u32& delta_time);

    virtual void Draw();

private:
    int mRotation;
    int mTexId;

    std::vector<Vertex> mPoints;
    TotalGeometry mPyramid;
    std::vector<Vertex> mQuadsTex;
};



#endif // SCREENDISPLAYTEST_H
