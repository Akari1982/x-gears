// $Id$

#include "../../common/display/Display.h"
#include "../../common/utilites/Logger.h"
#include "../../common/utilites/Math.h"

#include "UnitManager.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

UnitManager::UnitManager(FieldModule* pFieldModule):
    mpFieldModule(pFieldModule),
    mMoveForward(false),
    mMoveBack(false),
    mMoveLeft(false),
    mMoveRight(false)
{
///////////////////////////////////////
    // to be remove
    Model* model = new Model();
    mTempMainUnit.model = model;
    mTempMainUnit.visible = true;

    Trigger trigger;
    trigger.point1 = Vector3(200.0f, 0.0f, 100.0f);
    trigger.point2 = Vector3(50.0f, 0.0f, -100.0f);
    mTriggers.push_back(trigger);

    Vertex v;
    v.c.r = 0.0f; v.c.g = 1.0f; v.c.b = 1.0f; v.c.a = 1.0f;
    v.p = trigger.point1;
    mTriggersView.push_back(v);
    v.p = trigger.point2;
    mTriggersView.push_back(v);
//////////////////////////////////////

}



UnitManager::~UnitManager(void)
{
///////////////////////////////////////
    // to be remove
    delete mTempMainUnit.model;
///////////////////////////////////////
    Clear();
}



//============================= OPERATIONS ===================================

void
UnitManager::Clear(void)
{
    // clear character
    for (u8 i = 0; i < mUnits.size(); ++i)
    {
        delete mUnits[i].model;
    }
    mUnits.clear();

///////////////////////////////////////
    // to be remove
    mTempMainUnit.triangle = 0;
///////////////////////////////////////

    // clear walkmesh data
    mWalkMesh.clear();
    mAccess.clear();
    mAccessPool.clear();
    mTriggers.clear();
//    mTriggersView.clear();
}



void
UnitManager::Draw(void)
{
    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->SetLineWidth(1);
    DISPLAY->DrawTriangles(mWalkMesh);
    DISPLAY->SetPolygonMode(POLYGON_FILL);
    DISPLAY->SetLineWidth(2);
    DISPLAY->DrawLines(mAccess);

    // draw character
    for (u8 i = 0; i < mUnits.size(); ++i)
    {
        if (mUnits[i].visible == true)
        {
            DISPLAY->PushMatrix();
            DISPLAY->Translate(mUnits[i].position.x, mUnits[i].position.y, mUnits[i].position.z);
            DISPLAY->RotateY(360 * mUnits[i].direction / 255);
            mUnits[i].model->DrawModel();
            DISPLAY->PopMatrix();
        }
    }



    // draw triggers
    DISPLAY->PushMatrix();
    DISPLAY->SetLineWidth(3);
    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->DrawLines(mTriggersView);
    DISPLAY->SetPolygonMode(POLYGON_FILL);
    DISPLAY->PopMatrix();



///////////////////////////////////////
    // to be remove
    DISPLAY->PushMatrix();
    DISPLAY->Translate(mTempMainUnit.position.x, mTempMainUnit.position.y, mTempMainUnit.position.z);
    DISPLAY->RotateY(360 * mTempMainUnit.direction / 255);
    mTempMainUnit.model->DrawModel();
    DISPLAY->PopMatrix();
///////////////////////////////////////
}



bool
UnitManager::Input(const InputEvent &input)
{
    bool ret = false;

    // handle left input ourself
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_UP:    mMoveForward = true; ret = true; break;
            case KEY_DOWN:  mMoveBack    = true; ret = true; break;
            case KEY_LEFT:  mMoveRight   = true; ret = true; break;
            case KEY_RIGHT: mMoveLeft    = true; ret = true; break;
        }
    }

    if (input.type == IET_RELEASE)
    {
        switch (input.button)
        {
            case KEY_UP:    mMoveForward = false; ret = true; break;
            case KEY_DOWN:  mMoveBack    = false; ret = true; break;
            case KEY_LEFT:  mMoveRight   = false; ret = true; break;
            case KEY_RIGHT: mMoveLeft    = false; ret = true; break;
        }
    }

    return ret;
}



void
UnitManager::Update(const u32& deltaTime)
{
    static float step = 5.0f;
    Vector3 next_step(0.0f, 0.0f, 0.0f);

    if (mMoveForward)
    {
        next_step.z =  step;
    }

    if (mMoveBack)
    {
        next_step.z = -step;
    }

    if (mMoveLeft)
    {
        next_step.x =  step;
    }

    if (mMoveRight)
    {
        next_step.x = -step;
    }

    SetNextStep(next_step, false);
    CheckTriggers();
}



void
UnitManager::AddWalkmeshVertex(const Vertex& v)
{
    mWalkMesh.push_back(v);
}



void
UnitManager::AddAccessPool(const AccessPool& accessPool)
{
    mAccessPool.push_back(accessPool);
}



void
UnitManager::AddAccessVertex(const Vertex& v)
{
    mAccess.push_back(v);
}



const s8
UnitManager::AddChar(const u8& characterId)
{
    UnitData unit;

    Model* model = new Model();
    unit.model = model;

    mUnits.push_back(unit);

    return mUnits.size() - 1;
}



void
UnitManager::SetXYCoords(const s8& unitId, const float& x, const float& y)
{
    if (unitId < 0 || unitId >= mUnits.size() || mUnits[unitId].position_set == true)
    {
        return;
    }

    mUnits[unitId].position.x = x;
    mUnits[unitId].position.y = y;
}



void
UnitManager::SetZCoords(const s8& unitId, const float& z)
{
    if (unitId < 0 || unitId >= mUnits.size() || mUnits[unitId].position_set == true)
    {
        return;
    }

    mUnits[unitId].position.z = z;
}



void
UnitManager::SetTriangle(const s8& unitId, const u16& triangle)
{
    if (unitId < 0 || unitId >= mUnits.size() || mUnits[unitId].position_set == true)
    {
        return;
    }

    mUnits[unitId].triangle = triangle;
}



void
UnitManager::SetPosition(const s8& unitId)
{
    if (unitId < 0 || unitId >= mUnits.size() || mUnits[unitId].position_set == true)
    {
        return;
    }

    // fix unit position
    mUnits[unitId].position_set = true;

    // show it on map
    mUnits[unitId].visible = true;
}



void
UnitManager::SetDirection(const s8& unitId, const u8& direction)
{
    if (unitId < 0 || unitId >= mUnits.size())
    {
        return;
    }

    mUnits[unitId].direction = direction;
}



void
UnitManager::SetWalkMeshCoords(const u16& triangleIndex)
{
    Vector3 coords;

    float x1 = mWalkMesh[triangleIndex * 3 + 0].p.x;
    float y1 = mWalkMesh[triangleIndex * 3 + 0].p.y;
    float z1 = mWalkMesh[triangleIndex * 3 + 0].p.z;

    float x2 = mWalkMesh[triangleIndex * 3 + 1].p.x;
    float y2 = mWalkMesh[triangleIndex * 3 + 1].p.y;
    float z2 = mWalkMesh[triangleIndex * 3 + 1].p.z;

    float x3 = mWalkMesh[triangleIndex * 3 + 2].p.x;
    float y3 = mWalkMesh[triangleIndex * 3 + 2].p.y;
    float z3 = mWalkMesh[triangleIndex * 3 + 2].p.z;

    // get points of line that crosses in center of triangle
    float xc1 = x1 + (x2 - x1) * 0.5f;
    float zc1 = z1 + (z2 - z1) * 0.5f;

    float xc2 = x1 + (x3 - x1) * 0.5f;
    float zc2 = z1 + (z3 - z1) * 0.5f;

    // find coords of point in center of triangle
    float t = ((zc1 - zc2) * (x2 - xc1) - (xc1 - xc2) * (z2 - zc1)) / (( x3 - xc1) * (z2 - zc2) - ( z3 - zc1) * (x2 - xc2));

    float x = xc1 + (x3 - xc1) * t;
    float z = zc1 + (z3 - zc1) * t;

    coords.x = x;
    coords.y = point_elevation(Vector3(x, 0, z), Vector3(x1 , y1, z1), Vector3(x2, y2, z2), Vector3(x3, y3, z3));
    coords.z = z;

    mTempMainUnit.position = coords;
}



void
UnitManager::SetNextStep(const Vector3& moveVector, const bool slide)
{
    // if we are not moving anywhere
    if (moveVector.x == 0.0f && moveVector.y == 0.0f && moveVector.z == 0.0f)
    {
        return;
    }



    u16 triangle = mTempMainUnit.triangle;
    u16 prev_triangle = 0xFFFE; // number of triangles never must be such great

    Vector3 start_point = mTempMainUnit.position;
    Vector3 end_point(mTempMainUnit.position.x + moveVector.x,
                      mTempMainUnit.position.y + moveVector.y,
                      mTempMainUnit.position.z + moveVector.z);

    for (;;)
    {
        Vector3 A(mWalkMesh[triangle * 3 + 0].p.x, mWalkMesh[triangle * 3 + 0].p.y, mWalkMesh[triangle * 3 + 0].p.z);
        Vector3 B(mWalkMesh[triangle * 3 + 1].p.x, mWalkMesh[triangle * 3 + 1].p.y, mWalkMesh[triangle * 3 + 1].p.z);
        Vector3 C(mWalkMesh[triangle * 3 + 2].p.x, mWalkMesh[triangle * 3 + 2].p.y, mWalkMesh[triangle * 3 + 2].p.z);

        // check if we cross board of current triangle
        u8 cross = 0x00;
        // if we cross line 1
        if      (line_crossing(start_point, end_point, A, B) == true && mAccessPool[triangle].access[0] != prev_triangle)
        {
            cross = 0x01;
        }
        // if we cross line 2
        else if (line_crossing(start_point, end_point, B, C) == true && mAccessPool[triangle].access[1] != prev_triangle)
        {
            cross = 0x02;
        }
        // if we cross line 3
        else if (line_crossing(start_point, end_point, A, C) == true && mAccessPool[triangle].access[2] != prev_triangle)
        {
            cross = 0x03;
        }

        // if we do not cross border
        if (cross == 0x00)
        {
            end_point.y = point_elevation(end_point, A, B, C);
            mTempMainUnit.triangle = triangle;
            LOGGER->Log("final triangle = %d", triangle);
            mTempMainUnit.position = end_point;
            break;
        }
        else
        {
            // if board can be crossed
            if (mAccessPool[triangle].access[cross - 1] != 0xFFFF)
            {
                prev_triangle = triangle;
                triangle      = mAccessPool[triangle].access[cross - 1];
                LOGGER->Log("cross = %d, prev_triangle = %d, triangle = %d", cross, prev_triangle, triangle);
            }
            else
            {
                if (slide == false)
                {
                    Vector3 sp1 = (cross == 1 || cross == 3) ? A : B;
                    Vector3 sp2 = (cross == 1) ? B : C;

//                    LOGGER->Log("we met border");
                    Vector3 new_move = get_projection_on_line(moveVector, sp1, sp2);
                    SetNextStep(new_move, true);
//                    LOGGER->Log("we slide");
                }
                else
                {
//                    LOGGER->Log("we met border");
//                    LOGGER->Log("we can't slide");
                }

                break;
            }
        }
    }
}



void
UnitManager::CheckTriggers(void)
{
}
