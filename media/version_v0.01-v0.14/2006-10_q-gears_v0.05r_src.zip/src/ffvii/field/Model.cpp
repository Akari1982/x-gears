// $Id: Model.cpp 83 2006-10-08 06:55:30Z crazy_otaku $

#include "../../common/display/Display.h"

#include "Model.h"



Model::Model()
{
    Vertex point;
    point.p.x = -1.0f; point.p.y =  0.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  0.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  0.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x = -1.0f; point.p.y =  0.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);

    point.p.x = -1.0f; point.p.y =  3.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  3.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  3.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x = -1.0f; point.p.y =  3.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);

    point.p.x = -1.0f; point.p.y =  3.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  3.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  0.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x = -1.0f; point.p.y =  0.0f; point.p.z =  1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);

    point.p.x = -1.0f; point.p.y =  3.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  3.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  1.0f; point.p.y =  0.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x = -1.0f; point.p.y =  0.0f; point.p.z = -1.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);

    // direction line
    point.p.x =  0.0f; point.p.y =  0.0f; point.p.z =  0.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  0.0f; point.p.y =  3.0f; point.p.z =  0.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  0.0f; point.p.y =  3.0f; point.p.z = -3.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
    point.p.x =  0.0f; point.p.y =  0.0f; point.p.z = -3.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 1.0f;
    mDefaultGeom.push_back(point);
}



Model::~Model()
{
}



void
Model::DrawModel()
{
    DISPLAY->PushMatrix();
    DISPLAY->Scale(30.0f, 30.0f, 30.0f);
    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->SetLineWidth(2);
    DISPLAY->DrawQuads(mDefaultGeom);
    DISPLAY->SetPolygonMode(POLYGON_FILL);
    DISPLAY->PopMatrix();
}
