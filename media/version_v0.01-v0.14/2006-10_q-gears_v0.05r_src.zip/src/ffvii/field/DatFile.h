// $Id: DatFile.h 82 2006-09-30 06:46:19Z crazy_otaku $

#ifndef DATFILE_H
#define DATFILE_H

#include <vector>

#include "../../common/display/3dTypes.h"
#include "../../common/display/math/Matrix.h"
#include "../../common/utilites/StdString.h"

#include "UnitManager.h"
#include "WindowManager.h"
#include "script/ScriptManager.h"
#include "../filetypes/LzsFile.h"
#include "../filesystem/File.h"



class DatFile : public LzsFile
{
public:
    explicit DatFile(const RString &file);
    explicit DatFile(File* file);
    DatFile(File* file, const u32 &offset, const u32 &length);
    DatFile(u8* buffer, const u32 &offset, const u32 &length);
    virtual ~DatFile();

    void GetScripts(ScriptManager* scriptManager);
    void GetDialogs(WindowManager* windowManager);
    void GetWalkMesh(UnitManager* unitManager);
    void GetCameraMatrix(Matrix &camera);
};



#endif // DATFILE_H
