// $Id$

#include <libxml/tree.h>

#include "../../common/display/Display.h"
#include "../../common/filesystem/RealFileSystem.h"
#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "DatFile.h"
#include "FieldModule.h"
#include "FieldUtilites.h"
#include "script/Entity.h"
#include "script/Script.h"
#include "../kernel/Kernel.h"



#define READ_PROP(node, prop, name, target, cast) \
        prop = xmlGetProp(node, BAD_CAST name); \
        if (prop) { \
            target = cast((const char*)prop); \
            xmlFree(prop); \
        }



FieldModule::FieldModule():
    mRequestedMapId(0),

    mViewAxis(true),
    mViewFromCamera(true)
{
    mpScriptManager = new ScriptManager(this);
    mpUnitManager   = new UnitManager(this);
    mpWindowManager = new WindowManager(this);

    Init();
}



FieldModule::~FieldModule()
{
    delete mpScriptManager;
    delete mpUnitManager;
    delete mpWindowManager;
}



void
FieldModule::Init()
{
    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
    DISPLAY->SetAlphaTest(true);
    DISPLAY->SetBlendMode(BLEND_NORMAL);
    DISPLAY->SetCullMode(CULL_NONE);

    Vertex point;
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 0.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 500.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 0.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 1.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 500.0f; point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 1.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 0.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 500.0f;
    point.c.r = 0.0f;   point.c.g = 0.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    mAxis.push_back(point);



    // load init map
    LoadMap(0x41);
}



void
FieldModule::LoadMap(const u16& id)
{
    // check if this is field file (not worldmap)
    if (id < 0x41)
    {
        LOGGER->Log("Tried to load worldmap with mapId = %04x.", id);
        return;
    }



    // read info from DAT file
    DatFile* dat = new DatFile("data/FIELD/" + MapIdToRString(id) + ".DAT");

    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log("Load field %s", dat->GetFileName().c_str());
    }



    u8 dialogs = 0;
    u8 entitys = 0;

    // try to find xml file of this field
    RString xml_file_name = "data/FIELD/" + MapIdToRString(id) + ".xml";

    u32 buffer_size = REALFILESYSTEM->GetFileSize(xml_file_name);
    // if it exist read properties
    if (buffer_size > 0)
    {
        u8* p_buffer = (u8*)malloc(sizeof(u8) * buffer_size);
        REALFILESYSTEM->ReadFile(xml_file_name, p_buffer, 0, buffer_size);

        xmlDocPtr doc = xmlParseMemory((const char*)p_buffer, buffer_size);

        xmlNodePtr node = xmlDocGetRootElement(doc);

        if (!node || !xmlStrEqual(node->name, BAD_CAST "field"))
        {
            LOGGER->Log("Field XML Manager: %s is not a valid field file! No <field> in root.\n", xml_file_name.c_str());
        }
        else
        {
            xmlChar* prop = NULL;
            READ_PROP(node, prop, "dialogs", dialogs, atoi);
            READ_PROP(node, prop, "entitys", entitys, atoi);

            for (node = node->xmlChildrenNode; node != NULL; node = node->next)
            {
                // load dialogs from xml
                if (dialogs && xmlStrEqual(node->name, BAD_CAST "dialogs"))
                {
                    mpWindowManager->Clear();

                    for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                    {
                        if (!xmlStrEqual(node_2->name, BAD_CAST "dialog"))
                        {
                            continue;
                        }

                        // add dialog to mWindowManager
                        RString dialog((const char*)node_2->xmlChildrenNode->content, strlen((const char*)node_2->xmlChildrenNode->content));
                        mpWindowManager->AddDialog(RStringToFFVIIString(dialog));
                    }
                }

                // load entity and scripts from xml
                if (entitys && xmlStrEqual(node->name, BAD_CAST "entitys"))
                {
                    mpScriptManager->Clear();

                    for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                    {
                        if (!xmlStrEqual(node_2->name, BAD_CAST "entity"))
                        {
                            continue;
                        }

                        Entity* entity = new Entity();

                        RString name = "";
                        READ_PROP(node_2, prop, "name", name, );
                        entity->SetName(name);

                        u8 script_number = 0;

                        for (xmlNodePtr node_3 = node_2->xmlChildrenNode; node_3 != NULL; node_3 = node_3->next)
                        {
                            if (!xmlStrEqual(node_3->name, BAD_CAST "script"))
                            {
                                continue;
                            }

                            u32 script_size = 0;
                            u8* script_buffer = NULL;
                            script_buffer = OpcodesToRawScript((u8*)node_3->xmlChildrenNode->content, strlen((const char*)node_3->xmlChildrenNode->content), script_size);

//                            LOGGER->Log("%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x", *(script_buffer + 0), *(script_buffer + 1), *(script_buffer + 2), *(script_buffer + 3), *(script_buffer + 4), *(script_buffer + 5), *(script_buffer + 6), *(script_buffer + 7), *(script_buffer + 8), *(script_buffer + 9), *(script_buffer + 10), *(script_buffer + 11), *(script_buffer + 12), *(script_buffer + 13), *(script_buffer + 14), *(script_buffer + 15), *(script_buffer + 16), *(script_buffer + 17));

                            if (script_buffer != NULL)
                            {
                                Script* script = new Script(script_buffer, script_size);
                                entity->AddScript(script_number, script);
                                ++script_number;
                            }
                        }

                        mpScriptManager->PushEntity(entity);
                    }
                }
            }
        }
        xmlFreeDoc(doc);
        free(p_buffer);
    }



    // load standart data (not xml)
    if (!dialogs)
    {
        dat->GetDialogs(mpWindowManager);
    }
    if (!entitys)
    {
        dat->GetScripts(mpScriptManager);
    }
    dat->GetWalkMesh(mpUnitManager);
    dat->GetCameraMatrix(mMatrix);

    // we dont know how set scale yet
    mScale = 1.0f;

    delete dat;




///////////////////////////////////////
    // to be deleted
    mpUnitManager->SetWalkMeshCoords(0);
///////////////////////////////////////
}



void
FieldModule::RequestLoadMap(const u16& id)
{
    mRequestedMapId = id;
}



void
FieldModule::Input(const InputEvent &input)
{
    // handle system input ourself
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_Co:    mScale += 0.01f;                                    break;
            case KEY_Cp:    mScale -= 0.01f;                                    break;

            case KEY_Ck:    mViewFromCamera = (mViewFromCamera) ? false : true; break;
            case KEY_Cl:    mViewAxis       = (mViewAxis)       ? false : true; break;
        }
    }



    // give input to all opened windows
    if (mpWindowManager->Input(input) == true)
    {
        // if we handled input - return
        return;
    }



    // give input to all unit on map
    if (mpUnitManager->Input(input) == true)
    {
        // if we handled input - return
        return;
    }
}



void
FieldModule::Update(const u32& delta_time)
{
    // run script
    mpScriptManager->Run();



    // update all opened windows
    mpWindowManager->Update(delta_time);



    // update all units on map
    mpUnitManager->Update(delta_time);



    // if any map request load
    if (mRequestedMapId != 0)
    {
        LoadMap(mRequestedMapId);
        mRequestedMapId = 0;
    }
}



void
FieldModule::DrawPosibleActions(void) const
{
    KERNEL->DrawString(RStringToFFVIIString("Press 'O'/'P' button to scale walkmesh"),        350, 430, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'K' button to swich to/from camera view"), 350, 445, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'L' button to show/hide axis"),            350, 460, F_WHITE);
}



void
FieldModule::Draw()
{
    DISPLAY->CameraPushMatrix();

    // set camera
    if (mViewFromCamera == true)
    {
        DISPLAY->LoadCameraMatrix(mMatrix);
    }
    else
    {
        DISPLAY->LoadLookAt(50, Vector3(-500, 200, 900), Vector3(0, 0, 0), Vector3(0, 1, 0));
    }

    // draw axis
    if (mViewAxis == true)
    {
        DISPLAY->SetPointSize(3);
        DISPLAY->DrawPoints(mAxis);
        DISPLAY->SetLineWidth(1);
        DISPLAY->DrawLines(mAxis);
    }

    DrawPosibleActions();

    // draw all units on map
    DISPLAY->PushMatrix();
    DISPLAY->Scale(mScale, mScale, mScale);
    mpUnitManager->Draw();
    DISPLAY->PopMatrix();

    // draw all opened windows
    mpWindowManager->Draw();
}
