// $Id: Model.h 79 2006-09-15 19:02:27Z crazy_otaku $

#ifndef MODEL_h
#define MODEL_h

#include "../../common/display/3dTypes.h"
#include "../../common/utilites/NoCopy.h"



class Model : public NoCopy<Model>
{
public:
    Model();
    virtual ~Model();

    void DrawModel();

private:
    std::vector<Vertex> mDefaultGeom;
};



#endif // MODEL_h
