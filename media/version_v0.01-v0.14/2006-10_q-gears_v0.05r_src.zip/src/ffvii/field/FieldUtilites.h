// $Id: FieldUtilites.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef FIELD_UTILITES_h
#define FIELD_UTILITES_h

#include "../../common/TypeDefine.h"
#include "../../common/utilites/StdString.h"



// converter map_id to file name
RString MapIdToRString(const u16& mapId);



#endif // FIELD_UTILITES_h
