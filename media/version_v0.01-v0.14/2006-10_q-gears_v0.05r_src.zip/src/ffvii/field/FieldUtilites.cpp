// $Id: FieldUtilites.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "FieldUtilites.h"



RString
MapIdToRString(const u16& mapId)
{
    static RString maps[] = {
        "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
        "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
        "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
        "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
        "",
        "STARTMAP", // 0x0041
        "FSHIP_1",  // 0x0042
        "FSHIP_12", // 0x0043
        "FSHIP_2",  // 0x0044
        "FSHIP_22", // 0x0045
        "FSHIP_23", // 0x0046
        "FSHIP_24", // 0x0047
        "FSHIP_25", // 0x0048
        "FSHIP_3",  // 0x0049
        "FSHIP_4",  // 0x004A
        "FSHIP_42", // 0x004B
        "FSHIP_5",  // 0x004C
        "HILL",     // 0x004D
        "ZZ1",      // 0x004E
        "ZZ2",      // 0x004F
        "ZZ3",      // 0x0050
        "ZZ4",      // 0x0051
        "ZZ5",      // 0x0052
        "ZZ6",      // 0x0053
        "ZZ7",      // 0x0054
        "ZZ8",      // 0x0055
        "SEA",      // 0x0056
        "SKY",      // 0x0057
        "Q_1",      // 0x0058
        "Q_2",      // 0x0059
        "Q_3",      // 0x005A
        "Q_4",      // 0x005B
        "Q_5",      // 0x005C
        "BLACKBG1", // 0x005D
        "BLACKBG2", // 0x005E
        "BLACKBG3", // 0x005F
        "BLACKBG4", // 0x0060
        "BLACKBG5", // 0x0061
        "BLACKBG6", // 0x0062
        "BLACKBG7", // 0x0063
        "BLACKBG8", // 0x0064
        "BLACKBG9", // 0x0065
        "BLACKBGA", // 0x0066
        "BLACKBGB", // 0x0067
        "BLACKBGC", // 0x0068
        "BLACKBGD", // 0x0069
        "BLACKBGE", // 0x006A
        "BLACKBGF", // 0x006B
        "BLACKBGG", // 0x006C
        "BLACKBGH", // 0x006D
        "BLACKBGI", // 0x006E
        "BLACKBGJ", // 0x006F
        "BLACKBGK", // 0x0070
        "WHITEBG1", // 0x0071
        "WHITEBG2", // 0x0072
        "WHITEBG3", // 0x0073
        "MD1STIN",  // 0x0074
/*
0x0075 - =md1_1<BR>0x0076=20
                        - md1_2<BR>0x0077 - nrthmk<BR>0x0078 - =
nmkin_1<BR>0x0079=20
                        - elevtr1<BR>0x007A - nmkin_2<BR>0x007B -=20
                        nmkin_3<BR>0x007C - nmkin_4<BR>0x007D -=20
                        nmkin_5<BR>0x007E - southmk1<BR>0x007F -=20
                        southmk2<BR>0x0080 - smkin_1<BR>0x0081 -=20
                        smkin_2<BR>0x0082 - smkin_3<BR>0x0083 -=20
                        smkin_4<BR>0x0084 - smkin_5<BR>0x0085 - =
md8_1<BR>0x0086=20
                        - md8_2<BR>0x0087 - md8_3<BR>0x0088 - =
md8_4<BR>0x0089 -=20
                        md8brdg<BR>0x008A - cargoin<BR>0x008B - =
tin_1<BR>0x008C=20
                        - tin_2<BR>0x008D - tin_3<BR>0x008E - =
tin_4<BR>0x008F -=20
                        rootmap<BR>0x0090 - mds7st1<BR>0x0091 -=20
                        mds7st2<BR>0x0092 - mds7st3<BR>0x0093 -=20
                        mds7st32<BR>0x0094 - mds7_w1<BR>0x0095 -=20
                        mds7_w2<BR>0x0096 - mds7_w3<BR>0x0097 - =
mds7<BR>0x0098 -=20
                        mds7_im<BR>0x0099 - min71<BR>0x009A - =
mds7pb_1<BR>0x009B=20
                        - mds7pb_2<BR>0x009C - mds7plr1<BR>0x009D -=20
                        mds7plr2<BR>0x009E - pillar_1<BR>0x009F -=20
                        pillar_2<BR>0x00A0 - pillar_3<BR>0x00A1 -=20
                        tunnel_1<BR>0x00A2 - tunnel_2<BR>0x00A3 -=20
                        tunnel_3<BR>0x00A4 - sbwy4_1<BR>0x00A5 -=20
                        sbwy4_2<BR>0x00A6 - sbwy4_3<BR>0x00A7 -=20
                        sbwy4_4<BR>0x00A8 - sbwy4_5<BR>0x00A9 -=20
                        sbwy4_6<BR>0x00AA - mds5_5<BR>0x00AB - =
mds5_4<BR>0x00AC=20
                        - mds5_3<BR>0x00AD - mds5_2<BR>0x00AE -=20
                        min51_1<BR>0x00AF - min51_2<BR>0x00B0 -=20
                        mds5_dk<BR>0x00B1 - mds5_1<BR>0x00B2 - =
mds5_w<BR>0x00B3=20
                        - mds5_i<BR>0x00B4 - mds5_m<BR>0x00B5 - =
church<BR>0x00B6=20
                        - chrin_1a<BR>0x00B7 - chrin_1b<BR>0x00B8 -=20
                        chrin_2<BR>0x00B9 - chrin_3a<BR>0x00BA -=20
                        chrin_3b<BR>0x00BB - eals_1<BR>0x00BC -=20
                        ealin_1<BR>0x00BD - ealin_12<BR>0x00BE -=20
                        ealin_2<BR>0x00BF - mds6_1<BR>0x00C0 - =
mds6_2<BR>0x00C1=20
                        - mds6_22<BR>0x00C2 - mds6_3<BR>0x00C3 - =
mrkt2<BR>0x00C4=20
                        - mkt_w<BR>0x00C5 - mkt_mens<BR>0x00C6 -=20
                        mkt_ia<BR>0x00C7 - mktinn<BR>0x00C8 - =
mkt_m<BR>0x00C9 -=20
                        mkt_s1<BR>0x00CA - mkt_s2<BR>0x00CB - =
mkt_s3<BR>0x00CC -=20
                        mktpb<BR>0x00CD - mrkt1<BR>0x00CE - =
colne_1<BR>0x00CF -=20
                        colne_2<BR>0x00D0 - colne_3<BR>0x00D1 -=20
                        colne_4<BR>0x00D2 - colne_5<BR>0x00D3 -=20
                        colne_6<BR>0x00D4 - colne_b1<BR>0x00D5 -=20
                        colne_b3<BR>0x00D6 - mrkt3<BR>0x00D7 - =
onna_1<BR>0x00D8=20
                        - onna_2<BR>0x00D9 - onna_3<BR>0x00DA - =
onna_4<BR>0x00DB=20
                        - onna_5<BR>0x00DC - onna_52<BR>0x00DD -=20
                        onna_6<BR>0x00DE - mrkt4<BR>0x00DF - =
wcrimb_1<BR>0x00E0=20
                        - wcrimb_2<BR>0x00E1 - md0<BR>0x00E2 - =
roadend<BR>0x00E3=20
                        - sinbil_1<BR>0x00E4 - sinbil_2<BR>0x00E5 -=20
                        blinst_1<BR>0x00E6 - blinst_2<BR>0x00E7 -=20
                        blinst_3<BR>0x00E8 - blinele<BR>0x00E9 -=20
                        eleout<BR>0x00EA - blin1<BR>0x00EB - =
blin2<BR>0x00EC -=20
                        blin2_i<BR>0x00ED - blin3_1<BR>0x00EE - =
blin59<BR>0x00EF=20
                        - blin60_1<BR>0x00F0 - blin60_2<BR>0x00F1 -=20
                        blin61<BR>0x00F2 - blin62_1<BR>0x00F3 -=20
                        blin62_2<BR>0x00F4 - blin62_3<BR>0x00F5 -=20
                        blin63_1<BR>0x00F6 - blin63_t<BR>0x00F7 -=20
                        blin64<BR>0x00F8 - blin65_1<BR>0x00F9 -=20
                        blin65_2<BR>0x00FA - blin66_1<BR>0x00FB -=20
                        blin66_2<BR>0x00FC - blin66_3<BR>0x00FD -=20
                        blin66_4<BR>0x00FE - blin66_5<BR>0x00FF -=20
                        blin66_6<BR>0x0100 - blin67_1<BR>0x0101 -=20
                        blin671b<BR>0x0102 - blin67_2<BR>0x0103 -=20
                        blin67_3<BR>0x0104 - blin673b<BR>0x0105 -=20
                        blin67_4<BR>0x0106 - blin68_1<BR>0x0107 -=20
                        blin68_2<BR>0x0108 - blin69_1<BR>0x0109 -=20
                        blin69_2<BR>0x010A - blin70_1<BR>0x010B -=20
                        blin70_2<BR>0x010C - blin70_3<BR>0x010D -=20
                        blin70_4<BR>0x010E - niv_w<BR>0x010F -=20
                        nvmin1_1<BR>0x0110 - nvmin1_2<BR>0x0111 -=20
                        nivinn_1<BR>0x0112 - nivinn_2<BR>0x0113 -=20
                        nivinn_3<BR>0x0114 - niv_cl<BR>0x0115 -=20
                        trackin<BR>0x0116 - trackin2<BR>0x0117 -=20
                        nivgate<BR>0x0118 - nivgate2<BR>0x0119 -=20
                        nivgate3<BR>0x011A - nivl<BR>0x011B - =
nivl_2<BR>0x011C -=20
                        nivl_3<BR>0x011D - nivl_4<BR>0x011E - =
niv_ti1<BR>0x011F=20
                        - niv_ti2<BR>0x0120 - niv_ti3<BR>0x0121 -=20
                        niv_ti4<BR>0x0122 - nivl_b1<BR>0x0123 -=20
                        nivl_b12<BR>0x0124 - nivl_b2<BR>0x0125 -=20
                        nivl_b22<BR>0x0126 - nivl_e1<BR>0x0127 -=20
                        nivl_e2<BR>0x0128 - nivl_e3<BR>0x0129 -=20
                        sinin1_1<BR>0x012A - sinin1_2<BR>0x012B -=20
                        sinin2_1<BR>0x012C - sinin2_2<BR>0x012D -=20
                        sinin3<BR>0x012E - sininb1<BR>0x012F - =
sininb2<BR>0x0130=20
                        - sininb31<BR>0x0131 - sininb32<BR>0x0132 -=20
                        sininb33<BR>0x0133 - sininb41<BR>0x0134 -=20
                        sininb42<BR>0x0135 - sininb51<BR>0x0136 -=20
                        sininb52<BR>0x0137 - mtnvl2<BR>0x0138 - =
mtnvl3<BR>0x0139=20
                        - mtnvl4<BR>0x013A - mtnvl5<BR>0x013B - =
mtnvl6<BR>0x013C=20
                        - mtnvl6b<BR>0x013D - nvdun1<BR>0x013E -=20
                        nvdun2<BR>0x013F - nvdun3<BR>0x0140 - =
nvdun31<BR>0x0141=20
                        - nvdun4<BR>0x0142 - nvmkin1<BR>0x0143 -=20
                        nvmkin21<BR>0x0144 - nvmkin22<BR>0x0145 -=20
                        nvmkin23<BR>0x0146 - nvmkin31<BR>0x0147 -=20
                        nvmkin32<BR>0x0148 - elm_wa<BR>0x0149 - =
elm_i<BR>0x014A=20
                        - elmpb<BR>0x014B - elminn_1<BR>0x014C -=20
                        elminn_2<BR>0x014D - elmin1_1<BR>0x014E -=20
                        elmin1_2<BR>0x014F - elm<BR>0x0150 - =
elmin2_1<BR>0x0151=20
                        - elmin2_2<BR>0x0152 - elmin3_1<BR>0x0153 -=20
                        elmin3_2<BR>0x0154 - elmtow<BR>0x0155 -=20
                        elmin4_1<BR>0x0156 - elmin4_2<BR>0x0157 - =
farm<BR>0x0158=20
                        - frmin<BR>0x0159 - frcyo<BR>0x015A - =
trap<BR>0x015B -=20
                        fr_e<BR>0x015C - sichi<BR>0x015D - =
psdun_1<BR>0x015E -=20
                        psdun_2<BR>0x015F - psdun_3<BR>0x0160 -=20
                        psdun_4<BR>0x0161 - condor1<BR>0x0162 -=20
                        condor2<BR>0x0163 - convil_1<BR>0x0164 -=20
                        convil_2<BR>0x0165 - convil_3<BR>0x0166 -=20
                        convil_4<BR>0x0167 - junon<BR>0x0168 - =
junonr1<BR>0x0169=20
                        - junonr2<BR>0x016A - junonr3<BR>0x016B -=20
                        junonr4<BR>0x016C - jun_wa<BR>0x016D - =
jun_i1<BR>0x016E=20
                        - jun_m<BR>0x016F - junmin1<BR>0x0170 -=20
                        junmin2<BR>0x0171 - junmin3<BR>0x0172 -=20
                        junonl1<BR>0x0173 - junonl2<BR>0x0174 -=20
                        junonl3<BR>0x0175 - jun_w<BR>0x0176 - =
jun_a<BR>0x0177 -=20
                        jun_i2<BR>0x0178 - juninn<BR>0x0179 - =
junpb_1<BR>0x017A=20
                        - junpb_2<BR>0x017B - junpb_3<BR>0x017C -=20
                        junmin4<BR>0x017D - junmin5<BR>0x017E -=20
                        jundoc1a<BR>0x017F - jundoc1b<BR>0x0180 -=20
                        junair<BR>0x0181 - junair2<BR>0x0182 - =
junin1<BR>0x0183=20
                        - junin1a<BR>0x0184 - junele1<BR>0x0185 -=20
                        junin2<BR>0x0186 - junin3<BR>0x0187 - =
junele2<BR>0x0188=20
                        - junin4<BR>0x0189 - junin5<BR>0x018A - =
junin6<BR>0x018B=20
                        - junin7<BR>0x018C - junbin1<BR>0x018D -=20
                        junbin12<BR>0x018E - junbin21<BR>0x018F -=20
                        junbin22<BR>0x0190 - junbin3<BR>0x0191 -=20
                        junbin4<BR>0x0192 - junbin5<BR>0x0193 - =
junmon<BR>0x0194=20
                        - junsbd1<BR>0x0195 - subin_1a<BR>0x0196 -=20
                        subin_1b<BR>0x0197 - subin_2a<BR>0x0198 -=20
                        subin_2b<BR>0x0199 - subin_3<BR>0x019A -=20
                        subin_4<BR>0x019B - junone2<BR>0x019C -=20
                        junone3<BR>0x019D - junone4<BR>0x019E -=20
                        junone5<BR>0x019F - junone6<BR>0x01A0 -=20
                        junone7<BR>0x01A1 - spgate<BR>0x01A2 - =
spipe_1<BR>0x01A3=20
                        - spipe_2<BR>0x01A4 - semkin_1<BR>0x01A5 -=20
                        semkin_2<BR>0x01A6 - semkin_8<BR>0x01A7 -=20
                        semkin_3<BR>0x01A8 - semkin_4<BR>0x01A9 -=20
                        semkin_5<BR>0x01AA - semkin_6<BR>0x01AB -=20
                        semkin_7<BR>0x01AC - ujunon1<BR>0x01AD -=20
                        ujunon2<BR>0x01AE - ujunon3<BR>0x01AF -=20
                        prisila<BR>0x01B0 - ujun_w<BR>0x01B1 - =
jumin<BR>0x01B2 -=20
                        ujunon4<BR>0x01B3 - ujunon5<BR>0x01B4 - =
ship_1<BR>0x01B5=20
                        - ship_2<BR>0x01B6 - shpin_22<BR>0x01B7 -=20
                        shpin_2<BR>0x01B8 - shpin_3<BR>0x01B9 - =
del1<BR>0x01BA -=20
                        del12<BR>0x01BB - del2<BR>0x01BC - =
delinn<BR>0x01BD -=20
                        delpb<BR>0x01BE - delmin1<BR>0x01BF - =
delmin12<BR>0x01C0=20
                        - delmin2<BR>0x01C1 - del3<BR>0x01C2 - =
ncorel<BR>0x01C3=20
                        - ncorel2<BR>0x01C4 - ncorel3<BR>0x01C5 -=20
                        ncoin1<BR>0x01C6 - ncoin2<BR>0x01C7 - =
ncoin3<BR>0x01C8 -=20
                        ncoinn<BR>0x01C9 - ropest<BR>0x01CA - =
mtcrl_0<BR>0x01CB=20
                        - mtcrl_1<BR>0x01CC - mtcrl_2<BR>0x01CD -=20
                        mtcrl_3<BR>0x01CE - mtcrl_4<BR>0x01CF -=20
                        mtcrl_5<BR>0x01D0 - mtcrl_6<BR>0x01D1 -=20
                        mtcrl_7<BR>0x01D2 - mtcrl_8<BR>0x01D3 -=20
                        mtcrl_9<BR>0x01D4 - corel1<BR>0x01D5 - =
corel2<BR>0x01D6=20
                        - corel3<BR>0x01D7 - jail1<BR>0x01D8 - =
jailin1<BR>0x01D9=20
                        - jail2<BR>0x01DA - jailpb<BR>0x01DB - =
jailin2<BR>0x01DC=20
                        - jailin3<BR>0x01DD - jailin4<BR>0x01DE -=20
                        jail3<BR>0x01DF - jail4<BR>0x01E0 - =
dyne<BR>0x01E1 -=20
                        desert1<BR>0x01E2 - desert2<BR>0x01E3 -=20
                        corelin<BR>0x01E4 - astage_a<BR>0x01E5 -=20
                        astage_b<BR>0x01E6 - jet<BR>0x01E7 - =
jetin1<BR>0x01E8 -=20
                        bigwheel<BR>0x01E9 - bwhlin<BR>0x01EA -=20
                        bwhlin2<BR>0x01EB - ghotel<BR>0x01EC -=20
                        ghotin_1<BR>0x01ED - ghotin_4<BR>0x01EE -=20
                        ghotin_2<BR>0x01EF - ghotin_3<BR>0x01F0 -=20
                        gldst<BR>0x01F1 - gldgate<BR>0x01F2 - =
gldinfo<BR>0x01F3=20
                        - coloss<BR>0x01F4 - coloin1<BR>0x01F5 -=20
                        coloin2<BR>0x01F6 - clsin2_1<BR>0x01F7 -=20
                        clsin2_2<BR>0x01F8 - clsin2_3<BR>0x01F9 -=20
                        games<BR>0x01FA - games_1<BR>0x01FB - =
games_2<BR>0x01FC=20
                        - mogu_1<BR>0x01FD - chorace<BR>0x01FE -=20
                        chorace2<BR>0x01FF - crcin_1<BR>0x0200 -=20
                        crcin_2<BR>0x0201 - gldelev<BR>0x0202 -=20
                        gonjun1<BR>0x0203 - gonjun2<BR>0x0204 - =
gnmkf<BR>0x0205=20
                        - gnmk<BR>0x0206 - gongaga<BR>0x0207 - =
gon_wa1<BR>0x0208=20
                        - gon_wa2<BR>0x0209 - gon_i<BR>0x020A - =
gninn<BR>0x020B=20
                        - gomin<BR>0x020C - goson<BR>0x020D - =
cos_btm<BR>0x020E=20
                        - cos_btm2<BR>0x020F - cosmo<BR>0x0210 -=20
                        cosmo2<BR>0x0211 - cosin1<BR>0x0212 - =
cosin1_1<BR>0x0213=20
                        - cosin2<BR>0x0214 - cosin3<BR>0x0215 - =
cosin4<BR>0x0216=20
                        - cosin5<BR>0x0217 - cosmin2<BR>0x0218 -=20
                        cosmin3<BR>0x0219 - cosmin4<BR>0x021A -=20
                        cosmin6<BR>0x021B - cosmin7<BR>0x021C -=20
                        cos_top<BR>0x021D - bugin1a<BR>0x021E -=20
                        bugin1b<BR>0x021F - bugin1c<BR>0x0220 - =
bugin2<BR>0x0221=20
                        - bugin3<BR>0x0222 - gidun_1<BR>0x0223 -=20
                        gidun_2<BR>0x0224 - gidun_4<BR>0x0225 -=20
                        gidun_3<BR>0x0226 - seto1<BR>0x0227 - =
rckt2<BR>0x0228 -=20
                        rckt3<BR>0x0229 - rkt_w<BR>0x022A - =
rkt_i<BR>0x022B -=20
                        rktinn1<BR>0x022C - rktinn2<BR>0x022D - =
rckt<BR>0x022E -=20
                        rktsid<BR>0x022F - rktmin1<BR>0x0230 - =
rktmin2<BR>0x0231=20
                        - rcktbas1<BR>0x0232 - rcktbas2<BR>0x0233 -=20
                        rcktin1<BR>0x0234 - rcktin2<BR>0x0235 -=20
                        rcktin3<BR>0x0236 - rcktin4<BR>0x0237 -=20
                        rcktin5<BR>0x0238 - rcktin6<BR>0x0239 -=20
                        rcktin7<BR>0x023A - rcktin8<BR>0x023B - =
pass<BR>0x023C -=20
                        yougan<BR>0x023D - yougan2<BR>0x023E - =
yougan3<BR>0x023F=20
                        - uta_wa<BR>0x0240 - uta_im<BR>0x0241 - =
utmin1<BR>0x0242=20
                        - utmin2<BR>0x0243 - uutai1<BR>0x0244 - =
utapb<BR>0x0245=20
                        - yufy1<BR>0x0246 - yufy2<BR>0x0247 - =
hideway1<BR>0x0248=20
                        - hideway2<BR>0x0249 - hideway3<BR>0x024A -=20
                        tower5<BR>0x024B - uutai2<BR>0x024C - =
uttmpin1<BR>0x024D=20
                        - uttmpin2<BR>0x024E - uttmpin3<BR>0x024F -=20
                        uttmpin4<BR>0x0250 - datiao_1<BR>0x0251 -=20
                        datiao_2<BR>0x0252 - datiao_3<BR>0x0253 -=20
                        datiao_4<BR>0x0254 - datiao_5<BR>0x0255 -=20
                        datiao_6<BR>0x0256 - datiao_7<BR>0x0257 -=20
                        datiao_8<BR>0x0258 - jtempl<BR>0x0259 -=20
                        jtemplb<BR>0x025A - jtmpin1<BR>0x025B -=20
                        jtmpin2<BR>0x025C - kuro_1<BR>0x025D - =
kuro_2<BR>0x025E=20
                        - kuro_3<BR>0x025F - kuro_4<BR>0x0260 - =
kuro_5<BR>0x0261=20
                        - kuro_6<BR>0x0262 - kuro_7<BR>0x0263 - =
kuro_8<BR>0x0264=20
                        - kuro_82<BR>0x0265 - kuro_9<BR>0x0266 -=20
                        kuro_10<BR>0x0267 - kuro_11<BR>0x0268 -=20
                        kuro_12<BR>0x0269 - bonevil<BR>0x026A -=20
                        slfrst_1<BR>0x026B - slfrst_2<BR>0x026C -=20
                        anfrst_1<BR>0x026D - anfrst_2<BR>0x026E -=20
                        anfrst_3<BR>0x026F - anfrst_4<BR>0x0270 -=20
                        anfrst_5<BR>0x0271 - sango1<BR>0x0272 - =
sango2<BR>0x0273=20
                        - sango3<BR>0x0274 - sandun_1<BR>0x0275 -=20
                        sandun_2<BR>0x0276 - lost1<BR>0x0277 - =
losin1<BR>0x0278=20
                        - losin2<BR>0x0279 - losin3<BR>0x027A - =
lost2<BR>0x027B=20
                        - lost3<BR>0x027C - losinn<BR>0x027D -=20
                        loslake1<BR>0x027E - loslake2<BR>0x027F -=20
                        loslake3<BR>0x0280 - blue_1<BR>0x0281 - =
blue_2<BR>0x0282=20
                        - white1<BR>0x0283 - white2<BR>0x0284 - =
hekiga<BR>0x0285=20
                        - whitein<BR>0x0286 - ancnt1<BR>0x0287 -=20
                        ancnt2<BR>0x0288 - ancnt3<BR>0x0289 - =
ancnt4<BR>0x028A -=20
                        snw_w<BR>0x028B - sninn_1<BR>0x028C - =
sninn_2<BR>0x028D=20
                        - sninn_b1<BR>0x028E - snow<BR>0x028F - =
snmin1<BR>0x0290=20
                        - snmin2<BR>0x0291 - snmayor<BR>0x0292 - =
hyou1<BR>0x0293=20
                        - hyou2<BR>0x0294 - hyou3<BR>0x0295 - =
icedun_1<BR>0x0296=20
                        - icedun_2<BR>0x0297 - hyou4<BR>0x0298 -=20
                        hyou5_1<BR>0x0299 - hyou5_2<BR>0x029A -=20
                        hyou5_3<BR>0x029B - hyou5_4<BR>0x029C - =
hyou6<BR>0x029D=20
                        - hyoumap<BR>0x029E - move_s<BR>0x029F -=20
                        move_i<BR>0x02A0 - move_f<BR>0x02A1 - =
move_r<BR>0x02A2 -=20
                        move_u<BR>0x02A3 - move_d<BR>0x02A4 - =
hyou7<BR>0x02A5 -=20
                        hyou8_1<BR>0x02A6 - hyou8_2<BR>0x02A7 - =
hyou9<BR>0x02A8=20
                        - hyou10<BR>0x02A9 - hyou11<BR>0x02AA - =
hyou12<BR>0x02AB=20
                        - hyou13_1<BR>0x02AC - hyou13_2<BR>0x02AD -=20
                        hyou14<BR>0x02AE - gaiafoot<BR>0x02AF - =
holu_1<BR>0x02B0=20
                        - holu_2<BR>0x02B1 - gaia_1<BR>0x02B2 -=20
                        gaiin_1<BR>0x02B3 - gaiin_2<BR>0x02B4 - =
gaia_2<BR>0x02B5=20
                        - gaiin_3<BR>0x02B6 - gaia_31<BR>0x02B7 -=20
                        gaia_32<BR>0x02B8 - gaiin_4<BR>0x02B9 -=20
                        gaiin_5<BR>0x02BA - gaiin_6<BR>0x02BB -=20
                        gaiin_7<BR>0x02BC - crater_1<BR>0x02BD -=20
                        crater_2<BR>0x02BE - trnad_1<BR>0x02BF -=20
                        trnad_2<BR>0x02C0 - trnad_3<BR>0x02C1 -=20
                        trnad_4<BR>0x02C2 - trnad_51<BR>0x02C3 -=20
                        trnad_52<BR>0x02C4 - trnad_53<BR>0x02C5 -=20
                        woa_1<BR>0x02C6 - woa_2<BR>0x02C7 - =
woa_3<BR>0x02C8 -=20
                        itown1a<BR>0x02C9 - itown12<BR>0x02CA -=20
                        itown1b<BR>0x02CB - itown2<BR>0x02CC - =
ithill<BR>0x02CD=20
                        - itown_w<BR>0x02CE - itown_i<BR>0x02CF -=20
                        itown_m<BR>0x02D0 - ithos<BR>0x02D1 - =
itmin1<BR>0x02D2 -=20
                        itmin2<BR>0x02D3 - life<BR>0x02D4 - =
life2<BR>0x02D5 -=20
                        zmind1<BR>0x02D6 - zmind2<BR>0x02D7 - =
zmind3<BR>0x02D8 -=20
                        zcoal_1<BR>0x02D9 - zcoal_2<BR>0x02DA -=20
                        zcoal_3<BR>0x02DB - md8_5<BR>0x02DC - =
md8_6<BR>0x02DD -=20
                        md8_b1<BR>0x02DE - md8_b2<BR>0x02DF - =
sbwy4_22<BR>0x02E0=20
                        - tunnel_4<BR>0x02E1 - tunnel_5<BR>0x02E2 -=20
                        md8brdg2<BR>0x02E3 - md8_32<BR>0x02E4 -=20
                        canon_1<BR>0x02E5 - canon_2<BR>0x02E6 - =
md_e1<BR>0x02E7=20
                        - xmvtes<BR>0x02E8 - las0_1<BR>0x02E9 - =
las0_2<BR>0x02EA=20
                        - las0_3<BR>0x02EB - las0_4<BR>0x02EC - =
las0_5<BR>0x02ED=20
                        - las0_6<BR>0x02EE - las0_7<BR>0x02EF - =
las0_8<BR>0x02F0=20
                        - las1_1<BR>0x02F1 - las1_2<BR>0x02F2 - =
las1_3<BR>0x02F3=20
                        - las1_4<BR>0x02F4 - las2_1<BR>0x02F5 - =
las2_2<BR>0x02F6=20
                        - las2_3<BR>0x02F7 - las2_4<BR>0x02F8 - =
las3_1<BR>0x02F9=20
                        - las3_2<BR>0x02FA - las3_3<BR>0x02FB - =
las4_0<BR>0x02FC=20
                        - las4_1<BR>0x02FD - las4_2<BR>0x02FE - =
las4_3<BR>0x02FF=20
                        - las4_4<BR>0x0300 - lastmap<BR>0x0301 - =
fallp<BR>0x0302=20
                        - m_endo<BR>0x0303 - hill2<BR>0x0304 -=20
                        bonevil2<BR>0x0305 - junone22<BR>0x0306 -=20
                        rckt32<BR>0x0307 - jtemplc<BR>0x0308 -=20
                        fship_26<BR>0x0309 - las4_42<BR>0x030A -=20
                        tunnel_6<BR>0x030B - md8_52<BR>0x030C -=20
                        sininb34<BR>0x030D - mds7st33<BR>0x030E -=20
                        midgal<BR>0x030F - sininb35<BR>0x0310 -=20
                        nivgate4<BR>0x0311 - sininb36<BR>0x0312 -=20
                        ztruck</DIV></DIV></TD></TR>
*/
    };

    return maps[mapId];
}
