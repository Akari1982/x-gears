// $Id: GameMain.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef GAME_MAIN_H
#define GAME_MAIN_H



enum
{
    EXIT,
    GAME
};

extern unsigned char state;



#endif // GAME_MAIN_H