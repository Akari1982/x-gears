// $Id: GameFileSystem.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "GameFileSystem.h"



GameFileSystem *GAMEFILESYSTEM = NULL;



GameFileSystem::GameFileSystem()
{
}



GameFileSystem::~GameFileSystem()
{
}



unsigned int
GameFileSystem::GetFileSize(const RString &path)
{
    return mFileDriver.GetFileSize(path);
}



bool
GameFileSystem::ReadFile(const RString &path, const void* buffer, const unsigned int start, const unsigned int length)
{
    return mFileDriver.ReadFile(path, buffer, start, length);
}
