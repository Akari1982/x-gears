// $Id: WorldMapModule.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef WORLD_MAP_MODULE_h
#define WORLD_MAP_MODULE_h



#include "../../common/module/Module.h"




class WorldMapModule : public Module
{
public:
    WorldMapModule(void);
    virtual ~WorldMapModule(void);

    virtual void Init(void);

    virtual void Draw(void);

    virtual void Input(const InputEvent& input);

    virtual void Update(const u32& deltaTime);


};



#endif //  WORLD_MAP_MODULE_h
