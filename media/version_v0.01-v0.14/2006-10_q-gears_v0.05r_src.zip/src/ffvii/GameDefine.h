// $Id: GameDefine.h 83 2006-10-08 06:55:30Z crazy_otaku $

#ifndef GAME_DEFINE_H
#define GAME_DEFINE_H



#define APPLICATION_NAME "FFVII v0.05b"



#endif // GAME_DEFINE_H
