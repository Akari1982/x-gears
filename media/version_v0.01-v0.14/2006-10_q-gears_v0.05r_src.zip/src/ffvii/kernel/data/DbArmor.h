// $Id: DbArmor.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef DBARMOR_H
#define DBARMOR_H



typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;



struct DBArmor
{
    u8 Unknown[36];
};




#endif
