// $Id: DbCommand.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef DBCOMMAND_H
#define DBCOMMAND_H



typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;



struct DBCommand
{
    u8 Unknown[16];
};




#endif
