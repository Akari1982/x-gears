// $Id: DbAttack.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef DBATTACK_H
#define DBATTACK_H



typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;



struct DBAttack
{
    u8 Unknown[28];
};




#endif
