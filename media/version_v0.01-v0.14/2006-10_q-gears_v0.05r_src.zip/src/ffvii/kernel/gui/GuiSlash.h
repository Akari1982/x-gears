// $Id: GuiSlash.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef GUISLASH_H
#define GUISLASH_H



#include "../../../common/display/3dTypes.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/NoCopy.h"



class GuiSlash : public NoCopy<GuiSlash>
{
public:
             GuiSlash(Surface* image);
    virtual ~GuiSlash();

    void     DrawSlash(const int &x, const int &y);

private:
    int                 mTexId;
    std::vector<Vertex> mPoly;
};



#endif
