/* Fielddump, a program to print the Fieldscript files for Final Fantasy 7.*/

/* Usage:  fielddump [fieldfile] */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "script.h"

typedef uint16_t u16;
typedef uint32_t u32;

void display_usage(void);
int get_mips_u32(void);
int get_mips_u16(void);


FILE *fp;		/* field file handle */
FILE *outfp;	/* file handle for dumped field script */
char output_filename[12];	/* The name of the decompiled fieldscript file */


int entity;			/* current entity number */
int script_slot;	/* script slot for entity */
int next_entity;	/* address for the next entity's script */

/* used to keep the scripts from repeating */
int script_at = 0;
int script_to = 0;
int last_script_addr = 0;
int curr_script_addr = 0;
int next_script_addr = 0;

/* This is the length of the header for the PC verision of the game.
If I remeber, the PSX's header is different,
so adjust this accordingly if you want to make a PSX script dumper */ 
int header_length=4;


u32 unknown1;    
char nEntities;		/* Number of entities */
char unknown2;		/* Number of character entities (?) */
u16 wStringOffset;	/* Offset to dialog strings */
u16 nExtraOffsets;	/* An optional number of extra offsets... unknown */
u16 unknown4[4];
char szCreator[8];	/* Field creator */
char szName[8];		/* Field name */


main(int argc, char *argv[])
{
	int script_offset;
	

	if (argc < 2)
		{
		display_usage();
		exit (1);
		}

	if (( fp = fopen( argv[1], "rb" )) == NULL)
		{
		fprintf( stderr, "Error opening file %s\n", argv[1]);
		exit(1);
		}

	/* Now to see if it's a PC field file */
	fseek(fp,0,SEEK_SET);
	if (get_mips_u32() != 9)
		{
		fprintf(stderr, "Fielddump - By Halkun\n\n");
		fprintf( stderr, "ERROR: Header seems incorrect.\n");
		fprintf( stderr, "Did you uncompress the file first?\n");
		fprintf( stderr, "Are you using a PC Fieldfile?\n\n");
		exit(1);
		}

	/* Jump to the beginning to the fieldscript */
	fseek(fp,4,SEEK_SET);
	script_offset=get_mips_u32();
	fseek(fp,script_offset,SEEK_SET);	
	printf("Script found at location 0x%x\n",script_offset);
	printf("Script is 0x%x bytes long\n\n",get_mips_u16()); 

	/* This reads in the fieldscript header, I should make this a whole
	other function, but as I adore globals, and can't dynamically allocate
	struct memebers in C, it looks like this mess is required. */
	unknown1=get_mips_u32();
	printf("unknown1=%x\n",unknown1);
	nEntities=getc(fp);
	printf("nEntities=%x\n",nEntities);
	unknown2=getc(fp);
	printf("Unknown2=%x\n",unknown2);
	wStringOffset=get_mips_u16()+header_length+script_offset;
	printf("wStringOffset=%x\n",wStringOffset);
	nExtraOffsets=get_mips_u16();
	printf("nExtraOffsets=%x\n",nExtraOffsets);
	fread (unknown4,1,8,fp);
	fread (szCreator,1,8,fp);
	printf ("szCreator=%s\n",szCreator);
	fread (szName,1,8,fp);
	printf ("szName=%s\n",szName);

	/* Get entity names */
	char EntitiesName[nEntities][8];
	fread(EntitiesName,nEntities,8,fp);	
	for (entity =0;entity<nEntities;entity++)
	{
	printf ("entity number %d=%s\n",entity,EntitiesName[entity]);
	}
	
	/* get the pointer to any extra segments that are needed */
	u32 dwExtraOffsets[nExtraOffsets];
    for (entity =0;entity<nExtraOffsets;entity++)
	{
		dwExtraOffsets[entity]=get_mips_u16()+header_length+script_offset;
		
		/* This is a bug, but I have to jump up two positions. I think my
		MIPS convert thingy is off however the data I'm skipping are zeros
		anyway (I hope!) */
		fseek(fp,2,SEEK_CUR);
    }

	/* now load the entity script pointers */
	u16 vEntityScripts[nEntities][32];
	for (entity=0;entity<nEntities;entity++)
	{
		for (script_slot=0;script_slot<32;script_slot++)
		{
			vEntityScripts[entity][script_slot]=
				get_mips_u16()+header_length+script_offset;
		}
	}	


	
	/* Ok, now we have what we need to start dumping the script
	I shouldn't make this part of main(), hell, it shouldn't even
	be in this *FILE*  but now I've *TOTALLY* screwed up my 
	variable scope above so I need to make everything local ^_^

	...sorry guys! */
	
	/******************************************************************/
	/* DUMPING THE FIELDSCRIPT STARTS HERE IN THE MIDDLE OF THIS MESS */
	/******************************************************************/


	/* append .scp to the end of the field file name to make the script file */
	strcpy(output_filename,argv[1]);
	strcat(output_filename,".scp");

	if ((outfp = fopen(output_filename, "w" )) == NULL)
		{
		fprintf( stderr, "Error opening file %s\n", output_filename);
		exit(1);
		}

	/* Print header */
	fprintf(outfp, "# Final Fantasy 7 Field Script\n");
	fprintf(outfp, "# Original Name: %s\n",argv[1]);
	fprintf(outfp, "# Created by: %s\n",szCreator);
	fprintf(outfp, "#\n");
	fprintf(outfp, "# Internal filename: %s\n",szName);
	fprintf(outfp, "#\n");
	fprintf(outfp, "\n");
	fprintf(outfp, "\n");
	script_slot=0;
	/* now to go through all the entities and drop some code on thier ass */
	/* (Holy crap dude, it's like 2:00am now! ) */
	/* ================= */
	/* As a revision to the above comment, the code below is most likely */
	/* *very* broken I've already found a varible that I never used.*/
	/* To tell the truth, I don't even know what it's doing ^_^ */
	/* ================= */
	/* As a revision to the revision to the above comment, I was right */
	/* now I fixed it for readbility and for bug killing */
	/* ================= */
	/* revision, the 3rd (4th?) I'm still getting off-by-one errorsi. grrrr */


	for (entity=0;entity<nEntities;entity++)
	{
		
	fprintf(outfp,"####################");
	fprintf(outfp," Entity %d (%s) ",entity,EntitiesName[entity]);
	fprintf(outfp,"####################\n\n");
	fprintf(outfp,"ENTITY(%d) = %s\n\n",entity,EntitiesName[entity]);
		for (script_slot=0;script_slot<32;script_slot++)
		{
		/* look at the current script, is it the same as the last script? */
			curr_script_addr = vEntityScripts[entity][script_slot];
			if (curr_script_addr == last_script_addr)
			{
				/* yes it is so we need to bump up the "to entity" */
				script_to++;

				/* now check the next script and see if that's the same too */
				/* first we have to see if we are jumping to a new entity */
				/* If we are, then obviously it's a different script */
				if (script_slot == 31)
				{
					/* The next script is a new entity, so we need to write an
					"alias" script */
					fprintf(outfp,"alias %s (script %d to 31)\n\n",
						EntitiesName[entity],script_at-1);
					script_to=0;   /* now reset script_to */
				}
				/* now, what about if we are in the middle of an entity and the
				next script is different? */
				if (script_slot != 31)
				{
					next_script_addr=vEntityScripts[entity][script_slot+1];
					if (next_script_addr != curr_script_addr)
					{
						script_at++;
						fprintf(outfp,"alias %s (script %d to %d)\n\n",
							EntitiesName[entity],script_at-2,++script_to);
						
					} 
				}
			}			
			else
			{
				/* get the address of the next script */
				next_script_addr=vEntityScripts[entity][script_slot+1];

				/* now, here comes the ticky part. There is a chance that */
				/* we are midway through an alias switch. In this case the */
				/* next script will be the same as this script, but in fact */
				/* we need to grab the address of the next entity's script */
				
				if (next_entity < nEntities)
					{next_entity=entity+1;}
				if (next_script_addr == vEntityScripts[entity][31] &&
					curr_script_addr == next_script_addr &&
					next_entity < nEntities)
					{next_script_addr=(vEntityScripts[next_entity][0]);}

/*  fprintf(outfp,"%x to %x\n",curr_script_addr, next_script_addr); */
				fprintf(outfp,"%s (script %d)\n{\n",
					EntitiesName[entity],script_at);
				dumpscript(fp,outfp,curr_script_addr,next_script_addr,
					script_at);
				fprintf(outfp,"}\n\n");
				script_at++;
				last_script_addr = curr_script_addr;
			}
		}	
	script_at=0;
	}
	fclose (outfp);
}


void display_usage(void)
{
      fprintf(stderr, "Fielddump - By Halkun\n\n");
      fprintf(stderr, "ERROR: No Field file was given\n\nProper usage:\n" );
      fprintf(stderr, "fielddump [fieldfile]\n");
      fprintf(stderr, "where [fieldfile] is an uncompressed PC field file\n\n");
}


int get_mips_u32(void)
{
	int n=0; 
	unsigned char ch;
	/* Char 0 */
	ch = getc(fp);
	n = (ch << 16);

	/* Char 1 */
	ch = getc(fp);
	n |= (ch << 24);

	/* Char 2 */
	ch = getc(fp);
	n |= ch;
	
	/* Char 3 */
	ch = getc(fp);
	n |= (ch << 8);

	return(n);
}


int get_mips_u16(void)
{
	int n=0; 
	unsigned char ch;

	/* Char 0 */
	ch = getc(fp);
	n |= ch;
	/* Char 1 */
	ch = getc(fp);
	n |= (ch << 8);
	return(n);
}
