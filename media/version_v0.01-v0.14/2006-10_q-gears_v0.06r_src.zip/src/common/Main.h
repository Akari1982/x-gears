// $Id: Main.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef MAIN_H
#define MAIN_H

#include "utilites/StdString.h"



enum
{
    EXIT,
    GAME
};

extern unsigned char state;

extern void    game_main(void);
extern void    game_module_start(void);
extern RString game_title(void);



#endif // MAIN_H