// $Id: ModuleManager.h 76 2006-08-25 18:41:20Z crazy_otaku $
/**
 * @brief Manager that handles different game moduls.
 */

#ifndef MODULE_MANAGER_h
#define MODULE_MANAGER_h

#include "../TypeDefine.h"

#include "Module.h"
#include "../input/InputFilter.h"
#include "../utilites/NoCopy.h"

#include <vector>



class ModuleManager : public NoCopy<ModuleManager>
{
public:
// LIFECYCLE

    /**
     * @brief Default constructor.
     */
    ModuleManager(void);

    /**
     * @brief Default destructor.
     */
    virtual ~ModuleManager(void);

// OPERATIONS

    /**
     * @brief Draw modules.
     *
     * Draw all moduls that was added in manager.
     */
    void Draw(void);

    /**
     * @brief Give input to top module.
     *
     * @param input - single input event.
     */
    void Input(const InputEvent& input);

    /**
     * @brief Call update module in stack and delete all module from delete stack.
     *
     * @param deltaTime - time passed from last call.
     */
    void Update(const u32& deltaTime);

    /**
     * @brief Add new module to stack.
     *
     * Main module stack management. Add new module to the top.
     * @param pModule - pointer to new module that we want to add.
     */
    void PushModule(Module* pModule);

    /**
     * @brief Set top module to remove from stack.
     *
     * Main module stack management. Add top module to delete stack.
     */
    void PopTopModule(void);

private:
    std::vector<Module*> mModules;         /**< @brief stack of modules */
    std::vector<Module*> mModulesToDelete; /**< @brief stack of modules to delete */
};



extern ModuleManager* MODULEMAN; /**< @brief global ModuleManager instance. Visible from anywhere as the header are included. */



#endif // MODULE_MANAGER_h
