// $Id: RealFileSystem.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef REALFILESYSTEM_H
#define REALFILESYSTEM_H



#include "FileSystem.h"
#include "../utilites/StdString.h"
#include <vector>



class RealFileSystem : public FileSystem
{
public:
                         RealFileSystem();
    virtual             ~RealFileSystem();

    virtual unsigned int GetFileSize(const RString& path);
    virtual bool         ReadFile(const RString &path, const void* buffer, const unsigned int start, const unsigned int length);
            bool         WriteFile(const RString &path, const void* buffer, const unsigned int length);
            bool         WriteNewFile(const RString &path, const void* buffer, const unsigned int length);
            bool         RemoveFile(const RString &path);
};



extern RealFileSystem *REALFILESYSTEM;



#endif // REALFILESYSTEM_H
