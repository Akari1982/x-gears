// $Id: FileDriver.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "FileDriver.h"



FileDriver::FileDriver()
{
}



FileDriver::~FileDriver()
{
}
