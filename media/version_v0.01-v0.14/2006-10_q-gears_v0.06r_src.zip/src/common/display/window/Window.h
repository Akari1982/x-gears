// $Id: Window.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef WINDOW_H
#define WINDOW_H
// The Window Class : Abstract class for window

#include "../../utilites/NoCopy.h"



class Window : public NoCopy<Window>
{
public:
    virtual ~Window() {};

    virtual void SwapBuffers() = 0;

protected:
    // This need to be protected because implementation must call constructor
    Window() {};
};



#endif // WINDOW_H
