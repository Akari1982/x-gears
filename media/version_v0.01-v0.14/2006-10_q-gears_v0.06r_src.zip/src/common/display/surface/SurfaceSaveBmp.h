// $Id: SurfaceSaveBmp.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef SURFACESAVEBMP_H
#define SURFACESAVEBMP_H



#include "Surface.h"

#include <string>



namespace SurfaceUtils
{
    bool
    SaveBMP(const std::string &file, Surface* surface);
};



#endif
