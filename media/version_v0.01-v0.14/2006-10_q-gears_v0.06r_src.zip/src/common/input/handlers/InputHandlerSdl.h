// $Id: InputHandlerSdl.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef INPUTHANDLERSDL_H
#define INPUTHANDLERSDL_H



#include "InputHandler.h"



class InputHandlerSDL: public InputHandler
{
public:
     InputHandlerSDL();
    ~InputHandlerSDL();

    void  Update();
};



#endif // INPUTHANDLERSDL_H
