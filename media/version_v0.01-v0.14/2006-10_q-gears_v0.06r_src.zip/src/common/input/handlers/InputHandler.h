// $Id: InputHandler.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef INPUTHANDLER_H
#define INPUTHANDLER_H



#include "../InputFilter.h"
#include "../../utilites/NoCopy.h"



class InputHandler : public NoCopy<InputHandler>
{
public:
    virtual      ~InputHandler() {}
    virtual void  Update() = 0;

protected:
                  InputHandler() {}
    void          ButtonPressed(Button b, bool Down);
};



#endif // INPUTHANDLER_H
