// $Id: Define.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef DEFINE_H
#define DEFINE_H



#define DEFAULT_LOG      "game.log"
#define DEFAULT_CONFIG   "config.ini"



#endif // DEFINE_H
