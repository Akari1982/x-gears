// $Id: Utilites.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include <string.h>
#include "Utilites.h"



int
power_of_two(int input)
{
    int value = 1;
    while ( value < input ) value <<= 1;
    return value;
}
