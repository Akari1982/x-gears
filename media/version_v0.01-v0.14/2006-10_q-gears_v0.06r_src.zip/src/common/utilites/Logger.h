// $Id: Logger.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef LOGGER_H
#define LOGGER_H
// The Log Class : Useful to write debug or info messages

#include "NoCopy.h"
#include "StdString.h"



class Logger : public NoCopy<Logger>
{
public:
    // Constructor, opens log file for writing.
    explicit Logger(const RString &logFileName);

    // Destructor, closes log file.
    virtual ~Logger();

    // Enters a message in the log. The message will be timestamped.
    void Log(const char* logText, ...);

private:
    RString mLogFile;
};



// Visible from every part of programm
extern Logger *LOGGER;



#endif // LOGGER_H
