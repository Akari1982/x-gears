// $Id: TextureFile.h 76 2006-08-25 18:41:20Z crazy_otaku $

/**
 * @brief Class for common model textures.
 */

#ifndef TEXTURE_FILE_h
#define TEXTURE_FILE_h

#include <vector>

#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/StdString.h"

#include "../../filesystem/File.h"



class TextureFile : public File
{
public:
// LIFECYCLE

    /**
     * @brief A constructor.
     *
     * Read file from given path into memory.
     * @note after creation in buffer stored unarchived file.
     * @param file - path to file that we want to open.
     */
    explicit TextureFile(const RString& file);

    /**
     * @brief A constructor.
     *
     * Create completle copy of given file.
     * @note after creation in buffer stored unarchived file.
     * @param pFile - object that we want to copy.
     */
    explicit TextureFile(File* pFile);

    /**
     * @brief A constructor.
     *
     * Create partitial copy of given file.
     * @note after creation in buffer stored unarchived file.
     * @param pFile  - object that we want to copy.
     * @param offset - offset from where we want to copy data.
     * @param length - size of data that we want ot copy.
     */
    TextureFile(File* pFile, const u32& offset, const u32& length);

    /**
     * @brief A constructor.
     *
     * Create partitial copy of given buffer.
     * @note after creation in buffer stored unarchived file.
     * @param pBuffer - buffer from which we want to create new file.
     * @param offset  - offset from where we want to copy data.
     * @param length  - size of data that we want ot copy.
     */
    TextureFile(u8* pBuffer, const u32& offset, const u32& length);

    /**
     * @brief A destructor.
     */
    virtual ~TextureFile(void);

// OPERATIONS

    /**
     * @brief Create two surfaces from texture file.
     *
     * Create two surfaces from texture file.
     * If some error is occured then two NULL pointers will be returned.
     * @warning returned pointer must be deleted to prevent memory leak.
     * @param pClut - surface of CLUT.
     * @param pVram - surface of VRam.
     */
    void GetSurfaces(Surface* pClut, Surface* pVram);

private:
    struct TextureHeader
    {
        u32 id;        /**< @brief id of image type */
        u16 vram_x;    /**< @brief x position of whole image in Video Ram */
        u16 vram_y;    /**< @brief y position of whole image in Video Ram */
        u16 move_x;    /**< @brief x position of this part of image in whole image */
        u16 move_y;    /**< @brief y position of this part of image in whole image */
        u16 width;     /**< @brief width of part of the picture */
        u16 height;    /**< @brief height of part of the picture */
    };
};



#endif // TEXTURE_FILE_h
