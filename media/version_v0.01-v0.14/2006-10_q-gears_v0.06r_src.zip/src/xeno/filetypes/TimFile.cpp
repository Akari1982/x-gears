// $Id: TimFile.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "TimFile.h"

#include "../../common/utilites/Logger.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

TimFile::TimFile(const RString& file):
    File(file)
{
    InnerGetNumberOfClut();
}



TimFile::TimFile(File* pFile):
    File(pFile)
{
    InnerGetNumberOfClut();
}



TimFile::TimFile(File* pFile, const u32& offset, const u32& length):
    File(pFile, offset, length)
{
    InnerGetNumberOfClut();
}



TimFile::TimFile(u8* pBuffer, const u32& offset, const u32& length):
    File(pBuffer, offset, length)
{
    InnerGetNumberOfClut();
}



TimFile::~TimFile(void)
{
}



//============================= OPERATIONS ===================================

Surface*
TimFile::GetSurface(const u32& clutNumber)
{
    Surface* ret = NULL;

    if (clutNumber > mClutNumber)
    {
        LOGGER->Log("Warning: 'clut_number' is greater than number of clut in file.");
        return ret;
    }

    TimHeader* tim_header  = (TimHeader*)(mpBuffer);

    // convert 4BPP tim
    if (tim_header->id_tag == 0x10 && tim_header->id_tag_clut == 0x08)
    {
        TimHeader2* tim_header2 = (TimHeader2*)((u8*)mpBuffer + sizeof(TimHeader) + tim_header->number_of_colors * tim_header->number_of_clut * 2);
        int width  = tim_header2->width * 4;
        int height = tim_header2->height;
        ret = CreateSurface(width, height);

        Clut* clut = (Clut*)malloc(sizeof(Clut) * tim_header->number_of_colors * tim_header->number_of_clut);

        for (int i = 0; i < tim_header->number_of_colors; ++i)
        {
            u16 col = GetU16LE(sizeof(TimHeader) + clutNumber * tim_header->number_of_colors * 2 + i * 2);
            clut[i].r = ((col      ) & 31) * 255 / 31;
            clut[i].g = ((col >>  5) & 31) * 255 / 31;
            clut[i].b = ((col >> 10) & 31) * 255 / 31;
            clut[i].a = (col == 0x0000) ? 0 : 255;
        }

        for (int y = height - 1; y >= 0; --y)
        {
            for (int x = 0; x < width / 2; ++x)
            {
                memcpy(ret->pixels + x * 8 + ret->width * 4 * y + 0x00, &clut[(GetU8(sizeof(TimHeader) + tim_header->number_of_colors * tim_header->number_of_clut * 2 + sizeof(TimHeader2) + y * width / 2 + x) & 0x0F)], sizeof(Clut));
                memcpy(ret->pixels + x * 8 + ret->width * 4 * y + 0x04, &clut[((GetU8(sizeof(TimHeader) + tim_header->number_of_colors * tim_header->number_of_clut * 2 + sizeof(TimHeader2) + y * width / 2 + x) & 0xF0) >> 4)], sizeof(Clut));
            }
        }

        free(clut);
    }



    // convert 8BPP tim
    else if (tim_header->id_tag == 0x10 && tim_header->id_tag_clut == 0x09)
    {
        TimHeader2* tim_header2 = (TimHeader2*)((u8*)mpBuffer + sizeof(TimHeader) + tim_header->number_of_colors * tim_header->number_of_clut * 2);
        int width  = tim_header2->width * 2;
        int height = tim_header2->height;
        ret = CreateSurface(width, height);
        Clut* clut = (Clut*)malloc(sizeof(Clut) * tim_header->number_of_colors * tim_header->number_of_clut);

        for (int i = 0; i < tim_header->number_of_colors; ++i)
        {
            u16 col = GetU16LE(sizeof(TimHeader) + clutNumber * tim_header->number_of_colors * 2 + i * 2);
            clut[i].r = ((col      ) & 31) * 255 / 31;
            clut[i].g = ((col >>  5) & 31) * 255 / 31;
            clut[i].b = ((col >> 10) & 31) * 255 / 31;
            clut[i].a = (col == 0x0000) ? 0 : 255;
        }

        for (int y = height - 1; y >= 0; --y)
        {
            for (int x = 0; x < width; ++x)
            {
                memcpy(ret->pixels + x * 4 + ret->width * 4 * y, &clut[GetU8(sizeof(TimHeader) + tim_header->number_of_colors * tim_header->number_of_clut * 2 + sizeof(TimHeader2) + y * width + x)], sizeof(Clut));
            }
        }

        free(clut);

    }
    else
    {
        LOGGER->Log("Warning: unknown format! (tim_header->id_tag = %02x) (tim_header->id_tag_clut = %02x)", tim_header->id_tag, tim_header->id_tag_clut);
        LOGGER->Log("16BPP TIM, 24BPP TIM left");
    }

    return ret;
}



//============================= ACCESS     ===================================

const u32&
TimFile::GetNumberOfClut(void) const
{
    return mClutNumber;
}



/////////////////////////////// PROTECTED  ///////////////////////////////////

//============================= OPERATIONS ===================================

void
TimFile::InnerGetNumberOfClut(void)
{
    // get number of clut
    TimHeader* tim_header = (TimHeader*)(mpBuffer);
    mClutNumber = tim_header->number_of_clut;
}
