// $Id: BinFileDriver.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef BINFILEDRIVER_H
#define BINFILEDRIVER_H


#include "../../../common/filesystem/driver/FileDriver.h"
#include "../../../common/utilites/StdString.h"

#include <map>



class BinFileDriver : public FileDriver
{
public:
             BinFileDriver();
    virtual ~BinFileDriver();

    virtual unsigned int GetFileSize(const RString &path);
    virtual bool         ReadFile(const RString &path, const void* buffer, const unsigned int start, const unsigned int length);

private:
    void MountFileSystem();
    void ClearFileDB();

    private:
        struct FileDesc
        {
            bool          isDir;
            RString       name;
            RString       root;
            unsigned int  sector;
            unsigned long size;
            unsigned int  parentId;
        };

        std::map<unsigned int, FileDesc *> mFileDB;

        RString mRoot;
};



#endif // BINFILEDRIVER_H
