// $Id: Menu.h 76 2006-08-25 18:41:20Z crazy_otaku $

/**
 * @brief Menu base module.
 */

#ifndef MENU_h
#define MENU_h

#include "../../common/TypeDefine.h"
#include "../../common/module/Module.h"



class Menu : public Module
{
public:
// LIFECYCLE

    /**
     * @brief Default constructor.
     */
    Menu(void);

    /**
     * @brief Default destructor.
     */
    virtual ~Menu(void);

// OPERATIONS

    /**
     * @brief Init module.
     */
    virtual void Init(void);

    /**
     * @brief Draw module.
     */
    virtual void Draw(void);

    /**
     * @brief Handles input.
     *
     * @param input - single input event.
     */
    virtual void Input(const InputEvent& input);

    /**
     * @brief Handles update.
     *
     * @param deltaTime - time passed from last call.
     */
    virtual void Update(const u32& deltaTime);
};



#endif // MENU_h
