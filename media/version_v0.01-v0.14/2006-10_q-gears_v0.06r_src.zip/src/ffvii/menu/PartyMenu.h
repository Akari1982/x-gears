// $Id: PartyMenu.h 76 2006-08-25 18:41:20Z crazy_otaku $

/**
 * @brief Party menu module.
 */

#ifndef PARTY_MENU_h
#define PARTY_MENU_h

#include "Menu.h"
#include "../../common/TypeDefine.h"



class PartyMenu : public Menu
{
public:
// LIFECYCLE

    /**
     * @brief Default constructor.
     */
    PartyMenu(void);

    /**
     * @brief Default destructor.
     */
    virtual ~PartyMenu(void);

// OPERATIONS

    /**
     * @brief Init module.
     */
    virtual void Init(void);

    /**
     * @brief Draw module.
     */
    virtual void Draw(void);

    /**
     * @brief Handles input.
     *
     * @param input - single input event.
     */
    virtual void Input(const InputEvent& input);

    /**
     * @brief Handles update.
     *
     * @param deltaTime - time passed from last call.
     */
    virtual void Update(const u32 &deltaTime);

private:
    /**
     * @brief Draw character info.
     *
     * @param slotChar - 1, 2 or 3 slot where character held.
     * @param x        - x coords of screen where to start draw (from left to right).
     * @param y        - y coords of screen where to start draw (from top to bottom).
     */
    void DrawCharInfo(const u32& slotChar, const s32& x, const s32& y);

private:
    bool mStartLive;       /**< @brief play start animation                                             */
    bool mStartDie;        /**< @brief play die animation                                               */
    int  mStep;            /**< @brief number of steps in animation                                     */

    int  mMenuStartY;      /**< @brief Y position from where menu start slide in start animation        */
    int  mMenuX;           /**< @brief current X position of menu                                       */
    int  mMenuY;           /**< @brief current Y position of menu                                       */
    int  mMenuFinishY;     /**< @brief final Y position of menu                                         */

    int  mPartyStartX;     /**< @brief Y position from where party start slide in start animation       */
    int  mPartyX;          /**< @brief current X position of party                                      */
    int  mPartyY;          /**< @brief current Y position of party                                      */
    int  mPartyFinishX;    /**< @brief final Y position of party                                        */

    int  mTimeStartX;      /**< @brief Y position from where time window start slide in start animation */
    int  mTimeX;           /**< @brief current X position of time window                                */
    int  mTimeY;           /**< @brief current Y position of time window                                */
    int  mTimeFinishX;     /**< @brief final Y position of time window                                  */

    int  mLocationStartY;  /**< @brief final Y position of location                                     */
    int  mLocationX;       /**< @brief current X position of location                                   */
    int  mLocationY;       /**< @brief current Y position of location                                   */
    int  mLocationFinishY; /**< @brief final Y position of location                                     */

    u32  mTimer;           /**< @brief local copy of game timer                                         */
    bool mTimerColon;      /**< @brief current color of colon in time (true - white/false - gray)       */
};



#endif // PARTY_MENU_h
