// $Id: GameDefine.h 84 2006-10-13 19:20:42Z crazy_otaku $

#ifndef GAME_DEFINE_H
#define GAME_DEFINE_H



#define APPLICATION_NAME "FFVII v0.06a"



#endif // GAME_DEFINE_H
