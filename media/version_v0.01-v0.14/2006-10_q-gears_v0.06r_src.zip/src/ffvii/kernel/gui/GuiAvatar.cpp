// $Id: GuiAvatar.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "GuiAvatar.h"
#include "../../filetypes/TimFile.h"
#include "../../../common/display/3dTypes.h"
#include "../../../common/display/Display.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/Logger.h"



GuiAvatar::GuiAvatar()
{
    mAvatarTexId[0] = LoadAvatar("data/MENU/CLOUD.TIM");
    mAvatarTexId[1] = LoadAvatar("data/MENU/BARRE.TIM");
    mAvatarTexId[2] = LoadAvatar("data/MENU/TIFA.TIM");
    mAvatarTexId[3] = LoadAvatar("data/MENU/EARITH.TIM");
    mAvatarTexId[4] = LoadAvatar("data/MENU/RED.TIM");
    mAvatarTexId[5] = LoadAvatar("data/MENU/YUFI.TIM");
    mAvatarTexId[6] = LoadAvatar("data/MENU/KETC.TIM");
    mAvatarTexId[7] = LoadAvatar("data/MENU/BINS.TIM");
    mAvatarTexId[8] = LoadAvatar("data/MENU/CIDO.TIM");
    mAvatarTexId[9] = LoadAvatar("data/MENU/PCLOUD.TIM");
    mAvatarTexId[10] = LoadAvatar("data/MENU/PCEFI.TIM");
    mAvatarTexId[11] = LoadAvatar("data/MENU/CHOCO.TIM");



    Vertex point;
    point.p.x = 0.0f;  point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f;  point.t.y = 0.0f;
    mAvatarPoly.push_back(point);
    point.p.x = 64.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 0.0f;
    mAvatarPoly.push_back(point);
    point.p.x = 64.0f; point.p.y = -64.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 1.0f;
    mAvatarPoly.push_back(point);
    point.p.x = 0.0f;  point.p.y = -64.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a =  1.0f;
    point.t.x = 0.0f;  point.t.y = 1.0f;
    mAvatarPoly.push_back(point);
}



int
GuiAvatar::LoadAvatar(const RString &name)
{
    int ret = 0;

    TimFile* image;
    Surface* texture = NULL;

    // Cloud
    image = new TimFile(name);
    texture = image->GetSurface(0);
    delete image;

    if (texture != NULL)
    {
        SetSurfaceSize(texture, 64, 64);
        ret = DISPLAY->CreateTexture(texture);
        delete texture;
    }
    else
    {
        LOGGER->Log("Can't load avatar %s.", name.c_str());
    }

    return ret;
}



GuiAvatar::~GuiAvatar()
{
    for (int i = 0; i < 12; ++i)
    {
        DISPLAY->DeleteTexture(mAvatarTexId[i]);
    }
}



void
GuiAvatar::DrawAvatar(const int &x, const int &y, const unsigned char &avatar_id)
{
    DISPLAY->Translate(x, -y, 0);
    DISPLAY->PushMatrix();

    if (avatar_id >= 12)
    {
        LOGGER->Log("Unidentify avatar id %d.", avatar_id);
        return;
    }

    DISPLAY->SetTexture(mAvatarTexId[avatar_id]);
    DISPLAY->DrawQuads(mAvatarPoly);
    DISPLAY->UnsetTexture();
    DISPLAY->PopMatrix();
}
