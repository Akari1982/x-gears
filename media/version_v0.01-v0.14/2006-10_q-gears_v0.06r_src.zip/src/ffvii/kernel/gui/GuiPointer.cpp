// $Id: GuiPointer.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "GuiPointer.h"
#include "../../../common/display/3dTypes.h"
#include "../../../common/display/Display.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/Logger.h"



GuiPointer::GuiPointer(Surface* image, Surface* image2)
{
    Surface* temp;

    // to left pointer
    temp = CreateSubSurface(200, 8, 24, 16, image);
    SetSurfaceSize(temp, 32, 16);
    mPointerTexId[0] = DISPLAY->CreateTexture(temp);
    delete temp;
    // to right pointer
    temp = CreateSubSurface(224, 8, 24, 16, image);
    SetSurfaceSize(temp, 32, 16);
    mPointerTexId[1] = DISPLAY->CreateTexture(temp);
    delete temp;
    // to right cross pointer
    temp = CreateSubSurface(40, 16, 24, 16, image2);
    SetSurfaceSize(temp, 32, 16);
    mPointerTexId[2] = DISPLAY->CreateTexture(temp);
    delete temp;



    Vertex point;
    point.p.x = 0.0f;  point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f;  point.t.y = 0.0f;
    mPointerPoly.push_back(point);
    point.p.x = 32.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 0.0f;
    mPointerPoly.push_back(point);
    point.p.x = 32.0f; point.p.y = -16.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 1.0f;
    mPointerPoly.push_back(point);
    point.p.x = 0.0f;  point.p.y = -16.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a =  1.0f;
    point.t.x = 0.0f;  point.t.y = 1.0f;
    mPointerPoly.push_back(point);
}



GuiPointer::~GuiPointer()
{
    DISPLAY->DeleteTexture(mPointerTexId[0]);
    DISPLAY->DeleteTexture(mPointerTexId[1]);
    DISPLAY->DeleteTexture(mPointerTexId[2]);
}



void
GuiPointer::DrawPointer(const int &x, const int &y, const PointerType &type)
{
    DISPLAY->Translate(x, -y, 0);
    DISPLAY->PushMatrix();

    switch (type)
    {
        case TO_LEFT        : DISPLAY->SetTexture(mPointerTexId[0]); break;
        case TO_RIGHT       : DISPLAY->SetTexture(mPointerTexId[1]); break;
        case TO_RIGHT_CROSS : DISPLAY->SetTexture(mPointerTexId[2]); break;
        default             : LOGGER->Log("Unidentify pointer type %d.", static_cast<int>(type)); return;
    }
    DISPLAY->DrawQuads(mPointerPoly);
    DISPLAY->UnsetTexture();

    DISPLAY->PopMatrix();
}
