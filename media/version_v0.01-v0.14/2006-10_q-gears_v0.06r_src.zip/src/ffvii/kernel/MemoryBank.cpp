// $Id: MemoryBank.cpp 81 2006-09-28 15:35:24Z crazy_otaku $

#include "MemoryBank.h"
#include "Kernel.h"
#include "../../common/utilites/Logger.h"

#include <memory>



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

MemoryBank::MemoryBank(void):
    mpMemoryBank56(0)
{
    mpMemoryBank56 = (u8*)malloc(sizeof(u8) * 256);
}



MemoryBank::~MemoryBank(void)
{
    free(mpMemoryBank56);
}



//============================= OPERATIONS ===================================

void
MemoryBank::Put(const u8& memoryBank, const u8& offset, const u8& value)
{
    switch (memoryBank)
    {
        // savemap bank
        case 0x1 : case 0x2 : KERNEL->GetGamestate().mSavemap.MemoryBank12[offset] = value; break;
        case 0x3 : case 0x4 : KERNEL->GetGamestate().mSavemap.MemoryBank34[offset] = value; break;
        case 0x7 : case 0xF : KERNEL->GetGamestate().mSavemap.MemoryBank7F[offset] = value; break;
        case 0xB : case 0xC : KERNEL->GetGamestate().mSavemap.MemoryBankBC[offset] = value; break;
        case 0xD : case 0xE : KERNEL->GetGamestate().mSavemap.MemoryBankDE[offset] = value; break;
        // temp bank
        case 0x5 : case 0x6 : mpMemoryBank56[offset] = value;                               break;
    }
}



void
MemoryBank::Put(const u8& memoryBank, const u8& offset, const u16& value)
{
    if (offset == 255)
    {
        LOGGER->Log("Try to put u16 value in last byte in MemoryBank::Put();.");
        return;
    }

    u8 lower = static_cast<u8>(value & 0x00FF);
    u8 upper = static_cast<u8>(value >> 8);

    switch (memoryBank)
    {
        // savemap bank
        case 0x1 : case 0x2 : KERNEL->GetGamestate().mSavemap.MemoryBank12[offset] = lower;
                              KERNEL->GetGamestate().mSavemap.MemoryBank12[offset + 1] = upper; break;
        case 0x3 : case 0x4 : KERNEL->GetGamestate().mSavemap.MemoryBank34[offset] = lower;
                              KERNEL->GetGamestate().mSavemap.MemoryBank34[offset + 1] = upper; break;
        case 0x7 : case 0xF : KERNEL->GetGamestate().mSavemap.MemoryBank7F[offset] = lower;
                              KERNEL->GetGamestate().mSavemap.MemoryBank7F[offset + 1] = upper; break;
        case 0xB : case 0xC : KERNEL->GetGamestate().mSavemap.MemoryBankBC[offset] = lower;
                              KERNEL->GetGamestate().mSavemap.MemoryBankBC[offset + 1] = upper; break;
        case 0xD : case 0xE : KERNEL->GetGamestate().mSavemap.MemoryBankDE[offset] = lower;
                              KERNEL->GetGamestate().mSavemap.MemoryBankDE[offset + 1] = upper; break;
        // temp bank
        case 0x5 : case 0x6 : mpMemoryBank56[offset] = lower;
                              mpMemoryBank56[offset + 1] = upper;                               break;
    }
}



u8
MemoryBank::Get(const u8& memoryBank, const u8& offset)
{
    u8 ret = 0;

    switch (memoryBank)
    {
        // savemap bank
        case 0x1 : case 0x2 : ret = KERNEL->GetGamestate().mSavemap.MemoryBank12[offset]; break;
        case 0x3 : case 0x4 : ret = KERNEL->GetGamestate().mSavemap.MemoryBank34[offset]; break;
        case 0x7 : case 0xF : ret = KERNEL->GetGamestate().mSavemap.MemoryBank7F[offset]; break;
        case 0xB : case 0xC : ret = KERNEL->GetGamestate().mSavemap.MemoryBankBC[offset]; break;
        case 0xD : case 0xE : ret = KERNEL->GetGamestate().mSavemap.MemoryBankDE[offset]; break;
        // temp bank
        case 0x5 : case 0x6 : ret = mpMemoryBank56[offset];                                   break;
        // immediate value
        case 0x0 : ret = offset;
    }

    return ret;
}



u16
MemoryBank::Get(const u8& memoryBank, const u16& offset)
{
    u16 ret = 0;

    if (offset == 255)
    {
        LOGGER->Log("Try to get u16 value from last byte in MemoryBank::Get();.");
        return ret;
    }

    u16 lower = 0;
    u16 upper = 0;

    switch (memoryBank)
    {
        // savemap bank
        case 0x1 : case 0x2 : lower = KERNEL->GetGamestate().mSavemap.MemoryBank12[offset];
                              upper = KERNEL->GetGamestate().mSavemap.MemoryBank12[offset + 1]; break;
        case 0x3 : case 0x4 : lower = KERNEL->GetGamestate().mSavemap.MemoryBank34[offset];
                              upper = KERNEL->GetGamestate().mSavemap.MemoryBank34[offset + 1]; break;
        case 0x7 : case 0xF : lower = KERNEL->GetGamestate().mSavemap.MemoryBank7F[offset];
                              upper = KERNEL->GetGamestate().mSavemap.MemoryBank7F[offset + 1]; break;
        case 0xB : case 0xC : lower = KERNEL->GetGamestate().mSavemap.MemoryBankBC[offset];
                              upper = KERNEL->GetGamestate().mSavemap.MemoryBankBC[offset + 1]; break;
        case 0xD : case 0xE : lower = KERNEL->GetGamestate().mSavemap.MemoryBankDE[offset];
                              upper = KERNEL->GetGamestate().mSavemap.MemoryBankDE[offset + 1]; break;
        // temp bank
        case 0x5 : case 0x6 : lower = mpMemoryBank56[offset];
                              upper = mpMemoryBank56[offset + 1];                               break;
        // immediate value
        case 0x0 :            ret = offset;
    }

    // swap bytes
    if (upper != 0 || lower != 0)
    {
        ret = (upper << 8) | (lower);
    }

    return ret;
}
