// $Id: GameState.h 82 2006-09-30 06:46:19Z crazy_otaku $

#ifndef GAMESTATE_H
#define GAMESTATE_H
// The Gamestate Class : Contain all info about current game state



#include "Savemap.h"
#include "../../common/utilites/NoCopy.h"



// forward declaration
class Kernel;
class MemoryBank;



class Gamestate : public NoCopy<Gamestate>
{
    friend class Kernel;
    friend class MemoryBank;

public:
                     Gamestate();
    virtual         ~Gamestate();

    const Savemap&   GetSavemap() const;
    void             DumpSavemap();

    void             Update();

    // timer
    void             StartTimer(void);
    void             StopTimer(void);

private:
    Savemap mSavemap;



    // game timer
    bool    mTimerStarted;
};



#endif // GAMESTATE_H
