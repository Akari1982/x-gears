// $Id$

#ifndef GATEWAY_h
#define GATEWAY_h

#include "../../common/TypeDefine.h"

#include "Trigger.h"

class FieldModule;



class Gateway : public Trigger
{
public:
    Gateway(FieldModule* pFieldModule, const Vector3& point1, const Vector3& point2, const Vector3& position, const u16& mapId);

    virtual ~Gateway(void);

    void Action(void);

private:
    FieldModule* mpFieldModule; /**< @brief feed back to field module */

    Vector3      mPosition;
    u16          mMapId;
};



#endif // GATEWAY_h
