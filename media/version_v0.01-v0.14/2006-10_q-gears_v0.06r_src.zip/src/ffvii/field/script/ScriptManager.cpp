// $Id: ScriptManager.cpp 82 2006-09-30 06:46:19Z crazy_otaku $

#include "Entity.h"
#include "ScriptManager.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

ScriptManager::ScriptManager(FieldModule* pFieldModule):
    mpFieldModule(pFieldModule)
{
}



ScriptManager::~ScriptManager(void)
{
    Clear();
}



//============================= OPERATIONS ===================================

void
ScriptManager::Clear(void)
{
    for (int i = 0; i < mEntities.size(); ++i)
    {
        delete mEntities[i];
    }
    mEntities.clear();
}



void
ScriptManager::Run()
{
    for (int i = 0; i < mEntities.size(); ++i)
    {
        mEntities[i]->Run(mpFieldModule);
    }
}



void
ScriptManager::RequestRun(const u8& entityId, const u8& priority, const u8& scriptId)
{
    mEntities[entityId]->RequestRun(priority, scriptId);
}



void
ScriptManager::PushEntity(Entity* pEntity)
{
    mEntities.push_back(pEntity);
}
