// $Id: Entity.cpp 83 2006-10-08 06:55:30Z crazy_otaku $

#include "Entity.h"

#include <cassert>



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

Entity::Entity(void):
    mInited(false),
    mBaseOffset(0),
    mUnitId(-1)
{
    // initialize script array
    for (int i = 0; i < 32; ++i)
    {
        mScript[i] = NULL;
    }

    // initialize queue
    for (int i = 0; i < 8; ++i)
    {
        // -1 means no script
        mScriptQueue[i].id       = -1;
        mScriptQueue[i].position = 0;
    }

    // init and base scripts are always in priority 8
    mScriptQueue[7].id       = 0;
    mScriptQueue[7].position = 0;
}



Entity::~Entity(void)
{
    for (int i = 0; i < 32; ++i)
    {
        if (mScript[i] != 0)
        {
            delete mScript[i];
        }
    }
}



//============================= OPERATIONS ===================================

void
Entity::Run(FieldModule* fieldModule)
{
    // if we initialize
    if (mInited == false)
    {
        // must be run once... not with sync effects
        mScriptQueue[7].position = mBaseOffset = mScript[0]->Run(fieldModule, this, 0, true);
        mInited = true;
    }
    else
    {
        for (int i = 0; i < 8; ++i)
        {
            if (mScriptQueue[i].id != -1 && mScript[mScriptQueue[i].id] != NULL)
            {
                mScriptQueue[i].position = mScript[mScriptQueue[i].id]->Run(fieldModule, this, mScriptQueue[i].position, false);

                // if script finished it work
                if (mScriptQueue[i].position == -1)
                {
                    if (i == 7)
                    {
                        // if we run base script
                        mScriptQueue[i].position = mBaseOffset;
                    }
                    else
                    {
                        mScriptQueue[i].id       = -1;
                        mScriptQueue[i].position = 0;
                    }
                }

                break;
            }
        }
    }
}



void
Entity::RequestRun(const u8& priority, const u8& scriptId)
{
    printf("Request run script %02x at priority %02x\n", scriptId, priority);

    if (mScriptQueue[priority].id == -1)
    {
        mScriptQueue[priority].id       = scriptId;
        mScriptQueue[priority].position = 0;
    }
}



void
Entity::AddScript(const u8& id, Script* script)
{
    assert(id < 32);

    mScript[id] = script;
}



//============================= ACCESS     ===================================

void
Entity::SetName(const RString& name)
{
    mName = name;
}



void
Entity::SetUnitId(const s8& id)
{
    mUnitId = id;
}



const s8&
Entity::GetUnitId(void)
{
    return mUnitId;
}
