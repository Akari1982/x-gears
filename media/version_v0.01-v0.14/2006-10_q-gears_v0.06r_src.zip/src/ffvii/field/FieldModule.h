// $Id: FieldScreen.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef FIELDSCREEN_H
#define FIELDSCREEN_H



#include "DatFile.h"
#include "UnitManager.h"
#include "WindowManager.h"
#include "script/ScriptManager.h"
#include "../kernel/MemoryBank.h"
#include "../../common/module/Module.h"
#include "../../common/display/3dTypes.h"

#include <string>
#include <vector>

// forward declaration
class Script;



class FieldModule : public Module
{
friend class Script;
friend class WindowManager;

public:
    FieldModule();
    virtual ~FieldModule();

    virtual void Init();

    virtual void Input(const InputEvent &input);

    virtual void Update(const u32& delta_time);

    virtual void Draw();

    void RequestLoadMap(const u16& id);

    // we cant give id by reference because we may delete caller when clear map resources.
    void LoadMap(const u16 id);

private:
    void DrawDebugInfo(void) const;
    void DrawPosibleActions(void) const;

private:
    MemoryBank              mMemoryBank; /**< @brief memory bank instance */



    std::vector<Vertex>     mAxis;

    // engine managing
    bool                    mViewAxis;
    bool                    mViewFromCamera;



    // map loading related
    u16                     mRequestedMapId;



    // map related
    ScriptManager*          mpScriptManager;
    UnitManager*            mpUnitManager;
    WindowManager*          mpWindowManager;

    float                   mScale;
    Matrix                  mMatrix;
};



#endif // FIELDSCREEN_H
