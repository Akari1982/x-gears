// $Id$

#include "../../common/display/Display.h"
#include "../../common/utilites/Logger.h"

#include "Math.h"
#include "UnitManager.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

UnitManager::UnitManager(FieldModule* pFieldModule):
    mpFieldModule(pFieldModule),
    mMoveForward(false),
    mMoveBack(false),
    mMoveLeft(false),
    mMoveRight(false)
{
}



UnitManager::~UnitManager(void)
{
    Clear();
}



//============================= OPERATIONS ===================================

void
UnitManager::Clear(void)
{
    // clear character
    for (u8 i = 0; i < mUnits.size(); ++i)
    {
        delete mUnits[i].model;
    }
    mUnits.clear();



    // clear walkmesh data
    mWalkMesh.clear();
    for (u8 i = 0; i < mGateways.size(); ++i)
    {
        delete mGateways[i];
    }
    mGateways.clear();
}



void
UnitManager::Draw(void)
{
    std::vector<Vertex> line;
    line.resize(2);

    Vertex v;
    Color color_grant(217.0f / 255.0f, 217.0f / 255.0f, 217.0f / 255.0f, 1.0f);
    Color color_deny(191.0f / 255.0f, 0.0f, 0.0f, 1.0f);
    Color color_point(0.0f, 0.0f, 217.0f / 255.0f, 1.0f);

    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->SetLineWidth(1);
    DISPLAY->SetPointSize(3);

    for (u8 i = 0; i < mWalkMesh.size(); ++i)
    {
        // if this triangle is accessible
        // if we allowed to cross border
        // and if triangle to which we can cross is allowed
        v.c = (mWalkMesh[i].accessible == true && mWalkMesh[i].access[0] != 0xFFFF && mWalkMesh[mWalkMesh[i].access[0]].accessible == true) ? color_grant : color_deny;
        v.p.x = mWalkMesh[i].A.x; v.p.y = mWalkMesh[i].A.y; v.p.z = mWalkMesh[i].A.z;
        line[0] = v;
        v.p.x = mWalkMesh[i].B.x; v.p.y = mWalkMesh[i].B.y; v.p.z = mWalkMesh[i].B.z;
        line[1] = v;
        DISPLAY->DrawLines(line);
        line[0].c = color_point;
        line[1].c = color_point;
        DISPLAY->DrawPoints(line);

        v.c = (mWalkMesh[i].accessible == true && mWalkMesh[i].access[1] != 0xFFFF && mWalkMesh[mWalkMesh[i].access[1]].accessible == true) ? color_grant : color_deny;
        v.p.x = mWalkMesh[i].B.x; v.p.y = mWalkMesh[i].B.y; v.p.z = mWalkMesh[i].B.z;
        line[0] = v;
        v.p.x = mWalkMesh[i].C.x; v.p.y = mWalkMesh[i].C.y; v.p.z = mWalkMesh[i].C.z;
        line[1] = v;
        DISPLAY->DrawLines(line);
        line[0].c = color_point;
        line[1].c = color_point;
        DISPLAY->DrawPoints(line);

        v.c = (mWalkMesh[i].accessible == true && mWalkMesh[i].access[2] != 0xFFFF && mWalkMesh[mWalkMesh[i].access[2]].accessible == true) ? color_grant : color_deny;
        v.p.x = mWalkMesh[i].A.x; v.p.y = mWalkMesh[i].A.y; v.p.z = mWalkMesh[i].A.z;
        line[0] = v;
        v.p.x = mWalkMesh[i].C.x; v.p.y = mWalkMesh[i].C.y; v.p.z = mWalkMesh[i].C.z;
        line[1] = v;
        DISPLAY->DrawLines(line);
        line[0].c = color_point;
        line[1].c = color_point;
        DISPLAY->DrawPoints(line);
    }

    DISPLAY->SetPolygonMode(POLYGON_FILL);



    // draw character
    for (u8 i = 0; i < mUnits.size(); ++i)
    {
        if (mUnits[i].visible == true)
        {
            DISPLAY->PushMatrix();
            DISPLAY->Translate(mUnits[i].position.x, mUnits[i].position.y, mUnits[i].position.z);
            DISPLAY->RotateY(360 * mUnits[i].direction / 255);
            mUnits[i].model->Draw();
            DISPLAY->PopMatrix();
        }
    }



    // draw triggers
    for (u8 i = 0; i < mGateways.size(); ++i)
    {
        mGateways[i]->Draw();
    }
}



bool
UnitManager::Input(const InputEvent &input)
{
    bool ret = false;

    // handle left input ourself
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_UP:    mMoveForward = true; ret = true; break;
            case KEY_DOWN:  mMoveBack    = true; ret = true; break;
            case KEY_LEFT:  mMoveRight   = true; ret = true; break;
            case KEY_RIGHT: mMoveLeft    = true; ret = true; break;
        }
    }

    if (input.type == IET_RELEASE)
    {
        switch (input.button)
        {
            case KEY_UP:    mMoveForward = false; ret = true; break;
            case KEY_DOWN:  mMoveBack    = false; ret = true; break;
            case KEY_LEFT:  mMoveRight   = false; ret = true; break;
            case KEY_RIGHT: mMoveLeft    = false; ret = true; break;
        }
    }

    return ret;
}



void
UnitManager::Update(const u32& deltaTime)
{
    static float step = 20.0f;
    Vector3 next_step(0.0f, 0.0f, 0.0f);

    if (mMoveForward)
    {
        next_step.z =  step;
    }

    if (mMoveBack)
    {
        next_step.z = -step;
    }

    if (mMoveLeft)
    {
        next_step.x =  step;
    }

    if (mMoveRight)
    {
        next_step.x = -step;
    }

    if ((next_step.x != 0.0f || next_step.z != 0.0f) &&
         mUnits[mPC].pc           == true &&
         mUnits[mPC].position_set == true &&
         mUnits[mPC].visible      == true)
    {
        SetNextStep(next_step, false);
        CheckTriggers(mUnits[mPC].model->GetCollision(), mPC);
    }
}



void
UnitManager::AddWalkMeshTriangle(const WalkMeshTriangle& triangle)
{
    mWalkMesh.push_back(triangle);
}



void
UnitManager::AddGateway(const Vector3& point1, const Vector3& point2, const Vector3& position, const u16& mapId)
{
    Gateway* gateway = new Gateway(mpFieldModule, point1, point2, position, mapId);
    mGateways.push_back(gateway);
}



const s8
UnitManager::AddChar(const u8& characterId)
{
    UnitData unit;

    Model* model = new Model();
    unit.model = model;

    mUnits.push_back(unit);

    return mUnits.size() - 1;
}



void
UnitManager::SetPC(const s8& unitId, const u8& playableId)
{
    if (unitId < 0 || unitId >= mUnits.size())
    {
        return;
    }

    mUnits[unitId].pc    = true;
    mUnits[unitId].pc_id = playableId;

    if (playableId == 0)
    {
        mPC = unitId;
    }
}



void
UnitManager::SetXYCoords(const s8& unitId, const float& x, const float& y)
{
    if (unitId < 0 || unitId >= mUnits.size() || mUnits[unitId].position_set == true)
    {
        return;
    }

    mUnits[unitId].position.x = x;
    mUnits[unitId].position.y = y;
}



void
UnitManager::SetZCoords(const s8& unitId, const float& z)
{
    if (unitId < 0 || unitId >= mUnits.size() || mUnits[unitId].position_set == true)
    {
        return;
    }

    mUnits[unitId].position.z = z;
}



void
UnitManager::SetTriangle(const s8& unitId, const u16& triangle)
{
    if (unitId < 0 || unitId >= mUnits.size() || mUnits[unitId].position_set == true)
    {
        return;
    }

    mUnits[unitId].triangle = triangle;
}



void
UnitManager::SetPosition(const s8& unitId)
{
    if (unitId < 0 || unitId >= mUnits.size() || mUnits[unitId].position_set == true)
    {
        return;
    }

    // fix unit position
    mUnits[unitId].position_set = true;

    // show it on map
    mUnits[unitId].visible = true;
}



void
UnitManager::SetDirection(const s8& unitId, const u8& direction)
{
    if (unitId < 0 || unitId >= mUnits.size())
    {
        return;
    }

    mUnits[unitId].direction = direction;
}



void
UnitManager::SetTriangleAccess(const u16& triangleId, const u8& lock)
{
    if (triangleId < 0 || triangleId >= mWalkMesh.size())
    {
        return;
    }

    mWalkMesh[triangleId].accessible = (lock == 1) ? false : true;
}



void
UnitManager::SetWalkMeshCoords(const u16& triangleIndex)
{
    Vector3 coords;

    float x1 = mWalkMesh[triangleIndex].A.x;
    float y1 = mWalkMesh[triangleIndex].A.y;
    float z1 = mWalkMesh[triangleIndex].A.z;

    float x2 = mWalkMesh[triangleIndex].B.x;
    float y2 = mWalkMesh[triangleIndex].B.y;
    float z2 = mWalkMesh[triangleIndex].B.z;

    float x3 = mWalkMesh[triangleIndex].C.x;
    float y3 = mWalkMesh[triangleIndex].C.y;
    float z3 = mWalkMesh[triangleIndex].C.z;

    // get points of line that crosses in center of triangle
    float xc1 = x1 + (x2 - x1) * 0.5f;
    float zc1 = z1 + (z2 - z1) * 0.5f;

    float xc2 = x1 + (x3 - x1) * 0.5f;
    float zc2 = z1 + (z3 - z1) * 0.5f;

    // find coords of point in center of triangle
    float t = ((zc1 - zc2) * (x2 - xc1) - (xc1 - xc2) * (z2 - zc1)) / (( x3 - xc1) * (z2 - zc2) - ( z3 - zc1) * (x2 - xc2));

    float x = xc1 + (x3 - xc1) * t;
    float z = zc1 + (z3 - zc1) * t;

    coords.x = x;
    coords.y = point_elevation(Vector3(x, 0, z), mWalkMesh[triangleIndex].A, mWalkMesh[triangleIndex].B, mWalkMesh[triangleIndex].C);
    coords.z = z;

    mUnits[mPC].position = coords;
}



void
UnitManager::SetNextStep(const Vector3& moveVector, const bool slide)
{
    // if we are not moving anywhere
    if (moveVector.x == 0.0f && moveVector.y == 0.0f && moveVector.z == 0.0f)
    {
        return;
    }



    u16 triangle = mUnits[mPC].triangle;
    u16 prev_triangle = 0xFFFE; // number of triangles never must be such great

    Vector3 start_point = mUnits[mPC].position;
    Vector3 end_point(mUnits[mPC].position.x + moveVector.x,
                      mUnits[mPC].position.y + moveVector.y,
                      mUnits[mPC].position.z + moveVector.z);

    for (;;)
    {
        Vector3 A = mWalkMesh[triangle].A;
        Vector3 B = mWalkMesh[triangle].B;
        Vector3 C = mWalkMesh[triangle].C;



        // check if we cross board of current triangle
        u8 cross = 0x00;
        // if we cross line 1
        if      (line_crossing(start_point, end_point, A, B) == true && mWalkMesh[triangle].access[0] != prev_triangle)
        {
            cross = 0x01;
        }
        // if we cross line 2
        else if (line_crossing(start_point, end_point, B, C) == true && mWalkMesh[triangle].access[1] != prev_triangle)
        {
            cross = 0x02;
        }
        // if we cross line 3
        else if (line_crossing(start_point, end_point, A, C) == true && mWalkMesh[triangle].access[2] != prev_triangle)
        {
            cross = 0x03;
        }

        // if we do not cross border
        if (cross == 0x00)
        {
            end_point.y = point_elevation(end_point, A, B, C);
            mUnits[mPC].triangle = triangle;
//            LOGGER->Log("final triangle = %d", triangle);
            mUnits[mPC].position = end_point;
            break;
        }
        else
        {
            // if board can be crossed
            if (mWalkMesh[triangle].accessible == true &&
                mWalkMesh[triangle].access[cross - 1] != 0xFFFF &&
                mWalkMesh[mWalkMesh[triangle].access[cross - 1]].accessible == true)
            {
                // if line crosses corner of the triangle move final point a bit and recheck all things
                if (point_on_line(A, start_point, end_point) == true ||
                    point_on_line(B, start_point, end_point) == true ||
                    point_on_line(C, start_point, end_point) == true)
                {
//                    LOGGER->Log("We try to cross corner of triangle");
                    end_point.z += 0.01f;
                    end_point.x += 0.01f;
                    continue;
                }

                prev_triangle = triangle;
                triangle      = mWalkMesh[triangle].access[cross - 1];
//                LOGGER->Log("cross = %d, prev_triangle = %d, triangle = %d", cross, prev_triangle, triangle);
            }
            else
            {
                if (slide == false)
                {
                    Vector3 sp1 = (cross == 1 || cross == 3) ? A : B;
                    Vector3 sp2 = (cross == 1) ? B : C;

//                    LOGGER->Log("we met border");
                    Vector3 new_move = get_projection_on_line(moveVector, sp1, sp2);
                    SetNextStep(new_move, true);
//                    LOGGER->Log("we slide");
                }
                else
                {
//                    LOGGER->Log("we met border");
//                    LOGGER->Log("we can't slide");
                }

                break;
            }
        }
    }
}



void
UnitManager::CheckTriggers(const Collision& collision, const s8& unitId)
{
    if (unitId < 0 || unitId >= mUnits.size())
    {
        return;
    }

    for (u8 i = 0; i < mGateways.size(); ++i)
    {
        mGateways[i]->CheckCollision(mUnits[unitId].position, collision);
    }
}
