// $Id: Model.cpp 84 2006-10-13 19:20:42Z crazy_otaku $

#include "../../common/display/Display.h"

#include "Model.h"



Model::Model(void)
{
    Vector3 point;
    point.x = -20.0f; point.y =   0.0f; point.z =  20.0f;
    mCollision.mPoints[0] = point;

    point.x =  20.0f; point.y =   0.0f; point.z =  20.0f;
    mCollision.mPoints[1] = point;

    point.x =  20.0f; point.y =   0.0f; point.z = -20.0f;
    mCollision.mPoints[2] = point;

    point.x = -20.0f; point.y =   0.0f; point.z = -20.0f;
    mCollision.mPoints[3] = point;

    point.x = -20.0f; point.y =  50.0f; point.z =  20.0f;
    mCollision.mPoints[4] = point;

    point.x =  20.0f; point.y =  50.0f; point.z =  20.0f;
    mCollision.mPoints[5] = point;

    point.x =  20.0f; point.y =  50.0f; point.z = -20.0f;
    mCollision.mPoints[6] = point;

    point.x = -20.0f; point.y =  50.0f; point.z = -20.0f;
    mCollision.mPoints[7] = point;
}



Model::~Model(void)
{
}



void
Model::Draw(void)
{
    mCollision.Draw();
}



const Collision&
Model::GetCollision(void)
{
    return mCollision;
}
