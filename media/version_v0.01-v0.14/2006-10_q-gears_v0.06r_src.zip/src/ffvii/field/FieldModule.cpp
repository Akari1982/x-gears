// $Id$

#include <libxml/tree.h>

#include "../../common/display/Display.h"
#include "../../common/filesystem/RealFileSystem.h"
#include "../../common/module/ModuleManager.h"
#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "DatFile.h"
#include "FieldModule.h"
#include "FieldUtilites.h"
#include "script/Entity.h"
#include "script/Script.h"
#include "../kernel/Kernel.h"
#include "../menu/PartyMenu.h"



#define READ_PROP(node, prop, name, target, cast) \
        prop = xmlGetProp(node, BAD_CAST name); \
        if (prop) { \
            target = cast((const char*)prop); \
            xmlFree(prop); \
        }



FieldModule::FieldModule():
    mRequestedMapId(0),

    mViewAxis(true),
    mViewFromCamera(true)
{
    mpScriptManager = new ScriptManager(this);
    mpUnitManager   = new UnitManager(this);
    mpWindowManager = new WindowManager(this);

    Init();
}



FieldModule::~FieldModule()
{
    delete mpScriptManager;
    delete mpUnitManager;
    delete mpWindowManager;
}



void
FieldModule::Init()
{
    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
    DISPLAY->SetAlphaTest(true);
    DISPLAY->SetBlendMode(BLEND_NORMAL);
    DISPLAY->SetCullMode(CULL_NONE);

    Vertex point;
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 0.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 500.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 0.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 1.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 500.0f; point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 1.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 0.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 500.0f;
    point.c.r = 0.0f;   point.c.g = 0.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    mAxis.push_back(point);



    // load init map
    LoadMap(0x41);
}



void
FieldModule::LoadMap(const u16 id)
{
    // check if this is field file (not worldmap)
    if (id < 0x41)
    {
        LOGGER->Log("Tried to load worldmap with mapId = %04x.", id);
        return;
    }

    mpWindowManager->Clear();
    mpScriptManager->Clear();
    mpUnitManager->Clear();



    // read info from DAT file
    DatFile* dat = new DatFile("data/FIELD/" + MapIdToRString(id) + ".DAT");

    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log("Load field %s", dat->GetFileName().c_str());
    }



    u8 dialogs  = 0;
    u8 entitys  = 0;
    u8 gateways = 0;

    // try to find xml file of this field
    RString xml_file_name = "data/FIELD/" + MapIdToRString(id) + ".xml";

    u32 buffer_size = REALFILESYSTEM->GetFileSize(xml_file_name);
    // if it exist read properties
    if (buffer_size > 0)
    {
        u8* p_buffer = (u8*)malloc(sizeof(u8) * buffer_size);
        REALFILESYSTEM->ReadFile(xml_file_name, p_buffer, 0, buffer_size);

        xmlDocPtr doc = xmlParseMemory((const char*)p_buffer, buffer_size);

        xmlNodePtr node = xmlDocGetRootElement(doc);

        if (!node || !xmlStrEqual(node->name, BAD_CAST "field"))
        {
            LOGGER->Log("Field XML Manager: %s is not a valid field file! No <field> in root.\n", xml_file_name.c_str());
        }
        else
        {
            xmlChar* prop = NULL;
            READ_PROP(node, prop, "dialogs",  dialogs,  atoi);
            READ_PROP(node, prop, "entitys",  entitys,  atoi);
            READ_PROP(node, prop, "gateways", gateways, atoi);

            for (node = node->xmlChildrenNode; node != NULL; node = node->next)
            {
                // load dialogs from xml
                if (dialogs && xmlStrEqual(node->name, BAD_CAST "dialogs"))
                {
                    for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                    {
                        if (!xmlStrEqual(node_2->name, BAD_CAST "dialog"))
                        {
                            continue;
                        }

                        // add dialog to mpWindowManager
                        RString dialog((const char*)node_2->xmlChildrenNode->content, strlen((const char*)node_2->xmlChildrenNode->content));
                        mpWindowManager->AddDialog(RStringToFFVIIString(dialog));
                    }
                }

                // load entity and scripts from xml
                if (entitys && xmlStrEqual(node->name, BAD_CAST "entitys"))
                {
                    for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                    {
                        if (!xmlStrEqual(node_2->name, BAD_CAST "entity"))
                        {
                            continue;
                        }

                        Entity* entity = new Entity();

                        RString name = "";
                        READ_PROP(node_2, prop, "name", name, );
                        entity->SetName(name);

                        u8 script_number = 0;

                        for (xmlNodePtr node_3 = node_2->xmlChildrenNode; node_3 != NULL; node_3 = node_3->next)
                        {
                            if (!xmlStrEqual(node_3->name, BAD_CAST "script"))
                            {
                                continue;
                            }

                            u32 script_size = 0;
                            u8* script_buffer = NULL;
                            script_buffer = OpcodesToRawScript((u8*)node_3->xmlChildrenNode->content, strlen((const char*)node_3->xmlChildrenNode->content), script_size);

                            if (script_buffer != NULL)
                            {
                                Script* script = new Script(script_buffer, script_size);
                                entity->AddScript(script_number, script);
                                ++script_number;
                            }
                        }

                        mpScriptManager->PushEntity(entity);
                    }
                }

                // load gateways from xml
                if (gateways && xmlStrEqual(node->name, BAD_CAST "gateways"))
                {
                    for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                    {
                        if (!xmlStrEqual(node_2->name, BAD_CAST "gateway"))
                        {
                            continue;
                        }

                        // add gateway to mpUnitManager
                        int x1, y1, z1, x2, y2, z2, x3, y3, z3, map_id;
                        READ_PROP(node_2, prop, "x1", x1, atoi); 
                        READ_PROP(node_2, prop, "y1", y1, atoi);
                        READ_PROP(node_2, prop, "z1", z1, atoi);
                        READ_PROP(node_2, prop, "x2", x2, atoi);
                        READ_PROP(node_2, prop, "y2", y2, atoi);
                        READ_PROP(node_2, prop, "z2", z2, atoi);
                        READ_PROP(node_2, prop, "x3", x3, atoi);
                        READ_PROP(node_2, prop, "y3", y3, atoi);
                        READ_PROP(node_2, prop, "z3", z3, atoi);
                        READ_PROP(node_2, prop, "map_id", map_id, atoi);

                        Vector3 point1(x1, y1, z1);
                        Vector3 point2(x2, y2, z2);
                        Vector3 position(x3, y3, z3);

                        mpUnitManager->AddGateway(point1, point2, position, map_id);
                    }
                }
            }
        }
        xmlFreeDoc(doc);
        free(p_buffer);
    }



    // load standart data (not xml)
    if (!dialogs)
    {
        dat->GetDialogs(mpWindowManager);
    }
    if (!entitys)
    {
        dat->GetScripts(mpScriptManager);
    }
    dat->GetWalkMesh(mpUnitManager);
    if (!gateways)
    {
        dat->GetGateway(mpUnitManager);
    }
    dat->GetCameraMatrix(mMatrix);

    // we dont know how set scale yet
    mScale = 1.0f;

    delete dat;
}



void
FieldModule::RequestLoadMap(const u16& id)
{
    mRequestedMapId = id;
}



void
FieldModule::Input(const InputEvent &input)
{
    // handle system input ourself
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_Co:    mScale += 0.01f;                                    break;
            case KEY_Cp:    mScale -= 0.01f;                                    break;

            case KEY_Ck:    mViewFromCamera = (mViewFromCamera) ? false : true; break;
            case KEY_Cl:    mViewAxis       = (mViewAxis)       ? false : true; break;
        }
    }

    // give input to all opened windows
    if (mpWindowManager->Input(input) == true)
    {
        // if we handled input - return
        return;
    }



    // give input to all unit on map
    if (mpUnitManager->Input(input) == true)
    {
        // if we handled input - return
        return;
    }



    // handle other game input
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_Cs:
            {
                PartyMenu* screen = new PartyMenu();
                MODULEMAN->PushModule(screen);
                break;
            }
        }
    }
}



void
FieldModule::Update(const u32& delta_time)
{
    // run script
    mpScriptManager->Run();



    // update all opened windows
    mpWindowManager->Update(delta_time);



    // update all units on map
    mpUnitManager->Update(delta_time);



    // if any map request load
    if (mRequestedMapId != 0)
    {
        LoadMap(mRequestedMapId);
        mRequestedMapId = 0;
    }
}



void
FieldModule::DrawPosibleActions(void) const
{
    KERNEL->DrawString(RStringToFFVIIString("Press 'O'/'P' button to scale walkmesh"),        350, 430, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'K' button to swich to/from camera view"), 350, 445, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'L' button to show/hide axis"),            350, 460, F_WHITE);
}



void
FieldModule::Draw()
{
    DISPLAY->CameraPushMatrix();

    // set camera
    if (mViewFromCamera == true)
    {
        DISPLAY->LoadCameraMatrix(mMatrix);
    }
    else
    {
        DISPLAY->LoadLookAt(50, Vector3(-500, 200, 900), Vector3(0, 0, 0), Vector3(0, 1, 0));
    }

    // draw axis
    if (mViewAxis == true)
    {
        DISPLAY->SetPointSize(3);
        DISPLAY->DrawPoints(mAxis);
        DISPLAY->SetLineWidth(1);
        DISPLAY->DrawLines(mAxis);
    }

    DrawPosibleActions();

    // draw all units on map
    DISPLAY->PushMatrix();
    DISPLAY->Scale(mScale, mScale, mScale);
    mpUnitManager->Draw();
    DISPLAY->PopMatrix();

    // draw all opened windows
    mpWindowManager->Draw();
}
