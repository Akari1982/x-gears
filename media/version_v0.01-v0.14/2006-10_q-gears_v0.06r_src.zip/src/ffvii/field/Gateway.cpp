// $Id$

#include "../../common/utilites/Logger.h"

#include "FieldModule.h"
#include "Gateway.h"



Gateway::Gateway(FieldModule* pFieldModule, const Vector3& point1, const Vector3& point2, const Vector3& position, const u16& mapId):
    mpFieldModule(pFieldModule),
    Trigger(point1, point2),
    mPosition(position),
    mMapId(mapId)
{
}



Gateway::~Gateway(void)
{
}



void
Gateway::Action(void)
{
    if (mMapId != 0x7FFF)
    {
        printf("Gateway activates. Load next Map %d\n", mMapId);
        mpFieldModule->LoadMap(mMapId);
    }
    else
    {
        printf("Gateway inactive.\n");
    }
}
