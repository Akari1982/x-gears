// $Id$

#ifndef TRIGGER_h
#define TRIGGER_h

#include "../../common/display/3dTypes.h"
#include "../../common/utilites/NoCopy.h"

#include "Collision.h"



class Trigger : public NoCopy<Trigger>
{
public:
    Trigger(const Vector3& point1, const Vector3& point2);

    virtual ~Trigger(void);

    void Draw(void);

    void CheckCollision(const Vector3& position, const Collision& collision);

    virtual void Action(void) = 0;

private:
    Vector3 mPoint1;
    Vector3 mPoint2;
};



#endif // TRIGGER_h
