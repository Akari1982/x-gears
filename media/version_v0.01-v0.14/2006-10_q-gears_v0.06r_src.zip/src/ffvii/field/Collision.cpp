// $Id$

#include "../../common/display/Display.h"

#include "Collision.h"



Collision::Collision(void)
{
}



Collision::~Collision(void)
{
}



void
Collision::Draw(void)
{
    std::vector<Vertex> quads;
    quads.resize(16);

    Vertex v;
    Color color(0.0f, 1.0f, 1.0f, 1.0f);
    v.c = color;

    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->SetLineWidth(1);

    v.p = mPoints[0]; quads[ 0] = v;
    v.p = mPoints[4]; quads[ 1] = v;
    v.p = mPoints[5]; quads[ 2] = v;
    v.p = mPoints[1]; quads[ 3] = v;

    v.p = mPoints[3]; quads[ 4] = v;
    v.p = mPoints[7]; quads[ 5] = v;
    v.p = mPoints[6]; quads[ 6] = v;
    v.p = mPoints[2]; quads[ 7] = v;

    v.p = mPoints[0]; quads[ 8] = v;
    v.p = mPoints[4]; quads[ 9] = v;
    v.p = mPoints[7]; quads[10] = v;
    v.p = mPoints[3]; quads[11] = v;

    v.p = mPoints[1]; quads[12] = v;
    v.p = mPoints[5]; quads[13] = v;
    v.p = mPoints[6]; quads[14] = v;
    v.p = mPoints[2]; quads[15] = v;

    DISPLAY->DrawQuads(quads);

    DISPLAY->SetPolygonMode(POLYGON_FILL);
}
