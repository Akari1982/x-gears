// $Id: Model.h 84 2006-10-13 19:20:42Z crazy_otaku $

#ifndef MODEL_h
#define MODEL_h

#include "../../common/display/3dTypes.h"
#include "../../common/utilites/NoCopy.h"

#include "Collision.h"



class Model : public NoCopy<Model>
{
public:
    Model(void);

    virtual ~Model(void);

    void Draw(void);

    const Collision& GetCollision(void);

private:
    Collision mCollision;
};



#endif // MODEL_h
