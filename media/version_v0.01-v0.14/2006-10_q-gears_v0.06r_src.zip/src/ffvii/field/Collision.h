// $Id$

#ifndef COLLISION_h
#define COLLISION_h

#include "../../common/display/3dTypes.h"



struct Collision
{
    Collision(void);

    virtual ~Collision(void);

    void Draw(void);



    Vector3 mPoints[8];
};



#endif // COLLISION_h
