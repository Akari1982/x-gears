// $Id: Math.h 83 2006-10-08 06:55:30Z crazy_otaku $

#ifndef MATH_H
#define MATH_H

#include <math.h>

#include "../../common/display/3dTypes.h"



float   point_elevation(const Vector3& point, const Vector3& A, const Vector3& B, const Vector3& C);



bool    line_crossing(const Vector3& p11, const Vector3& p12, const Vector3& p21, const Vector3& p22);


bool    point_on_line(const Vector3& point, const Vector3& p1, const Vector3& p2);


Vector3 get_projection_on_line(const Vector3& moveVector, const Vector3& sp1, const Vector3& sp2);



bool    find_point_on_plane(Vector3& ret, const Vector3& point1, const Vector3& point2, const Vector3& A, const Vector3& B, const Vector3& C);



#endif // MATH_H
