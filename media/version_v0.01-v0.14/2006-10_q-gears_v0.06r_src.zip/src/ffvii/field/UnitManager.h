// $Id$

/**
 * @brief Unit manager for field module.
 */

#ifndef UNIT_MANAGER_h
#define UNIT_MANAGER_h

#include <vector>

#include "../../common/TypeDefine.h"
#include "../../common/input/InputFilter.h"
#include "../../common/utilites/NoCopy.h"

#include "Collision.h"
#include "Model.h"
#include "Gateway.h"

class FieldModule;



struct WalkMeshTriangle
{
    WalkMeshTriangle():
        accessible(true)
    {
    }

    Vector3 A;
    Vector3 B;
    Vector3 C;

    u16    access[3];
    bool   accessible;
};



struct UnitData
{
    UnitData():
        position(0.0f, 0.0f, 0.0f),
        triangle(0),
        position_set(false),
        visible(false),
        direction(0),

        pc(false),
        pc_id(0)
    {
    }

    Model*       model;
    bool         visible;

    Vector3      position;
    u16          triangle;
    bool         position_set;
    u8           direction;

    bool         pc;
    u8           pc_id;
};



class UnitManager : public NoCopy<UnitManager>
{
public:
// LIFECYCLE

    /**
     * @brief Default constructor.
     *
     * @param pFieldModule - pointer to this FieldModule object
     */
    UnitManager(FieldModule* pFieldModule);

    /**
     * @brief Default destructor.
     */
    virtual ~UnitManager(void);

// OPERATIONS

    /**
     * @brief Clear data.
     */
    void Clear(void);

    /**
     * @brief Draw data.
     */
    void Draw(void);

    /**
     * @brief Handles input.
     *
     * @param input - single input event.
     * @return true if we handled input, false otherwise
     */
    bool Input(const InputEvent& input);

    /**
     * @brief Handles update.
     *
     * @param deltaTime - time passed from last call.
     */
    void Update(const u32& deltaTime);

    /**
     * @brief Add new walkmesh triangle.
     *
     * @param v - single walkmesh triangle.
     */
    void AddWalkMeshTriangle(const WalkMeshTriangle& triangle);

    void AddGateway(const Vector3& point1, const Vector3& point2, const Vector3& position, const u16& mapId);

    /**
     * @brief Defines character for entity.
     *
     * @param characterId - id of character (not inplemented).
     * @return id of defined unit.
     */
    const s8 AddChar(const u8& characterId);

    /**
     * @brief Defines character as playable.
     *
     * @param unitId     - id of defined unit.
     * @param playableId - id of playable character.
     */
    void SetPC(const s8& unitId, const u8& playableId);

    /**
     * @brief Set coords for unit.
     *
     * @param unitId - id of defined unit.
     * @param x      - x coord.
     * @param y      - y coord.
     */
    void SetXYCoords(const s8& unitId, const float& x, const float& y);

    /**
     * @brief Set coords for unit.
     *
     * @param unitId - id of defined unit.
     * @param z      - z coord.
     */
    void SetZCoords(const s8& unitId, const float& z);

    /**
     * @brief Set triangle for unit.
     *
     * @param unitId   - id of defined unit.
     * @param triangle - current triangle in walkmesh.
     */
    void SetTriangle(const s8& unitId, const u16& triangle);

    /**
     * @brief Set position for unit (cannot be changed).
     *
     * @param unitId   - id of defined unit.
     */
    void SetPosition(const s8& unitId);


    /**
     * @brief Set direction for unit.
     *
     * @param unitId    - id of defined unit.
     * @param direction - direction in ffvii direction format.
     */
    void SetDirection(const s8& unitId, const u8& direction);

    /**
     * @brief Turns on or off the boundary status for the set of edges marked by the triangle ID
     *
     * @param triangleId - id of triangle to lock/unlock.
     * @param lock       - 1 - triangle can't be accessed, 0 - can be.
     */
    void SetTriangleAccess(const u16& triangleId, const u8& lock);

public:
    void SetWalkMeshCoords(const u16& triangleIndex);

    void SetNextStep(const Vector3& moveVector, const bool slide);

    void CheckTriggers(const Collision& collision, const s8& unitId);

private:
    FieldModule*            mpFieldModule; /**< @brief feed back to field module */


    // move managing
    bool                    mMoveForward;
    bool                    mMoveBack;
    bool                    mMoveLeft;
    bool                    mMoveRight;



    // walkmesh
    std::vector<WalkMeshTriangle> mWalkMesh;
    std::vector<Vertex>           mTriggersView;
    std::vector<Gateway*>         mGateways;



    // units
    std::vector<UnitData>   mUnits;        /**< @brief array of units */
    u8                      mPC;           /**< @brief playable chatacter id */
};



#endif // UNIT_MANAGER_h
