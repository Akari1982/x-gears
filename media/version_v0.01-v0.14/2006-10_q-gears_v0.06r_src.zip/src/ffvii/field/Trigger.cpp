// $Id$

#include "../../common/display/Display.h"
#include "../../common/utilites/Logger.h"

#include "Math.h"
#include "Trigger.h"



Trigger::Trigger(const Vector3& point1, const Vector3& point2):
    mPoint1(point1),
    mPoint2(point2)
{
}



Trigger::~Trigger(void)
{
}



void
Trigger::Draw(void)
{
    std::vector<Vertex> line;
    line.resize(2);

    Vertex v;
    Color color(0.0f, 128.0f / 255.0f, 242.0f / 255.0f, 1.0f);
    v.c = color;

    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->SetLineWidth(3);

    v.p = mPoint1;
    line[0] = v;
    v.p = mPoint2;
    line[1] = v;
    DISPLAY->DrawLines(line);

    DISPLAY->SetPolygonMode(POLYGON_FILL);
}



void
Trigger::CheckCollision(const Vector3& position, const Collision& collision)
{
    Vector3 point, A, B, C, D;

    for (u8 i = 0; i < 4; ++i)
    {
        switch (i)
        {
            case 0:
            {
                A = position + collision.mPoints[0];
                B = position + collision.mPoints[4];
                C = position + collision.mPoints[5];
                D = position + collision.mPoints[1];
                break;
            }
            case 1:
            {
                A = position + collision.mPoints[3];
                B = position + collision.mPoints[7];
                C = position + collision.mPoints[6];
                D = position + collision.mPoints[2];
                break;
            }
            case 2:
            {
                A = position + collision.mPoints[0];
                B = position + collision.mPoints[4];
                C = position + collision.mPoints[7];
                D = position + collision.mPoints[3];
                break;
            }
            case 3:
            {
                A = position + collision.mPoints[1];
                B = position + collision.mPoints[5];
                C = position + collision.mPoints[6];
                D = position + collision.mPoints[2];
                break;
            }
        }

        if (find_point_on_plane(point, mPoint1, mPoint2, A, B, C) == true)
        {
            LOGGER->Log("point.x = %f, point.z = %f", point.x, point.z);
            if ((((point.x >= A.x) && (point.x <= D.x)) || ((point.x <= A.x) && (point.x >= D.x))) &&
                (((point.y >= A.y) && (point.y <= B.y)) || ((point.y <= A.y) && (point.y >= B.y))) &&
                (((point.z >= A.z) && (point.z <= D.z)) || ((point.z <= A.z) && (point.z >= D.z))))
            {
                printf("We cross the plane\n");
                Action();
                return;
            }
        }
    }
}
