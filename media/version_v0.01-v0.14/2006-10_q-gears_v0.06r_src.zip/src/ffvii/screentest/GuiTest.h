// $Id: GuiTest.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef GUITEST_H
#define GUITEST_H

#include "../../common/TypeDefine.h"
#include "../../common/module/Module.h"
#include "../../common/display/3dTypes.h"
#include "../kernel/gui/BattleFont.h"
#include "../kernel/gui/FFVIIString.h"
#include "../kernel/gui/GuiPointer.h"

#include <vector>



class GuiTest : public Module
{
public:
    GuiTest();
    virtual ~GuiTest();

    virtual void Init();

    virtual void Input(const InputEvent &input);

    virtual void Update(const u32& delta_time);

    virtual void Draw();

private:
    void         DrawStatus();

private:
    int         mStartY;
    int         mTotalPos;
    int         mPointerPos;
    PointerType mPointerType;

    int         mTimer;
    bool        mTest1;

    int         mTest3First;
    int         mTest3Cur;
    int         mTest3Last;

    FFVIIString mFFString;
};



#endif // GUITEST_H
