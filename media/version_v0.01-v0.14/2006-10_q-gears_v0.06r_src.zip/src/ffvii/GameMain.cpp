// $Id: GameMain.cpp 76 2006-08-25 18:41:20Z crazy_otaku $

#include "GameDefine.h"
#include "GameMain.h"
#include "filesystem/GameFileSystem.h"
#include "kernel/Kernel.h"
#include "screentest/DisplayTest.h"
#include "../common/input/InputFilter.h"
#include "../common/module/ModuleManager.h"
#include "../common/utilites/StdString.h"
#include "../common/utilites/timer/Timer.h"
#include "../common/utilites/timer/TimerSdl.h"



unsigned char  state;  /**< @brief global game state */



void
handle_input_events(void)
{
    INPUTFILTER->Update();

    static InputEventArray input_event_attay;
    input_event_attay.clear();
    INPUTFILTER->GetInputEvents(input_event_attay);

    for (int i = 0; i < input_event_attay.size(); i++)
    {
        MODULEMAN->Input(input_event_attay[i]);
    }
}



RString
game_title(void)
{
    RString title = APPLICATION_NAME;
    return title;
}



void
game_module_start(void)
{
    // load display test
    ScreenDisplayTest* screen1 = new ScreenDisplayTest();
    MODULEMAN->PushModule(screen1);
}



void
game_main(void)
{
    GAMEFILESYSTEM = new GameFileSystem();
    KERNEL = new Kernel();



    TimerSDL::InitTimer();
    Timer* timer_logic = MakeTimer();
    Timer* timer_draw  = MakeTimer();
    unsigned int delta_logic = 0;
    unsigned int delta_draw  = 0;

    state = GAME;
    while (state != EXIT)
    {
        // Handle all necessary game logic
        if (delta_logic > 10)
        {
            handle_input_events();
            KERNEL->Update();
            MODULEMAN->Update(delta_logic);
            delta_logic = 0;
        }

        if (delta_draw > 32)
        {
            MODULEMAN->Draw();
            delta_draw = 0;
        }

        delta_logic += timer_logic->GetDeltaTime();
        delta_draw  += timer_draw->GetDeltaTime();
    }

    delete timer_logic;
    delete timer_draw;
    TimerSDL::QuitTimer();



    delete KERNEL;
    delete GAMEFILESYSTEM;
    
    return;
}
