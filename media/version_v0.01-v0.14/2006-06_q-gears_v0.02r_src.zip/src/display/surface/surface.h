/*
 *  $Id: surface.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef SURFACE_H
#define SURFACE_H



#include <string>



struct Surface
{
    Surface();
    Surface(const Surface &copy);
    Surface& operator =(const Surface &copy);
    ~Surface();


    unsigned char *pixels;
    int            width;
    int            height;
};



Surface* CreateSurface(const int width, const int height);
Surface* CreateSubSurface(const int x, const int y, const int width, const int height, Surface* surface);
Surface* CreateSurfaceFrom(const int width, const int height, unsigned char* pixels);

void     SetSurfaceSize(Surface* &surface, const int &width, const int &height);



#endif
