/*
 *  $Id: window.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef WINDOW_H
#define WINDOW_H
// The Window Class : Abstract class for window

#include "../../utilites/nocopy.h"



class Window : public NoCopy<Window>
{
public:
    virtual ~Window() {};

    virtual void SwapBuffers() = 0;

    virtual void Update() = 0;

protected:
    // This need to be protected because implementation must call constructor
    Window() {};
};



#endif // WINDOW_H
