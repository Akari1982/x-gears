/*
 *  $Id: main.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "main.h"

#include "define.h"
#include "display/displayogl.h"
#include "filesystem/file.h"
#include "filesystem/gamefilesystem.h"
#include "filesystem/realfilesystem.h"
#include "input/inputfilter.h"
#include "game/filetypes/bingzipfile.h"
#include "game/filetypes/lzsfile.h"
#include "game/filetypes/timfile.h"
#include "game/kernel/kernel.h"
#include "screen/splash.h"
#include "screen/screenmanager.h"
#include "utilites/config.h"
#include "utilites/logger.h"
#include "utilites/utilites.h"

#include <stdio.h>



// game state
unsigned char state;



void
HandleInputEvents()
{
    INPUTFILTER->Update();

    static InputEventArray input_event_attay;
    input_event_attay.clear();
    INPUTFILTER->GetInputEvents(input_event_attay);

    for (int i = 0; i < input_event_attay.size(); i++)
    {
        SCREENMAN->Input(input_event_attay[i]);
    }
}



int
main(int argc, char *argv[])
{
    REALFILESYSTEM = new RealFileSystem();
    GAMEFILESYSTEM = new GameFileSystem();
    LOGGER         = new Logger(DEFAULT_LOG);
    CONFIG         = new Config();
    DISPLAY        = DisplayOGL::MakeDisplay();
    SCREENMAN      = new ScreenManager();
    INPUTFILTER    = new InputFilter();
    KERNEL         = new Kernel();



    state = GAME;
    while (state != EXIT)
    {
        SCREENMAN->Update();
        SCREENMAN->Draw();
        HandleInputEvents();
        KERNEL->Update();
    }



    SAFE_DELETE(KERNEL)
    SAFE_DELETE(INPUTFILTER)
    SAFE_DELETE(SCREENMAN)
    SAFE_DELETE(DISPLAY)
    SAFE_DELETE(CONFIG)
    SAFE_DELETE(LOGGER)
    SAFE_DELETE(GAMEFILESYSTEM)
    SAFE_DELETE(REALFILESYSTEM)

    return 0;
}
