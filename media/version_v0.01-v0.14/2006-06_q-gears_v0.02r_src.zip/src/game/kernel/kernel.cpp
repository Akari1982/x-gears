/*
 *  $Id: kernel.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "kernel.h"
#include "../filetypes/bingzipfile.h"
#include "../filetypes/timfile.h"
#include "../../display/display.h"
#include "../../display/surface/surface.h"
#include "../../display/surface/surfacesavebmp.h"
#include "../../utilites/logger.h"
#include "../../utilites/stdstring.h"



Kernel* KERNEL = NULL; // global and accessable from anywhere in our program



Kernel::Kernel()
{
    Init();
}



Kernel::~Kernel()
{
    delete mBattleFont;
    delete mWindow;
    delete mGuiPointer;
}



void
Kernel::Init()
{
    InitGraphics();
}



void
Kernel::Update()
{
    mGamestate.Update();
}



void
Kernel::SetFrontScreen()
{
    DISPLAY->PushMatrix();
    DISPLAY->LoadIdentity();
    DISPLAY->Translate(-1.0f, 1.0f, 0.0f);
    DISPLAY->Scale(1.0f/320.0f, 1.0f/240.0f, 1.0f);

    DISPLAY->CameraPushMatrix();
    DISPLAY->LoadCameraIdentity();
    DISPLAY->TexturePushMatrix();
    DISPLAY->LoadTextureIdentity();
}



void
Kernel::UnsetFrontScreen()
{
    DISPLAY->TexturePopMatrix();
    DISPLAY->CameraPopMatrix();
    DISPLAY->PopMatrix();
}



void
Kernel::DrawBattleString(const FFVIIString &string, const int &x, const int &y, const BattleFontColor &color)
{
    SetFrontScreen();
    mBattleFont->DrawString(string, x, y, color);
    UnsetFrontScreen();
}



void
Kernel::DrawString(const FFVIIString &string, const int &x, const int &y, const FontColor &color)
{
    SetFrontScreen();
    mFont->DrawString(string, x, y, color);
    UnsetFrontScreen();
}



void
Kernel::DrawWindow(const int &x, const int &y, const int &width, const int &height)
{
    SetFrontScreen();
    mWindow->DrawWindow(x, y, width, height);
    UnsetFrontScreen();
}



void
Kernel::DrawPointer(const int &x, const int &y, const PointerType &type)
{
    SetFrontScreen();
    mGuiPointer->DrawPointer(x, y, type);
    UnsetFrontScreen();
}



void
Kernel::DrawCounter(const int &x, const int &y, const RString &string)
{
    SetFrontScreen();
    mGuiCounter->DrawCounter(x, y, string);
    UnsetFrontScreen();
}



void
Kernel::InitGraphics()
{
    BinGZipFile* file = new BinGZipFile("data/INIT/WINDOW.BIN");
    File* data1        = file->ExtractGZip(0);
    File* data2        = file->ExtractGZip(1);
    File* font_padding = file->ExtractGZip(2);
    delete file;
    TimFile* image = new TimFile(data1);
    delete data1;



    // Init window
    Surface* texture0 = image->GetSurface(0);
    if (texture0 != NULL)
    {
        mWindow = new DialogWindow(texture0);
    }
    else
    {
        LOGGER->Log("Can't load window texture.");
    }



    // Init pointer
    Surface* texture1 = image->GetSurface(1);
    Surface* texture7 = image->GetSurface(7);
    if (texture1 != NULL && texture7 != NULL)
    {
        mGuiPointer = new GuiPointer(texture1, texture7);
        delete texture1;
    }
    else
    {
        LOGGER->Log("Can't load pointer texture.");
    }



    Surface* texture5 = image->GetSurface(5);
    if (texture0 != NULL && texture5 != NULL && texture7 != NULL)
    {
        mBattleFont = new BattleFont(texture0, texture5, texture7);

        delete texture0;
        delete texture7;
    }
    else
    {
        LOGGER->Log("Can't load battle font texture.");
    }



    Surface* texture12 = image->GetSurface(12);
    if (texture12 != NULL)
    {
        mGuiCounter = new GuiCounter(texture12);

        delete texture12;
    }
    else
    {
        LOGGER->Log("Can't load counter font texture.");
    }



    delete image;



    TimFile* image2 = new TimFile(data2);
    delete data2;



    Surface* texture2_0 = image->GetSurface(0);
//    SurfaceUtils::SaveBMP("bmp.bmp", texture2_0);
    Surface* texture2_5 = image->GetSurface(5);
    Surface* texture2_7 = image->GetSurface(7);
    if (texture2_0 != NULL && texture2_5 != NULL && texture2_7 != NULL)
    {
        mFont = new Font(texture2_0, texture2_5, texture2_7, font_padding);

        delete texture2_0;
        delete texture2_5;
        delete texture2_7;

    }
    else
    {
        LOGGER->Log("Can't load font texture.");
    }

    delete font_padding;



    delete image2;
}
