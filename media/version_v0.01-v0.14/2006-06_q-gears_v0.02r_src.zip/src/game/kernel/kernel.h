/*
 *  $Id: kernel.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef KERNEL_H
#define KERNEL_H



#include "gamestate.h"
#include "gui/battlefont.h"
#include "gui/dialogwindow.h"
#include "gui/font.h"
#include "gui/ffviistring.h"
#include "gui/guicounter.h"
#include "gui/guipointer.h"
#include "../../utilites/nocopy.h"
#include "../../utilites/stdstring.h"



class Kernel : public NoCopy<Kernel>
{
public:
             Kernel();
    virtual ~Kernel();

    void     Init();
    void     Update();

    void     DrawBattleString(const FFVIIString &string, const int &x, const int &y, const BattleFontColor &color);
    void     DrawString(const FFVIIString &string, const int &x, const int &y, const FontColor &color);
    void     DrawWindow(const int &x, const int &y, const int &width, const int &height);
    void     DrawPointer(const int &x, const int &y, const PointerType &type);
    void     DrawCounter(const int &x, const int &y, const RString &string);

private:
    void     InitGraphics();
    void     SetFrontScreen();
    void     UnsetFrontScreen();

private:
    Gamestate     mGamestate;

    BattleFont*   mBattleFont;
    Font*         mFont;
    DialogWindow* mWindow;
    GuiPointer*   mGuiPointer;
    GuiCounter*   mGuiCounter;
};



// Visible from every part of programm
extern Kernel *KERNEL;



#endif // KERNEL_H
