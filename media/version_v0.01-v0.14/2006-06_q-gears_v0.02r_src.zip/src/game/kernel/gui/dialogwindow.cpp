#include "dialogwindow.h"
#include "../../../display/3dtypes.h"
#include "../../../display/display.h"
#include "../../../display/surface/surface.h"
#include "../../../utilites/logger.h"



DialogWindow::DialogWindow(Surface* image):
    mBorderWidth(8.0f),
    mBorderHeight(8.0f)
{
    Surface* temp;

    // +---+---+---+
    // | 1 | 5 | 2 |
    // +---+---+---+
    // | 6 | 9 | 7 |
    // +---+---+---+
    // | 3 | 8 | 4 |
    // +---+---+---+

    // 1
    temp = CreateSubSurface(0, 232, 8, 8, image);
    mWindowTexId[0] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 2
    temp = CreateSubSurface(8, 232, 8, 8, image);
    mWindowTexId[1] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 3
    temp = CreateSubSurface(16, 224, 8, 8, image);
    mWindowTexId[2] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 4
    temp = CreateSubSurface(24, 224, 8, 8, image);
    mWindowTexId[3] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 5
    temp = CreateSubSurface(0, 224, 16, 8, image);
    mWindowTexId[4] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 6
    temp = CreateSubSurface(0, 240, 8, 16, image);
    mWindowTexId[5] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 7
    temp = CreateSubSurface(24, 240, 8, 16, image);
    mWindowTexId[6] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 8
    temp = CreateSubSurface(16, 232, 16, 8, image);
    mWindowTexId[7] = DISPLAY->CreateTexture(temp);
    delete temp;



    Vertex point;
    point.p.x = 0.0f;         point.p.y = 0.0f;           point.p.z = 0.0f;
    point.c.r = 1.0f;         point.c.g = 1.0f;           point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f;         point.t.y = 0.0f;
    mWindowPoly.push_back(point);
    point.p.x = mBorderWidth; point.p.y = 0.0f;           point.p.z = 0.0f;
    point.c.r = 1.0f;         point.c.g = 1.0f;           point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;         point.t.y = 0.0f;
    mWindowPoly.push_back(point);
    point.p.x = mBorderWidth; point.p.y = -mBorderHeight; point.p.z = 0.0f;
    point.c.r = 1.0f;         point.c.g = 1.0f;           point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;         point.t.y = 1.0f;
    mWindowPoly.push_back(point);
    point.p.x = 0.0f;         point.p.y = -mBorderHeight; point.p.z = 0.0f;
    point.c.r = 1.0f;         point.c.g = 1.0f;           point.c.b = 1.0f; point.c.a =  1.0f;
    point.t.x = 0.0f;         point.t.y = 1.0f;
    mWindowPoly.push_back(point);
}



DialogWindow::~DialogWindow()
{
    DISPLAY->DeleteTexture(mWindowTexId[0]);
    DISPLAY->DeleteTexture(mWindowTexId[1]);
    DISPLAY->DeleteTexture(mWindowTexId[2]);
    DISPLAY->DeleteTexture(mWindowTexId[3]);
    DISPLAY->DeleteTexture(mWindowTexId[4]);
    DISPLAY->DeleteTexture(mWindowTexId[5]);
    DISPLAY->DeleteTexture(mWindowTexId[6]);
    DISPLAY->DeleteTexture(mWindowTexId[7]);
    DISPLAY->DeleteTexture(mWindowTexId[8]);
}



void
DialogWindow::DrawWindow(const int &x, const int &y, const int &width, const int &height)
{
    DISPLAY->Translate(x - mBorderWidth, -y + mBorderHeight, 0);
    DISPLAY->PushMatrix();

    mWindowPoly[0].c.r =  1.0f; mWindowPoly[0].c.g =  1.0f; mWindowPoly[0].c.b =  1.0f;
    mWindowPoly[1].c.r =  1.0f; mWindowPoly[1].c.g =  1.0f; mWindowPoly[1].c.b =  1.0f;
    mWindowPoly[2].c.r =  1.0f; mWindowPoly[2].c.g =  1.0f; mWindowPoly[2].c.b =  1.0f;
    mWindowPoly[3].c.r =  1.0f; mWindowPoly[3].c.g =  1.0f; mWindowPoly[3].c.b =  1.0f;
    // sector 1
    mWindowPoly[0].p.x = 0.0f;         mWindowPoly[0].p.y = 0.0f;
    mWindowPoly[1].p.x = mBorderWidth; mWindowPoly[1].p.y = 0.0f;
    mWindowPoly[2].p.x = mBorderWidth; mWindowPoly[2].p.y = -mBorderHeight;
    mWindowPoly[3].p.x = 0.0f;         mWindowPoly[3].p.y = -mBorderHeight;
    DISPLAY->SetTexture(mWindowTexId[0]);
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();

    // sector 2
    mWindowPoly[0].p.x = mBorderWidth + width;     mWindowPoly[0].p.y = 0.0f;
    mWindowPoly[1].p.x = mBorderWidth * 2 + width; mWindowPoly[1].p.y = 0.0f;
    mWindowPoly[2].p.x = mBorderWidth * 2 + width; mWindowPoly[2].p.y = -mBorderHeight;
    mWindowPoly[3].p.x = mBorderWidth + width;     mWindowPoly[3].p.y = -mBorderHeight;
    DISPLAY->SetTexture(mWindowTexId[1]);
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();

    // sector 3
    mWindowPoly[0].p.x = 0.0f;         mWindowPoly[0].p.y = -mBorderHeight - height;
    mWindowPoly[1].p.x = mBorderWidth; mWindowPoly[1].p.y = -mBorderHeight - height;
    mWindowPoly[2].p.x = mBorderWidth; mWindowPoly[2].p.y = -mBorderHeight * 2 - height;
    mWindowPoly[3].p.x = 0.0f;         mWindowPoly[3].p.y = -mBorderHeight * 2 - height;
    DISPLAY->SetTexture(mWindowTexId[2]);
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();

    // sector 4
    mWindowPoly[0].p.x = mBorderWidth + width;     mWindowPoly[0].p.y = -mBorderHeight - height;
    mWindowPoly[1].p.x = mBorderWidth * 2 + width; mWindowPoly[1].p.y = -mBorderHeight - height;
    mWindowPoly[2].p.x = mBorderWidth * 2 + width; mWindowPoly[2].p.y = -mBorderHeight * 2 - height;
    mWindowPoly[3].p.x = mBorderWidth + width;     mWindowPoly[3].p.y = -mBorderHeight * 2 - height;
    DISPLAY->SetTexture(mWindowTexId[3]);
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();

    // sector 5
    mWindowPoly[0].p.x = mBorderWidth;         mWindowPoly[0].p.y = 0.0f;
    mWindowPoly[1].p.x = mBorderWidth + width; mWindowPoly[1].p.y = 0.0f;
    mWindowPoly[2].p.x = mBorderWidth + width; mWindowPoly[2].p.y = -mBorderHeight;
    mWindowPoly[3].p.x = mBorderWidth;         mWindowPoly[3].p.y = -mBorderHeight;
    DISPLAY->SetTexture(mWindowTexId[4]);
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();

    // sector 6
    DISPLAY->PushMatrix();
    DISPLAY->Translate(0.0f, -mBorderHeight, 0.0f);
    DISPLAY->SetTexture(mWindowTexId[5]);
    mWindowPoly[0].p.x = 0.0f;         mWindowPoly[0].p.y = 0.0f;
    mWindowPoly[1].p.x = mBorderWidth; mWindowPoly[1].p.y = 0.0f;
    mWindowPoly[2].p.x = mBorderWidth; mWindowPoly[2].p.y = -height;
    mWindowPoly[3].p.x = 0.0f;         mWindowPoly[3].p.y = -height;
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();
    DISPLAY->PopMatrix();

    // sector 7
    DISPLAY->PushMatrix();
    DISPLAY->Translate(mBorderWidth + width, -mBorderHeight, 0.0f);
    DISPLAY->SetTexture(mWindowTexId[6]);
    mWindowPoly[0].p.x = 0.0f;         mWindowPoly[0].p.y = 0.0f;
    mWindowPoly[1].p.x = mBorderWidth; mWindowPoly[1].p.y = 0.0f;
    mWindowPoly[2].p.x = mBorderWidth; mWindowPoly[2].p.y = -height;
    mWindowPoly[3].p.x = 0.0f;         mWindowPoly[3].p.y = -height;
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();
    DISPLAY->PopMatrix();

    // sector 8
    DISPLAY->PushMatrix();
    DISPLAY->Translate(mBorderWidth, -mBorderHeight - height, 0.0f);
    DISPLAY->SetTexture(mWindowTexId[7]);
    mWindowPoly[0].p.x = 0.0f;  mWindowPoly[0].p.y = 0.0f;
    mWindowPoly[1].p.x = width; mWindowPoly[1].p.y = 0.0f;
    mWindowPoly[2].p.x = width; mWindowPoly[2].p.y = -mBorderHeight;
    mWindowPoly[3].p.x = 0.0f;  mWindowPoly[3].p.y = -mBorderHeight;
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();
    DISPLAY->PopMatrix();

    // sector 9
    mWindowPoly[0].p.x = 3.0f;                            mWindowPoly[0].p.y = -3.0f;
    mWindowPoly[1].p.x = mBorderWidth * 2 + width - 3.0f; mWindowPoly[1].p.y = -3.0f;
    mWindowPoly[2].p.x = mBorderWidth * 2 + width - 3.0f; mWindowPoly[2].p.y = -mBorderHeight * 2 - height + 3.0f;
    mWindowPoly[3].p.x = 3.0f;                            mWindowPoly[3].p.y = -mBorderHeight * 2 - height + 3.0f;
    mWindowPoly[0].c.r =   0.0f/255.0f; mWindowPoly[0].c.g =   0.0f/255.0f; mWindowPoly[0].c.b = 176.0f/255.0f;
    mWindowPoly[1].c.r =   0.0f/255.0f; mWindowPoly[1].c.g =   0.0f/255.0f; mWindowPoly[1].c.b = 128.0f/255.0f;
    mWindowPoly[2].c.r =   0.0f/255.0f; mWindowPoly[2].c.g =   0.0f/255.0f; mWindowPoly[2].c.b =  32.0f/255.0f;
    mWindowPoly[3].c.r =   0.0f/255.0f; mWindowPoly[3].c.g =   0.0f/255.0f; mWindowPoly[3].c.b =  80.0f/255.0f;
    DISPLAY->DrawQuads(mWindowPoly);

    DISPLAY->PopMatrix();
}
