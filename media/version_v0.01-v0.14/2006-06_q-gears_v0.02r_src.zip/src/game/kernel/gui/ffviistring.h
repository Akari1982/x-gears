/*
 *  $Id: ffviistring.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef FFVIISTRING_H
#define FFVIISTRING_H



#include "../../../utilites/stdstring.h"

#include <vector>



typedef std::vector<unsigned char> FFVIIString;



// converter
FFVIIString RStringToFFVIIString(const RString &string);



#endif
