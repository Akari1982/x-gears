/*
 *  $Id: guicounter.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef GUICOUNTER_H
#define GUICOUNTER_H



#include "../../../display/3dtypes.h"
#include "../../../display/surface/surface.h"
#include "../../../utilites/nocopy.h"
#include "../../../utilites/stdstring.h"

#include <map>
#include <vector>



class GuiCounter : public NoCopy<GuiCounter>
{
public:
             GuiCounter(Surface* image);

    virtual ~GuiCounter();

    void     DrawCounter(const int &x, const int &y, const RString &string);

private:
    std::map<int, int>  mCounterTexId;
    std::vector<Vertex> mCounterPoly;
};



#endif
