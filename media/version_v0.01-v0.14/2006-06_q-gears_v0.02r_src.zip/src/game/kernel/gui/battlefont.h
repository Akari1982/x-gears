/*
 *  $Id: battlefont.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef BATTLEFONT_H
#define BATTLEFONT_H



#include <vector>
#include <map>
#include <utility>

#include "ffviistring.h"
#include "../../../display/3dtypes.h"
#include "../../../display/surface/surface.h"
#include "../../../utilites/nocopy.h"



enum BattleFontColor {BF_GRAY, BF_BLUE, BF_WHITE};



class BattleFont : public NoCopy<BattleFont>
{
public:
             BattleFont(Surface* image_gray,
                        Surface* image_blue,
                        Surface* image_white);

    virtual ~BattleFont();

    void     DrawString(const FFVIIString &string, const int &x, const int &y, const BattleFontColor &color);

protected:
    int mLetterWidth;
    int mLetterHeight;
    int mLetterSpacing;
    int mRowSpacing;

    std::map<int, int>  mFontGrayTexId;
    std::map<int, int>  mFontBlueTexId;
    std::map<int, int>  mFontWhiteTexId;
    std::vector<Vertex> mFontPoly;

    int mTab;
    int mNewLine;
};



#endif
