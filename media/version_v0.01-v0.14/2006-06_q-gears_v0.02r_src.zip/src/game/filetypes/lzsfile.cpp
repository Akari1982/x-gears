/*
 *  $Id: lzsfile.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "lzsfile.h"
#include "../../utilites/logger.h"



LzsFile::LzsFile(const std::string &file):
    File(file)
{
    ExtractLzs();
}



LzsFile::LzsFile(File *file, u32 offset, u32 length):
    File(file, offset, length)
{
    ExtractLzs();
}



LzsFile::LzsFile(u8* buffer, u32 offset, u32 length):
    File(buffer, offset, length)
{
    ExtractLzs();
}



LzsFile::LzsFile(File *file):
    File(file)
{
    ExtractLzs();
}



LzsFile::~LzsFile()
{
}



void
LzsFile::ExtractLzs()
{
    u32 input_length = GetU32LE(0) + 4;

    if (input_length != mBufferSize)
    {
        LOGGER->Log("Warning: extract failed, this is not lzs!");
        return;
    }



    u32 extract_size = (mBufferSize + 255) & ~255;
    u8* extract_buffer = (u8*)malloc(extract_size);



    int input_offset = 4;
    int output_offset = 0;
    u8 control_byte = 0;
    u8 control_bit = 0;

    while (input_offset < mBufferSize)
    {
        if (control_bit == 0)
        {
            control_byte = ((u8*)mBuffer)[input_offset++];
            control_bit = 8;
        }

        if (control_byte & 1)
        {
            ((u8*)extract_buffer)[output_offset++] = ((u8*)mBuffer)[input_offset++];

            if (output_offset == extract_size)
            {
                extract_size += 256;
                extract_buffer = (u8*)realloc(extract_buffer, extract_size);
            }
        }
        else
        {
            u8 reference1 = ((u8*)mBuffer)[input_offset++];
            u8 reference2 = ((u8*)mBuffer)[input_offset++];

            u16 reference_offset = reference1 | ((reference2 & 0xF0) << 4);

            u8 reference_length = (reference2 & 0xF) + 3;

            int real_offset = output_offset - ((output_offset - 18 - reference_offset) & 0xFFF);

            for (int j = 0; j < reference_length; ++j)
            {
                if (real_offset < 0)
                {
                    ((u8*)extract_buffer)[output_offset++] = 0;
                }
                else
                {
                    ((u8*)extract_buffer)[output_offset++] = ((u8*)extract_buffer)[real_offset];
                }

                if (output_offset == extract_size)
                {
                    extract_size += 256;
                    extract_buffer = (u8*)realloc(extract_buffer, extract_size);
                }

                ++real_offset;
            }
        }

        control_byte >>= 1;
        control_bit--;
    }

    free(mBuffer);
    // the real buffer size and mBufferSize will be a bit different
    mBuffer = extract_buffer;
    mBufferSize = output_offset;
}
