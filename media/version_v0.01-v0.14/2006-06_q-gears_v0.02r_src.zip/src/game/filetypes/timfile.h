/*
 *  $Id: timfile.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef TIMFILE_H
#define TIMFILE_H

#include "../../display/surface/surface.h"
#include "../../filesystem/file.h"
#include "../../utilites/stdstring.h"



class TimFile : public File
{
public:
    explicit          TimFile(const RString &file);
    explicit          TimFile(File* file);
                      TimFile(File* file, u32 offset, u32 length);
                      TimFile(u8* buffer, u32 offset, u32 length);
    virtual          ~TimFile();

    Surface*          GetSurface(const int clut_number);

    // get number of clut in tim
    const int         GetNumberOfClut() const;

private:
    void              InnerGetNumberOfClut();

private:
    struct timHeader
    {
        u32 id_tag;
        u32 id_tag_clut;
        u32 clut_size; // Size of CLUT + 12 (accounting for 12 bytes before the CLUT block starts)
        u16 x;
        u16 y;
        u16 number_of_colors;
        u16 number_of_clut;
    } *tim_header;

    struct timHeader2
    {
        u32 data_size;
        u16 x;
        u16 y;
        u16 width;
        u16 height;
    } *tim_header2;

    struct CLUT
    {
        u8 r;
        u8 g;
        u8 b;
        u8 a;
    } *clut;

    // number of clut
    int mClutNumber;
};



#endif
