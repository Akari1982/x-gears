/*
 *  $Id: fieldscreen.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef FIELDSCREEN_H
#define FIELDSCREEN_H



#include "../../screen/screen.h"
#include "../../display/3dtypes.h"

#include <string>
#include <vector>



class FieldScreen : public Screen
{
public:
    FieldScreen();
    virtual ~FieldScreen();

    virtual void Init();

    virtual void Input(const InputEvent &input);

    virtual void Draw();

private:
    TotalGeometry mWalkMesh;
    std::vector<Vertex> mPoints;
};



#endif // FIELDSCREEN_H
