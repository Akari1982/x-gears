/*
 *  $Id: fieldscreen.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "fieldscreen.h"
#include "datfile.h"
#include "../../display/display.h"
#include "../../utilites/logger.h"

#include <string>



FieldScreen::FieldScreen()
{
    Init();
}



FieldScreen::~FieldScreen()
{
}



void
FieldScreen::Init()
{
    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
    DISPLAY->SetAlphaTest(true);
    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->SetBlendMode(BLEND_NORMAL);
    DISPLAY->SetCullMode(CULL_NONE);
    DISPLAY->LoadLookAt(50, Vector3(5, 5, -2), Vector3(0, 0, 0), Vector3(0, 1, 0));

    Vertex point;
    point.p.x = -5.0f; point.p.y =  0.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    mPoints.push_back(point);
    point.p.x =  5.0f; point.p.y =  0.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y = -5.0f; point.p.z =  0.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y =  5.0f; point.p.z =  0.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y =  0.0f; point.p.z = -5.0f;
    point.c.r =  0.0f; point.c.g =  0.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y =  0.0f; point.p.z =  5.0f;
    point.c.r =  0.0f; point.c.g =  0.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    mPoints.push_back(point);



    DatFile *dat = new DatFile("data/MD1STIN.DAT");
    dat->GetWalkMesh(mWalkMesh);
    Matrix camera;
    dat->GetCameraMatrix(camera);
//    *(const_cast<Matrix*>(DISPLAY->GetViewTop())) = camera;
    delete dat;
}



void
FieldScreen::Input(const InputEvent &input)
{
}



void
FieldScreen::Draw()
{
    DISPLAY->SetPointSize(3);
    DISPLAY->DrawPoints(mPoints);
    DISPLAY->SetLineWidth(1);
    DISPLAY->DrawLines(mPoints);

    DISPLAY->DrawTotalGeometry(mWalkMesh);
}
