/*
 *  $Id: datfile.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef DATFILE_H
#define DATFILE_H



#include "../filetypes/lzsfile.h"
#include "../../filesystem/file.h"
#include "../../display/3dtypes.h"
#include "../../display/math/matrix.h"

#include <string>



class DatFile : public LzsFile
{
public:
    explicit          DatFile(const std::string &file);
    explicit          DatFile(File* file);
                      DatFile(File* file, u32 offset, u32 length);
                      DatFile(u8* buffer, u32 offset, u32 length);
    virtual          ~DatFile();

    void              GetWalkMesh(TotalGeometry &walkmesh);
    void              GetCameraMatrix(Matrix &camera);
};



#endif // DATFILE_H
