/*
 *  $Id: datfile.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "datfile.h"
#include "../../display/math/matrix.h"
#include "../../display/math/matrixmath.h"
#include "../../display/math/vector.h"
#include "../../display/math/vectormath.h"
#include "../../utilites/logger.h"

#include <string>
#include <vector>



DatFile::DatFile(const std::string &file):
    LzsFile(file)
{
}



DatFile::DatFile(File *file, u32 offset, u32 length):
    LzsFile(file, offset, length)
{
}



DatFile::DatFile(u8* buffer, u32 offset, u32 length):
    LzsFile(buffer, offset, length)
{
}



DatFile::DatFile(File *file):
    LzsFile(file)
{
}



DatFile::~DatFile()
{
}



void
DatFile::GetWalkMesh(TotalGeometry &walkmesh)
{
    u32 offset_to_walkmesh = 0x1C + GetU32LE(0x04) - GetU32LE(0x00);

    Geometry geometry;
    geometry.TexEnabled = false;

    u32 number_of_poly = GetU32LE(offset_to_walkmesh);
    int start = offset_to_walkmesh + 0x04;

    for (u32 i = 0; i < number_of_poly; ++i)
    {
        Vertex v[3];

        v[0].p.x = -(s16)GetU16LE(start + 0x00); v[0].p.z =  (s16)GetU16LE(start + 0x02); v[0].p.y =  (s16)GetU16LE(start + 0x04);
        v[0].c.r = 1.0f; v[0].c.g = 0.0f; v[0].c.b = 0.0f; v[0].c.a = 1.0f;
        v[1].p.x = -(s16)GetU16LE(start + 0x08); v[1].p.z =  (s16)GetU16LE(start + 0x0A); v[1].p.y =  (s16)GetU16LE(start + 0x0C);
        v[1].c.r = 1.0f; v[1].c.g = 0.0f; v[1].c.b = 0.0f; v[1].c.a = 1.0f;
        v[2].p.x = -(s16)GetU16LE(start + 0x10); v[2].p.z =  (s16)GetU16LE(start + 0x12); v[2].p.y =  (s16)GetU16LE(start + 0x14);
        v[2].c.r = 1.0f; v[2].c.g = 0.0f; v[2].c.b = 0.0f; v[2].c.a = 1.0f;

        geometry.AddTriangle(v);

        // go to the next triangle
        start += 0x18;

    }

    walkmesh.GeometryVector.push_back(geometry);
}



void
DatFile::GetCameraMatrix(Matrix &camera)
{
    u32 offset_to_camera = 0x1C + GetU32LE(0x0C) - GetU32LE(0x00);

    Vector3 x( GetU16LE(offset_to_camera + 0x00) / 4096,
               GetU16LE(offset_to_camera + 0x04) / 4096,
               GetU16LE(offset_to_camera + 0x02) / 4096);
    Vector3Normalize(x, x);

    Vector3 y(-GetU16LE(offset_to_camera + 0x06) / 4096,
              -GetU16LE(offset_to_camera + 0x0A) / 4096,
              -GetU16LE(offset_to_camera + 0x08) / 4096);
    Vector3Normalize(y, y);

    Vector3 z( GetU16LE(offset_to_camera + 0x0C) / 4096,
               GetU16LE(offset_to_camera + 0x10) / 4096,
               GetU16LE(offset_to_camera + 0x0E) / 4096);
    Vector3Normalize(z, z);

    Matrix mat(
        x[0], y[0], z[0], 0,
        x[1], y[1], z[1], 0,
        x[2], y[2], z[2], 0,
        0,    0,    0,    1);



    Matrix mat2;
    MatrixTranslation(mat2, -GetU16LE(offset_to_camera + 0x14),
                             GetU16LE(offset_to_camera + 0x16),
                            -GetU16LE(offset_to_camera + 0x18));

    MatrixMultiply(camera, mat, mat2);
}
