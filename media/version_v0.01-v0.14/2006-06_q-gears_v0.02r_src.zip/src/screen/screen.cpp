/*
 *  $Id: screen.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "screen.h"

#include <string>



Screen::Screen()
{
}



Screen::~Screen()
{
}
