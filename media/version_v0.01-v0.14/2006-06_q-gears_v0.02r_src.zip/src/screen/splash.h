/*
 *  $Id: splash.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef SCREENSPLASH_H
#define SCREENSPLASH_H



#include "screen.h"
#include "../display/3dtypes.h"

#include <string>
#include <vector>



class ScreenSplash : public Screen
{
public:
    ScreenSplash();
    virtual ~ScreenSplash();

    virtual void Init();

    virtual void Input(const InputEvent &input);

    virtual void Draw();

private:
    int mTexId;

    std::vector<Vertex> mQuadsTex;
};



#endif // SCREENSPLASH_H
