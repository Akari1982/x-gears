/*
 *  $Id: inpututils.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef INPUTUTILS_H
#define INPUTUTILS_H



#include <string>



enum Button
{
    KEY_SPACE       = 32,
    KEY_EXCL        = 33,
    KEY_QUOTE       = 34,
    KEY_HASH        = 35,
    KEY_DOLLAR      = 36,
    KEY_PERCENT     = 37,
    KEY_AMPER       = 38,
    KEY_SQUOTE      = 39,
    KEY_LPAREN      = 40,
    KEY_RPAREN      = 41,
    KEY_ASTERISK    = 42,
    KEY_PLUS        = 43,
    KEY_COMMA       = 44,
    KEY_HYPHEN      = 45,
    KEY_PERIOD      = 46,
    KEY_SLASH       = 47,
    KEY_C0          = 48,
    KEY_C1          = 49,
    KEY_C2          = 50,
    KEY_C3          = 51,
    KEY_C4          = 52,
    KEY_C5          = 53,
    KEY_C6          = 54,
    KEY_C7          = 55,
    KEY_C8          = 56,
    KEY_C9          = 57,
    KEY_COLON       = 58,
    KEY_SEMICOLON   = 59,
    KEY_LANGLE      = 60,
    KEY_EQUAL       = 61,
    KEY_RANGLE      = 62,
    KEY_QUESTION    = 63,
    KEY_AT          = 64,
    KEY_CA          = 65,
    KEY_CB          = 66,
    KEY_CC          = 67,
    KEY_CD          = 68,
    KEY_CE          = 69,
    KEY_CF          = 70,
    KEY_CG          = 71,
    KEY_CH          = 72,
    KEY_CI          = 73,
    KEY_CJ          = 74,
    KEY_CK          = 75,
    KEY_CL          = 76,
    KEY_CM          = 77,
    KEY_CN          = 78,
    KEY_CO          = 79,
    KEY_CP          = 80,
    KEY_CQ          = 81,
    KEY_CR          = 82,
    KEY_CS          = 83,
    KEY_CT          = 84,
    KEY_CU          = 85,
    KEY_CV          = 86,
    KEY_CW          = 87,
    KEY_CX          = 88,
    KEY_CY          = 89,
    KEY_CZ          = 90,
    KEY_LBRACKET    = 91,
    KEY_BACKSLASH   = 92,
    KEY_RBRACKET    = 93,
    KEY_CARAT       = 94,
    KEY_UNDERSCORE  = 95,
    KEY_ACCENT      = 96,
    KEY_Ca          = 97,
    KEY_Cb          = 98,
    KEY_Cc          = 99,
    KEY_Cd          = 100,
    KEY_Ce          = 101,
    KEY_Cf          = 102,
    KEY_Cg          = 103,
    KEY_Ch          = 104,
    KEY_Ci          = 105,
    KEY_Cj          = 106,
    KEY_Ck          = 107,
    KEY_Cl          = 108,
    KEY_Cm          = 109,
    KEY_Cn          = 110,
    KEY_Co          = 111,
    KEY_Cp          = 112,
    KEY_Cq          = 113,
    KEY_Cr          = 114,
    KEY_Cs          = 115,
    KEY_Ct          = 116,
    KEY_Cu          = 117,
    KEY_Cv          = 118,
    KEY_Cw          = 119,
    KEY_Cx          = 120,
    KEY_Cy          = 121,
    KEY_Cz          = 122,
    KEY_LBRACE      = 123,
    KEY_PIPE        = 124,
    KEY_RBRACE      = 125,
    KEY_DEL         = 127,

    KEY_BACK,
    KEY_TAB,
    KEY_ENTER,
    KEY_PAUSE,
    KEY_ESC,

    KEY_F1,
    KEY_F2,
    KEY_F3,
    KEY_F4,
    KEY_F5,
    KEY_F6,
    KEY_F7,
    KEY_F8,
    KEY_F9,
    KEY_F10,
    KEY_F11,
    KEY_F12,
    KEY_F13,
    KEY_F14,
    KEY_F15,
    KEY_F16,

    KEY_LCTRL,
    KEY_RCTRL,
    KEY_LSHIFT,
    KEY_RSHIFT,
    KEY_LALT,
    KEY_RALT,
    KEY_LMETA,
    KEY_RMETA,
    KEY_LSUPER,
    KEY_RSUPER,
    KEY_MENU,

    KEY_NUMLOCK,
    KEY_SCRLLOCK,
    KEY_CAPSLOCK,
    KEY_PRTSC,

    KEY_UP,
    KEY_DOWN,
    KEY_LEFT,
    KEY_RIGHT,

    KEY_INSERT,
    KEY_HOME,
    KEY_END,
    KEY_PGUP,
    KEY_PGDN,

    KEY_KP_C0,
    KEY_KP_C1,
    KEY_KP_C2,
    KEY_KP_C3,
    KEY_KP_C4,
    KEY_KP_C5,
    KEY_KP_C6,
    KEY_KP_C7,
    KEY_KP_C8,
    KEY_KP_C9,
    KEY_KP_SLASH,
    KEY_KP_ASTERISK,
    KEY_KP_HYPHEN,
    KEY_KP_PLUS,
    KEY_KP_PERIOD,
    KEY_KP_EQUAL,
    KEY_KP_ENTER,

    KEY_OTHER_0,
    // ...
    KEY_LAST_OTHER = 512,

    NUM_KEYS,
    KEY_INVALID
};

std::string ButtonToString(const Button i);

Button StringToButton(const std::string &s);



const int MAX_BUTTONS = NUM_KEYS;
const int BUTTON_INVALID = MAX_BUTTONS + 1;



#endif // INPUTUTILS_H
