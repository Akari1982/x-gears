/*
 *  $Id: guitest.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef GUITEST_H
#define GUITEST_H



#include "../screen/screen.h"
#include "../display/3dtypes.h"
#include "../game/kernel/gui/battlefont.h"
#include "../game/kernel/gui/ffviistring.h"
#include "../game/kernel/gui/guipointer.h"

#include <vector>



class GuiTest : public Screen
{
public:
    GuiTest();
    virtual ~GuiTest();

    virtual void Init();

    virtual void Input(const InputEvent &input);

    virtual void Draw();

private:
    void         DrawStatus();

private:
    int         mStartY;
    int         mTotalPos;
    int         mPointerPos;

    int         mTimer;

    PointerType mPointerType;

    bool        mTest1;

    FFVIIString mFFString;
};



#endif // GUITEST_H
