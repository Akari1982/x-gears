#include "guitest.h"
#include "../game/kernel/kernel.h"

#include "../game/kernel/kernel.h"
#include "../game/kernel/gui/ffviistring.h"
#include "../game/kernel/gui/guipointer.h"
#include "../utilites/logger.h"



GuiTest::GuiTest()
{
    Init();
}



GuiTest::~GuiTest()
{
}



void
GuiTest::Init()
{
    mPointerPos  = 1;
    mTotalPos    = 2;

    mStartY      = 35;

    mPointerType = TO_RIGHT;

    mTest1       = false;

    mTimer       = 0;

    unsigned char rawData[210] = {
        0xB2, 0x33, 0x4F, 0x4D, 0x45, 0x00, 0x33, 0x48, 0x49, 0x4E, 0x52, 0x41, 0x00, 0x53, 0x4F, 0x4C, 
        0x44, 0x49, 0x45, 0x52, 0x53, 0x00, 0x57, 0x45, 0x4E, 0x54, 0x00, 0x55, 0x50, 0x00, 0x54, 0x4F, 
        0x00, 0x2D, 0x54, 0x0E, 0x00, 0x23, 0x4F, 0x52, 0x45, 0x4C, 0x0E, 0xE7, 0xE1, 0x34, 0x48, 0x45, 
        0x59, 0x00, 0x53, 0x41, 0x49, 0x44, 0x00, 0x54, 0x48, 0x45, 0x59, 0x07, 0x52, 0x45, 0x00, 0x43, 
        0x4F, 0x4C, 0x4C, 0x45, 0x43, 0x54, 0x49, 0x4E, 0x47, 0x00, 0x28, 0x55, 0x47, 0x45, 0x00, 0x2D, 
        0x41, 0x54, 0x45, 0x52, 0x49, 0x41, 0xE7, 0xE1, 0x54, 0x4F, 0x00, 0x42, 0x4C, 0x4F, 0x57, 0x00, 
        0x55, 0x50, 0x00, 0x2D, 0x45, 0x54, 0x45, 0x4F, 0x52, 0x01, 0xB3, 0xE8, 0xB2, 0x39, 0x41, 0x00, 
        0x54, 0x48, 0x49, 0x4E, 0x4B, 0x00, 0x54, 0x48, 0x45, 0x59, 0x00, 0x43, 0x41, 0x4E, 0x00, 0x52, 
        0x45, 0x41, 0x4C, 0x4C, 0x59, 0x00, 0x44, 0x4F, 0x00, 0x49, 0x54, 0x1F, 0xE7, 0xE1, 0x29, 0x07, 
        0x4C, 0x4C, 0x00, 0x42, 0x45, 0x54, 0x00, 0x54, 0x48, 0x45, 0x00, 0x52, 0x45, 0x41, 0x43, 0x54, 
        0x4F, 0x52, 0x00, 0x44, 0x45, 0x53, 0x54, 0x52, 0x4F, 0x59, 0x53, 0x00, 0x45, 0x56, 0x45, 0x52, 
        0x59, 0x54, 0x48, 0x49, 0x4E, 0x47, 0xE7, 0xE1, 0x45, 0x56, 0x45, 0x4E, 0x00, 0x42, 0x45, 0x46, 
        0x4F, 0x52, 0x45, 0x00, 0x2D, 0x45, 0x54, 0x45, 0x4F, 0x52, 0x00, 0x48, 0x49, 0x54, 0x53, 0x01, 
        0xB3, 0xFF, 
    };

    for (int i = 0; i < sizeof(rawData); ++i)
    {
        mFFString.push_back(rawData[i]);
    }
}



void
GuiTest::Input(const InputEvent &input)
{
    switch (input.button)
    {
        case KEY_UP:
        {
            if (input.type == IET_FIRST_PRESS && mPointerPos > 1)
            {
                mPointerPos--;
            }
            break;
        }
        case KEY_DOWN:
        {
            if (input.type == IET_FIRST_PRESS && mPointerPos < mTotalPos)
            {
                mPointerPos++;
            }
            break;
        }
        case KEY_LEFT:
        {
            if (input.type != IET_FIRST_PRESS)
            {
                break;
            }

            switch (mPointerPos)
            {
                case 1 : mTest1 = true;
            }
            break;
        }
        case KEY_RIGHT:
        {
            if (input.type != IET_FIRST_PRESS)
            {
                break;
            }

            switch (mPointerPos)
            {
                case 1 : mTest1 = false;
            }
            break;
        }
    }
}



void
GuiTest::Draw()
{
    if (mTest1 != false)
    {
        mTimer++;
    }

    if (mPointerPos == 2 && mPointerType != TO_RIGHT_CROSS)
    {
        mPointerType = TO_RIGHT_CROSS;
    }
    else
    {
        mPointerType = TO_RIGHT;
    }

    KERNEL->DrawWindow(20, 10, 180, 10);
    KERNEL->DrawString(RStringToFFVIIString("Testing example of FFVII GUI."), 20, 10, F_WHITE);

    KERNEL->DrawWindow(20, 35, 180, 30);
    KERNEL->DrawPointer(20, mStartY + (mPointerPos - 1) * 20, mPointerType);



    // TEST1
    KERNEL->DrawString(RStringToFFVIIString("Test1"), 50, mStartY, F_BLUE);
    FontColor color1, color2;
    if (mTest1 == false)
    {
        color1 = F_GRAY;
        color2 = F_WHITE;
    }
    else
    {
        color1 = F_WHITE;
        color2 = F_GRAY;
    }
    KERNEL->DrawString(RStringToFFVIIString("True"), 120, mStartY, color1);
    KERNEL->DrawString(RStringToFFVIIString("False"), 160, mStartY, color2);



    // TEST2
    KERNEL->DrawString(RStringToFFVIIString("Test2"), 50, mStartY + 20, F_BLUE);



    // Timer
    RString timer_string;
    timer_string.Format("%04d:%02d", mTimer / 60, mTimer % 60);

    KERNEL->DrawString(mFFString, 20, 150, F_WHITE);

    KERNEL->DrawCounter(20, 100, timer_string);
}
