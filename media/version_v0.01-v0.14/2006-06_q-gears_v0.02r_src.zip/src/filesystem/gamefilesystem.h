/*
 *  $Id: gamefilesystem.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef GAMEFILESYSTEM_H
#define GAMEFILESYSTEM_H



#include "filesystem.h"
#include "driver/nullfiledriver.h"

#include <string>
#include <vector>



class GameFileSystem : public FileSystem
{
public:
                         GameFileSystem();
    virtual             ~GameFileSystem();

    virtual unsigned int GetFileSize(const std::string &path);
    virtual bool         ReadFile(const std::string &path, const void* buffer, const unsigned int start, const unsigned int length);

private:
    NullFileDriver mFileDriver;
};



extern GameFileSystem *GAMEFILESYSTEM;



#endif // GAMEFILESYSTEM_H
