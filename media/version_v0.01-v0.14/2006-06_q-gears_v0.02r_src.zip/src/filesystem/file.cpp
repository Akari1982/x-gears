#include "file.h"
#include "gamefilesystem.h"
#include "realfilesystem.h"
#include "../utilites/logger.h"

#include <cassert>
#include <string>



File::File(const RString &file):
    mBuffer(NULL),
    mBufferSize(0),
    mFileName(file)
{
    mBufferSize = REALFILESYSTEM->GetFileSize(mFileName);

    mBuffer = (u8*)malloc(sizeof(u8) * mBufferSize);

    if (!REALFILESYSTEM->ReadFile(mFileName, mBuffer, 0, mBufferSize))
    {
        LOGGER->Log("Warning: %s not found!", mFileName.c_str());
    }
}



File::File(File* file, u32 offset, u32 length):
    mBuffer(NULL),
    mBufferSize(length)
{
    assert(file != NULL);

    mFileName = file->GetFileName();

    mBuffer = (u8 *)malloc(sizeof(u8) * mBufferSize);
    file->GetFileBuffer(mBuffer, offset, mBufferSize);
}



File::File(u8* buffer, u32 offset, u32 length):
    mBuffer(NULL),
    mBufferSize(length),
    mFileName("BUFFER")
{
    assert(buffer != NULL);

    mBuffer = (u8*)malloc(sizeof(u8) * mBufferSize);
    memcpy(mBuffer, buffer, mBufferSize);
}



File::File(File *file)
{
    assert(file != NULL);

    mBufferSize = file->GetFileSize();
    mFileName   = file->GetFileName();

    mBuffer = (u8*)malloc(sizeof(u8) * mBufferSize);
    file->GetFileBuffer(mBuffer, 0, mBufferSize);
}


File::~File()
{
    free(mBuffer);
}



const RString&
File::GetFileName() const
{
    return mFileName;
}



const File::u32&
File::GetFileSize() const
{
    return mBufferSize;
}



void
File::GetFileBuffer(u8 *buffer, u32 start, u32 length)
{
    memcpy(buffer, mBuffer + start, length);
}



const File::u8
File::GetU8(const u32 offset)
{
    return (u8)(*(mBuffer + offset));
}



const File::u16
File::GetU16LE(const u32 offset)
{
    return ((u8*)mBuffer + offset)[0] | (((u8*)mBuffer + offset)[1] << 8);
}



const File::u32
File::GetU32LE(const u32 offset)
{
    return ((u8*)mBuffer + offset)[0] | (((u8*)mBuffer + offset)[1] << 8) | (((u8*)mBuffer + offset)[2] << 16) | (((u8*)mBuffer + offset)[3] << 24);
}



void
File::WriteFile(const RString &file)
{
    REALFILESYSTEM->WriteNewFile(file, mBuffer, mBufferSize);
}
