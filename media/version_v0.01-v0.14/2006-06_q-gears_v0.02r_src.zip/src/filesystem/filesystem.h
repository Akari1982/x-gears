/*
 *  $Id: filesystem.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef FILESYSTEM_H
#define FILESYSTEM_H



#include "../utilites/nocopy.h"

#include <string>
#include <vector>



class FileSystem : public NoCopy<FileSystem>
{
public:
                         FileSystem();
    virtual             ~FileSystem();

    virtual unsigned int GetFileSize(const std::string &path) = 0;
    virtual bool         ReadFile(const std::string &path, const void* buffer, const unsigned int start, const unsigned int length) = 0;
};



#endif // FILESYSTEM_H
