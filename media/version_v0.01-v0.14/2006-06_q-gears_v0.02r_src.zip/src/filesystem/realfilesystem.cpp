/*
 *  $Id: realfilesystem.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "realfilesystem.h"

#include <stdio.h>



RealFileSystem *REALFILESYSTEM = NULL;



RealFileSystem::RealFileSystem()
{
}



RealFileSystem::~RealFileSystem()
{
}



unsigned int
RealFileSystem::GetFileSize(const std::string &path)
{
    FILE* file = fopen(path.c_str(), "rb");

    if (file == NULL)
    {
        return 0;
    }

    // set cursor to end of file
    fseek(file, 0, SEEK_END);
    unsigned int size = ftell(file);
    fclose(file);
    return size;
}



bool
RealFileSystem::ReadFile(const std::string &path, const void* buffer, const unsigned int start, const unsigned int length)
{
    FILE* file = fopen(path.c_str(), "rb");

    if (file == NULL)
    {
        return false;
    }

    fseek(file, start, SEEK_SET);
    fread(const_cast<void*>(buffer), sizeof(char), length, file);
    fclose(file);

    return true;
}



bool
RealFileSystem::WriteFile(const std::string &path, const void* buffer, const unsigned int length)
{
    FILE* file = fopen(path.c_str(), "ab");

    if (file == NULL)
    {
        return false;
    }

    fwrite(buffer, sizeof(char), length, file);
    fclose(file);

    return true;
}



bool
RealFileSystem::WriteNewFile(const std::string &path, const void* buffer, unsigned int length)
{
    RemoveFile(path);
    return !!(WriteFile(path, buffer, length));
}



bool
RealFileSystem::RemoveFile(const std::string &path)
{
    return (remove(path.c_str()) == 0);
}
