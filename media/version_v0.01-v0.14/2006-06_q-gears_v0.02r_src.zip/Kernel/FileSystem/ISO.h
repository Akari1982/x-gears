#ifndef ISO_H_
#define ISO_H_

#ifndef	UINT8
typedef	unsigned char UINT8;
#endif
#ifndef	UINT16
typedef	unsigned short UINT16;
#endif

#ifndef UINT32
typedef unsigned UINT32;
#endif

#define	ISO_RAW_SEC_SIZE	2352
#define	ISO_CACHE_SIZE		16

#define ISO_BOOTREC_SECTOR	16
#define	ISO_VOLDESC_SECTOR	16

typedef struct ISO_SecHdr
{
	UINT8	Sync[12];
	UINT8	Minute, 
			Second,
			Frame;
	UINT8	Mode;
};

typedef struct M2_SubHdr
{
	UINT8	FileN,
			ChannelN,
			SubMode,
			CodeInfo;
	UINT8	FileN2,
			ChannelN2,
			SubMode2,
			CodeInfo2;
};

typedef struct BaseSec
{
	ISO_SecHdr	Header;
	UINT8		Data[2336];
};

typedef struct ISO_SecM1F1
{
	ISO_SecHdr	Header;
	UINT8	Data[2048];
	UINT32	EDC;
	UINT8	Zs[8];
	UINT8	ECC[276];
};

typedef	struct ISO_SecM2F1
{
	ISO_SecHdr	Header;
	M2_SubHdr	SubHdr;
	UINT8		Data[2048];
	UINT32		EDC;
	UINT8		ECC[276];
};

typedef struct ISO_SecM2F2
{
	ISO_SecHdr	Header;
	M2_SubHdr	SubHdr;
	UINT8		Data[2324];
	UINT8		Spare[4];
};

typedef struct ISO_VolDesc9660
{
	UINT8	Type;
	char	ID[5];
	UINT8	Version;
	UINT8	Data[2041];
};

typedef struct ISO_BootRec9660
{
	UINT8	Type;
	char	ID[5];
	UINT8	Version;
	char	System[32];
	char	VolID[32];
	UINT8	Data[1975];
};

typedef struct ISO_TimeDateRec
{
	UINT8	Year,
			Month,
			Day,
			Hour,
			Min,
			Sec,
			TimeZone;
};

typedef	struct ISO_DirRec
{
	UINT8	DirRecLen;
	UINT8	EARecLen;
	UINT32	LocExt[2];
	UINT32	DataLen[2];
	ISO_TimeDateRec
			RecTimeDate;
	UINT8	Flags;
	UINT8	UnitSize;
	UINT8	GapSize;
	UINT16	VolSeq[2];
	UINT8	FileNameLen;
	UINT8	FileName;
};

typedef struct ISO_PathTblRec
{
	UINT8	LenName;
	UINT8	LenEARec;
	UINT32	LocExt;
	UINT16	ParentDir;
	UINT8	DirName[0];
};

typedef struct ISO_VolDateTime
{
	char	Year[4];
	char	Month[2];
	char	Day[2];
	char	Hour[2];
	char	Minute[2];
	char	Second[2];
	char	Hundredths[2];
	UINT8	TimeZone;
};

typedef struct ISO_PrimaryVDesc
{
	UINT8	Type;
	char	ID[5];
	UINT8	Version;
	UINT8	ZZ0;
	char	SystemID[40-8];
	char	VolumeID[72-40];
	UINT8	ZZ1[8];
	UINT32	VolSpaceSize[2];
	UINT8	ZZ2[120-88];
	UINT16	VolSetSize[2];
	UINT16	VolSeq[2];
	UINT16	LogicalBlockSize[2];
	UINT32	PathTblSize[2];
	UINT32	LocationOccLPTbl;
	UINT32	LocationOptOccLPTbl;
	UINT32	LocationOccMPTbl;
	UINT32	LocationOptOccMPTbl;
	ISO_DirRec
			RootDirectory;
	char	VolSetID[318-190];
	char	Publisher[446-318];
	char	DataPrep[574-446];
	char	Application[702-574];
	char	CopyRightF[739-702];
	char	AbstractF[776-739];
	char	BibloF[813-776];
	ISO_VolDateTime
			VolumeCreation;
	ISO_VolDateTime
			VolumeMod;
	ISO_VolDateTime
			VolumeExp;
	ISO_VolDateTime
			VolumeEff;
	UINT8	FileStrucVersion;
	UINT8	ZZ3;
	UINT8	AppUse[1395-883];
	UINT8	ZZ5[2048-1395];
};

typedef	char ISO_RawSector[ISO_RAW_SEC_SIZE];

typedef	struct CacheEl
{
	UINT8	Age;
	int		Sector;
};

#define	MFS2SEC(M, S, F)	((M)*60*75 + (S)*75 + (F))

// base class
class ISO
{
private:
	// primary volume descriptor of CD
	ISO_PrimaryVDesc PrimVD;
	// sector cache
	ISO_RawSector	*Sectors;	// cached sector data
	CacheEl		*Cache;			// index table to cached sectors
	
	int			SizeOfCache;	// how many sectors are cached
	int			SectorCount;	// number of sectors in Image
	char		*ISO_Path;		// Path data pointer
	char		ImagePath[2048];// big for rediculously loong paths
	
	void		Init(int);	// initialize variables etc.
	void		Reset(void);// clean things up
	void		Age(void);	// make the sector cache older
	int			Oldest(void);	// the least used sector
	int			Find(int);		// find Sector in Cache -1 if fails
public:
	ISO();
	// create sector cache of N size
	ISO(int);
	virtual ~ISO();
	// sector reads DATA areas Only from
	// a sector
	void	*Sector(int);
	// RawSector reads a pure sector and 
	// all it's contents
	void	*RawSector(int);
	// return sector's mode
	int		Mode(int);
	// get Cache Size
	//int		CacheSize(void);
	// set Cache Size
	//void	CacheSize(int);
	// get ISO image path
	char	*Path(void);
	// set ISO image path
	void	Path(char *);	
};

#endif /*ISO_H_*/
