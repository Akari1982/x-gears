#include "ISO.h"
#include <stdio.h>
#include <memory.h>
//#include <ios.h>
#include <fstream.h>

ISO::ISO()
{
	Init(ISO_CACHE_SIZE);
}

ISO::ISO(int N)
{
	Init(N);
}

ISO::~ISO()
{
	if(Sectors != NULL)
	{
		delete Sectors;
	}
	if(Cache != NULL)
	{
		delete Cache;
	}
}

void ISO::Init(int N)
{
	SizeOfCache = N;
	// if there are sectors allocated
	if(Sectors != NULL)
	{	// delete the sectors allocated
		delete Sectors;
	}
	// if there is a cache register allocated
	if(Cache != NULL)
	{
		delete Cache;
	}
	// allocate new sectors
	Sectors = new ISO_RawSector[SizeOfCache];
	Cache = new CacheEl[SizeOfCache];
	// reset the system
	Reset();	
}

void ISO::Reset(void)
{
	// Set Path pointer
	ISO_Path = ImagePath;
	// clear path information
	memset(ImagePath, 0, sizeof(ImagePath));
	// clear primary volume descriptor
	memset((void *)&PrimVD, 0, sizeof(ISO_PrimaryVDesc));
	// clear all residual cache data	
	memset(Sectors, 0, sizeof(ISO_RawSector)*SizeOfCache);
	// all sectors are old and invalid
	memset(Cache, 0xFF, sizeof(CacheEl)*SizeOfCache);
}

// age all the tags in the cache until it reaches 0 
// 0 - indicates it's in the old sock drawer
// and is first to be recycled
void ISO::Age(void)
{
	int	Index;
	for(Index = 0; Index < SizeOfCache; Index++)
	{
		// if it's < the maximum age
		if(Cache[Index].Age < 0xFF)
		{
			// if it has a valid sector
			if(Cache[Index].Sector >= 0)
				Cache[Index].Age++;
		}
	}
}

// grab the oldest part of the cache.
// IE the lowest Aged sector
int	ISO::Oldest(void)
{
	int	Index = 0;
	int	Return;
	
	Return = -1;
	do
	{
		if(Cache[Index].Age < 0xFF)
		{
			if(Cache[Return].Age < Cache[Index].Age)
			{
				Return = Index;
			}
		}
		else
			return Index;
		Index++;
	}
	while(Index < SizeOfCache);
	return Return;
}

// find SectorID in the cache
int	ISO::Find(int SectorID)
{
	int	Index = 0;
	
	while((Index < SizeOfCache)&&
		(Cache[Index].Sector != SectorID))
		Index++;
	// if we reached the end of the cache we failed
	if(Index >= SizeOfCache)
		Index = -1;
	return Index;
}

void *ISO::Sector(int SectorID)
{
	BaseSec 	*Reference;
	void		*Return;
	
	Reference = (BaseSec *)RawSector(SectorID);
	if(Reference != NULL)
	{
		if(Reference->Header.Mode == 1)
		{	// Mode one Form ?? :D
			ISO_SecM1F1 *Info = (ISO_SecM1F1 *)Reference;
			Return = (void *)&Info->Data;
		}
		else
		{
			// Mode 2 has 2 forms 
			// however the data is always in the same location
			ISO_SecM2F1 *Info = (ISO_SecM2F1 *)Reference;
			Return = (void *)&Info->Data;
		}
	}
	else
		Return = (void *)Reference;
	return Return;
}

void *ISO::RawSector(int SectorID)
{
	void *Return = NULL;
	int		Index;
	
	// find the sector in the cache
	Index = Find(SectorID);
	if(Index < 0)
	{	// we have a cache miss load it into the cache
		fstream	File;
		
		File.open(ISO_Path, fstream::in);
		if(File.is_open())
		{	// file is open find the oldest cache segement
			Index = Oldest();
			// move to file location of the sector
			File.seekg(ISO_RAW_SEC_SIZE*SectorID, fstream::beg);
			// load the data into the cache
			File.read((char *)&Sectors[Index], sizeof(ISO_RawSector));
			// everytime something new is swapped in age all entries.
			Age();
			// this is the yougest addition
			Cache[Index].Age = 0;
			Cache[Index].Sector = SectorID;
			// close the open file
			File.close();
		}
	}
	Return = (void *)&Sectors[Index];
	return Return;
}

void ISO::Path(char *APath)
{
	fstream	File;
	
	File.open(APath, fstream::in);
	if(File.is_open())
	{
		// we found the fille find it's size
		File.seekg(0, fstream::end);
		SectorCount = File.tellg();
		// close the file
		File.close();
		// get the sector count
		SectorCount/= sizeof(ISO_RawSector);
		// now it's safe to set the path since it's 
		// a valid file
		strncpy(ISO_Path, APath, sizeof(ImagePath) - 1);
	}
}

char *ISO::Path(void)
{
	return ISO_Path;
}

int	ISO::Mode(int SectorID)
{
	BaseSec 	*Reference;
	
	Reference = (BaseSec *)RawSector(SectorID);
	return Reference->Header.Mode;
}
