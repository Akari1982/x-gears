menu = {
    start = function(self)
        module:run_battle(300);
    end,



    finish = function(self)
    end,



    onupdate = function(self)
    end,



    oninput = function(self, button)
    end,
};
