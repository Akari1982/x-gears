After you run the game call console with '~' and enter field id you want to run.

start console       - '~'
pause - 'F11'
exit - 'ESC'

console commands:
/field 1            - test 1
/field 2            - test 2
/field 3            - test 3
/field 65           - startmap
/field 116          - start of game

/battle 300         - run battle (battle id can be 300-324)

/quit               - exit game

additional console commands are in file console_commands.ods



player control:
move - directional buttons.
run - 'X'
exit battle - 'Z'

camera control:
move - 'WASD'
rotate - mouse with right couse button

debug field walkmesh and triggers   - '1'
debug field model                   - '2'
debug game items                    - '8'
debug game party                    - '9'



ps: If you have some questions ask http://community.livejournal.com/q_gears/ or http://forums.qhimm.com