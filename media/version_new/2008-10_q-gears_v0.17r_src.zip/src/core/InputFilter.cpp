// $Id$

#include "InputFilter.h"



InputFilter::InputFilter(void)
{
    // game
    //SetInputMap(OIS::KC_SPACE,       "game_assist");
    //SetInputMap(OIS::KC_RETURN,      "game_start");
    SetInputMap("message_up",              OIS::KC_UP,               IE_PRESSED);
    SetInputMap("message_down",            OIS::KC_DOWN,             IE_PRESSED);
    SetInputMap("game_up",                 OIS::KC_UP,               IE_PRESSED | IE_REPEATED);
    SetInputMap("game_right",              OIS::KC_RIGHT,            IE_PRESSED | IE_REPEATED);
    SetInputMap("game_down",               OIS::KC_DOWN,             IE_PRESSED | IE_REPEATED);
    SetInputMap("game_left",               OIS::KC_LEFT,             IE_PRESSED | IE_REPEATED);
    //SetInputMap(OIS::KC_HOME,        "game_camera");
    //SetInputMap(OIS::KC_PGUP,        "game_target");
    //SetInputMap(OIS::KC_PGDOWN,      "game_next");
    //SetInputMap(OIS::KC_END,         "game_previous");
    SetInputMap("game_menu",               OIS::KC_S,                IE_PRESSED);
    SetInputMap("game_run",                OIS::KC_Z,                IE_PRESSED | IE_REPEATED);
    SetInputMap("game_ok",                 OIS::KC_X,                IE_PRESSED);
    SetInputMap("game_ok_repeated",        OIS::KC_X,                IE_REPEATED);
    SetInputMap("game_cancel",             OIS::KC_Z,                IE_PRESSED);
    //SetInputMap(OIS::KC_A,           "game_switch");

    // application specific
    SetInputMap("pause",                   OIS::KC_F11,              IE_PRESSED);
    SetInputMap("quit",                    OIS::KC_ESCAPE,           IE_PRESSED);
    SetInputMap("console",                 OIS::KC_GRAVE,            IE_PRESSED);

    // camera
    SetInputMap("camera_change",           OIS::KC_C,                IE_PRESSED);
    SetInputMap("camera_rotate_on",        OIS::MB_Right + 256,      IE_PRESSED);
    SetInputMap("camera_rotate_off",       OIS::MB_Right + 256,      IE_RELEASED);
    SetInputMap("camera_forward",          OIS::KC_W,                IE_PRESSED | IE_REPEATED);
    SetInputMap("camera_left",             OIS::KC_A,                IE_PRESSED | IE_REPEATED);
    SetInputMap("camera_backward",         OIS::KC_S,                IE_PRESSED | IE_REPEATED);
    SetInputMap("camera_right",            OIS::KC_D,                IE_PRESSED | IE_REPEATED);

    // debug
    SetInputMap("debug_field_walkmesh",    OIS::KC_1,                IE_PRESSED);
    SetInputMap("debug_field_triggers",    OIS::KC_1,                IE_PRESSED);
    SetInputMap("debug_field_model",       OIS::KC_2,                IE_PRESSED);
    //SetInputMap("debug_field_script",      OIS::KC_3,                IE_PRESSED);
    //SetInputMap("debug_field_message",     OIS::KC_4,                IE_PRESSED);
    //SetInputMap("debug_field_fade",        OIS::KC_5,                IE_PRESSED);
    //SetInputMap("debug_field_encounter",   OIS::KC_3,                IE_PRESSED);
    SetInputMap("debug_game_party",        OIS::KC_9,                IE_PRESSED);
    SetInputMap("debug_game_items",        OIS::KC_8,                IE_PRESSED);

    Reset();
}



InputFilter::~InputFilter(void)
{
}



void
InputFilter::Reset(void)
{
    for (int button = 0; button < 264; ++button)
    {
        m_ButtonState[button] = false;
    }

    m_EventQueue.clear();
}



void
InputFilter::ButtonPressed(const int button, const bool down)
{
    if (m_ButtonState[button] != down)
    {
        m_ButtonState[button] = down;
        InsertEventsForButton(button, (m_ButtonState[button] == true) ? IE_PRESSED : IE_RELEASED);
    }
}



void
InputFilter::MouseMoved(int x, int y)
{
    m_EventQueue.push_back(Event("mouse_move", x, y));
}



void
InputFilter::Update(void)
{
    for (int button = 0; button < 264; ++button)
    {
        if (m_ButtonState[button] == true)
        {
            InsertEventsForButton(button, IE_REPEATED);
        }
    }
}



bool
InputFilter::IsButtonPressed(const int button) const
{
    return m_ButtonState[button];
}



void
InputFilter::GetInputEvents(InputEventArray& input_events)
{
    input_events = m_EventQueue;

    m_EventQueue.clear();
}



void
InputFilter::ClearAllMappings(void)
{
    m_InputMap.clear();
}



void
InputFilter::SetInputMap(const Ogre::String& name, const int button, const int type)
{
    Mapping mapping;
    mapping.key  = button;
    mapping.name = name;
    mapping.type = type;
    m_InputMap.push_back(mapping);
}



void
InputFilter::InsertEventsForButton(const int button, const InputEventType type)
{
    std::vector<Mapping>::iterator i = m_InputMap.begin();

    for (; i != m_InputMap.end(); ++i)
    {
        //Ogre::LogManager::getSingletonPtr()->logMessage("Check '" + (*i).name + "':" + Ogre::StringConverter::toString(int((*i).key)) + "==" + Ogre::StringConverter::toString((int)button));

        if ((*i).key == button && ((*i).type & type))
        {
            //Ogre::LogManager::getSingletonPtr()->logMessage("Add '" + (*i).name + "' and type '" + Ogre::StringConverter::toString(int(type)) + "'");
            m_EventQueue.push_back(Event((*i).name, 0, 0));
        }
    }
}
