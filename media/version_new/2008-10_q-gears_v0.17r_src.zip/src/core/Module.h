// $Id$

#ifndef MODULE_h
#define MODULE_h

#include <vector>

#include "Actor.h"



enum MODULE_STATE
{
    MODULE_START,
    MODULE_RUN,
    MODULE_FINISH,
    MODULE_STOP
};



class Module : public Actor
{
public:
                       Module(const int parameter);
    virtual           ~Module();

    virtual void       Input(const Event& input) = 0;
    virtual void       OnStart(const float delta_time) = 0;
    virtual void       Update(const float delta_time) = 0;
    virtual void       OnFinish(const float delta_time) = 0;

    virtual void       OnPauseOn(){};
    virtual void       OnPauseOff(){};

    void               SetState(const MODULE_STATE state);
    const MODULE_STATE GetState() const;

private:
                       Module();

private:
    MODULE_STATE m_State;
};



#endif // MODULE_MANAGER_h
