// $Id$

#ifndef LUA_MATH_h
#define LUA_MATH_h



class LuaMath
{
public:
              LuaMath();
             ~LuaMath();

    const int IsVisible() const;

};



#endif // LUA_MATH_h
