// $Id$

#ifndef BINDER_h
#define BINDER_h

#include <lua.hpp>
#include <luabind/luabind.hpp>



void BindGameStateToLua(lua_State* state);
void BindModuleManagerToLua(lua_State* state);



#endif // BINDER_h
