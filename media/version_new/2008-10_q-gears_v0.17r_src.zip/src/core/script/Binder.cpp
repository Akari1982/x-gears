// $Id$

#include "Binder.h"
#include "../ModuleManager.h"
#include "../../game/Gamestate.h"



void
BindGameStateToLua(lua_State* state)
{
    luabind::module(state)
    [
        luabind::class_<GameState>("GameState")
            .def("variable_set", (void(GameState::*)(const char*, const int))&GameState::ScriptVariableSet)
            .def("variable_get", (int(GameState::*)(const char*))&GameState::ScriptVariableGet)
            .def("item_add", (void(GameState::*)(const int, const int))&GameState::ScriptItemAdd)
            .def("item_get", (int(GameState::*)(const int))&GameState::ScriptItemGet)
            .def("party_set_size", (void(GameState::*)(const int))&GameState::ScriptPartySetSize)
            .def("party_clear", (void(GameState::*)())&GameState::ScriptPartyClear)
            .def("character_add_to_party", (void(GameState::*)(const int))&GameState::ScriptCharacterAddToParty)
            .def("character_remove_from_party", (void(GameState::*)(const int))&GameState::ScriptCharacterRemoveFromParty)
    ];

    luabind::globals(state)["game"] = boost::ref(*g_GameState);
}



void
BindModuleManagerToLua(lua_State* state)
{
    luabind::module(state)
    [
        luabind::class_<ModuleManager>("ModuleManager")

            .def("run_field", (void(ModuleManager::*)(const int))&ModuleManager::RunField)
            .def("run_menu", (void(ModuleManager::*)(const int))&ModuleManager::RunMenu)
            .def("run_battle", (void(ModuleManager::*)(const int))&ModuleManager::RunBattle)
    ];

    luabind::globals(state)["module"] = boost::ref(*g_ModuleManager);
}
