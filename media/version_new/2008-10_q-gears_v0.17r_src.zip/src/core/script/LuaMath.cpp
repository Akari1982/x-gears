// $Id$

#include <OgreLogManager.h>
#include <OgreOverlayManager.h>
#include <OgreRoot.h>
#include <OgreStringConverter.h>

#include "Configuration.h"
#include "Console.h"
#include "ModuleManager.h"
#include "../Main.h"
#include "../game/GameState.h"



template<>Console *Ogre::Singleton<Console>::ms_Singleton=0;



void ConsoleQuit(std::vector<Ogre::String>& parameter)
{
    g_ApplicationState = QG_EXIT;
}



void ConsoleFieldLoad(std::vector<Ogre::String>& parameter)
{
    if (parameter.size() > 1)
    {
        int map_id = Ogre::StringConverter::parseInt(parameter[1]);

        Ogre::LogManager::getSingletonPtr()->logMessage("[CONSOLE] Field start " + parameter[1]);

        g_ModuleManager->RunField(map_id);
    }
}



void ConsoleBattleLoad(std::vector<Ogre::String>& parameter)
{
    if (parameter.size() > 1)
    {
        int battle_id = Ogre::StringConverter::parseInt(parameter[1]);

        Ogre::LogManager::getSingletonPtr()->logMessage("[CONSOLE] Battle start " + parameter[1]);

        g_ModuleManager->RunBattle(battle_id);
    }
}



void ConsoleMenuLoad(std::vector<Ogre::String>& parameter)
{
    if (parameter.size() > 1)
    {
        int menu_id = Ogre::StringConverter::parseInt(parameter[1]);

        Ogre::LogManager::getSingletonPtr()->logMessage("[CONSOLE] Menu start " + parameter[1]);

        g_ModuleManager->RunMenu(menu_id);
    }
}



Console::Console():
    m_BackgroundX(0),
    m_BackgroundY(-480),
    m_BackgroundWidth(640),
    m_BackgroundHeight(480),

    m_VersionTextBoxX(470),
    m_VersionTextBoxY(-12),

    m_OutputTextBoxX(5),
    m_OutputTextBoxY(-200),

    m_Visible(false),
    m_Speed(500),
    m_Height(0),
    m_MaxHeight(200),

    m_StartLine(0),
    m_UpdateLines(true),
    m_LinesWidth(85),
    m_LinesMaxNumber(10)
{
    Ogre::Root* root = Ogre::Root::getSingletonPtr();
    Ogre::SceneManager* scene = root->getSceneManager("Scene");

    // create background for console
    m_Background = (Ogre::PanelOverlayElement*)Ogre::OverlayManager::getSingleton().createOverlayElement("Panel", "ConsoleBackground");
    m_Background->setMetricsMode(Ogre::GMM_PIXELS);
    m_Background->setPosition(m_BackgroundX, m_BackgroundY);
    m_Background->setWidth(m_BackgroundWidth);
    m_Background->setHeight(m_BackgroundHeight);
    m_Background->setMaterialName("console/background");

    // create text field for version output
    m_VersionTextBox = new TextArea("ConsoleVersionText");
    m_VersionTextBox->setCaption("Q-Gears 0.00 alpha-2.");
    m_VersionTextBox->setMetricsMode(Ogre::GMM_PIXELS);
    m_VersionTextBox->setPosition(m_VersionTextBoxX, m_VersionTextBoxY);
    m_VersionTextBox->setFontName("Console");
    m_VersionTextBox->setCharHeight(12);

    // create text field for output
    m_OutputTextBox = new TextArea("ConsoleOutputText");
    m_OutputTextBox->setCaption("");
    m_OutputTextBox->setMetricsMode(Ogre::GMM_PIXELS);
    m_OutputTextBox->setPosition(m_OutputTextBoxX, m_OutputTextBoxY);
    m_OutputTextBox->setFontName("Console");
    m_OutputTextBox->setCharHeight(18);

    m_Overlay = Ogre::OverlayManager::getSingleton().create("Console");
    m_Overlay->add2D((Ogre::OverlayContainer*)m_Background);
    m_Overlay->add2D((Ogre::OverlayContainer*)m_OutputTextBox);
    m_Overlay->add2D((Ogre::OverlayContainer*)m_VersionTextBox);
    m_Overlay->setZOrder(QGOO_CONSOLE);
    m_Overlay->show();

    // add as frame and log listner
    root->addFrameListener(this);
    Ogre::LogManager::getSingleton().getDefaultLog()->addListener(this);

    // init output text
    for (int i = 0; i < m_LinesMaxNumber; ++i)
    {
        m_Lines.push_back("");
    }

    // add few default actions
    AddCommand("/quit", &ConsoleQuit);
    AddCommand("/field", &ConsoleFieldLoad);
    AddCommand("/battle", &ConsoleBattleLoad);
    AddCommand("/menu", &ConsoleMenuLoad);
}



Console::~Console()
{
    Ogre::Root* root = Ogre::Root::getSingletonPtr();
    Ogre::SceneManager* scene = root->getSceneManager("Scene");

    // remove as listner
    Ogre::LogManager::getSingleton().getDefaultLog()->removeListener(this);
    root->removeFrameListener(this);

    m_Overlay->remove2D((Ogre::OverlayContainer*)m_OutputTextBox);
    delete m_OutputTextBox;
    m_Overlay->remove2D((Ogre::OverlayContainer*)m_VersionTextBox);
    delete m_VersionTextBox;
    m_Overlay->remove2D((Ogre::OverlayContainer*)m_Background);
    Ogre::OverlayManager::getSingleton().destroyOverlayElement(m_Background);

    Ogre::OverlayManager::getSingleton().destroy("Console");
}



bool
Console::keyPressed(const OIS::KeyEvent& arg)
{
    if (m_Visible != true)
    {
        return false;
    }

    if (arg.key == OIS::KC_RETURN && prompt.length())
    {
        //split the parameter list
        const char* str = prompt.c_str();
        std::vector<Ogre::String> params;
        Ogre::String param = "";
        for (int c = 0; c < prompt.length(); ++c)
        {
            if (str[c] == ' ')
            {
                if (param.length())
                {
                    params.push_back(param);
                }
                param = "";
            }
            else
            {
                param += str[c];
            }
        }
        if (param.length())
        {
            params.push_back(param);
        }

        //try to execute the command
        std::map<Ogre::String, void(*)(std::vector<Ogre::String>&)>::iterator i;
        for (i = commands.begin(); i != commands.end(); ++i)
        {
            if ((*i).first == params[0])
            {
                if ((*i).second)
                {
                    (*i).second(params);
                }
                break;
            }
        }

        if (i == commands.end())
        {
            // send event
            Event event;
            event.name = params[0];
            for (int i = 1; i < params.size(); ++i)
            {
                event.value.push_back(params[i]);
            }
            g_GameState->Input(event);
            g_ModuleManager->Input(event);
        }

        print(prompt);
        prompt = "";
    }
    else if (arg.key == OIS::KC_BACK)
    {
        prompt = prompt.substr(0, prompt.length() - 1);
    }
    else if (arg.key == OIS::KC_PGUP)
    {
        if (m_StartLine > 0)
        {
            --m_StartLine;
        }
    }
    else if (arg.key == OIS::KC_PGDOWN)
    {
        if (m_StartLine < m_Lines.size())
        {
            ++m_StartLine;
        }
    }
    else
    {
        char legalchars[] = "ABCDEFGHIJKLMNOPQRSTUVWXUZabcdefghijklmnopqrstuvwxyz1234567890+!\"#%&/()=?[]\\*-_.:,; ";
        for (int c = 0; c < sizeof(legalchars) - 1; ++c)
        {
            if (legalchars[c] == arg.text)
            {
                prompt += arg.text;
                break;
            }
        }
    }

    m_UpdateLines = true;
}



bool
Console::frameStarted(const Ogre::FrameEvent &evt)
{
    if (m_Visible == true && m_Height < m_MaxHeight)
    {
        m_Height += evt.timeSinceLastFrame * m_Speed;

        m_Background->show();
        m_VersionTextBox->show();
        m_OutputTextBox->show();

        if (m_Height >= m_MaxHeight)
        {
            m_Height = m_MaxHeight;
        }
    }
    else if (m_Visible == false && m_Height > 0)
    {
        m_Height -= evt.timeSinceLastFrame * m_Speed;

        if (m_Height <= 0)
        {
            m_Height = 0;

            m_Background->hide();
            m_VersionTextBox->hide();
            m_OutputTextBox->hide();
        }
    }

    m_Background->setPosition(m_BackgroundX, m_BackgroundY + m_Height);
    m_VersionTextBox->setPosition(m_VersionTextBoxX, m_VersionTextBoxY + m_Height);
    m_OutputTextBox->setPosition(m_OutputTextBoxX, m_OutputTextBoxY + m_Height);



    if (m_UpdateLines == true)
    {
        Ogre::String text;
        std::list<Ogre::String>::iterator i, start, end;

        //make sure is in range
        if (m_StartLine > m_Lines.size())
        {
            m_StartLine = m_Lines.size();
        }

        start = m_Lines.begin();
        for (int c = 0; c < m_StartLine; ++c)
        {
            ++start;
        }

        end = start;

        for (int c = 0; c < m_LinesMaxNumber; ++c)
        {
            if (end == m_Lines.end())
            {
                break;
            }
            ++end;
        }

        for (i = start; i != end; ++i)
        {
            text += (*i) + "\n";
        }

        //add the prompt
        text += ">" + prompt;

        m_OutputTextBox->setCaption(Ogre::DisplayString(text));
        m_UpdateLines = false;
    }

    return true;
}



void
Console::print(const Ogre::String &text)
{
    //subdivide it into lines
    const char *str = text.c_str();
    int start = 0, count = 0;
    int len = text.length();
    Ogre::String line;

    for (int c = 0; c < len; ++c)
    {
        if (str[c] == '\n' || line.length() >= m_LinesWidth)
        {
            m_Lines.push_back(line);
            line = "";
        }

        if (str[c] != '\n')
        {
            line += str[c];
        }
    }

    if (line.length())
    {
        m_Lines.push_back(line);
    }

    if (m_Lines.size() > m_LinesMaxNumber)
    {
        m_StartLine = m_Lines.size() - m_LinesMaxNumber;
    }
    else
    {
        m_StartLine = 0;
    }

    m_UpdateLines = true;
}



bool
Console::frameEnded(const Ogre::FrameEvent &evt)
{
    return true;
}



void
Console::SetVisible(bool is_visible)
{
    m_Visible = is_visible;
}



bool
Console::IsVisible() const
{
    return m_Visible;
}



void
Console::AddCommand(const Ogre::String& command, void (*func)(std::vector<Ogre::String>&))
{
    commands[command] = func;
}



void
Console::RemoveCommand(const Ogre::String &command)
{
    commands.erase(commands.find(command));
}



void
Console::messageLogged(const Ogre::String& message, Ogre::LogMessageLevel lml, bool maskDebug, const Ogre::String &logName)
{
    //print(logName + ": " + message);
};
