// $Id$

#include <OgreLogManager.h>
#include <OgreStringConverter.h>

#include "XmlFile.h"



XmlFile::XmlFile(const Ogre::String& file):
    m_File(NULL)
{
    m_File = xmlParseFile(file.c_str());

    if (m_File == NULL)
    {
        Ogre::LogManager::getSingletonPtr()->logMessage("[ERROR] Can't open " + file + ".");
    }
}



XmlFile::~XmlFile(void)
{
    xmlFreeDoc(m_File);
}



const bool
XmlFile::GetBool(const xmlNodePtr& node, const Ogre::String& tag) const
{
    bool ret = false;

    xmlChar* prop = xmlGetProp(node, BAD_CAST tag.c_str());
    if (prop != NULL)
    {
        Ogre::String string = (const char*)prop;
        ret = Ogre::StringConverter::parseBool(string);
        xmlFree(prop);
    }

    return ret;
}



const int
XmlFile::GetInt(const xmlNodePtr& node, const Ogre::String& tag) const
{
    int ret = 0;

    xmlChar* prop = xmlGetProp(node, BAD_CAST tag.c_str());
    if (prop != NULL)
    {
        Ogre::String string = (const char*)prop;
        ret = Ogre::StringConverter::parseInt(string);
        xmlFree(prop);
    }

    return ret;
}



const float
XmlFile::GetFloat(const xmlNodePtr& node, const Ogre::String& tag) const
{
    float ret = 0;

    xmlChar* prop = xmlGetProp(node, BAD_CAST tag.c_str());
    if (prop != NULL)
    {
        Ogre::String string = (const char*)prop;
        ret = Ogre::StringConverter::parseReal(string);
        xmlFree(prop);
    }

    return ret;
}



const Ogre::String
XmlFile::GetString(const xmlNodePtr& node, const Ogre::String& tag) const
{
    Ogre::String ret("");

    xmlChar* prop = xmlGetProp(node, BAD_CAST tag.c_str());
    if (prop != NULL)
    {
        ret = (const char*)prop;
        xmlFree(prop);
    }

    return ret;
}



const Ogre::UTFString
XmlFile::GetText(const xmlNodePtr& node) const
{
    Ogre::UTFString ret = "";

    for (xmlNodePtr node2 = node->xmlChildrenNode; node2 != NULL; node2 = node2->next)
    {
        if (node2->type == XML_TEXT_NODE)
        {
            xmlBufferPtr buffer = xmlBufferCreateSize(1024);
            int res = xmlNodeBufGetContent(buffer, node2);
            if (res == -1)
            {
                Ogre::LogManager::getSingletonPtr()->logMessage("[ERROR] Failed to read text.");
            }
            else
            {
                ret = (const char*)(xmlBufferContent(buffer));
            }
            xmlBufferFree(buffer);
        }
    }

    return ret;
}



const Ogre::Vector3
XmlFile::GetVector3(const xmlNodePtr& node, const Ogre::String& tag) const
{
    Ogre::Vector3 ret = Ogre::Vector3::ZERO;

    xmlChar* prop = xmlGetProp(node, BAD_CAST tag.c_str());
    if (prop != NULL)
    {
        Ogre::String string = (const char*)prop;
        ret = Ogre::StringConverter::parseVector3(string);

        xmlFree(prop);
    }

    return ret;
}



const Ogre::Matrix4
XmlFile::GetMatrix4(const xmlNodePtr& node, const Ogre::String& tag) const
{
    Ogre::Matrix4 ret = Ogre::Matrix4::IDENTITY;

    xmlChar* prop = xmlGetProp(node, BAD_CAST tag.c_str());
    if (prop != NULL)
    {
        Ogre::String string = (const char*)prop;
        ret = Ogre::StringConverter::parseMatrix4(string);

        xmlFree(prop);
    }

    return ret;
}
