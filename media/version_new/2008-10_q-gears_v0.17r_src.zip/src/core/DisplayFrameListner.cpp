// $Id$

#include <Ogre.h>
#include <OIS/OIS.h>

#include "Console.h"
#include "DisplayFrameListner.h"
#include "ModuleManager.h"
#include "../Main.h"
#include "../game/GameState.h"



DisplayFrameListener::DisplayFrameListener(Ogre::RenderWindow* win):
    m_Window(win),

    m_InputManager(0),
    m_Keyboard(0),

    m_GameSpeed(1.0f)
{
    Ogre::LogManager::getSingletonPtr()->logMessage("Initializing OIS");
    OIS::ParamList pl;
    size_t windowHnd = 0;
    std::ostringstream windowHndStr;

    win->getCustomAttribute("WINDOW", &windowHnd);
    windowHndStr << windowHnd;
    pl.insert(std::make_pair(std::string("WINDOW"), windowHndStr.str()));

    m_InputManager = OIS::InputManager::createInputSystem(pl);

    m_Keyboard = static_cast<OIS::Keyboard*>(m_InputManager->createInputObject(OIS::OISKeyboard, true));
    m_Keyboard->setEventCallback(this);

    m_Mouse = static_cast<OIS::Mouse*>(m_InputManager->createInputObject(OIS::OISMouse, true));
    m_Mouse->setEventCallback(this);



    //Register as a Window listener
    Ogre::WindowEventUtilities::addWindowEventListener(m_Window, this);
}



DisplayFrameListener::~DisplayFrameListener(void)
{
    m_InputManager->destroyInputObject(m_Keyboard);
    m_InputManager->destroyInputObject(m_Mouse);

    OIS::InputManager::destroyInputSystem(m_InputManager);

    //Remove ourself as a Window listener
    Ogre::WindowEventUtilities::removeWindowEventListener(m_Window, this);
    windowClosed(m_Window);
}



bool
DisplayFrameListener::frameStarted(const Ogre::FrameEvent& evt)
{
    if (g_ApplicationState == QG_EXIT)
    {
        return false;
    }

    if (m_Keyboard)
    {
        m_Keyboard->capture();
    }

    if (m_Mouse)
    {
        m_Mouse->capture();
    }

    m_InputFilter.Update();

    static InputEventArray input_event_array;
    input_event_array.clear();
    m_InputFilter.GetInputEvents(input_event_array);

    for (int i = 0; i < input_event_array.size(); ++i)
    {
        if (input_event_array[i].name == "pause")
        {
            m_GameSpeed = (m_GameSpeed == 0.0f) ? 1.0f : 0.0f;
            continue;
        }
        else if (input_event_array[i].name == "quit")
        {
            Ogre::LogManager::getSingletonPtr()->logMessage("Quit Pressed");
            g_ApplicationState = QG_EXIT;
            continue;
        }
        else if (input_event_array[i].name == "console")
        {
            if (Console::getSingleton().IsVisible() == true)
            {
                Console::getSingleton().SetVisible(false);
            }
            else
            {
                Console::getSingleton().SetVisible(true);
            }
            continue;
        }



        if (Console::getSingleton().IsVisible() == false)
        {
            g_GameState->Input(input_event_array[i]);
            g_ModuleManager->Input(input_event_array[i]);
        }
    }



    g_GameState->Update(evt.timeSinceLastFrame * m_GameSpeed);
    g_ModuleManager->Update(evt.timeSinceLastFrame * m_GameSpeed);



    return true;
}



bool
DisplayFrameListener::frameEnded(const Ogre::FrameEvent& evt)
{
    return true;
}



void
DisplayFrameListener::windowMoved(Ogre::RenderWindow *rw)
{
}



void
DisplayFrameListener::windowResized(Ogre::RenderWindow *rw)
{
}



void
DisplayFrameListener::windowClosed(Ogre::RenderWindow* rw)
{
    g_ApplicationState = QG_EXIT;
}



void
DisplayFrameListener::windowFocusChange(Ogre::RenderWindow *rw)
{
}



bool
DisplayFrameListener::keyPressed(const OIS::KeyEvent &event)
{
    //Ogre::LogManager::getSingletonPtr()->logMessage("button pressed " + Ogre::StringConverter::toString(event.key) + " with symbol '" + Ogre::StringConverter::toString(event.text) + "'.");

    if (Console::getSingleton().IsVisible() == true)
    {
        // send button to console
        Console::getSingleton().keyPressed(event);
    }

    m_InputFilter.ButtonPressed(event.key, true);

    return true;
}



bool
DisplayFrameListener::keyReleased(const OIS::KeyEvent& event)
{
    m_InputFilter.ButtonPressed(event.key, false);

    return true;
}



bool
DisplayFrameListener::mouseMoved(const OIS::MouseEvent &e)
{
    m_InputFilter.MouseMoved(e.state.X.rel, e.state.Y.rel);

    return true;
}



bool
DisplayFrameListener::mousePressed(const OIS::MouseEvent &e, OIS::MouseButtonID id)
{
    m_InputFilter.ButtonPressed(id + 256, true);

    return true;
}



bool
DisplayFrameListener::mouseReleased(const OIS::MouseEvent &e, OIS::MouseButtonID id)
{
    m_InputFilter.ButtonPressed(id + 256, false);

    return true;
}
