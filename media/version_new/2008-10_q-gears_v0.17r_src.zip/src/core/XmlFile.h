// $Id$

#ifndef XML_FILE_h
#define XML_FILE_h

#include <libxml/tree.h>
#include <OgreMatrix4.h>
#include <OgreString.h>
#include <OgreVector3.h>
#include <OgreUTFString.h>



class XmlFile
{
public:
    explicit       XmlFile(const Ogre::String& file);
    virtual       ~XmlFile(void);

    const bool                GetBool(const xmlNodePtr& node, const Ogre::String& tag) const;
    const int                 GetInt(const xmlNodePtr& node, const Ogre::String& tag) const;
    const float               GetFloat(const xmlNodePtr& node, const Ogre::String& tag) const;
    const Ogre::String        GetString(const xmlNodePtr& node, const Ogre::String& tag) const;
    const Ogre::UTFString     GetText(const xmlNodePtr& node) const;
    const Ogre::Vector3       GetVector3(const xmlNodePtr& node, const Ogre::String& tag) const;
    const Ogre::Matrix4       GetMatrix4(const xmlNodePtr& node, const Ogre::String& tag) const;

protected:
    xmlDocPtr m_File;
};



#endif // XML_FILE_h
