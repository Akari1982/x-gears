// $Id$

#ifndef CONSOLE_h
#define CONSOLE_h

#include <OgreFrameListener.h>
#include <OgreLog.h>
#include <OgrePanelOverlayElement.h>
#include <OgreSingleton.h>
#include <OIS/OIS.h>
#include <list>
#include <vector>

#include "ui/TextArea.h"



class Console : public Ogre::Singleton<Console>, public Ogre::FrameListener, public Ogre::LogListener
{
public:
         Console();
        ~Console();

    void SetVisible(bool is_visible);
    bool IsVisible() const;

    void AddCommand(const Ogre::String &command, void (*)(std::vector<Ogre::String>&));
    void RemoveCommand(const Ogre::String &command);

    void print(const Ogre::String &text);

    virtual bool frameStarted(const Ogre::FrameEvent &evt);
    virtual bool frameEnded(const Ogre::FrameEvent &evt);
    bool         keyPressed(const OIS::KeyEvent& e);

    virtual void messageLogged( const Ogre::String& message, Ogre::LogMessageLevel lml, bool maskDebug, const Ogre::String& logName);

private:
    Ogre::PanelOverlayElement*    m_Background;
    Ogre::Real                    m_BackgroundWidth;
    Ogre::Real                    m_BackgroundHeight;
    Ogre::Real                    m_BackgroundX;
    Ogre::Real                    m_BackgroundY;
    TextArea*                     m_VersionTextBox;
    Ogre::Real                    m_VersionTextBoxX;
    Ogre::Real                    m_VersionTextBoxY;
    TextArea*                     m_OutputTextBox;
    Ogre::Real                    m_OutputTextBoxX;
    Ogre::Real                    m_OutputTextBoxY;
    Ogre::Overlay*                m_Overlay;

    bool                          m_Visible;
    int                           m_Speed;
    float                         m_Height;
    Ogre::Real                    m_MaxHeight;

    int                           m_StartLine;
    int                           m_LinesWidth;
    int                           m_LinesMaxNumber;
    std::list<Ogre::String>       m_Lines;
    bool                          m_UpdateLines;


    Ogre::String                  prompt;
    std::map<Ogre::String, void (*)(std::vector<Ogre::String>&)> commands;
};



#endif // CONSOLE_h
