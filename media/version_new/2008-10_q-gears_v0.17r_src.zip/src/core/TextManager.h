// $Id$

#ifndef TEXT_MANAGER_h
#define TEXT_MANAGER_h

#include <OgreString.h>
#include <OgreUTFString.h>
#include <map>

struct TextData
{
    TextData():
        text(""),
        width(0),
        height(0)
    {
    }

    Ogre::UTFString     text;
    int                 width;
    int                 height;
};



class TextManager
{
public:
                          TextManager(void);
    virtual              ~TextManager(void);

    void                  LoadTexts(const Ogre::String& file_name);
    const TextData        GetText(const int id);
    void                  AddText(const int id, const TextData& text);
    void                  SetLanguageRoot(const Ogre::String& root);

private:
    Ogre::String            m_LanguageRoot;
    std::map<int, TextData> m_Texts;
};



extern TextManager* g_TextManager;



#endif // TEXT_MANAGER_h
