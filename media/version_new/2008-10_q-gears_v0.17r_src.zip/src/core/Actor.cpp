// $Id$

#include "Actor.h"



Actor::Actor(void)
{
}



Actor::~Actor(void)
{
}
