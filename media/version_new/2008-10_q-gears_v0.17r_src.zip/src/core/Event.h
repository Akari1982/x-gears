// $Id$

#ifndef EVENT_h
#define EVENT_h

#include <OgreString.h>



typedef std::vector<Ogre::String> EventStringValues;



struct Event
{
    Event():
        name(""),
        x(0),
        y(0)
    {
    };

    Event(const Ogre::String& n):
        name(n),
        x(0),
        y(0)
    {
    };

    Event(const Ogre::String& n, int c_x, int c_y):
        name(n),
        x(c_x),
        y(c_y)
    {
    };

    Ogre::String      name;
    int               x;
    int               y;
    EventStringValues value;
};



#endif // EVENT_h
