// $Id$

#include "Module.h"



Module::Module()
{
}



Module::Module(const int parameter)
{
}



Module::~Module()
{
}



void
Module::SetState(const MODULE_STATE state)
{
    m_State = state;
}



const MODULE_STATE
Module::GetState() const
{
    return m_State;
}
