// $Id$

#ifndef MODULE_MANAGER_h
#define MODULE_MANAGER_h

#include <vector>

#include "Actor.h"
#include "Module.h"



class ModuleManager : public Actor
{
public:
                          ModuleManager(void);
    virtual              ~ModuleManager(void);

    void                  Input(const Event& input);
    void                  Update(const float delta_time);

    void                  RunField(const int map_id);
    void                  RunBattle(const int battle_id);
    void                  RunMenu(const int menu_id);

private:
    Module* m_RunningMapModule;
    Module* m_RequestedMapModule;

    Module* m_RunningBattleModule;
    Module* m_RequestedBattleModule;

    Module* m_RunningMenuModule;
    Module* m_RequestedMenuModule;
};



extern ModuleManager* g_ModuleManager;



#endif // MODULE_MANAGER_h
