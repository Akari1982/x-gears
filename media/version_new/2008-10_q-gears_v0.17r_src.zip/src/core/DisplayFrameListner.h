// $Id$

#ifndef DISPLAY_FRAME_LISTENER_h
#define DISPLAY_FRAME_LISTENER_h

#include <Ogre.h>
#include <OIS/OIS.h>

#include "InputFilter.h"



class DisplayFrameListener : public Ogre::FrameListener, public Ogre::WindowEventListener, public OIS::KeyListener, public OIS::MouseListener
{
public:
                 DisplayFrameListener(Ogre::RenderWindow* win);
    virtual     ~DisplayFrameListener(void);

    bool         frameStarted(const Ogre::FrameEvent& evt);
    bool         frameEnded(const Ogre::FrameEvent& evt);

    virtual void windowMoved(Ogre::RenderWindow *rw);
    virtual void windowResized(Ogre::RenderWindow *rw);
    virtual void windowClosed(Ogre::RenderWindow* rw);
    virtual void windowFocusChange(Ogre::RenderWindow *rw);

    bool         keyPressed(const OIS::KeyEvent& e);
    bool         keyReleased(const OIS::KeyEvent& e);

    bool         mouseMoved(const OIS::MouseEvent &e);
    bool         mousePressed(const OIS::MouseEvent &e, OIS::MouseButtonID id);
    bool         mouseReleased(const OIS::MouseEvent &e, OIS::MouseButtonID id);

protected:
    Ogre::RenderWindow* m_Window;

    OIS::InputManager*  m_InputManager;
    OIS::Keyboard*      m_Keyboard;
    OIS::Mouse*         m_Mouse;

    InputFilter         m_InputFilter;

    float               m_GameSpeed;
};



#endif // BATTLE_MODULE_h
