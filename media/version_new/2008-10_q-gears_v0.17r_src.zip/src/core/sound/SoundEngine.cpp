/*
	This file is part of Q-Gears.

	Copyright 2008 G

	Q-Gears is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Q-Gears is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with Q-Gears.  If not, see <http://www.gnu.org/licenses/>.
*/



#include <string>
#include <list>
#include <boost/thread.hpp>

#if defined(__WIN32__) || defined(_WIN32)
	#include <al.h>
	#include <alc.h>
#else
	#include <AL/al.h>
	#include <AL/alc.h>
#endif

#include <vorbis/vorbisfile.h>
#include <Ogre.h>

#include "SoundEngine.h"



#define USED_IN_QGEARS



using namespace std;
using namespace boost;



template<>SoundEngine *Ogre::Singleton<SoundEngine>::ms_Singleton = 0;



const ALfloat SoundEngine::m_DEFAULT_LISTENER_POS[3] =
{
	0.0f, 0.0f, 0.0f
};

const ALfloat SoundEngine::m_DEFAULT_LISTENER_VEL[3] =
{
	0.0f, 0.0f, 0.0f
};

const ALfloat SoundEngine::m_DEFAULT_LISTENER_ORI[6] =
{
	0.0f, 0.0f, -1.0f,  0.0f, 1.0f, 0.0f
};

ALCdevice *SoundEngine::m_ALDevice = NULL;
string SoundEngine::m_ErrorMessage("");
const string SoundEngine::m_LogPrefix("SoundEngine: ");


SoundEngine::SoundEngine() :
	m_ThreadContinue(true),
	m_NextHandle(INVALID_HANDLE + 1)
{
	// suspend next created thread while not fully initialized
	recursive_mutex::scoped_lock lock(m_UpdateMutex);

	Log("Initializing...");

	m_Initialized = OpenALInit();

	if(m_Initialized)
	{
		Log("Success");
		m_Buffer = new char[m_CH_BUF_SIZE];
		m_UpdateThread = new thread(ref(*this));
	}
	else
		Log("Failure");
}


SoundEngine::~SoundEngine()
{
	StopAllSounds();

	if(m_Initialized)
	{
		Log("Destroying...");

		m_ThreadContinue = false;
		m_UpdateThread->join();
		delete m_UpdateThread;
		delete [] m_Buffer;

		OpenALFree();
		Log("Success");
	}
}


const bool SoundEngine::AddSound(const int arg_id, const string &arg_filename,
		const double arg_loop)
{
	recursive_mutex::scoped_lock lock(m_UpdateMutex);

	bool result;

	if(GetSoundRecord(arg_id) == m_SoundDB.end())
	{
		SoundRecord record = {arg_id, arg_filename, arg_loop};
		m_SoundDB.push_back(record);
		result = true;
	}
	else
		result = false;

	return result;
}


const bool SoundEngine::IsSoundAdded(const int arg_id)
{
	recursive_mutex::scoped_lock lock(m_UpdateMutex);

	return GetSoundRecord(arg_id) != m_SoundDB.end();
}


const bool SoundEngine::RemoveSound(const int arg_id)
{
	recursive_mutex::scoped_lock lock(m_UpdateMutex);

	bool result;

	list<SoundRecord>::iterator it = GetSoundRecord(arg_id);
	if(it != m_SoundDB.end())
	{
		m_SoundDB.erase(it);
		result = true;
	}
	else
		result = false;

	return result;
}


const SoundEngine::Handle SoundEngine::PlaySoundA(const int arg_id)
{
	recursive_mutex::scoped_lock lock(m_UpdateMutex);

	Channel ch;
	ch.id = arg_id;
	ch.handle = INVALID_HANDLE;

	if(!m_Initialized)
		return ch.handle;

	// open vorbis file
	ch.vorbis = new OggVorbis_File;
	list<SoundRecord>::iterator record = GetSoundRecord(ch.id);
	if(record != m_SoundDB.end() &&
			!ov_fopen(const_cast<char *>(record->path.c_str()), ch.vorbis))
	{
		// get file info
		ch.info = ov_info(ch.vorbis, -1.0f);

		// select first stream
		ch.vorbis_section = 0;

		// clear stream finished flag
		ch.stream_finished = false;

		// create sound source
		alGenSources(1, &ch.source);

		// create buffers
		ALuint buffers[m_CH_BUF_COUNT];
		alGenBuffers(m_CH_BUF_COUNT, buffers);

		// set source parameters
		alSourcei(ch.source, AL_LOOPING, AL_FALSE);

		// fill buffers
		for(int i = 0; i < m_CH_BUF_COUNT; ++i)
		{
			FillBuffer(ch, buffers[i]);
			alSourceQueueBuffers(ch.source, 1, &buffers[i]);
		}

		// start playback
		alSourcePlay(ch.source);

		// assign unical handle for this sound
		ch.handle = GetUnusedHandle();

		// add generated channel to processing pipeline
		m_Channels.push_back(ch);
	}
	else
	{
		Log("Can't play file");
	}

	return ch.handle;
}


const bool SoundEngine::IsSoundPlaying(const SoundEngine::Handle arg_handle)
{
	recursive_mutex::scoped_lock lock(m_UpdateMutex);

	list<Channel>::iterator it = GetChannel(arg_handle);
	return it != m_Channels.end();
}


const bool SoundEngine::StopSound(const SoundEngine::Handle arg_handle)
{
	recursive_mutex::scoped_lock lock(m_UpdateMutex);

	bool result;

	list<Channel>::iterator it = GetChannel(arg_handle);
	if(it != m_Channels.end())
	{
		StopChannel(*it);
		m_Channels.erase(it);
		result = true;
	}
	else
		result = false;

	return result;
}


const bool SoundEngine::PauseSound(const SoundEngine::Handle arg_handle,
		const bool arg_pause)
{
	recursive_mutex::scoped_lock lock(m_UpdateMutex);

	bool result;

	list<Channel>::iterator it = GetChannel(arg_handle);
	if(it != m_Channels.end())
	{
		if(arg_pause)
			alSourcePause(it->source);
		else
			alSourcePlay(it->source);

		result = true;
	}
	else
		result = false;

	return result;
}


void SoundEngine::PauseAllSounds()
{
	recursive_mutex::scoped_lock lock(m_UpdateMutex);

	for(list<Channel>::iterator it = m_Channels.begin();
			it != m_Channels.end(); ++it)
		PauseSound(it->handle, true);
}


void SoundEngine::ResumeAllSounds()
{
	recursive_mutex::scoped_lock lock(m_UpdateMutex);

	for(list<Channel>::iterator it = m_Channels.begin();
			it != m_Channels.end(); ++it)
		PauseSound(it->handle, false);
}


void SoundEngine::StopAllSounds()
{
	recursive_mutex::scoped_lock lock(m_UpdateMutex);

	for(list<Channel>::iterator it = m_Channels.begin();
			it != m_Channels.end(); ++it)
	{
		StopChannel(*it);
	}
	m_Channels.clear();
}


void SoundEngine::operator()()
{
	while(m_ThreadContinue)
	{
		Update();

		// sleep some time [250ms]
		xtime xt;
		xtime_get(&xt, TIME_UTC);
		xt.nsec += m_ThreadSleepTime * 1000000;
		thread::sleep(xt);

		// try give control to another threads, in we are non-preemptive
		m_UpdateThread->yield();
	}
}


const bool SoundEngine::OpenALInit()
{
	bool result = false;

	m_ALDevice = alcOpenDevice(NULL);
	if (m_ALDevice == NULL)
	{
		Log("Default sound device is not present");
		return result;
	}

	// create and select rendering context
	m_ALContext = alcCreateContext(m_ALDevice, NULL);
	if (m_ALContext == NULL)
	{
		Log("Can't create context for sound device");
		return result;
	}
	alcMakeContextCurrent(m_ALContext);

	// set default listener properties
	alListenerfv(AL_POSITION, m_DEFAULT_LISTENER_POS);
	alListenerfv(AL_VELOCITY, m_DEFAULT_LISTENER_VEL);
	alListenerfv(AL_ORIENTATION, m_DEFAULT_LISTENER_ORI);

	result = true;

	return result;
}


void SoundEngine::OpenALFree()
{
	// deselect active context
	alcMakeContextCurrent(NULL);
	// destroy context
	alcDestroyContext(m_ALContext);
	// close sound device
	alcCloseDevice(m_ALDevice);
}


const bool SoundEngine::OpenALalError()
{
	bool result;

	ALenum error_code = alGetError();

	if(error_code == AL_NO_ERROR)
		result = false;
	else
	{
		m_ErrorMessage = string(alGetString(error_code));
		result = true;
	}

	return result;
}


const bool SoundEngine::OpenALalcError(const ALCdevice *arg_device)
{
	bool result;

	const ALCdevice *device = (arg_device == NULL ?
		const_cast<ALCdevice *>(m_ALDevice) :
		const_cast<ALCdevice *>(arg_device));

	ALCenum error_code = alcGetError(const_cast<ALCdevice *>(device));

	if(error_code == ALC_NO_ERROR)
		result = false;
	else
	{
		m_ErrorMessage =
			string(alcGetString(const_cast<ALCdevice *>(device), error_code));
		result = true;
	}

	return result;
}


const SoundEngine::Handle SoundEngine::GetUnusedHandle()
{
	Handle result = m_NextHandle++;

	// save next valid handle
	while(IsSoundPlaying(m_NextHandle) || m_NextHandle == INVALID_HANDLE)
		++m_NextHandle;

	return result;
}


void SoundEngine::StopChannel(Channel &ret_ch)
{
	// stop source
	alSourceStop(ret_ch.source);

	// get source buffers
	int queued_count = 0;
	alGetSourcei(ret_ch.source, AL_BUFFERS_QUEUED, &queued_count);

	// unqueue and delete buffers
	for(int i = 0; i < queued_count; ++i)
	{
		ALuint buffer_id;
		alSourceUnqueueBuffers(ret_ch.source, 1, &buffer_id);
		alDeleteBuffers(1, &buffer_id);
	}

	// delete source
	alDeleteSources(1, &ret_ch.source);

	// rest cleanup
	ov_clear(ret_ch.vorbis);
	delete ret_ch.vorbis;
}


const list<SoundEngine::SoundRecord>::iterator
SoundEngine::GetSoundRecord(const int arg_id)
{
	list<SoundRecord>::iterator result = m_SoundDB.end();

	for(list<SoundRecord>::iterator it = m_SoundDB.begin();
			it != m_SoundDB.end(); ++it)
	{
		if(it->id == arg_id)
		{
			result = it;
			break;
		}
	}

	return result;
}


const list<SoundEngine::Channel>::iterator
SoundEngine::GetChannel(const Handle arg_handle)
{
	list<Channel>::iterator result = m_Channels.end();

	for(list<Channel>::iterator it = m_Channels.begin();
			it != m_Channels.end(); ++it)
	{
		if(it->handle == arg_handle)
		{
			result = it;
			break;
		}
	}

	return result;
}


void SoundEngine::FillBuffer(Channel &ret_ch, const ALuint arg_buffer_id)
{
	if(ret_ch.stream_finished)
		return;

	ALsizei read = 0;

	bool finished = false;
	while(!finished)
	{
		long result = ov_read(ret_ch.vorbis, m_Buffer + read,
			m_CH_BUF_SIZE - read, 0, 2, 1, &ret_ch.vorbis_section);

		switch(result)
		{
		// error
		case OV_HOLE:
		case OV_EBADLINK:
		case OV_EINVAL:
			finished = true;
			break;

		// end of stream
		case 0:
			{
				double loop = GetSoundRecord(ret_ch.id)->loop;
				// if there isn't loop point
				if(loop < 0.0f)
				{
					finished = true;
					ret_ch.stream_finished = true;
				}
				else
				{
					// perform seek
					if(ov_time_seek(ret_ch.vorbis, loop))
					{
						// seek unsuccessfull
						finished = true;
						ret_ch.stream_finished = true;
					}
				}
			}
			break;

		// readed "result" bytes
		default:
			read += result;
			if(read == m_CH_BUF_SIZE)
				finished = true;
		}
	}

	if(read)
	{
		alBufferData(arg_buffer_id, ret_ch.info->channels == 1 ?
			AL_FORMAT_MONO16 : AL_FORMAT_STEREO16, (const ALvoid *)m_Buffer,
			(ALsizei)read, (ALsizei)ret_ch.info->rate);
	}
}


const bool SoundEngine::RefreshBuffers(Channel &ret_ch)
{
	bool result = false;

	// try to fill processed buffers
	{
		int processed;
		alGetSourcei(ret_ch.source, AL_BUFFERS_PROCESSED, &processed);

		for(int i = 0; i < processed; ++i)
		{
			ALuint buffer_id;
			alSourceUnqueueBuffers(ret_ch.source, 1, &buffer_id);

			// try fill buffer
			FillBuffer(ret_ch, buffer_id);

			// finished reading stream
			if(ret_ch.stream_finished)
				break;
			// queue buffer
			else
				alSourceQueueBuffers(ret_ch.source, 1, &buffer_id);
		}
	}

	// manage source state
	{
		ALenum source_state;
		alGetSourcei(ret_ch.source, AL_SOURCE_STATE, &source_state);
		if(source_state == AL_STOPPED)
		{
			int queued;
			alGetSourcei(ret_ch.source, AL_BUFFERS_QUEUED, &queued);

			if(ret_ch.stream_finished && !queued)
			{
				StopChannel(ret_ch);
				result = true;
			}
			else
				alSourcePlay(ret_ch.source);
		}
	}

	return result;
}


void SoundEngine::Update()
{
	recursive_mutex::scoped_lock lock(m_UpdateMutex);

	for(list<Channel>::iterator it = m_Channels.begin();
			it != m_Channels.end(); ++it)
	{
		if(RefreshBuffers(*it))
		{
			m_Channels.erase(it);
		}
	}
}


void SoundEngine::Log(const string &arg_message)
{
#ifdef USED_IN_QGEARS
	Ogre::LogManager::getSingletonPtr()->logMessage(m_LogPrefix + arg_message);
#else
	cout << m_LogPrefix << arg_message << endl;
#endif
}
