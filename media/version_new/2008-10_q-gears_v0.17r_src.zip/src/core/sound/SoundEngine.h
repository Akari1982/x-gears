/*
	This file is part of Q-Gears.

	Copyright 2008 G

	Q-Gears is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Q-Gears is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with Q-Gears.  If not, see <http://www.gnu.org/licenses/>.
*/



#ifndef SOUND_MANAGER_HH__
#define SOUND_MANAGER_HH__



#include <string>
#include <sstream>
#include <list>
#include <boost/thread.hpp>

#if defined(__WIN32__) || defined(_WIN32)
	#include <al.h>
	#include <alc.h>
#else
	#include <AL/al.h>
	#include <AL/alc.h>
#endif

#include <vorbis/vorbisfile.h>
#include <Ogre.h>



class SoundEngine : public Ogre::Singleton<SoundEngine>
{
public:
	typedef uint32_t Handle;

	enum
	{
		INVALID_HANDLE = 0
	};

	SoundEngine();
	~SoundEngine();

	// sound database management
	const bool AddSound(const int arg_id, const std::string &arg_filename,
			const double arg_loop = -1.0f);
	const bool IsSoundAdded(const int arg_id);
	const bool RemoveSound(const int arg_id);

	// playback interface
	const Handle PlaySoundA(const int arg_id);
	const bool IsSoundPlaying(const Handle arg_handle);
	const bool StopSound(const Handle arg_handle);
	const bool PauseSound(const Handle arg_handle, const bool arg_pause = true);
	void PauseAllSounds();
	void ResumeAllSounds();
	void StopAllSounds();

	// boost threading interface
	void operator()();

private:
	// allocate for every new stream two 96Kb buffer chunks
	// every chunk would buffer ~0.5 seconds of 44100Hz stereo 16-bit data
	// in that case we can sleep updating buffers for 250ms
	static const int m_CH_BUF_COUNT = 2;
	static const ALsizei m_CH_BUF_SIZE = 96 * 1024;

	// default listener position
	static const ALfloat m_DEFAULT_LISTENER_POS[3];
	// default listener speed
	static const ALfloat m_DEFAULT_LISTENER_VEL[3];
	// default listener orientation
	static const ALfloat m_DEFAULT_LISTENER_ORI[6];

	// general
	static const std::string m_LogPrefix;
	bool m_Initialized;
	static ALCdevice *m_ALDevice;
	ALCcontext *m_ALContext;
	char *m_Buffer;
	static std::string m_ErrorMessage;

	// threading
	static const int m_ThreadSleepTime = 250;
	boost::recursive_mutex m_UpdateMutex;
	boost::thread *m_UpdateThread;
	bool m_ThreadContinue;

	struct SoundRecord
	{
		int id;
		std::string path;
		double loop;
	};

	struct Channel
	{
		Handle handle;
		uint32_t id;
		OggVorbis_File *vorbis;
		vorbis_info *info;
		int vorbis_section;
		bool stream_finished;

		ALuint source;
	};

	Handle m_NextHandle;
	std::list<SoundRecord> m_SoundDB;
	std::list<Channel> m_Channels;

	const bool OpenALInit();
	void OpenALFree();
	static const bool OpenALalError();
	static const bool OpenALalcError(const ALCdevice *arg_device = NULL);


	const Handle GetUnusedHandle();

	void StopChannel(Channel &ret_ch);

	const std::list<SoundRecord>::iterator GetSoundRecord(const int arg_id);
	const std::list<Channel>::iterator GetChannel(const Handle arg_handle);

	void FillBuffer(Channel &ret_ch, const ALuint arg_buffer_id);
	const bool RefreshBuffers(Channel &ret_ch);
	void Update();

	static void Log(const std::string &arg_message);
};



#endif
