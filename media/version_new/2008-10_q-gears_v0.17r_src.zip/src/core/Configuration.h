// $Id$

#ifndef CONFIGURATION_h
#define CONFIGURATION_h



#include <OgreSingleton.h>
#include <map>
#include <vector>



typedef std::vector<Ogre::String> ValueList;

class Configuration : public Ogre::Singleton<Configuration>
{
public:
                     Configuration();
    virtual         ~Configuration();

    void             SetOption(const Ogre::String& name, const ValueList& value);
    void             SetOption(const Ogre::String& name, const bool value);

    const ValueList& GetOptionValueList(const Ogre::String& name);
    const bool       GetOptionBool(const Ogre::String& name);

private:
    std::map<Ogre::String, ValueList> m_Configuration;
};



#endif // CONFIGURATION_h
