#include "TextArea.h"

#include "OgreStableHeaders.h"
#include "OgreRoot.h"
#include "OgreLogManager.h"
#include "OgreOverlayManager.h"
#include "OgreHardwareBufferManager.h"
#include "OgreHardwareVertexBuffer.h"
#include "OgreException.h"
#include "OgreStringConverter.h"
#include "OgreFont.h"
#include "OgreFontManager.h"

#define DEFAULT_INITIAL_CHARS 12

#define POS_TEX_BINDING 0
#define COLOUR_BINDING 1

#define UNICODE_NEL 0x0085
#define UNICODE_CR 0x000D
#define UNICODE_LF 0x000A
#define UNICODE_SPACE 0x0020
#define UNICODE_ZERO 0x0030

Ogre::String TextArea::m_TypeName = "QGearsTextArea";



TextArea::TextArea(const Ogre::String& name):
    Ogre::OverlayContainer(name),
    m_AllocSize(0),
    m_HorizontalAlignment(LEFT)
{
    mCharHeight = 0.02;
    mPixelCharHeight = 12;
    mSpaceWidth = 0;
    mPixelSpaceWidth = 0;
    mViewportAspectCoef = 1;
}



TextArea::~TextArea()
{
    delete m_RenderOp.vertexData;
}



void
TextArea::initialise(void)
{
    if (!mInitialised)
    {
        // Set up the render op
        // Combine positions and texture coords since they tend to change together
        // since character sizes are different
        m_RenderOp.vertexData = new Ogre::VertexData();
        Ogre::VertexDeclaration* decl = m_RenderOp.vertexData->vertexDeclaration;
        size_t offset = 0;
        // Positions
        decl->addElement(POS_TEX_BINDING, offset, Ogre::VET_FLOAT3, Ogre::VES_POSITION);
        offset += Ogre::VertexElement::getTypeSize(Ogre::VET_FLOAT3);
        // Texcoords
        decl->addElement(POS_TEX_BINDING, offset, Ogre::VET_FLOAT2, Ogre::VES_TEXTURE_COORDINATES, 0);
        offset += Ogre::VertexElement::getTypeSize(Ogre::VET_FLOAT2);
        // Colours - store these in a separate buffer because they change less often
        decl->addElement(COLOUR_BINDING, 0, Ogre::VET_COLOUR, Ogre::VES_DIFFUSE);

        m_RenderOp.operationType = Ogre::RenderOperation::OT_TRIANGLE_LIST;
        m_RenderOp.useIndexes = false;
        m_RenderOp.vertexData->vertexStart = 0;

        // Vertex buffer will be created in checkMemoryAllocation
        CheckMemoryAllocation(DEFAULT_INITIAL_CHARS);

        mInitialised = true;
    }

}

void
TextArea::CheckMemoryAllocation(const int number_of_chars)
{
    if (m_AllocSize < number_of_chars)
    {
        // Create and bind new buffers
        // Note that old buffers will be deleted automatically through reference counting

        // 6 verts per char since we're doing tri lists without indexes
        // Allocate space for positions & texture coords
        Ogre::VertexDeclaration* decl = m_RenderOp.vertexData->vertexDeclaration;
        Ogre::VertexBufferBinding* bind = m_RenderOp.vertexData->vertexBufferBinding;

        m_RenderOp.vertexData->vertexCount = number_of_chars * 6;



        Ogre::HardwareVertexBufferSharedPtr vbuf;

        // Create dynamic since text tends to change alot
        // positions & texcoords
        vbuf = Ogre::HardwareBufferManager::getSingleton().createVertexBuffer(
                    decl->getVertexSize(POS_TEX_BINDING),
                    m_RenderOp.vertexData->vertexCount,
                    Ogre::HardwareBuffer::HBU_DYNAMIC_WRITE_ONLY);
        bind->setBinding(POS_TEX_BINDING, vbuf);

        // colours
        vbuf = Ogre::HardwareBufferManager::getSingleton().createVertexBuffer(
                    decl->getVertexSize(COLOUR_BINDING),
                    m_RenderOp.vertexData->vertexCount,
                    Ogre::HardwareBuffer::HBU_DYNAMIC_WRITE_ONLY);
        bind->setBinding(COLOUR_BINDING, vbuf);

        m_AllocSize = number_of_chars;
    }
}



int
TextArea::GetCaptionSize() const
{
    return mCaption.size();
}




void
TextArea::setCaption( const Ogre::DisplayString& caption )
{
    mCaption = caption;
    mGeomPositionsOutOfDate = true;
    mGeomUVsOutOfDate = true;
}



void
TextArea::setFontName(const Ogre::String& font)
{
    m_Font = Ogre::FontManager::getSingleton().getByName(font);
    if (m_Font.isNull())
    {
        OGRE_EXCEPT(Ogre::Exception::ERR_ITEM_NOT_FOUND, "Could not find font " + font, "TextArea::setFontName");
    }

    m_Font->load();
    mpMaterial = m_Font->getMaterial();
    mpMaterial->setDepthCheckEnabled(false);
    mpMaterial->setLightingEnabled(false);

    mGeomPositionsOutOfDate = true;
    mGeomUVsOutOfDate = true;
}



const Ogre::String&
TextArea::getFontName() const
{
    return m_Font->getName();
}



void
TextArea::setTextAlignment(const HorizontalAlignment& alignment)
{
    m_HorizontalAlignment = alignment;
}



void
TextArea::setCharHeight(Ogre::Real height)
{
    if (mMetricsMode != Ogre::GMM_RELATIVE)
    {
        mPixelCharHeight = static_cast<unsigned>(height);
    }
    else
    {
        mCharHeight = height;
    }
    mGeomPositionsOutOfDate = true;
}



Ogre::Real
TextArea::getCharHeight() const
{
    if (mMetricsMode == Ogre::GMM_PIXELS)
    {
        return mPixelCharHeight;
    }
    else
    {
        return mCharHeight;
    }
}



void
TextArea::setSpaceWidth(Ogre::Real width)
{
    if (mMetricsMode != Ogre::GMM_RELATIVE)
    {
        mPixelSpaceWidth = static_cast<unsigned>(width);
    }
    else
    {
        mSpaceWidth = width;
    }

    mGeomPositionsOutOfDate = true;
}



Ogre::Real
TextArea::getSpaceWidth() const
{
    if (mMetricsMode == Ogre::GMM_PIXELS)
    {
        return mPixelSpaceWidth;
    }
    else
    {
        return mSpaceWidth;
    }
}



const Ogre::String&
TextArea::getTypeName() const
{
    return m_TypeName;
}



void
TextArea::getRenderOperation(Ogre::RenderOperation& op)
{
    op = m_RenderOp;
}



void
TextArea::setMaterialName(const Ogre::String& matName)
{
    Ogre::OverlayElement::setMaterialName(matName);
}



void
TextArea::setMetricsMode(Ogre::GuiMetricsMode gmm)
{
    Ogre::Real vpWidth, vpHeight;
    vpWidth = (Ogre::Real) (Ogre::OverlayManager::getSingleton().getViewportWidth());
    vpHeight = (Ogre::Real) (Ogre::OverlayManager::getSingleton().getViewportHeight());

    mViewportAspectCoef = vpHeight/vpWidth;

    Ogre::OverlayElement::setMetricsMode(gmm);

    switch (mMetricsMode)
    {
    case Ogre::GMM_PIXELS:
        // set pixel variables based on viewport multipliers
        mPixelCharHeight = static_cast<unsigned>(mCharHeight * vpHeight);
        mPixelSpaceWidth = static_cast<unsigned>(mSpaceWidth * vpHeight);
        break;

    case Ogre::GMM_RELATIVE_ASPECT_ADJUSTED:
        // set pixel variables multiplied by the height constant
        mPixelCharHeight = static_cast<unsigned>(mCharHeight * 10000.0);
        mPixelSpaceWidth = static_cast<unsigned>(mSpaceWidth * 10000.0);
        break;

    default:
        break;
    }
}



void
TextArea::_update(void)
{
    Ogre::Real vpWidth, vpHeight;
    vpWidth = (Ogre::Real) (Ogre::OverlayManager::getSingleton().getViewportWidth());
    vpHeight = (Ogre::Real) (Ogre::OverlayManager::getSingleton().getViewportHeight());

    mViewportAspectCoef = vpHeight/vpWidth;

    // Check size if pixel-based / relative-aspect-adjusted
    switch (mMetricsMode)
    {
    case Ogre::GMM_PIXELS:
        if(Ogre::OverlayManager::getSingleton().hasViewportChanged() || mGeomPositionsOutOfDate)
        {
            // recalculate character size
            mCharHeight = (Ogre::Real) mPixelCharHeight / vpHeight;
            mSpaceWidth = (Ogre::Real) mPixelSpaceWidth / vpHeight;
            mGeomPositionsOutOfDate = true;
        }
        break;

    case Ogre::GMM_RELATIVE_ASPECT_ADJUSTED:
        if(Ogre::OverlayManager::getSingleton().hasViewportChanged() || mGeomPositionsOutOfDate)
        {
            // recalculate character size
            mCharHeight = (Ogre::Real) mPixelCharHeight / 10000.0;
            mSpaceWidth = (Ogre::Real) mPixelSpaceWidth / 10000.0;
            mGeomPositionsOutOfDate = true;
        }
        break;

    default:
        break;
    }

    Ogre::OverlayElement::_update();
}



void
TextArea::updatePositionGeometry()
{
    if (m_Font.isNull())
    {
        // not initialised yet, probably due to the order of creation in a template
        return;
    }

    // set default colour for text
    Ogre::RGBA current_colour;
    Ogre::Root::getSingleton().convertColourValue(Ogre::ColourValue::White, &current_colour);
    // allocate needed buffers
    int charlen = GetCaptionSize();
    CheckMemoryAllocation(charlen);

    m_RenderOp.vertexData->vertexCount = charlen * 6;

    // Get position / texcoord buffer
    Ogre::HardwareVertexBufferSharedPtr vbuf = m_RenderOp.vertexData->vertexBufferBinding->getBuffer(POS_TEX_BINDING);
    float* pVert = static_cast<float*>(vbuf->lock(Ogre::HardwareBuffer::HBL_DISCARD));

    // Get color buffer
    Ogre::HardwareVertexBufferSharedPtr cbuf = m_RenderOp.vertexData->vertexBufferBinding->getBuffer(COLOUR_BINDING);
    Ogre::RGBA* pDest = static_cast<Ogre::RGBA*>(cbuf->lock(Ogre::HardwareBuffer::HBL_DISCARD));

    float largestWidth = 0;
    float left = _getDerivedLeft() * 2.0 - 1.0;
    float top = -((_getDerivedTop() * 2.0 ) - 1.0);

    // Derive space with from a number 0
    if (mSpaceWidth == 0)
    {
        mSpaceWidth = m_Font->getGlyphAspectRatio(UNICODE_ZERO) * mCharHeight * 2.0 * mViewportAspectCoef;
    }

    // Use iterator
    int i, iend;
    iend = mCaption.size();
    bool newLine = true;
    float len = 0.0f;

    for (i = 0; i < iend; ++i)
    {
        if (newLine)
        {
            len = 0.0f;
            for (int j = i; j < iend && (mCaption[j] != UNICODE_CR && mCaption[j] != UNICODE_NEL && mCaption[j] != UNICODE_LF); ++j)
            {
                if (mCaption[j] == UNICODE_SPACE)
                {
                    len += mSpaceWidth;
                }
                else
                {
                    len += m_Font->getGlyphAspectRatio(mCaption[j]) * mCharHeight;
                }
            }

            newLine = false;
        }

        Ogre::Font::CodePoint character = mCaption[i];
        if (character == UNICODE_CR || character == UNICODE_NEL || character == UNICODE_LF)
        {
            left = _getDerivedLeft() * 2.0 - 1.0;
            top -= mCharHeight * 2.0;
            // Also reduce tri count
            m_RenderOp.vertexData->vertexCount -= 6;
            newLine = true;

            // consume CR/LF in one
            if (character == UNICODE_CR)
            {
                int peeki = i;
                ++peeki;
                if (peeki < iend && mCaption[peeki] == UNICODE_LF)
                {
                    i = peeki; // skip both as one newline
                    // Also reduce tri count
                    m_RenderOp.vertexData->vertexCount -= 6;
                }
            }

            continue;
        }
        else if (character == UNICODE_SPACE) // space
        {
            // Just leave a gap, no tris
            left += mSpaceWidth;
            // Also reduce tri count
            m_RenderOp.vertexData->vertexCount -= 6;
            continue;
        }

        ///////////////////////////
        // colour formatter
        Ogre::ColourValue temp_colour;
        int ret = swscanf(mCaption.asWStr_c_str() + i, L"[colour r=\"%f\" g=\"%f\" b=\"%f\"]", &temp_colour.r, &temp_colour.g, &temp_colour.b);
        if (ret == 3)
        {
            Ogre::UTFString tag_end = "]";
            for (; i < mCaption.size() && mCaption[i] != tag_end[0]; ++i)
            {
                m_RenderOp.vertexData->vertexCount -= 6;
            }
            if (mCaption[i] == tag_end[0])
            {
                m_RenderOp.vertexData->vertexCount -= 6;
            }

            Ogre::Root::getSingleton().convertColourValue(temp_colour, &current_colour);
            continue;
        }

        Ogre::Real horiz_height = m_Font->getGlyphAspectRatio(character) * mViewportAspectCoef;
        const Ogre::Font::UVRect& uvRect = m_Font->getGlyphTexCoords(character);

        // each vert is (x, y, z, u, v)
        //-------------------------------------------------------------------------------------
        // First tri
        //
        // Upper left
        if (m_HorizontalAlignment == TextArea::LEFT)
        {
            *pVert++ = left;
        }
        else
        {
            *pVert++ = left - (len / 2);
        }
        *pVert++ = top;
        *pVert++ = -1.0;
        *pVert++ = uvRect.left;
        *pVert++ = uvRect.top;

        top -= mCharHeight * 2.0;

        // Bottom left
        if (m_HorizontalAlignment == TextArea::LEFT)
        {
            *pVert++ = left;
        }
        else
        {
            *pVert++ = left - (len / 2);
        }
        *pVert++ = top;
        *pVert++ = -1.0;
        *pVert++ = uvRect.left;
        *pVert++ = uvRect.bottom;

        top += mCharHeight * 2.0;
        left += horiz_height * mCharHeight * 2.0;

        // Top right
        if (m_HorizontalAlignment == TextArea::LEFT)
        {
            *pVert++ = left;
        }
        else
        {
            *pVert++ = left - (len / 2);
        }
        *pVert++ = top;
        *pVert++ = -1.0;
        *pVert++ = uvRect.right;
        *pVert++ = uvRect.top;
        //-------------------------------------------------------------------------------------

        //-------------------------------------------------------------------------------------
        // Second tri
        //
        // Top right (again)
        if (m_HorizontalAlignment == TextArea::LEFT)
        {
            *pVert++ = left;
        }
        else
        {
            *pVert++ = left - (len / 2);
        }
        *pVert++ = top;
        *pVert++ = -1.0;
        *pVert++ = uvRect.right;
        *pVert++ = uvRect.top;

        top -= mCharHeight * 2.0;
        left -= horiz_height  * mCharHeight * 2.0;

        // Bottom left (again)
        if (m_HorizontalAlignment == TextArea::LEFT)
        {
            *pVert++ = left;
        }
        else
        {
            *pVert++ = left - (len / 2);
        }
        *pVert++ = top;
        *pVert++ = -1.0;
        *pVert++ = uvRect.left;
        *pVert++ = uvRect.bottom;

        left += horiz_height  * mCharHeight * 2.0;

        // Bottom right
        if (m_HorizontalAlignment == TextArea::LEFT)
        {
            *pVert++ = left;
        }
        else
        {
            *pVert++ = left - (len / 2);
        }
        *pVert++ = top;
        *pVert++ = -1.0;
        *pVert++ = uvRect.right;
        *pVert++ = uvRect.bottom;
        //-------------------------------------------------------------------------------------


        // colour
        // First tri (top, bottom, top)
        *pDest++ = current_colour;
        *pDest++ = current_colour;
        *pDest++ = current_colour;
        // Second tri (top, bottom, bottom)
        *pDest++ = current_colour;
        *pDest++ = current_colour;
        *pDest++ = current_colour;


        // Go back up with top
        top += mCharHeight * 2.0;

        float currentWidth = (left + 1)/2 - _getDerivedLeft();
        if (currentWidth > largestWidth)
        {
            largestWidth = currentWidth;

        }
    }

    // Unlock vertex buffer and color buffer
    vbuf->unlock();
    cbuf->unlock();

    if (mMetricsMode == Ogre::GMM_PIXELS)
    {
        // Derive parametric version of dimensions
        Ogre::Real vpWidth;
        vpWidth = (Ogre::Real) (Ogre::OverlayManager::getSingleton().getViewportWidth());

        largestWidth *= vpWidth;
    };

    if (getWidth() < largestWidth)
    {
        //setWidth(largestWidth);
    }
}



void
TextArea::updateTextureGeometry()
{
    // Nothing to do, we combine positions and textures
}
