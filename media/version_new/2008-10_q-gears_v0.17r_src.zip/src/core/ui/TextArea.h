#ifndef TEXT_AREA_h
#define TEXT_AREA_h

#include <OgreOverlayContainer.h>
#include <OgreFont.h>



class TextArea : public Ogre::OverlayContainer
{
public:
    enum HorizontalAlignment
    {
        LEFT,
        CENTER
    };

public:
                                TextArea(const Ogre::String& name);
    virtual                    ~TextArea();

    virtual void                initialise();
    virtual void                setCaption(const Ogre::DisplayString& text);

    void                        setCharHeight(Ogre::Real height);
    Ogre::Real                  getCharHeight() const;

    void                        setSpaceWidth(Ogre::Real width);
    Ogre::Real                  getSpaceWidth() const;

    void                        setFontName(const Ogre::String& font);
    const Ogre::String&         getFontName() const;

    void                        setTextAlignment(const HorizontalAlignment& alignment);

    // See OverlayElement.
    virtual const Ogre::String& getTypeName() const;
    // See Renderable.
    void                        getRenderOperation(Ogre::RenderOperation& op);
    // Overridden from OverlayElement
    void                        setMaterialName(const Ogre::String& matName);
    // Overridden from OverlayElement
    void                        setMetricsMode(Ogre::GuiMetricsMode gmm);
    // Overridden from OverlayElement
    void                        _update();

    // Get real string size (without special symbols like colours)
    int                         GetCaptionSize() const;

private:
    // Internal method to allocate memory, only reallocates when necessary
    void                        CheckMemoryAllocation(const int number_of_chars);
    // Inherited function
    virtual void                updatePositionGeometry();
    // Inherited function
    virtual void                updateTextureGeometry();

protected:
    static Ogre::String   m_TypeName;
    // Render operation
    Ogre::RenderOperation m_RenderOp;

    size_t                m_AllocSize;

    Ogre::FontPtr         m_Font;

    HorizontalAlignment   m_HorizontalAlignment;

    float        mCharHeight;
    Ogre::ushort mPixelCharHeight;
    float        mSpaceWidth;
    Ogre::ushort mPixelSpaceWidth;
    float        mViewportAspectCoef;
};



#endif // TEXT_AREA_h
