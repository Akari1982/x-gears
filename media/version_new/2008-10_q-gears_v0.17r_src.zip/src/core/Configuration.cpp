// $Id$

#include <OgreStringConverter.h>

#include "Configuration.h"



template<>Configuration *Ogre::Singleton<Configuration>::ms_Singleton = 0;



Configuration::Configuration()
{
    ValueList value_true;
    ValueList value_false;
    value_true.push_back("true");
    value_false.push_back("false");

    m_Configuration["debug_field_walkmesh"]  = value_true;
    m_Configuration["debug_field_model"]     = value_false;
    m_Configuration["debug_field_script"]    = value_false;
    m_Configuration["debug_field_message"]   = value_false;
    m_Configuration["debug_field_fade"]      = value_false;
    m_Configuration["debug_field_encounter"] = value_false;
    m_Configuration["debug_field_triggers"]  = value_true;

    m_Configuration["debug_game_party"]      = value_false;
    m_Configuration["debug_game_items"]      = value_false;
}



Configuration::~Configuration()
{
}



void
Configuration::SetOption(const Ogre::String& name, const ValueList& value)
{
    m_Configuration[name] = value;
}



void
Configuration::SetOption(const Ogre::String& name, const bool value)
{
    ValueList value_list;
    value_list.push_back(Ogre::StringConverter::toString(value));
    m_Configuration[name] = value_list;
}



const ValueList&
Configuration::GetOptionValueList(const Ogre::String& name)
{
    return m_Configuration[name];
}



const bool
Configuration::GetOptionBool(const Ogre::String& name)
{
    if (m_Configuration[name].size() >= 1)
    {
        return Ogre::StringConverter::parseBool((m_Configuration[name])[0]);
    }

    return false;
}
