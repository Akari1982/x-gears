// $Id$

#ifndef INPUT_FILTER_h
#define INPUT_FILTER_h

#include <OgreString.h>
#include <OIS/OIS.h>
#include <vector>

#include "Event.h"



enum InputEventType
{
    IE_PRESSED  = 0x00000001, // The device was just pressed.
    IE_REPEATED = 0x00000002, // The device is auto-repeating.
    IE_RELEASED = 0x00000004  // The device is no longer pressed.  Exactly one RELEASED event will be sent for each PRESSED.
};



typedef std::vector<Event> InputEventArray;



class InputFilter
{
public:
                       InputFilter(void);
    virtual           ~InputFilter(void);

    void               ButtonPressed(const int button, const bool down);
    void               MouseMoved(int x, int y);
    void               Reset(void);
    void               Update(void);

    bool               IsButtonPressed(const int button) const;
    void               GetInputEvents(InputEventArray& input_events);

    void               ClearAllMappings(void);
    void               SetInputMap(const Ogre::String& name, const int button, const int type);
    void               InsertEventsForButton(const int button, const InputEventType type);

private:
    struct Mapping
    {
        int          key;
        Ogre::String name;
        int          type;
    };

    bool                                 m_ButtonState[256 + 8];
    std::vector<Mapping>                 m_InputMap;
    InputEventArray                      m_EventQueue;
};



#endif // INPUT_FILTER_h
