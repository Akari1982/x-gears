// $Id$

#ifndef ACTOR_h
#define ACTOR_h

#include "Event.h"



class Actor
{
public:
                 Actor(void);
    virtual     ~Actor(void);

    virtual void Input(const Event& input) = 0;
    virtual void Update(const float delta_time) = 0;
};



#endif // ACTOR_h
