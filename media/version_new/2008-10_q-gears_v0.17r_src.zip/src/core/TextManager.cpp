// $Id$

#include <OgreLogManager.h>

#include "TextManager.h"
#include "XmlLangFile.h"
#include "XmlTextFile.h"

TextManager* g_TextManager = NULL;



TextManager::TextManager(void)
{
    XmlLangFile lang_file("data/text/lang.xml");
    lang_file.LoadLanguageRoot(this, "English");

    Ogre::LogManager::getSingletonPtr()->logMessage("TextManager created. Language root '" + m_LanguageRoot + "'.");
}



TextManager::~TextManager(void)
{
}



void
TextManager::LoadTexts(const Ogre::String& file_name)
{
    XmlTextFile text_file(m_LanguageRoot + file_name);
    text_file.LoadAllTexts(this);
}



const TextData
TextManager::GetText(const int id)
{
    return m_Texts[id];
}



void
TextManager::AddText(const int id, const TextData& text)
{
    m_Texts[id] = text;
}



void
TextManager::SetLanguageRoot(const Ogre::String& root)
{
    m_LanguageRoot = root;
}
