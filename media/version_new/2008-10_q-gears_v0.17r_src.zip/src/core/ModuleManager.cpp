// $Id$

#include "ModuleManager.h"
#include "../battle/BattleModule.h"
#include "../field/FieldModule.h"
#include "../menu/MenuModule.h"



ModuleManager* g_ModuleManager = NULL;



ModuleManager::ModuleManager(void):
    m_RunningMapModule(NULL),
    m_RequestedMapModule(NULL),

    m_RunningBattleModule(NULL),
    m_RequestedBattleModule(NULL),

    m_RunningMenuModule(NULL),
    m_RequestedMenuModule(NULL)
{
}



ModuleManager::~ModuleManager(void)
{
    if (m_RunningMapModule != NULL)
    {
        delete m_RunningMapModule;
    }
    if (m_RequestedMapModule != NULL)
    {
        delete m_RequestedMapModule;
    }

    if (m_RunningBattleModule != NULL)
    {
        delete m_RunningBattleModule;
    }
    if (m_RequestedBattleModule != NULL)
    {
        delete m_RequestedBattleModule;
    }

    if (m_RunningMenuModule != NULL)
    {
        delete m_RunningMenuModule;
    }
    if (m_RequestedMenuModule != NULL)
    {
        delete m_RequestedMenuModule;
    }
}




void
ModuleManager::Input(const Event& input)
{
    if (m_RunningMenuModule != NULL)
    {
        MODULE_STATE state = m_RunningMenuModule->GetState();
        if (state != MODULE_STOP)
        {
            m_RunningMenuModule->Input(input);
        }
    }
    else if (m_RunningBattleModule != NULL)
    {
        MODULE_STATE state = m_RunningBattleModule->GetState();
        if (state != MODULE_STOP)
        {
            m_RunningBattleModule->Input(input);
        }
    }
    else if (m_RunningMapModule != NULL)
    {
        MODULE_STATE state = m_RunningMapModule->GetState();
        if (state != MODULE_STOP)
        {
            m_RunningMapModule->Input(input);
        }
    }
}



void
ModuleManager::Update(const float delta_time)
{
    // menu module has top priority
    if (m_RunningMenuModule != NULL || m_RequestedMenuModule != NULL)
    {
        if (m_RunningMenuModule == NULL && m_RequestedMenuModule != NULL)
        {
            m_RunningMenuModule = m_RequestedMenuModule;
            m_RequestedMenuModule = NULL;

            m_RunningMenuModule->SetState(MODULE_START);
            m_RunningMenuModule->OnStart(delta_time);
        }
        else
        {
            MODULE_STATE state = m_RunningMenuModule->GetState();

            switch (state)
            {
                case MODULE_START: m_RunningMenuModule->OnStart(delta_time);  break;
                case MODULE_RUN:
                {
                    m_RunningMenuModule->Update(delta_time);

                    if (m_RequestedMenuModule != NULL)
                    {
                        m_RunningMenuModule->SetState(MODULE_FINISH);
                    }
                }
                break;
                case MODULE_FINISH: m_RunningMenuModule->OnFinish(delta_time); break;
                case MODULE_STOP:
                {
                    delete m_RunningMenuModule;
                    m_RunningMenuModule = NULL;

                    if (m_RequestedMenuModule != NULL)
                    {
                        m_RunningMenuModule = m_RequestedMenuModule;
                        m_RequestedMenuModule = NULL;

                        m_RunningMenuModule->SetState(MODULE_START);
                        m_RunningMenuModule->OnStart(delta_time);
                    }
                }
                break;
            }
        }
    }
    // else update battle
    else if (m_RunningBattleModule != NULL || m_RequestedBattleModule != NULL)
    {
        if (m_RunningBattleModule == NULL && m_RequestedBattleModule != NULL)
        {
            // in battle we need clear map module first
            if (m_RunningMapModule != NULL)
            {
                m_RunningMapModule->OnPauseOn();
            }

            m_RunningBattleModule = m_RequestedBattleModule;
            m_RequestedBattleModule = NULL;

            m_RunningBattleModule->SetState(MODULE_START);
            m_RunningBattleModule->OnStart(delta_time);
        }
        else
        {
            MODULE_STATE state = m_RunningBattleModule->GetState();

            switch (state)
            {
                case MODULE_START:  m_RunningBattleModule->OnStart(delta_time);  break;
                case MODULE_RUN:
                {
                    m_RunningBattleModule->Update(delta_time);

                    if (m_RequestedBattleModule != NULL)
                    {
                        m_RunningBattleModule->SetState(MODULE_FINISH);
                    }
                }
                break;
                case MODULE_FINISH: m_RunningBattleModule->OnFinish(delta_time); break;
                case MODULE_STOP:
                {
                    delete m_RunningBattleModule;
                    m_RunningBattleModule = NULL;

                    if (m_RequestedBattleModule != NULL)
                    {
                        m_RunningBattleModule = m_RequestedBattleModule;
                        m_RequestedBattleModule = NULL;

                        m_RunningBattleModule->SetState(MODULE_START);
                        m_RunningBattleModule->OnStart(delta_time);
                    }
                    else
                    {
                        // battle over and we need to restore map module
                        if (m_RunningMapModule != NULL)
                        {
                            m_RunningMapModule->OnPauseOff();
                        }
                    }
                }
                break;
            }
        }
    }
    else if (m_RunningMapModule != NULL || m_RequestedMapModule != NULL)
    {
        if (m_RunningMapModule == NULL && m_RequestedMapModule != NULL)
        {
            m_RunningMapModule = m_RequestedMapModule;
            m_RequestedMapModule = NULL;

            m_RunningMapModule->SetState(MODULE_START);
            m_RunningMapModule->OnStart(delta_time);
        }
        else
        {
            MODULE_STATE state = m_RunningMapModule->GetState();

            switch (state)
            {
                case MODULE_START:  m_RunningMapModule->OnStart(delta_time);  break;
                case MODULE_RUN:
                {
                    m_RunningMapModule->Update(delta_time);

                    if (m_RequestedMapModule != NULL)
                    {
                        m_RunningMapModule->SetState(MODULE_FINISH);
                    }
                }
                break;
                case MODULE_FINISH: m_RunningMapModule->OnFinish(delta_time); break;
                case MODULE_STOP:
                {
                    delete m_RunningMapModule;
                    m_RunningMapModule = NULL;

                    if (m_RequestedMapModule != NULL)
                    {
                        m_RunningMapModule = m_RequestedMapModule;
                        m_RequestedMapModule = NULL;

                        m_RunningMapModule->SetState(MODULE_START);
                        m_RunningMapModule->OnStart(delta_time);
                    }
                }
                break;
            }
        }
    }
}



void
ModuleManager::RunField(const int map_id)
{
    if (m_RequestedMapModule != NULL)
    {
        delete m_RequestedMapModule;
    }

    m_RequestedMapModule = new FieldModule(map_id);
}



void
ModuleManager::RunMenu(const int menu_id)
{
    if (m_RequestedMenuModule != NULL)
    {
        delete m_RequestedMenuModule;
    }

    m_RequestedMenuModule = new MenuModule(menu_id);
}



void
ModuleManager::RunBattle(const int battle_id)
{
    if (m_RequestedBattleModule != NULL)
    {
        delete m_RequestedBattleModule;
    }

    m_RequestedBattleModule = new BattleModule(battle_id);
}
