// $Id$

#include <QApplication>
#include <QtGui>

#include "MainWindow.h"



MainWindow::MainWindow(void)
{
    resize(800, 600);

    CreateActions();
    CreateMenuBar();
}



MainWindow::~MainWindow(void)
{
}



void
MainWindow::CreateActions(void)
{
    m_NewAction = new QAction(QIcon(":/images/new.png"), tr("&New"), this);
    m_NewAction->setShortcut(tr("Ctrl+N"));
    m_NewAction->setStatusTip(tr("Create a new file"));
//    connect(m_NewAction, SIGNAL(triggered()), this, SLOT(newFile()));

    m_OpenAction = new QAction(QIcon(":/images/open.png"), tr("&Open..."), this);
    m_OpenAction->setShortcut(tr("Ctrl+O"));
    m_OpenAction->setStatusTip(tr("Open an existing file"));
//    connect(m_OpenAction, SIGNAL(triggered()), this, SLOT(open()));

    m_SaveAction = new QAction(QIcon(":/images/save.png"), tr("&Save"), this);
    m_SaveAction->setShortcut(tr("Ctrl+S"));
    m_SaveAction->setStatusTip(tr("Save the document to disk"));
//    connect(m_SaveAction, SIGNAL(triggered()), this, SLOT(save()));

    m_ExitAction = new QAction(tr("E&xit"), this);
    m_ExitAction->setShortcut(tr("Ctrl+Q"));
    m_ExitAction->setStatusTip(tr("Exit the application"));
//    connect(m_ExitAction, SIGNAL(triggered()), this, SLOT(close()));

    m_AboutAction = new QAction(tr("&About"), this);
    m_AboutAction->setStatusTip(tr("Show the application's About box"));
    connect(m_AboutAction, SIGNAL(triggered()), this, SLOT(AboutAction()));
}



void
MainWindow::CreateMenuBar(void)
{
    m_HelpMenu = menuBar()->addMenu(tr("&Help"));
    m_HelpMenu->addAction(m_AboutAction);
}



void
MainWindow::AboutAction(void)
{
    m_FileMenu = menuBar()->addMenu(tr("&File"));
    m_FileMenu->addAction(m_NewAction);
    m_FileMenu->addAction(m_OpenAction);
    m_FileMenu->addAction(m_SaveAction);
    m_FileMenu->addSeparator();
    m_FileMenu->addAction(m_ExitAction);

    QMessageBox::about(this, tr("About Application"),
        tr("The <b>Application</b> example demonstrates how to "
           "write modern GUI applications using Qt, with a menu bar, "
           "toolbars, and a status bar."));
}
