// $Id$

#ifndef MAIN_WINDOW_h
#define MAIN_WINDOW_h

#include <QAction>
#include <QMainWindow>
#include <QMenu>



class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
             MainWindow(void);
    virtual ~MainWindow(void);

private:
    void     CreateActions(void);
    void     CreateMenuBar(void);

private slots:
    void     AboutAction(void);

private:
    QMenu*    m_FileMenu;
    QMenu*    m_HelpMenu;
    QAction*  m_NewAction;
    QAction*  m_OpenAction;
    QAction*  m_SaveAction;
    QAction*  m_ExitAction;
    QAction*  m_AboutAction;
};



#endif // MAIN_WINDOW_h
