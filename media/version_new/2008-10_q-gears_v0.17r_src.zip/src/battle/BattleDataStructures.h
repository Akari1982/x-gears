// $Id$

#ifndef BATTLE_DATA_STRUCTURES_h
#define BATTLE_DATA_STRUCTURES_h

#include <map>
#include <Ogre.h>
#include <vector>



struct FormationData
{
    int           enemy_id;
    Ogre::Vector3 position;
    int           row;
};



struct BattleData
{
    int                        map_id;
    std::vector<FormationData> formation;
};



struct BattleMapData
{
    std::string file_name;
};



struct EnemyData
{
    std::string file_name;
};



#endif // BATTLE_DATA_STRUCTURES_h
