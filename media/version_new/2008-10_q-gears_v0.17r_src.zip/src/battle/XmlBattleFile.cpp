// $Id$

#include "XmlBattleFile.h"



XmlBattleFile::XmlBattleFile(const std::string& file):
    XmlFile(file)
{
    if (m_File != NULL)
    {
        m_RootNode = xmlDocGetRootElement(m_File);

        if (m_RootNode == NULL || xmlStrEqual(m_RootNode->name, BAD_CAST "battles") == false)
        {
            m_NormalFile = false;
            Ogre::LogManager::getSingletonPtr()->logMessage("Battle XML Manager: " + file + " is not a valid battle file! No <battles> in root.");
        }
        else
        {
            m_NormalFile = true;
        }
    }
    else
    {
        m_NormalFile = false;
    }
}



XmlBattleFile::~XmlBattleFile()
{
}



BattleData*
XmlBattleFile::Load(const int battle_id)
{
    BattleData* ret = NULL;

    if (m_NormalFile != true)
    {
        return ret;
    }



    for (xmlNodePtr node = m_RootNode->xmlChildrenNode; node != NULL; node = node->next)
    {
        if (xmlStrEqual(node->name, BAD_CAST "battle"))
        {
            if (GetInt(node, "id") == battle_id)
            {
                BattleData* ret = new BattleData();
                ret->map_id = GetInt(node, "map_id");

                for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                {
                    if (!xmlStrEqual(node_2->name, BAD_CAST "formation"))
                    {
                        continue;
                    }

                    FormationData form;
                    form.enemy_id = GetInt(node_2, "enemy_id");
                    form.position = GetVector3(node_2, "position");
                    form.row      = GetInt(node_2, "row");

                    ret->formation.push_back(form);
                }

                return ret;
            }
        }
    }

    Ogre::LogManager::getSingletonPtr()->logMessage("Can't find data for battle with id " + Ogre::StringConverter::toString(battle_id) + ".");
    return ret;
}
