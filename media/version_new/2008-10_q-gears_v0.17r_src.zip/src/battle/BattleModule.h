// $Id$

#ifndef BATTLE_MODULE_h
#define BATTLE_MODULE_h

#include "BattleDataStructures.h"
#include "../core/Module.h"



class BattleModule : public Module
{
public:
                 BattleModule(const int parameter);
    virtual     ~BattleModule(void);

    virtual void Input(const Event& input);
    virtual void OnStart(const float delta_time);
    virtual void Update(const float delta_time);
    virtual void OnFinish(const float delta_time);

private:
    void         LoadBattle(const int battle_id);
    void         UnloadBattle();

private:
    Ogre::Camera*  m_PreviousCamera;

    BattleData*    m_BattleData;
    BattleMapData* m_BattleMapData;

    int            m_BattleId;

    // battle player
    // battle enemy
};



#endif // BATTLE_MODULE_h
