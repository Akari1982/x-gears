// $Id$

#include <libxml/tree.h>
#include <Ogre.h>

#include "BattleModule.h"
#include "XmlBattleFile.h"
#include "XmlMapFile.h"
#include "../core/ModuleManager.h"



BattleModule::BattleModule(const int parameter):
    Module(parameter),
    m_BattleId(parameter),

    m_BattleData(NULL),
    m_BattleMapData(NULL)
{
    Ogre::LogManager::getSingletonPtr()->logMessage("BattleModule created.");
}



BattleModule::~BattleModule(void)
{
    Ogre::LogManager::getSingletonPtr()->logMessage("BattleModule destroyed.");
}



void
BattleModule::Input(const Event& input)
{
    if (input.name == "game_cancel")
    {
        SetState(MODULE_FINISH);
    }
}



void
BattleModule::OnStart(const float delta_time)
{
    LoadBattle(m_BattleId);

    SetState(MODULE_RUN);
    Ogre::LogManager::getSingletonPtr()->logMessage("BattleModule started.");
}



void
BattleModule::Update(const float delta_time)
{
    Ogre::SceneManager* scene_manager;
    scene_manager = Ogre::Root::getSingleton().getSceneManager("Scene");
    scene_manager->getSceneNode("BattleModule")->yaw(Ogre::Radian(Ogre::Degree(delta_time * 45.0f)));
    Ogre::LogManager::getSingletonPtr()->logMessage("BattleModule running. delta_time " + Ogre::StringConverter::toString(delta_time) + ".");
}



void
BattleModule::OnFinish(const float delta_time)
{
    UnloadBattle();

    SetState(MODULE_STOP);
    Ogre::LogManager::getSingletonPtr()->logMessage("BattleModule stopped.");
}



void
BattleModule::LoadBattle(const int battle_id)
{
    Ogre::SceneManager* scene_manager;
    scene_manager = Ogre::Root::getSingleton().getSceneManager("Scene");
    scene_manager->getRootSceneNode()->createChildSceneNode("BattleModule");
    scene_manager->setAmbientLight(Ogre::ColourValue(1.0, 1.0, 1.0));

    Ogre::Camera* camera = scene_manager->createCamera("BattleCamera");
    camera->setNearClipDistance(5);
    camera->setPosition(9000, 6000, 9000);
    camera->lookAt(0, 0, 0);

    Ogre::Viewport* viewport = Ogre::Root::getSingleton().getAutoCreatedWindow()->getViewport(0);
    m_PreviousCamera = viewport->getCamera();
    viewport->setCamera(camera);
    camera->setAspectRatio(Ogre::Real(viewport->getActualWidth()) / Ogre::Real(viewport->getActualHeight()));



    XmlBattleFile battle_file("data/battle/battle.xml");
    m_BattleData = battle_file.Load(battle_id);

    if (m_BattleData != NULL)
    {
        Ogre::LogManager::getSingletonPtr()->logMessage("Data for battle with id " + Ogre::StringConverter::toString(battle_id) + " loaded.");
        Ogre::LogManager::getSingletonPtr()->logMessage("Map id " + Ogre::StringConverter::toString(m_BattleData->map_id) + ".");
        for (int i = 0; i < m_BattleData->formation.size(); ++i)
        {
            Ogre::LogManager::getSingletonPtr()->logMessage(
                "Formation "  + Ogre::StringConverter::toString(i) +
                ": enemy_id " + Ogre::StringConverter::toString(m_BattleData->formation[i].enemy_id) +
                ", position " + Ogre::StringConverter::toString(m_BattleData->formation[i].position.x) +
                " "           + Ogre::StringConverter::toString(m_BattleData->formation[i].position.y) +
                " "           + Ogre::StringConverter::toString(m_BattleData->formation[i].position.z) +
                ", row "      + Ogre::StringConverter::toString(m_BattleData->formation[i].row) + ".");
        }

        XmlMapFile map_file("data/battle/map.xml");
        m_BattleMapData = map_file.Load(m_BattleData->map_id);

        if (m_BattleMapData != NULL)
        {
            Ogre::LogManager::getSingletonPtr()->logMessage("Map name " + m_BattleMapData->file_name + ".");

            Ogre::Entity* entity = scene_manager->createEntity("BattleField", m_BattleMapData->file_name);
            scene_manager->getSceneNode("BattleModule")->createChildSceneNode("BattleField")->attachObject(entity);
        }
    }
}



void
BattleModule::UnloadBattle()
{
    if (m_BattleData != NULL)
    {
        delete m_BattleData;
    }

    if (m_BattleMapData != NULL)
    {
        delete m_BattleMapData;
    }

    Ogre::SceneManager* scene_manager;
    scene_manager = Ogre::Root::getSingleton().getSceneManager("Scene");
    scene_manager->destroyEntity("BattleField");
    scene_manager->getRootSceneNode()->removeAndDestroyChild("BattleModule");
    scene_manager->destroyCamera(scene_manager->getCamera("BattleCamera"));

    Ogre::Root::getSingleton().getAutoCreatedWindow()->getViewport(0)->setCamera(m_PreviousCamera);
}
