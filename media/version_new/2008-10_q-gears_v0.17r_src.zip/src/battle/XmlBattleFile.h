// $Id$

#ifndef XML_BATTLE_FILE_h
#define XML_BATTLE_FILE_h

#include <string>

#include "BattleDataStructures.h"
#include "../core/XmlFile.h"



class XmlBattleFile : public XmlFile
{
public:
    explicit XmlBattleFile(const std::string& file);
    virtual ~XmlBattleFile();

    BattleData* Load(const int battle_id);

private:
    bool       m_NormalFile;
    xmlNodePtr m_RootNode;
};



#endif // XML_BATTLE_FILE_h
