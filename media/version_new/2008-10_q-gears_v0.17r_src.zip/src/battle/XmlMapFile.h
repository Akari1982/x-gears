// $Id$

#ifndef XML_MAP_FILE_h
#define XML_MAP_FILE_h

#include <string>

#include "BattleDataStructures.h"
#include "../core/XmlFile.h"



class XmlMapFile : public XmlFile
{
public:
    explicit XmlMapFile(const std::string& file);
    virtual ~XmlMapFile();

    BattleMapData* Load(const int map_id);

private:
    bool       m_NormalFile;
    xmlNodePtr m_RootNode;
};



#endif // XML_MAP_FILE_h
