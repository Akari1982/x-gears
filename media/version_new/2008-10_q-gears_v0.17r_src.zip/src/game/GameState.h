// $Id$

#ifndef GAMESTATE_H
#define GAMESTATE_H

#include "../core/Actor.h"
#include "../core/ui/TextArea.h"



struct Character
{
    int          id;

    Ogre::String name;
    int          hp;
    int          mp;

    bool         available;
    bool         locked;
};



struct PartySlot
{
    PartySlot(void):
        character_id(-1)
    {
    }

    int character_id;
};



class GameState : public Actor
{
public:
                        GameState();
    virtual            ~GameState();

    void                Input(const Event& input);
    void                Update(const float delta_time);

    // functions for script access
    void                ScriptVariableSet(const char* name, const int value);
    const int           ScriptVariableGet(const char* name);
    void                ScriptItemAdd(const int item_id, const int quantity);
    const int           ScriptItemGet(const int item_id) const;
    void                ScriptPartySetSize(const int size);
    void                ScriptPartyClear();
    void                ScriptCharacterAddToParty(const int character_id);
    void                ScriptCharacterRemoveFromParty(const int character_id);

    // variable to store
    void                SetVariable(const Ogre::String& name, const int value);
    const int           GetVariable(const Ogre::String& name);

    // items
    void                ItemAdd(const int item_id, const int quantity);
    const int           ItemGet(const int item_id) const;

    // party and character
    void                SetCharacterName(const int character_id, const Ogre::String& name);
    const Ogre::String  GetCharacterName(const int character_id) const;

    void                AddPartyCharacter(const int character_id);
    void                RemovePartyCharacter(const int character_id);
    const int           GetPartyCharacter(const int party_slot_id) const;

    void                SetCharacterLock(const int character_id, const bool locked);

    void                SetPlayerCharacterPosition(const Ogre::Vector3& position);
    const Ogre::Vector3 GetPlayerCharacterPosition() const;
    void                SetPlayerCharacterDirection(const Ogre::Degree& direction);
    const Ogre::Degree  GetPlayerCharacterDirection() const;

private:
    const int           FindItem(const int item_id) const;
    const int           FindCharacter(const int character_id) const;
    const bool          CheckParty(const int party_id) const;

private:
    TextArea*                         m_DebugPartyText;
    Ogre::Overlay*                    m_DebugPartyOverlay;
    TextArea*                         m_DebugItemsText;
    Ogre::Overlay*                    m_DebugItemsOverlay;

    std::map<Ogre::String, int>       m_Variable;

    std::vector<Character>            m_Characters;
    std::vector<PartySlot>            m_Party;

    int                               m_Money;
    std::vector<std::pair<int, int> > m_Items;

    Ogre::Vector3                     m_PlayerCharacterPosition;
    Ogre::Degree                      m_PlayerCharacterDirection;
};



// Visible from every part of program
extern GameState* g_GameState;



#endif // GAMESTATE_H
