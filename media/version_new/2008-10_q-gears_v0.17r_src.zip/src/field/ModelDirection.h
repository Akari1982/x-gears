// $Id$

#ifndef MODEL_DIRECTION_h
#define MODEL_DIRECTION_h

#include <OgreCamera.h>
#include <OgreSimpleRenderable.h>



class _OgreExport ModelDirection : public Ogre::SimpleRenderable
{
public:
                 ModelDirection(void);
    virtual     ~ModelDirection(void);

    Ogre::Real   getSquaredViewDepth(const Ogre::Camera* cam) const;
    Ogre::Real   getBoundingRadius(void) const;
};



#endif // MODEL_DIRECTION_h
