// $Id$

#include <OgreLogManager.h>

#include "XmlWalkmeshFile.h"



XmlWalkmeshFile::XmlWalkmeshFile(const Ogre::String& file):
    XmlFile(file)
{
    if (m_File != NULL)
    {
        m_RootNode = xmlDocGetRootElement(m_File);

        if (m_RootNode == NULL || xmlStrEqual(m_RootNode->name, BAD_CAST "walkmesh") == false)
        {
            m_NormalFile = false;
            Ogre::LogManager::getSingletonPtr()->logMessage("Field XML Manager: " + file + " is not a valid walkmesh file! No <walkmesh> in root.");
        }
        else
        {
            m_NormalFile = true;
        }
    }
    else
    {
        m_NormalFile = false;
    }
}



XmlWalkmeshFile::~XmlWalkmeshFile(void)
{
}



void
XmlWalkmeshFile::Load(Walkmesh* walkmesh)
{
    if (m_NormalFile != true)
    {
        return;
    }

    for (xmlNodePtr node = m_RootNode->xmlChildrenNode; node != NULL; node = node->next)
    {
        if (xmlStrEqual(node->name, BAD_CAST "triangle"))
        {
            WalkmeshTriangle triangle;

            triangle.a = GetVector3(node, "a");
            triangle.b = GetVector3(node, "b");
            triangle.c = GetVector3(node, "c");

            triangle.access_side[0] = GetInt(node, "a_b");
            triangle.access_side[1] = GetInt(node, "b_c");
            triangle.access_side[2] = GetInt(node, "c_a");

            walkmesh->AddTriangle(triangle);
        }
    }

    Ogre::LogManager::getSingletonPtr()->logMessage("Finish loading Walkmesh from XML.");
}
