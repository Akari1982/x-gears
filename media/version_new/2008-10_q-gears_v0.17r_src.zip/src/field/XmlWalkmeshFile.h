// $Id$

#ifndef XML_WALKMESH_FILE_h
#define XML_WALKMESH_FILE_h

#include "Walkmesh.h"
#include "../core/XmlFile.h"



class XmlWalkmeshFile : public XmlFile
{
public:
    explicit XmlWalkmeshFile(const Ogre::String& file);
    virtual ~XmlWalkmeshFile(void);

    void     Load(Walkmesh* walkmesh);

private:
    bool       m_NormalFile;
    xmlNodePtr m_RootNode;
};



#endif // XML_WALKMESH_FILE_h
