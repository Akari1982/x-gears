// $Id$

#ifndef MODEL_COLLISION_h
#define MODEL_COLLISION_h

#include <Ogre.h>



class _OgreExport ModelCollision : public Ogre::SimpleRenderable
{
public:
                 ModelCollision(void);
    virtual     ~ModelCollision(void);

    Ogre::Real   getSquaredViewDepth(const Ogre::Camera* cam) const;
    Ogre::Real   getBoundingRadius(void) const;
};



#endif // MODEL_COLLISION_h
