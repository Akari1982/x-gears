// $Id$

#include <Ogre.h>

#include "MenuModule.h"
#include "../core/ModuleManager.h"




MenuModule::MenuModule(const int parameter):
    Module(parameter),

    m_ScriptManager(NULL)
{
    Ogre::LogManager::getSingletonPtr()->logMessage("MenuModule created.");
}



MenuModule::~MenuModule(void)
{
    if (m_ScriptManager != NULL)
    {
        delete m_ScriptManager;
    }

    Ogre::LogManager::getSingletonPtr()->logMessage("MenuModule destroyed.");
}



void
MenuModule::Input(const Event& input)
{
    if (input.name == "game_cancel")
    {
        SetState(MODULE_FINISH);
    }



    if (m_ScriptManager != NULL)
    {
        m_ScriptManager->Input(input);
    }
}



void
MenuModule::OnStart(const float delta_time)
{
    m_ScriptManager = new MenuScriptManager(this);
    m_ScriptManager->LoadFile("data/menu/simple.lua");
    m_ScriptManager->Update(delta_time);

    SetState(MODULE_RUN);
    Ogre::LogManager::getSingletonPtr()->logMessage("MenuModule started.");
}



void
MenuModule::Update(const float delta_time)
{
    if (m_ScriptManager != NULL)
    {
        m_ScriptManager->Update(delta_time);
    }
}



void
MenuModule::OnFinish(const float delta_time)
{
    if (m_ScriptManager != NULL)
    {
        m_ScriptManager->Update(delta_time);
    }

    SetState(MODULE_STOP);
    Ogre::LogManager::getSingletonPtr()->logMessage("MenuModule stopped.");
}
