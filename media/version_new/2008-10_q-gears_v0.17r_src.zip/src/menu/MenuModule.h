// $Id$

#ifndef MENU_MODULE_h
#define MENU_MODULE_h

#include "MenuScriptManager.h"
#include "../core/Module.h"



class MenuModule : public Module
{
public:
                 MenuModule(const int parameter);
    virtual     ~MenuModule(void);

    virtual void Input(const Event& input);
    virtual void OnStart(const float delta_time);
    virtual void Update(const float delta_time);
    virtual void OnFinish(const float delta_time);

private:
    MenuScriptManager* m_ScriptManager;
};



#endif // MENU_MODULE_h
