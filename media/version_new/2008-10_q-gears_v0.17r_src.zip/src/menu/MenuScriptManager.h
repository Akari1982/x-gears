// $Id$

#ifndef MENU_SCRIPT_MANAGER_h
#define MENU_SCRIPT_MANAGER_h

#include <lua.hpp>
#include <luabind/luabind.hpp>
#include <OgreString.h>

#include "../core/Actor.h"

class MenuModule;



class MenuScriptManager : public Actor
{
public:
                   MenuScriptManager(MenuModule* menu);
    virtual       ~MenuScriptManager();

    virtual void   Input(const Event& input);
    virtual void   Update(const float delta_time);

    void           LoadFile(const Ogre::String& name);

private:
    MenuModule*             m_MenuModule;
    lua_State*              m_LuaState;
};



#endif // MENU_SCRIPT_MANAGER_h
