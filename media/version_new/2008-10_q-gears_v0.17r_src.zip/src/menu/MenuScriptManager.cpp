// $Id$

#include <OgreLogManager.h>
#include <lua.hpp>
#include <luabind/luabind.hpp>

#include "MenuModule.h"
#include "MenuScriptManager.h"
#include "../core/script/Binder.h"



MenuScriptManager::MenuScriptManager(MenuModule* menu):
    m_MenuModule(menu)
{
    m_LuaState = lua_open();
    lua_gc(m_LuaState, LUA_GCSTOP, 0);
    luabind::open(m_LuaState);

    BindGameStateToLua(m_LuaState);
    BindModuleManagerToLua(m_LuaState);

    Ogre::LogManager::getSingletonPtr()->logMessage("MenuScriptManager created.");
}



MenuScriptManager::~MenuScriptManager(void)
{
    lua_close(m_LuaState);

    Ogre::LogManager::getSingletonPtr()->logMessage("MenuScriptManager destroyed.");
}



void
MenuScriptManager::Input(const Event& input)
{
}



void
MenuScriptManager::Update(const float delta_time)
{
    switch (m_MenuModule->GetState())
    {
        case MODULE_START:
        {
            try
            {
            luabind::object table = luabind::gettable(luabind::globals(m_LuaState), "menu");


                luabind::resume_function<int>(table["start"], table);
            }
            catch(luabind::error& e)
            {
                luabind::object error_msg(luabind::from_stack(e.state(), -1));
                Ogre::LogManager::getSingletonPtr()->logMessage("[SCRIPT ERROR] " + Ogre::String(luabind::object_cast<std::string>(error_msg)));
            }
        }
        break;

        case MODULE_RUN:
        {
            luabind::object table = luabind::gettable(luabind::globals(m_LuaState), "menu");

            try
            {
                luabind::resume_function<int>(table["onupdate"], table);
            }
            catch(luabind::error& e)
            {
                luabind::object error_msg(luabind::from_stack(e.state(), -1));
                Ogre::LogManager::getSingletonPtr()->logMessage("[SCRIPT ERROR] " + Ogre::String(luabind::object_cast<std::string>(error_msg)));
            }
        }
        break;

        case MODULE_FINISH:
        {
            luabind::object table = luabind::gettable(luabind::globals(m_LuaState), "menu");

            try
            {
                luabind::resume_function<int>(table["finish"], table);
            }
            catch(luabind::error& e)
            {
                luabind::object error_msg(luabind::from_stack(e.state(), -1));
                Ogre::LogManager::getSingletonPtr()->logMessage("[SCRIPT ERROR] " + Ogre::String(luabind::object_cast<std::string>(error_msg)));
            }
        }
        break;
    }
}




void
MenuScriptManager::LoadFile(const Ogre::String& name)
{
    Ogre::LogManager::getSingletonPtr()->logMessage("Load script file.");

    if (luaL_dofile(m_LuaState, name.c_str()) == 1)
    {
        luabind::object error_msg(luabind::from_stack(m_LuaState, -1));
        Ogre::LogManager::getSingletonPtr()->logMessage("[SCRIPT ERROR] " + Ogre::String(luabind::object_cast<std::string>(error_msg)));
    }
}
