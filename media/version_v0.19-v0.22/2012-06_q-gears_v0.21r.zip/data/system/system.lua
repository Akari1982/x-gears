-- create containers for all script entitys
System = {}
EntityContainer = {}
UiContainer = {}
