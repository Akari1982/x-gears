/*
 *  $Id: inputhandler.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "inputhandler.h"
#include "../inputfilter.h"



void
InputHandler::ButtonPressed(Button b, bool Down)
{
    INPUTFILTER->ButtonPressed(b, Down);
}
