/*
 *  $Id: inputhandler.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef INPUTHANDLER_H
#define INPUTHANDLER_H



#include "../inputfilter.h"



class InputHandler
{
public:
    virtual      ~InputHandler() {}
    virtual void  Update() = 0;

protected:
                  InputHandler() {}
    void          ButtonPressed(Button b, bool Down);

private:
     // We set copy constructor and operator= private
    // because we dont want that anyone copy object
    InputHandler(const InputHandler &input);
    InputHandler& operator =(const InputHandler &input);
};



#endif // INPUTHANDLER_H
