/*
 *  $Id: config.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef CONFIG_H
#define CONFIG_H
// The Config Class : Implements basic config file



#include <string>



class Config
{
public:
    Config();

    virtual ~Config();

    void ReadConfig(const std::string &file);

private:
    // We set copy constructor and operator= private
    // because we dont want that anyone copy object of Config
    Config(const Config &config);
    Config& operator =(const Config &config);



public:
    // Debug:
    bool mLogToDisk;
};



extern Config* CONFIG; // global and accessable from anywhere in our program



#endif // CONFIG_H
