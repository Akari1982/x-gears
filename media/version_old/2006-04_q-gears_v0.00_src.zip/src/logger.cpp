/*
 *  $Id: logger.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "logger.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <stdarg.h>
#include <stdio.h>
#include <string>
#include <time.h>



Logger* LOGGER = NULL; // global and accessable from anywhere in our program



Logger::Logger(const std::string &logFileName):
    mLogFile(logFileName.c_str(), std::ios_base::trunc)
{
    if (!mLogFile.is_open())
    {
        std::cout << "Warning: error while opening " << logFileName << " for writing.\n";
    }
}



Logger::~Logger()
{
    if (mLogFile.is_open())
    {
        mLogFile.close();
    }
}



void Logger::Log(const char *logText, ...)
{
    if (mLogFile.is_open())
    {
        char* buffer = new char[1024];

        // Use a temporary buffer to fill in the variables
        va_list ap;
        va_start(ap, logText);
        vsprintf(buffer, logText, ap);
        va_end(ap);

        // Get the current system time
        time_t t;
        time(&t);

        // Print the log entry
        std::stringstream timeStr;
        timeStr << "[";
        timeStr << ((((t / 60) / 60) % 24 < 10) ? "0" : "");
        timeStr << (int)(((t / 60) / 60) % 24);
        timeStr << ":";
        timeStr << (((t / 60) % 60 < 10) ? "0" : "");
        timeStr << (int)((t / 60) % 60);
        timeStr << ":";
        timeStr << ((t % 60 < 10) ? "0" : "");
        timeStr << (int)(t % 60);
        timeStr << "] ";

        mLogFile << timeStr.str() << buffer << std::endl;

        // Delete temporary buffer
        delete[] buffer;
    }
}
