/*
 *  $Id: displayogl.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "displayogl.h"
#include "window/windowsdl.h"
#include "../logger.h"
#include "../utilites/utilites.h"

#include <GL/gl.h>
#include <GL/glu.h>



DisplayOGL::DisplayOGL():
    mWindow(NULL)
{
    LOGGER->Log("Set current renderer: OpenGL.");

    Init();
}



DisplayOGL::~DisplayOGL()
{
    delete mWindow;
}



Display *
DisplayOGL::MakeDisplay()
{
    return new DisplayOGL();
}



void
DisplayOGL::Init()
{
    mWindow = WindowSDL::MakeWindow();

    // Log driver details
    LOGGER->Log("OGL Vendor: %s", glGetString(GL_VENDOR));
    LOGGER->Log("OGL Renderer: %s", glGetString(GL_RENDERER));
    LOGGER->Log("OGL Version: %s", glGetString(GL_VERSION));
    LOGGER->Log("OGL Extensions: %s", glGetString(GL_EXTENSIONS));
    LOGGER->Log("GLU Version: %s", gluGetString(GLU_VERSION));
}



bool
DisplayOGL::BeginFrame()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    return true;
}



void
DisplayOGL::EndFrame()
{
    // glFlush(), not glFinish(); NVIDIA_GLX's glFinish()'s behavior is
    // nowhere near performance-friendly and uses unholy amounts of CPU for
    // Gog-knows-what.
    glFlush();

    mWindow->SwapBuffers();
    mWindow->Update();

    Display::EndFrame();
}



unsigned int
DisplayOGL::CreateTexture(Surface *image)
{
    if (image->width != power_of_two(image->width) || image->height != power_of_two(image->height))
    {
        LOGGER->Log("Texture are not in power of two size.");
        return 0;
    }

    // allocate OpenGL texture resource
    unsigned int tex_handle;
    glGenTextures(1, reinterpret_cast<GLuint*>(&tex_handle));
    glBindTexture(GL_TEXTURE_2D, tex_handle);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
//    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
//    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, image->width, image->height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image->pixels);

    glFlush();

    return tex_handle;
}



void
DisplayOGL::UpdateTexture(unsigned int tex_handle, Surface *image, int xoffset, int yoffset, int width, int height)
{
    glBindTexture(GL_TEXTURE_2D, tex_handle);
    glTexSubImage2D(GL_TEXTURE_2D, 0, xoffset, yoffset, width, height, GL_RGBA, GL_UNSIGNED_BYTE, image->pixels);
    glFlush();
}


void
DisplayOGL::DeleteTexture(unsigned int tex_handle)
{
    glDeleteTextures(1, reinterpret_cast<GLuint*>(&tex_handle));
}



void
DisplayOGL::SetTexture(unsigned int tex_handle)
{
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, tex_handle);
}



void
DisplayOGL::UnsetTexture()
{
    glDisable(GL_TEXTURE_2D);
}



void
DisplayOGL::DrawPointsInternal(const std::vector<Vertex> &v)
{
    SendCurrentMatrices();
    SetupVertices(v);
    glDrawArrays(GL_POINTS, 0, v.size());
}



void
DisplayOGL::DrawLinesInternal(const std::vector<Vertex> &v)
{
    SendCurrentMatrices();
    SetupVertices(v);
    glDrawArrays(GL_LINES, 0, v.size());
}



void
DisplayOGL::DrawTrianglesInternal(const std::vector<Vertex> &v)
{
    SendCurrentMatrices();
    SetupVertices(v);
    glDrawArrays(GL_TRIANGLES, 0, v.size());
}



void
DisplayOGL::DrawQuadsInternal(const std::vector<Vertex> &v)
{
    SendCurrentMatrices();

    SetupVertices(v);
    glDrawArrays(GL_QUADS, 0, v.size());
}



void
DisplayOGL::SetupVertices(const std::vector<Vertex> &v)
{
    static float *vertex, *texture, *normal, *color;
    int size = 0;

    if (v.size() > size)
    {
        size = v.size();
        delete [] vertex;
        delete [] color;
        delete [] texture;
        delete [] normal;
        vertex  = new float[size * 3];
        color   = new float[size * 4];
        texture = new float[size * 2];
        normal  = new float[size * 3];
    }

    for (unsigned i = 0; i < size; ++i)
    {
        vertex[i * 3 + 0]  = v[i].p.x;
        vertex[i * 3 + 1]  = v[i].p.y;
        vertex[i * 3 + 2]  = v[i].p.z;
        color[i * 4 + 0]   = v[i].c.r;
        color[i * 4 + 1]   = v[i].c.g;
        color[i * 4 + 2]   = v[i].c.b;
        color[i * 4 + 3]   = v[i].c.a;
        texture[i * 2 + 0] = v[i].t[0];
        texture[i * 2 + 1] = v[i].t[1];
        normal[i * 3 + 0]  = v[i].n[0];
        normal[i * 3 + 1]  = v[i].n[1];
        normal[i * 3 + 2]  = v[i].n[2];
    }

    if (size > 0)
    {
        glEnableClientState(GL_VERTEX_ARRAY);
        glVertexPointer(3, GL_FLOAT, 0, vertex);

        glEnableClientState(GL_COLOR_ARRAY);
        glColorPointer(4, GL_FLOAT, 0, color);

        glEnableClientState(GL_TEXTURE_COORD_ARRAY);
        glTexCoordPointer(2, GL_FLOAT, 0, texture);

        glEnableClientState(GL_NORMAL_ARRAY);
        glNormalPointer(GL_FLOAT, 0, normal);
    }
}



void
DisplayOGL::SendCurrentMatrices()
{
    glMatrixMode(GL_PROJECTION);
    glLoadMatrixf((const float*)GetProjectionTop());

    // OpenGL has just "modelView", whereas D3D has "world" and "view"
    Matrix modelView;
    MatrixMultiply(modelView, *(GetViewTop()), *(GetWorldTop()));
    glMatrixMode(GL_MODELVIEW);
    glLoadMatrixf((const float*)&modelView);

    glMatrixMode(GL_TEXTURE);
    glLoadMatrixf((const float *)GetTextureTop());
}



void
DisplayOGL::SetAlphaTest(bool b)
{
    glAlphaFunc(GL_GREATER, 0.01f);
    if (b)
    {
        glEnable(GL_ALPHA_TEST);
    }
    else
    {
        glDisable(GL_ALPHA_TEST);
    }
}



void
DisplayOGL::SetZTestMode(ZTestMode mode)
{
    glEnable(GL_DEPTH_TEST);

    switch(mode)
    {
        case ZTEST_OFF:           glDepthFunc(GL_ALWAYS);  break;
        case ZTEST_WRITE_ON_PASS: glDepthFunc(GL_LEQUAL);  break;
        case ZTEST_WRITE_ON_FAIL: glDepthFunc(GL_GREATER); break;
    }
}



void
DisplayOGL::SetBlendMode(BlendMode mode)
{
    glEnable(GL_BLEND);

    switch(mode)
    {
        case BLEND_DISABLED:  glDisable(GL_BLEND);                               break;
        case BLEND_NORMAL:    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); break;
        case BLEND_ADD:       glBlendFunc(GL_SRC_ALPHA, GL_ONE);                 break;
    }
}



void
DisplayOGL::SetCullMode(CullMode mode)
{
    switch(mode)
    {
        case CULL_BACK:  glEnable(GL_CULL_FACE); glCullFace(GL_BACK);  break;
        case CULL_FRONT: glEnable(GL_CULL_FACE); glCullFace(GL_FRONT); break;
        case CULL_NONE:  glDisable(GL_CULL_FACE);                      break;
    }
}



void
DisplayOGL::SetPolygonMode(PolygonMode pm)
{
    switch(pm)
    {
        case POLYGON_FILL: glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); break;
        case POLYGON_LINE: glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); break;
    }
}



void
DisplayOGL::SetLineWidth(float width)
{
    glLineWidth(width);
}



void
DisplayOGL::SetPointSize(float size)
{
    glPointSize(size);
}
