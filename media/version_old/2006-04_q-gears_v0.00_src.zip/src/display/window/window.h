/*
 *  $Id: window.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef WINDOW_H
#define WINDOW_H
// The Window Class : Abstract class for window



class Window
{
public:
    virtual ~Window() {};

    virtual void SwapBuffers() = 0;

    virtual void Update() = 0;

protected:
    // This need to be protected because implementation must call constructor
    Window() {};

private:
    // We set copy constructor and operator= private
    // because we dont want that anyone copy object of Window
    Window(const Window &window);
    Window& operator =(const Window &window);
};



#endif // WINDOW_H
