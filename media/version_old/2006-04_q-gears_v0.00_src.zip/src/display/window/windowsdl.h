/*
 *  $Id: windowsdl.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef WINDOWSDL_H
#define WINDOWSDL_H
// The WindowSDL Class : Implementation of window



#include "window.h"



class WindowSDL : public Window
{
public:
    ~WindowSDL();

    static Window* MakeWindow();

    void SwapBuffers();

    void Update();

private:
    // We set constructor, copy constructor and operator= private
    // because we dont want that anyone copy or create object of Window directly
    WindowSDL();
    WindowSDL(const WindowSDL &window);
    WindowSDL& operator =(const WindowSDL &window);
};



#endif // WINDOWSDL_H
