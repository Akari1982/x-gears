/*
 *  $Id: logger.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef LOGGER_H
#define LOGGER_H
// The Log Class : Useful to write debug or info messages



#include <iostream>
#include <fstream>
#include <string>



class Logger
{
public:
    // Constructor, opens log file for writing.
    explicit Logger(const std::string &logFileName);

    // Destructor, closes log file.
    virtual ~Logger();

    // Enters a message in the log. The message will be timestamped.
    void Log(const char *logText, ...);

private:
    // We set copy constructor and operator= private
    // because we dont want that anyone copy object of Logger
    Logger(const Logger &logger);
    Logger& operator =(const Logger &logger);



private:
    std::ofstream mLogFile;
};



// Visible from every part of programm
extern Logger *LOGGER;



#endif // LOGGER_H
