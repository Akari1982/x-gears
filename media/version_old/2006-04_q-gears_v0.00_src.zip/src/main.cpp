/*
 *  $Id: main.cpp, v 1.1 2006/04/17 00:00:01 Exp $
 */

#include "main.h"

#include "config.h"
#include "define.h"
#include "logger.h"
#include "display/displayogl.h"
#include "display/surface/surfaceload.h"
#include "input/inputfilter.h"
#include "game/gamestate.h"
#include "game/savemap.h"
#include "utilites/utilites.h"

#include <stdio.h>



// game state
unsigned char state;



void
HandleInputEvents()
{
    INPUTFILTER->Update();

    static InputEventArray input_event_attay;
    input_event_attay.clear();
    INPUTFILTER->GetInputEvents(input_event_attay);

    for (int i = 0; i < input_event_attay.size(); i++)
    {
        printf("%s - %s\n", ButtonToString(input_event_attay[i].button).c_str(), (input_event_attay[i].type == IET_FIRST_PRESS) ? "Pressed" : "Unpressed");
    }
}



int
main(int argc, char *argv[])
{
    LOGGER         = new Logger(DEFAULT_LOG);
    CONFIG         = new Config();
    DISPLAY        = DisplayOGL::MakeDisplay();
    INPUTFILTER    = new InputFilter();
    GAMESTATE      = new Gamestate();



    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
    DISPLAY->SetAlphaTest(true);
    DISPLAY->SetBlendMode(BLEND_NORMAL);
    DISPLAY->SetCullMode(CULL_NONE);
    DISPLAY->LoadLookAt(50, Vector3(10, 5, 5), Vector3(0, 0, 0), Vector3(0, 1, 0));



    std::vector<Vertex> points;
    Vertex point;
    point.p.x = -5.0f; point.p.y =  0.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    points.push_back(point);
    point.p.x =  5.0f; point.p.y =  0.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    points.push_back(point);
    point.p.x =  0.0f; point.p.y = -5.0f; point.p.z =  0.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    points.push_back(point);
    point.p.x =  0.0f; point.p.y =  5.0f; point.p.z =  0.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    points.push_back(point);
    point.p.x =  0.0f; point.p.y =  0.0f; point.p.z = -5.0f;
    point.c.r =  0.0f; point.c.g =  0.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    points.push_back(point);
    point.p.x =  0.0f; point.p.y =  0.0f; point.p.z =  5.0f;
    point.c.r =  0.0f; point.c.g =  0.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    points.push_back(point);

    std::vector<Vertex> triangles;
    point.p.x = -1.0f; point.p.y =  0.0f; point.p.z =  1.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    triangles.push_back(point);
    point.p.x = -1.0f; point.p.y =  0.0f; point.p.z =  3.0f;
    point.c.r =  0.0f; point.c.g =  0.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    triangles.push_back(point);
    point.p.x = -2.0f; point.p.y =  2.0f; point.p.z =  2.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    triangles.push_back(point);

    point.p.x = -1.0f; point.p.y =  0.0f; point.p.z =  1.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    triangles.push_back(point);
    point.p.x = -3.0f; point.p.y =  0.0f; point.p.z =  1.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    triangles.push_back(point);
    point.p.x = -2.0f; point.p.y =  2.0f; point.p.z =  2.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    triangles.push_back(point);

    point.p.x = -3.0f; point.p.y =  0.0f; point.p.z =  3.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    triangles.push_back(point);
    point.p.x = -3.0f; point.p.y =  0.0f; point.p.z =  1.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    triangles.push_back(point);
    point.p.x = -2.0f; point.p.y =  2.0f; point.p.z =  2.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    triangles.push_back(point);

    point.p.x = -3.0f; point.p.y =  0.0f; point.p.z =  3.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    triangles.push_back(point);
    point.p.x = -1.0f; point.p.y =  0.0f; point.p.z =  3.0f;
    point.c.r =  0.0f; point.c.g =  0.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    triangles.push_back(point);
    point.p.x = -2.0f; point.p.y =  2.0f; point.p.z =  2.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    triangles.push_back(point);

    std::vector<Vertex> quads;
    point.p.x = -1.0f; point.p.y =  0.0f; point.p.z =  1.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    quads.push_back(point);
    point.p.x = -3.0f; point.p.y =  0.0f; point.p.z =  1.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    quads.push_back(point);
    point.p.x = -3.0f; point.p.y =  0.0f; point.p.z =  3.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    quads.push_back(point);
    point.p.x = -1.0f; point.p.y =  0.0f; point.p.z =  3.0f;
    point.c.r =  0.0f; point.c.g =  0.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    quads.push_back(point);
    int rotation_tr = 0;

    Surface* texture = SurfaceUtils::LoadFile("test_tex.bmp");
    unsigned int tex_id;
    if (texture != NULL)
    {
        tex_id = DISPLAY->CreateTexture(texture);
    }
    else
    {
        LOGGER->Log("Can't load texture.");
    }

    std::vector<Vertex> quads_tex;
    point.p.x =  0.5f; point.p.y = -1.0f; point.p.z =  4.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  0.0f; point.t.y =  0.0f;
    quads_tex.push_back(point);
    point.p.x =  4.5f; point.p.y = -1.0f; point.p.z =  4.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  0.0f; point.t.y =  1.0f;
    quads_tex.push_back(point);
    point.p.x =  4.5f; point.p.y = -1.0f; point.p.z = -4.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  1.0f; point.t.y =  1.0f;
    quads_tex.push_back(point);
    point.p.x =  0.5f; point.p.y = -1.0f; point.p.z = -4.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  1.0f; point.t.y =  0.0f;
    quads_tex.push_back(point);



    state = GAME;
    while (state != EXIT)
    {
        HandleInputEvents();
        GAMESTATE->Update();
        DISPLAY->BeginFrame();

        DISPLAY->SetPointSize(3);
        DISPLAY->DrawPoints(points);
        DISPLAY->SetLineWidth(1);
        DISPLAY->DrawLines(points);

        DISPLAY->PushMatrix();
        DISPLAY->RotateX(rotation_tr);
        DISPLAY->DrawTriangles(triangles);
        DISPLAY->DrawQuads(quads);
        DISPLAY->PopMatrix();
        ++rotation_tr;

        DISPLAY->TextureTranslate(0.01f, 0.0f);
        DISPLAY->SetTexture(tex_id);
        DISPLAY->DrawQuads(quads_tex);
        DISPLAY->UnsetTexture();

        DISPLAY->EndFrame();
    }


    DISPLAY->DeleteTexture(tex_id);
    delete texture;



    SAFE_DELETE(GAMESTATE)
    SAFE_DELETE(DISPLAY)
    SAFE_DELETE(CONFIG)
    SAFE_DELETE(LOGGER)

    return 0;
}
