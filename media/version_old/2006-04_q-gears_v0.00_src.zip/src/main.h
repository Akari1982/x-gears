/*
 *  $Id: main.h, v 1.1 2006/04/17 00:00:01 Exp $
 */

#ifndef MAIN_H
#define MAIN_H



enum
{
    EXIT,
    GAME
};

extern unsigned char state;



#endif // MAIN_H