// $Id: FieldModule.h 140 2007-02-15 08:31:17Z super_gb $

#ifndef FIELD_MODULE_h
#define FIELD_MODULE_h

#include <string>
#include <vector>

#include "UnitManager.h"
#include "../../common/display/3dTypes.h"
#include "../../common/display/actor/Actor.h"



class FieldModule : public Actor
{
public:
    FieldModule();
    virtual ~FieldModule();

    virtual void Init();
    virtual void Input(const InputEvent &input);
    virtual void Update(const Uint32 delta_time);
    virtual void Draw() const;

private:
    void LoadMap(const u16& id);

private:
    std::vector<Vertex>     mAxis;

    // engine managing
    bool                    mViewAxis;

    // map related
    UnitManager*            mpUnitManager;
};



#endif // FIELD_MODULE_h
