// $Id: TimFile.cpp 105 2006-12-02 00:07:47Z einherjar $

#include "../../../common/utilites/Logger.h"

#include "EnemyFile.h"
#include "../../filesystem/GameFileSystem.h"



EnemyFile::EnemyFile(const RString& file):
    File(*GAMEFILESYSTEM, file)
{
}



EnemyFile::EnemyFile(File* pFile):
    File(pFile)
{
}



EnemyFile::EnemyFile(File* pFile, const u32& offset, const u32& length):
    File(pFile, offset, length)
{
}



EnemyFile::EnemyFile(u8* pBuffer, const u32& offset, const u32& length):
    File(pBuffer, offset, length)
{
}



EnemyFile::~EnemyFile(void)
{
}
