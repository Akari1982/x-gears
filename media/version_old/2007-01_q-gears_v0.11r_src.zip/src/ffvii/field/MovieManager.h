// $Id$

#ifndef MOVIE_MANAGER_h
#define MOVIE_MANAGER_h

#include "../../common/display/3dTypes.h"
#include "../../common/display/actor/Actor.h"
#include "../../common/input/InputFilter.h"

class FieldModule;



class MovieManager : public Actor
{
public:
    explicit     MovieManager(FieldModule* field_module);
    virtual     ~MovieManager(void);

    void         Draw(void) const;
    void         Input(const InputEvent& input);
    void         Update(const Uint32 delta_time);

    void         SetPositionToDraw(const Vector3& move);

    void         SetMovieToPlay(const Uint32 movie_id);
    void         Play(const Sint8 entity_id);
    bool         IsPlay(void) const;
    const Uint32 GetFrame(void) const;

    // set/unset camera for 3d entity with screen offset
    void         EnableCamera(void) const;
    void         DisableCamera(void) const;
    void         SetCameraUse(const bool use_camera);
    bool         IsCameraUse(void) const;

private:
    FieldModule* m_FieldModule;

    Vector3      m_Position;

    bool         m_Play;
    Sint8        m_WaitForPlay;
    bool         m_UseCamera;

    Geometry     m_Poly;
};



#endif // MOVIE_MANAGER_h
