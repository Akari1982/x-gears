// $Id: Entity.cpp 94 2006-11-12 19:44:43Z crazy_otaku $

#include <math.h>

#include "../../common/display/Display.h"
#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "BcxFile.h"
#include "Entity.h"
#include "ObjectManager.h"



Entity::Entity(void):
    m_Name(""),

    m_bInited(false),
    m_bWait(false),
    m_usFramesToWait(0),

    m_ModelId(-1),
    m_Visible(true),

    m_SolidRange(30),
    m_Solid(true),

    m_TalkRange(100),
    m_Talkable(false),

    m_bPositionFixed(false),
    m_Position(0.0f, 0.0f, 0.0f),
    m_Triangle(0),
    m_Direction(0),

    m_sbPlayerCharacter(-1),

    m_OnLadder(false),
    m_LadderStart(0.0f, 0.0f, 0.0f),
    m_LadderTriangleStart(0),
    m_LadderEnd(0.0f, 0.0f, 0.0f),
    m_LadderTriangleEnd(0),

    m_InJump(false),
    m_JumpStart(0.0f, 0.0f, 0.0f),
    m_JumpEnd(0.0f, 0.0f, 0.0f)
{
    // initialize queue
    for (u8 i = 0; i < 8; ++i)
    {
        // -1 means no script
        m_aScriptQueue[i].id       = -1;
        m_aScriptQueue[i].position = 0;
    }

    // init and base scripts are always in priority 8
    m_aScriptQueue[7].id       = 0;



    // temp
    BcxFile model("FIELD/CLOUD.BCX");
    model.GetModel(m_Model);
}



Entity::~Entity(void)
{
}



void
Entity::Input(const InputEvent &input)
{
}



void
Entity::Update(const Uint32 delta_time)
{
}



void
Entity::Draw(void) const
{
    if (m_Visible == true)
    {
        DISPLAY->PushMatrix();
        DISPLAY->Translate(m_Position.x, m_Position.y + 40, m_Position.z);
        DISPLAY->RotateY(360.0f * m_Direction / 255.0f);
        DISPLAY->Scale(0.1f, 0.1f, 0.1f);
        m_Model.Draw();
        DISPLAY->PopMatrix();
    }
}



void
Entity::DrawCollision(void) const
{
    Geometry quads;
    quads.vertexes.resize(16);

    Vertex v;
    Color color(0.0f, 1.0f, 1.0f, 1.0f);
    v.c = color;

    float lx = m_SolidRange / 2.0f;
    float ly = m_SolidRange / 2.0f;
    float lz = m_SolidRange / 2.0f;

    v.p.x =  lx; v.p.y =  ly; v.p.z =  lz; quads.vertexes[ 0] = v;
    v.p.x =  lx; v.p.y =  ly; v.p.z = -lz; quads.vertexes[ 1] = v;
    v.p.x =  lx; v.p.y = -ly; v.p.z = -lz; quads.vertexes[ 2] = v;
    v.p.x =  lx; v.p.y = -ly; v.p.z =  lz; quads.vertexes[ 3] = v;

    v.p.x =  lx; v.p.y =  ly; v.p.z = -lz; quads.vertexes[ 4] = v;
    v.p.x = -lx; v.p.y =  ly; v.p.z = -lz; quads.vertexes[ 5] = v;
    v.p.x = -lx; v.p.y = -ly; v.p.z = -lz; quads.vertexes[ 6] = v;
    v.p.x =  lx; v.p.y = -ly; v.p.z = -lz; quads.vertexes[ 7] = v;

    v.p.x = -lx; v.p.y =  ly; v.p.z = -lz; quads.vertexes[ 8] = v;
    v.p.x = -lx; v.p.y =  ly; v.p.z =  lz; quads.vertexes[ 9] = v;
    v.p.x = -lx; v.p.y = -ly; v.p.z =  lz; quads.vertexes[10] = v;
    v.p.x = -lx; v.p.y = -ly; v.p.z = -lz; quads.vertexes[11] = v;

    v.p.x = -lx; v.p.y =  ly; v.p.z =  lz; quads.vertexes[12] = v;
    v.p.x =  lx; v.p.y =  ly; v.p.z =  lz; quads.vertexes[13] = v;
    v.p.x =  lx; v.p.y = -ly; v.p.z =  lz; quads.vertexes[14] = v;
    v.p.x = -lx; v.p.y = -ly; v.p.z =  lz; quads.vertexes[15] = v;



    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->SetLineWidth(1);
    DISPLAY->PushMatrix();
    DISPLAY->Translate(m_Position.x, m_Position.y, m_Position.z);
    DISPLAY->RotateY(360.0f * m_Direction / 255.0f);
    DISPLAY->DrawQuads(quads);
    DISPLAY->PopMatrix();
    DISPLAY->SetPolygonMode(POLYGON_FILL);
}



const bool
Entity::IsActionEnabled(void) const
{
    return (m_ModelId != -1) && (m_Visible == true) && (m_bPositionFixed == true);
}



const bool
Entity::CheckCollision(Entity* pEntity)
{
    Vector3 point = pEntity->GetPosition();

    float distance = sqrtf((point.x - m_Position.x) * (point.x - m_Position.x) + (point.y - m_Position.y) * (point.y - m_Position.y) + (point.z - m_Position.z) * (point.z - m_Position.z));

    return (distance < m_SolidRange) ? true : false;
}



void
Entity::CheckCollisionTalk(Entity* pEntity)
{
    Vector3 point = pEntity->GetPosition();

    float distance = sqrtf((point.x - m_Position.x) * (point.x - m_Position.x) + (point.y - m_Position.y) * (point.y - m_Position.y) + (point.z - m_Position.z) * (point.z - m_Position.z));

    m_Talkable = (distance < m_TalkRange) ? true : false;
}



void
Entity::SetName(const RString& name)
{
    m_Name = name;
}



const RString&
Entity::GetName(void) const
{
    return m_Name;
}



void
Entity::SetEntryPoint(const u8 id, const u32 entryPoint)
{
    if (id >= 32)
    {
        LOGGER->Log(LOGGER_WARNING, "Entity::SetEntryPoint: Tried to set entry point to id larger or equal 32.");
        return;
    }

    m_aulEntryPoints[id] = entryPoint;
}



void
Entity::Run(FieldModule* pFieldModule, Script* script, const s8 sbEntityId)
{
    // if we syncronize with something
    if (m_bWait == true || m_usFramesToWait > 0)
    {
        if (m_usFramesToWait > 0)
        {
            --m_usFramesToWait;
        }

        return;
    }



    // if we not inited
    if (m_bInited == false)
    {
        Init(pFieldModule, script, sbEntityId);
    }
    else
    {
        for (int i = 0; i < 8; ++i)
        {
            if (m_aScriptQueue[i].id != -1)
            {
                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log(LOGGER_INFO, "Script %02x from entity %s with priority %d started.", m_aScriptQueue[i].id, m_Name.c_str(), i);
                }

                bool finish = script->Run(pFieldModule, sbEntityId, m_aScriptQueue[i].position);

                // if script finished it work
                if (finish)
                {
                    if (CONFIG->m_DumpScript == true)
                    {
                        LOGGER->Log(LOGGER_INFO, "Script %02x from entity %s with priority %d finished.", m_aScriptQueue[i].id, m_Name.c_str(), i);
                    }

                    if (i == 7)
                    {
                        // if we run base script
                        m_aScriptQueue[i].position = m_aulEntryPoints[0];
                    }
                    else
                    {
                        m_aScriptQueue[i].id       = -1;
                        m_aScriptQueue[i].position = 0;
                    }
                }
                else
                {
                    if (CONFIG->m_DumpScript == true)
                    {
                        LOGGER->Log(LOGGER_INFO, "Script %02x from entity %s with priority %d waiting.", m_aScriptQueue[i].id, m_Name.c_str(), i);
                    }
                }

                break;
            }
        }
    }
}



void
Entity::Init(FieldModule* pFieldModule, Script* script, const s8 sbEntityId)
{
    if (CONFIG->m_DumpScript == true)
    {
        LOGGER->Log(LOGGER_INFO, "Run Init script from entity %s.", m_Name.c_str());
    }

    if (script->Run(pFieldModule, sbEntityId, m_aulEntryPoints[0]) == true)
    {
        m_bInited = true;
        m_aScriptQueue[7].position = m_aulEntryPoints[0];
    }
}



void
Entity::RequestRun(const u8 priority, const u8 scriptId)
{
    if (m_aScriptQueue[priority].id == -1)
    {
        m_aScriptQueue[priority].id       = scriptId;
        m_aScriptQueue[priority].position = m_aulEntryPoints[scriptId];
    }
}



void
Entity::SetWait(const bool bWait)
{
    m_bWait = bWait;
}



void
Entity::SetFramesToWait(const u16 usWait)
{
    m_usFramesToWait = usWait;
}



void
Entity::SetModelId(const Sint8 model_id)
{
    m_ModelId = model_id;
}



const Sint8
Entity::GetModelId(void) const
{
    return m_ModelId;
}



void
Entity::SetVisible(const bool visible)
{
    m_Visible = visible;
}



const bool
Entity::IsVisible(void) const
{
    return m_Visible;
}



void
Entity::SetSolidRange(const Uint16 range)
{
    m_SolidRange = range;
}



const Uint16
Entity::GetSolidRange(void) const
{
    return m_SolidRange;
}



void
Entity::SetSolid(const bool solid)
{
    m_Solid = solid;
}



const bool
Entity::IsSolid(void) const
{
    return m_Solid;
}



void
Entity::SetTalkRange(const Uint16 range)
{
    m_TalkRange = range;
}



const Uint16
Entity::GetTalkRange(void) const
{
    return m_TalkRange;
}



const bool
Entity::IsTalkable(void) const
{
    return m_Talkable;
}



void
Entity::SetPositionFixed(const bool bFixed)
{
    m_bPositionFixed = bFixed;
}



const bool
Entity::IsPositionFixed(void) const
{
    return m_bPositionFixed;
}



void
Entity::SetPosition(const Vector3& position)
{
    m_Position = position;
}



const Vector3&
Entity::GetPosition(void) const
{
    return m_Position;
}



void
Entity::SetTriangle(const Sint16 triangle)
{
    m_Triangle = triangle;
}



const Sint16
Entity::GetTriangle(void) const
{
    return m_Triangle;
}



void
Entity::SetDirection(const Uint8 direction)
{
    m_Direction = direction;
}



const Uint8
Entity::GetDirection(void) const
{
    return m_Direction;
}



void
Entity::SetPlayerCharacter(const s8 sbPlayerCharacter)
{
    m_sbPlayerCharacter = sbPlayerCharacter;
}



const s8
Entity::GetPlayerCharacter(void) const
{
    return m_sbPlayerCharacter;
}



void
Entity::SetOnLadder(const bool on_ladder)
{
    m_OnLadder = on_ladder;
}



const bool
Entity::IsOnLadder(void) const
{
    return m_OnLadder;
}



void
Entity::SetLadder(const Vector3& ladder_end, const Sint16 end_triangle)
{
    m_LadderStart         = m_Position;
    m_LadderTriangleStart = m_Triangle;
    m_LadderEnd           = ladder_end;
    m_LadderTriangleEnd   = end_triangle;
}



const Vector3&
Entity::GetLadderStart(void) const
{
    return m_LadderStart;
}



const Sint16
Entity::GetLadderTriangleStart(void) const
{
    return m_LadderTriangleStart;
}



const Vector3&
Entity::GetLadderEnd(void) const
{
    return m_LadderEnd;
}



const Sint16
Entity::GetLadderTriangleEnd(void) const
{
    return m_LadderTriangleEnd;
}



const bool
Entity::IsInJump(void) const
{
    return m_InJump;
}



void
Entity::SetJump(const Vector3& jump_to, const Sint8 entity_id, ObjectManager* manager)
{
    m_InJump         = true;
    m_JumpStart      = m_Position;
    m_JumpEnd        = jump_to;
    m_EntityId       = entity_id;
    m_ObjectManager  = manager;

    // temp teleport
    m_bPositionFixed = false;
    m_ObjectManager->SetPositionByXZ(m_EntityId, m_JumpEnd);
    m_InJump         = false;
}
