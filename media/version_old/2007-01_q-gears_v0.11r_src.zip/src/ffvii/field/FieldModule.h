// $Id: FieldModule.h 151 2007-03-04 11:28:52Z super_gb $

#ifndef FIELDSCREEN_H
#define FIELDSCREEN_H

#include <string>
#include <vector>

#include "../../common/display/3dTypes.h"
#include "../../common/display/actor/Actor.h"

#include "BackgroundManager.h"
#include "DatFile.h"
#include "MovieManager.h"
#include "ObjectManager.h"
#include "ScreenManager.h"
#include "WindowManager.h"
#include "../kernel/Kernel.h"

// forward declaration
class Script;



class FieldModule : public Actor
{
friend class Line;
friend class MovieManager;
friend class ObjectManager;
friend class ScreenManager;
friend class Script;
friend class WindowManager;

public:
                 FieldModule(void);
    virtual     ~FieldModule(void);

    virtual void Input(const InputEvent &input);
    virtual void Update(const Uint32 delta_time);
    virtual void Draw(void) const;

    void         RequestLoadMap(const u16& id);
    void         LoadBattle(const u16& id);

    // 0x6B FADE
    void         Fade(const u8& speed, const u8& start, const Color& color, const u8& type);
    // 0x6C FADEW
    void         AddWaitForFade(const s8& sbEntityId);

private:
    void         LoadMap(const u16& id);

    void         DrawDebugInfo(void) const;
    void         DrawPosibleActions(void) const;

public:
    // map related
    BackgroundManager       mBackgroundManager;
    MovieManager            m_MovieManager;
    ObjectManager           mObjectManager;
    ScreenManager           m_ScreenManager;
    WindowManager           mWindowManager;

private:
    std::vector<Vertex>     mAxis;

    // engine managing
    bool                    mViewDebugInfo;



    // map loading related
    u16                     mRequestMapId;
    bool                    mRequestLoadMap;
    bool                    m_bMenuAccess;



    // fade (move this somewhere)
    s16                     mFadeAlpha;
    s16                     mFadeSpeed;
    bool                    mFadeIn;
    Color                   mFadeColor;
    std::vector<s8>         m_vWaitingForFade;
};



#endif // FIELDSCREEN_H
