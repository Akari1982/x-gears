// $Id: FieldModule.cpp 151 2007-03-04 11:28:52Z super_gb $

#include <libxml/tree.h>

#include "../../common/display/Display.h"
#include "../../common/module/ModuleManager.h"
#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "DatFile.h"
#include "DatXmlFile.h"
#include "FieldModule.h"
#include "FieldUtilites.h"
#include "Entity.h"
#include "Script.h"
#include "../battle/BattleModule.h"
#include "../kernel/GameState.h"
#include "../menu/PartyMenu.h"
#include "../worldmap/WorldMapModule.h"

#include "../screentest/DisplayTest.h"



FieldModule::FieldModule():
    mRequestMapId(0),
    mRequestLoadMap(false),
    m_bMenuAccess(true),

    mViewDebugInfo(false),

    mFadeAlpha(0),
    mFadeSpeed(0),
    mFadeIn(false),

    // dangerous
    // we musn't use FieldModule pointer until it compleatly constructed
    m_MovieManager(this),
    mObjectManager(this),
    mWindowManager(this),
    mBackgroundManager(this),
    m_ScreenManager(this)
{
    LOGGER->Log(LOGGER_INFO, "Field module start.");
    DISPLAY->SetZTestMode(ZTEST_OFF);
    DISPLAY->SetAlphaTest(true);
    DISPLAY->SetBlendMode(BLEND_PSX_0);
    DISPLAY->SetCullMode(CULL_NONE);
    DISPLAY->SetPolygonMode(POLYGON_FILL);

    // load map from savemap
    LoadMap(GAMESTATE->CurrentFieldGet());
}



FieldModule::~FieldModule()
{
    LOGGER->Log(LOGGER_INFO, "Field module stopped (%08x).", this);
}



void
FieldModule::LoadMap(const u16& id)
{
    // check if this is field file (not worldmap)
    if (id < 0x41)
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to load worldmap with mapId = %04x.", id);
        return;
    }
    LOGGER->Log(LOGGER_INFO, "Start load field %04x.", id);



    // remember current map
    GAMESTATE->CurrentFieldSet(id);

    // clear all managers
    mBackgroundManager.Clear();
    m_ScreenManager.Clear();
    mObjectManager.Clear();
    mWindowManager.Clear();



    // load DAT file
    DatFile dat("FIELD/" + MapIdToRString(id) + ".DAT");
    //dat.WriteFile(MapIdToRString(id) + "_u.DAT");
    LOGGER->Log(LOGGER_INFO, "Load field %s", dat.GetFileName().c_str());



    // try load xml file
    DatXmlFile xml_file("data/FIELD/" + MapIdToRString(id) + ".xml");



    // load dialogs
    if (xml_file.GetDialogs(mWindowManager) != 0)
    {
        LOGGER->Log(LOGGER_INFO, "Load dialogs from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log(LOGGER_INFO, "Load entity from FieldFile.");
        dat.GetDialogs(mWindowManager);
    }



    // load entity info
    if (xml_file.GetScripts(mObjectManager) != 0)
    {
        LOGGER->Log(LOGGER_INFO, "Load entitys from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log(LOGGER_INFO, "Load entitys from FieldFile.");
        dat.GetScripts(mObjectManager);
    }



    LOGGER->Log(LOGGER_INFO, "Loading background image.");
    mBackgroundManager.LoadBackground("FIELD/" + MapIdToRString(id) + ".MIM");
    LOGGER->Log(LOGGER_INFO, "Loading of background image has been complete.");
    LOGGER->Log(LOGGER_INFO, "Loading background info from FieldFile.");
    dat.GetBackground(mBackgroundManager);
    mBackgroundManager.UnloadBackground();



    // load walkmesh info
    if (xml_file.GetWalkMesh(mObjectManager) != 0)
    {
        LOGGER->Log(LOGGER_INFO, "Load walkmesh from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log(LOGGER_INFO, "Loading walkmesh from FieldFile.");
        dat.GetWalkMesh(mObjectManager);
    }



    // load gateways info
    if (xml_file.GetGateway(mObjectManager) != 0)
    {
        LOGGER->Log(LOGGER_INFO, "Load gateways from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log(LOGGER_INFO, "Loading gateways from FieldFile.");
        dat.GetGateway(mObjectManager);
    }



    // load mark triangles info
    if (xml_file.GetMarkTriangles(mObjectManager) != 0)
    {
        LOGGER->Log(LOGGER_INFO, "Load mark triangles from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log(LOGGER_INFO, "Loading mark triangles from FieldFile.");
        dat.GetMarkTriangles(mObjectManager);
    }



    // load movement rotation info
    if (xml_file.GetMovementRotation(mObjectManager) != 0)
    {
        LOGGER->Log(LOGGER_INFO, "Load movement rotation from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log(LOGGER_INFO, "Loading movement rotation from FieldFile.");
        dat.GetMovementRotation(mObjectManager);
    }



    // load encounters info
    if (xml_file.GetEncounter(mObjectManager) != 0)
    {
        LOGGER->Log(LOGGER_INFO, "Load encounters from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log(LOGGER_INFO, "Loading encounter from FieldFile.");
        dat.GetEncounter(mObjectManager);
    }



    // load camera matrix
    LOGGER->Log(LOGGER_INFO, "Loading camera from FieldFile.");
    dat.GetCameraMatrix(m_ScreenManager);


    // load camera matrix
    LOGGER->Log(LOGGER_INFO, "Loading picture range FieldFile.");
    dat.GetScreenRange(m_ScreenManager);



    // start fadeout
    mFadeColor.r = 0;
    mFadeColor.g = 0;
    mFadeColor.b = 0;
    mFadeAlpha = 255;
    mFadeSpeed = 5;
    mFadeIn    = false;
    m_vWaitingForFade.clear();

    // menu access
    m_bMenuAccess = true;
}



void
FieldModule::RequestLoadMap(const u16& id)
{
    LOGGER->Log(LOGGER_INFO, "FieldModule::RequestLoadMap: map %04x.", id);
    mRequestMapId = id;
    mRequestLoadMap = true;

    // start fade in
    mFadeColor.r = 0;
    mFadeColor.g = 0;
    mFadeColor.b = 0;
    mFadeAlpha = 0;
    mFadeSpeed = 5;
    mFadeIn    = true;
}



void
FieldModule::LoadBattle(const u16& id)
{
    BattleModule* module = new BattleModule();
    module->LoadBattle(id);
    MODULEMAN->PushModule(module);
}



void
FieldModule::Fade(const u8& speed, const u8& start, const Color& color, const u8& type)
{
    if (type == 3)
    {
        mFadeAlpha = 0;
    }
    else if (type == 4)
    {
        mFadeColor.r = 0;
        mFadeColor.g = 0;
        mFadeColor.b = 0;
        mFadeAlpha = 255;
    }
    else if (type == 5)
    {
        mFadeAlpha = start;
        mFadeColor = color;
        mFadeSpeed = speed;
        mFadeIn = false;
    }
    else if (type == 6)
    {
        mFadeAlpha = start;
        mFadeColor = color;
        mFadeSpeed = speed;
        mFadeIn = true;
    }
}



void
FieldModule::AddWaitForFade(const s8& sbEntityId)
{
    m_vWaitingForFade.push_back(sbEntityId);
}



void
FieldModule::Input(const InputEvent& input)
{
    // handle system input ourself
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_Cd:    mViewDebugInfo  = (mViewDebugInfo == true) ? false : true; break;

            case KEY_Cm:
            {
                MODULEMAN->PopTopModule();
                WorldMapModule* module = new WorldMapModule();
                MODULEMAN->PushModule(module);
                break;
            }

            case KEY_Ct:
            {
                MODULEMAN->PopTopModule();
                ScreenDisplayTest* module = new ScreenDisplayTest();
                MODULEMAN->PushModule(module);
                break;
            }
        }
    }



    // give input to everything only if we not load next map.
    // we must stop all process in this case
    if (mRequestLoadMap != true)
    {
        // give input to background (for debug)
        if (mBackgroundManager.Input(input) == true)
        {
            // if we handled input - return
            return;
        }



        // give input to all opened windows
        if (mWindowManager.Input(input) == true)
        {
            // if we handled input - return
            return;
        }



        // give input to all object on map
        mObjectManager.Input(input);



        // give input to movie
        m_MovieManager.Input(input);



        // handle other game input
        if (input.type == IET_FIRST_PRESS)
        {
            switch (input.button)
            {
                case KEY_Cs:
                {
                    if (m_bMenuAccess == true)
                    {
                        PartyMenu* module = new PartyMenu();
                        MODULEMAN->PushModule(module);
                    }
                    break;
                }

                case KEY_Cb:
                {
                    LoadBattle(999);
                    break;
                }
            }
        }
    }
}



void
FieldModule::Update(const Uint32 delta_time)
{
    if (mRequestLoadMap == true && mFadeAlpha == 255)
    {
        LoadMap(mRequestMapId);

        mRequestLoadMap = false;
    }



    // update fade after request load map check
    // because we want to draw fully fade screen before map loading
    if (mFadeIn == true)
    {
        mFadeAlpha = ((mFadeAlpha + mFadeSpeed) > 255) ? 255 : mFadeAlpha + mFadeSpeed;
    }
    else
    {
        mFadeAlpha = ((mFadeAlpha - mFadeSpeed) < 0) ? 0 : mFadeAlpha - mFadeSpeed;
    }

    if ((mFadeAlpha == 0 || mFadeAlpha == 255))
    {
        for (u8 i = 0; i < m_vWaitingForFade.size(); ++i)
        {
            mObjectManager.SetWait(m_vWaitingForFade[i], false);
        }

        m_vWaitingForFade.clear();
    }

    mFadeColor.a = mFadeAlpha / 255.0f;


    // update everything only if we not load next map.
    // we must stop all process in this case
    if (mRequestLoadMap != true)
    {
        // update all objects on map
        mObjectManager.Update(delta_time);



        // update all opened windows
        mWindowManager.Update(delta_time);



        // update background
        mBackgroundManager.Update(delta_time);



        // update movie
        m_MovieManager.Update(delta_time);



        // update camera
        m_ScreenManager.Update(delta_time);
    }
}



void
FieldModule::DrawPosibleActions(void) const
{
    KERNEL->DrawString(RStringToFFVIIString("1,2 to operate with background"), 350, 400, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("3,4,5 to operate walkmesh, collision, triggers"), 350, 415, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("D to show/hide debug info"),              350, 430, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("T to go to 'Screen Test' module"),          350, 445, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("M to go to 'Worldmap' module"),             350, 460, F_WHITE);
}



void
FieldModule::Draw() const
{
    // draw background;
    if (m_MovieManager.IsPlay() == false)
    {
        mBackgroundManager.DrawInPosition(Vector3(m_ScreenManager.GetCameraPositionX(), m_ScreenManager.GetCameraPositionY(), 0.0f));
    }



    if (m_MovieManager.IsCameraUse() == false)
    {
        m_ScreenManager.EnableCamera();
    }
    else
    {
        m_MovieManager.EnableCamera();
    }

    m_MovieManager.Draw();
    mObjectManager.Draw();

    if (m_MovieManager.IsCameraUse() == false)
    {
        m_ScreenManager.DisableCamera();
    }
    else
    {
        m_MovieManager.DisableCamera();
    }



    // draw all opened windows
    mWindowManager.Draw();



    DrawPosibleActions();
    if (mViewDebugInfo == true)
    {
        mObjectManager.DrawDebugInfo();
        mWindowManager.DrawDebugInfo();
    }



    KERNEL->DrawColorOverlay(mFadeColor);



    m_ScreenManager.Draw();
}
