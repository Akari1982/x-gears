// $Id$

#include "../../common/utilites/Logger.h"
#include "../../common/filesystem/RealFileSystem.h"

#include "TdbFile.h"
#include "../kernel/Kernel.h"

#include "../../common/display/surface/SurfaceSaveBmp.h"



TdbFile::TdbFile(const RString& file):
    LzsFile(file)
{
//    InnerGetImage();
}



TdbFile::TdbFile(File* pFile):
    LzsFile(pFile)
{
//    InnerGetImage();
}



TdbFile::TdbFile(File* pFile, const u32& offset, const u32& length):
    LzsFile(pFile, offset, length)
{
//    InnerGetImage();
}



TdbFile::TdbFile(u8* pBuffer, const u32& offset, const u32& length):
    LzsFile(pBuffer, offset, length)
{
//    InnerGetImage();
}



TdbFile::~TdbFile(void)
{
}
