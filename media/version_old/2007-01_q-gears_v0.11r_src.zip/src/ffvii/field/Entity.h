// $Id: Entity.h 94 2006-11-12 19:44:43Z crazy_otaku $

#ifndef ENTITY_h
#define ENTITY_h

#include "../../common/TypeDefine.h"
#include "../../common/display/3dTypes.h"
#include "../../common/display/actor/Actor.h"
#include "../../common/utilites/StdString.h"

#include "Model.h"
#include "Script.h"

class FieldModule;
class ObjectManager;



struct ScriptQueueItem
{
    s8  id;
    u32 position;
};



class Entity : public Actor
{
public:
                   Entity(void);
    virtual       ~Entity(void);

    virtual void   Input(const InputEvent &input);
    virtual void   Update(const Uint32 delta_time);
    virtual void   Draw(void) const;

    void           DrawCollision(void) const;

    const bool     IsActionEnabled(void) const;

    const bool     CheckCollision(Entity* pEntity);
    void           CheckCollisionTalk(Entity* pEntity);

    // name related
    void           SetName(const RString& name);
    const RString& GetName(void) const;

    // script related
    void           SetEntryPoint(const u8 id, const u32 entryPoint);
    void           Run(FieldModule* pFieldModule, Script* script, const s8 sbEntityId);
    void           Init(FieldModule* pFieldModule, Script* script, const s8 sbEntityId);
    void           RequestRun(const u8 priority, const u8 scriptId);
    void           SetWait(const bool bWait);
    void           SetFramesToWait(const u16 usWait);

    // model related
    void           SetModelId(const Sint8 model_id);
    const Sint8    GetModelId(void) const;
    void           SetVisible(const bool visible);
    const bool     IsVisible(void) const;

    // solid related
    void           SetSolidRange(const Uint16 range);
    const Uint16   GetSolidRange(void) const;
    void           SetSolid(const bool solid);
    const bool     IsSolid(void) const;

    // talk related
    void           SetTalkRange(const Uint16 range);
    const Uint16   GetTalkRange(void) const;
    const bool     IsTalkable(void) const;

    // position related
    void           SetPositionFixed(const bool bFixed);
    const bool     IsPositionFixed(void) const;
    void           SetPosition(const Vector3& position);
    const Vector3& GetPosition(void) const;
    void           SetTriangle(const Sint16 triangle);
    const Sint16   GetTriangle(void) const;
    void           SetDirection(const u8 ubDirection);
    const u8       GetDirection(void) const;

    // player character related
    void           SetPlayerCharacter(const s8 sbPlayerCharacter);
    const s8       GetPlayerCharacter(void) const;

    // ladder related
    void           SetOnLadder(const bool on_ladder);
    const bool     IsOnLadder(void) const;
    void           SetLadder(const Vector3& ladder_end, const Sint16 end_triangle);
    const Vector3& GetLadderStart(void) const;
    const Sint16   GetLadderTriangleStart(void) const;
    const Vector3& GetLadderEnd(void) const;
    const Sint16   GetLadderTriangleEnd(void) const;

    // jump related
    const bool     IsInJump(void) const;
    void           SetJump(const Vector3& jump_to, const Sint8 entity_id, ObjectManager* manager);

private:
    // name of entity
    RString         m_Name;

    // script related
    u32             m_aulEntryPoints[32];
    ScriptQueueItem m_aScriptQueue[8];
    bool            m_bInited;
    bool            m_bWait;
    u16             m_usFramesToWait;

    // model related
    Model           m_Model;
    Sint8           m_ModelId;
    bool            m_Visible;

    // solid related
    Uint16          m_SolidRange;
    bool            m_Solid;

    // talk related
    Uint16          m_TalkRange;
    // we can talk with unit (seted and unseted in collision check).
    // Used only first true talkable in stack.
    bool            m_Talkable;

    // position related
    bool            m_bPositionFixed;
    Vector3         m_Position;
    Sint16          m_Triangle;
    u8              m_Direction;

    // player character related
    s8              m_sbPlayerCharacter;

    // ladder related
    bool            m_OnLadder;
    Vector3         m_LadderStart;
    Sint16          m_LadderTriangleStart;
    Vector3         m_LadderEnd;
    Sint16          m_LadderTriangleEnd;

    // jump related
    bool            m_InJump;
    Vector3         m_JumpStart;
    Vector3         m_JumpEnd;
    // temp
    Sint8           m_EntityId;
    ObjectManager*  m_ObjectManager;
};



#endif // ENTITY_h
