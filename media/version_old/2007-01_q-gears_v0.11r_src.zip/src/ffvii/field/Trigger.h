// $Id: Trigger.h 151 2007-03-04 11:28:52Z super_gb $

#ifndef TRIGGER_h
#define TRIGGER_h

class Entity;
class FieldModule;



class Trigger
{
public:
                   Trigger(FieldModule* pFieldModule, const Vector3& point1, const Vector3& point2);
    virtual       ~Trigger(void);

    void           Draw(void) const;

    void           CheckCollision(Entity* entity);

    virtual void   OnEnter (void) = 0;
    virtual void   OnMove  (void) = 0;
    virtual void   OnInside(void) = 0;
    virtual void   OnLeave (void) = 0;

    void           SetPoint1(const Vector3& point);
    const Vector3& GetPoint1(void) const;
    void           SetPoint2(const Vector3& point);
    const Vector3& GetPoint2(void) const;

protected:
    FieldModule* m_pFieldModule;

    bool         m_bEntered;

    Vector3      m_Point1;
    Vector3      m_Point2;

    Vector3      m_PcPreviousPosition;
};



#endif // TRIGGER_h
