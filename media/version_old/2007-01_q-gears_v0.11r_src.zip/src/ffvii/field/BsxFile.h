// $Id$

#ifndef BSX_FILE_h
#define BSX_FILE_h

#include "../../common/utilites/StdString.h"

#include "../filetypes/LzsFile.h"



class BsxFile : public LzsFile
{
public:
    explicit     BsxFile(const RString& file);
    explicit     BsxFile(File* pFile);
                 BsxFile(File* pFile, const u32& offset, const u32& length);
                 BsxFile(u8* pBuffer, const u32& offset, const u32& length);
    virtual     ~BsxFile(void);
};



#endif // BSX_FILE_h
