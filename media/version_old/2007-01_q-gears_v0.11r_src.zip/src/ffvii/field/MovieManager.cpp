// $Id$

#include "../../common/display/Display.h"
#include "../../common/movie/Movie.h"
#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "FieldModule.h"
#include "MovieManager.h"



MovieManager::MovieManager(FieldModule* field_module):
    m_FieldModule(field_module),

    m_Play(true),
    m_WaitForPlay(-1),
    m_UseCamera(false)
{
    Vertex point;
    point.p.x = 0.0f; point.p.y =  0.0f; point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f; point.t.y =  0.0f;
    m_Poly.vertexes.push_back(point);
    point.p.x = 320.0f; point.p.y =  0.0f; point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f; point.t.y =  0.0f;
    m_Poly.vertexes.push_back(point);
    point.p.x = 320.0f; point.p.y = -224.0f; point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f; point.t.y =  1.0f;
    m_Poly.vertexes.push_back(point);
    point.p.x = 0.0f; point.p.y = -224.0f; point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f; point.t.y =  1.0f;
    m_Poly.vertexes.push_back(point);
}



MovieManager::~MovieManager(void)
{
}



void
MovieManager::Draw(void) const
{
    if (m_Play == true)
    {
        DISPLAY->PushMatrix();
        DISPLAY->LoadIdentity();
        DISPLAY->Translate(-0.5f, 0.5f, 0.0f);
        DISPLAY->Scale(2.0f / CONFIG->GAME_WIDTH, 2.0f / CONFIG->GAME_HEIGHT, 1.0f);
        DISPLAY->Translate(m_Position.x, -m_Position.y - 8.0f, 0.0f);

        DISPLAY->CameraPushMatrix();
        DISPLAY->CameraLoadIdentity();
        DISPLAY->TexturePushMatrix();
        DISPLAY->TextureLoadIdentity();

        DISPLAY->SetTexture(MOVIEMAN->GetFrameTextureId());
        DISPLAY->DrawQuads(m_Poly);
        DISPLAY->UnsetTexture();

        DISPLAY->TexturePopMatrix();
        DISPLAY->CameraPopMatrix();
        DISPLAY->PopMatrix();
    }
}



void
MovieManager::Input(const InputEvent& input)
{
}



void
MovieManager::Update(const Uint32 delta_time)
{
    if (MOVIEMAN->IsPlaying() != true)
    {
        m_Play = false;
        if (m_WaitForPlay != -1)
        {
            m_FieldModule->mObjectManager.SetWait(m_WaitForPlay, false);
            m_WaitForPlay = -1;
        }
    }
}



void
MovieManager::SetPositionToDraw(const Vector3& move)
{
    m_Position = move;
}



void
MovieManager::SetMovieToPlay(const Uint32 movie_id)
{
    MOVIEMAN->SetMovieToPlay(movie_id);
}



void
MovieManager::Play(const Sint8 entity_id)
{
    m_Play        = true;
    m_WaitForPlay = entity_id;

    MOVIEMAN->Play();
}



bool
MovieManager::IsPlay(void) const
{
    return m_Play;
}



const Uint32
MovieManager::GetFrame(void) const
{
    return MOVIEMAN->GetFrame();
}



void
MovieManager::EnableCamera(void) const
{
}



void
MovieManager::DisableCamera(void) const
{
}



void
MovieManager::SetCameraUse(const bool use_camera)
{
    m_UseCamera = use_camera;
}



bool
MovieManager::IsCameraUse(void) const
{
    return m_UseCamera;
}
