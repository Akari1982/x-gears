// $Id: GameFileSystem.cpp 117 2006-12-15 21:10:57Z crazy_otaku $

#include "GameFileSystem.h"



GameFileSystem* GAMEFILESYSTEM = NULL;



GameFileSystem::GameFileSystem():
    mFileDriver("./data")
//    mFileDriver("/dev/cdrom")
{
}



GameFileSystem::~GameFileSystem()
{
}



unsigned int
GameFileSystem::GetFileSize(const RString &path)
{
    return mFileDriver.GetFileSize(path);
}



bool
GameFileSystem::ReadFile(const RString &path, void* buffer, const unsigned int start, const unsigned int length)
{
    return mFileDriver.ReadFile(path, buffer, start, length);
}
