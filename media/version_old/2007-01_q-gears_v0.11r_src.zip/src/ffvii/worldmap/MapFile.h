// $Id: MapFile.h 86 2006-10-23 21:44:13Z einherjar $
#ifndef MAP_FILE_H
#define MAP_FILE_H

#include "../../common/TypeDefine.h"
#include "../../common/utilites/StdString.h"

//
class Vector3;

class LzsFile;

class WorldMesh;
class WorldCell;
class WorldMap;

//
class MapFile
{
public:
  explicit MapFile(const RString &path);

public:
  WorldMap *Read() const;

protected:
  WorldMap *ReadMap(const RString &path, unsigned int nb_rows, unsigned int nb_cols, unsigned int nb_sup) const;
  WorldCell *ReadCell(uint8_t *map_block, const Vector3 &cell_translation) const;
  WorldMesh *ReadMesh(LzsFile &lzsf, const Vector3 &mesh_translation) const;

protected:
  const RString mPath;
};

#endif // !MAP_FILE_H
