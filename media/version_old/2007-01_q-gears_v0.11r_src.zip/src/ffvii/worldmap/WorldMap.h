// $Id$

#ifndef WORLD_MAP_H
#define WORLD_MAP_H

#include "WorldCell.h"

class WorldMap
{
public:
  explicit WorldMap(const WorldCellVector &sub_cells, unsigned int nb_rows, unsigned int nb_cols,
		    const WorldCellVector &supplementary_cells):
    mCells(sub_cells), mNbRows(nb_rows), mNbCols(nb_cols),
    mSupplementaryCells(supplementary_cells)
  {}

  ~WorldMap();

public:
  inline const WorldCellVector &GetCells() const { return mCells; }

protected:
  WorldCellVector mCells;
  unsigned int mNbRows;
  unsigned int mNbCols;

  WorldCellVector mSupplementaryCells;
};

#endif // !WORLD_MAP_H
