// $Id: GameState.h 151 2007-03-04 11:28:52Z super_gb $

#ifndef GAMESTATE_H
#define GAMESTATE_H
// The Gamestate Class : Contain all info about current game state

#include "../../common/display/3dTypes.h"
#include "../../common/utilites/NoCopy.h"

#include "Player.h"
#include "Savemap.h"
#include "gui/FFVIIString.h"
#include "../filesystem/File.h"

// forward declaration
class Kernel;
class MemoryBank;



class GameState : public NoCopy<GameState>
{
    friend class Kernel;
    friend class MemoryBank;

public:
                       GameState(void);
    virtual           ~GameState(void);

    const Savemap&     GetSavemap(void) const;
    void               LoadSavemap(File* file);
    void               DumpSavemap(void);



    // memory bank handling
    void               MemoryBankPut(const u8& memoryBank, const u8& offset, const u8& value);
    void               MemoryBankPut(const u8& memoryBank, const u8& offset, const u16& value);
    u8                 MemoryBankGet(const u8& memoryBank, const u8& offset);
    u16                MemoryBankGet(const u8& memoryBank, const u16& offset);

    // map
    const u16&         CurrentFieldGet(void);
    void               CurrentFieldSet(const u16& currentMap);
    FFVIIString        CurrentFieldNameGet(void);
    void               CurrentFieldNameSet(FFVIIString name);

    // party
    void               PartyCharacterAdd(const u8& ubCharacter);
    void               PartyCharactersAdd(const u8& ubCharacter1, const u8& ubCharacter2, const u8& ubCharacter3);

    // player
    const Vector3&     PlayerPositionGet(void);
    void               PlayerPositionSet(const Vector3& coord);
    const bool&        PlayerPositionIsSet(void);
    void               PlayerPositionUnset(void);
    const u16&         PlayerTriangleGet(void);
    void               PlayerTriangleSet(const u16& triangle);
    const bool&        PlayerTriangleIsSet(void);
    void               PlayerTriangleUnset(void);


    // timer
    void               TimerStart(void);
    void               TimerStop(void);

    // battle
    const bool&        BattleLockGet(void);
    void               BattleLockSet(const bool& lock);



    void               Update(void);

private:
    ////////////////////////////////////////////////
    // global values
    Savemap                       m_Savemap;

    // game timer
    bool                          mTimerStarted;

    // don't know where in the save map this can be.
    // so this is temp placement
    bool                          mBattleLock;
    ////////////////////////////////////////////////



    ////////////////////////////////////////////////
    // field module
    // temp memory bank 5/6
    u8*                           mpMemoryBank56;
    ////////////////////////////////////////////////



    ////////////////////////////////////////////////
    // player unit stats
    Player                        m_Player;

    Vector3                       mPlayerPosition;
    bool                          mPlayerPositionSet;
    u16                           mPlayerTriangle;
    bool                          mPlayerTriangleSet;
    ////////////////////////////////////////////////
};



// Visible from every part of programm
extern GameState* GAMESTATE;



#endif // GAMESTATE_H
