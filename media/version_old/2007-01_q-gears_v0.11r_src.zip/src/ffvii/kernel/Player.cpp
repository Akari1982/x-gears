// $Id$

#include "../../common/utilites/Logger.h"

#include "Player.h"
#include "../GameDefine.h"



class find_item_slot_by_id
{
public:
    find_item_slot_by_id(const Sint32 id):
        m_Id(id)
    {
    }

    bool
    operator()(const ItemSlot& slot) const
    {
        return slot.id == m_Id;
    }

private:
    Sint32 m_Id;
};



class find_materia_slot_by_id
{
public:
    find_materia_slot_by_id(const Sint32 id):
        m_Id(id)
    {
    }

    bool
    operator()(const MateriaSlot& slot) const
    {
        return slot.id == m_Id;
    }

private:
    Sint32 m_Id;
};



Player::Player(void):
    m_Money(0)
{
    m_Items.resize(MAX_ITEM_SLOT);
    m_Materias.resize(MAX_MATERIA_SLOT);
}



Player::~Player(void)
{
}



void
Player::AddItems(const Sint32 item_id, const Uint32 quantity)
{
    std::vector<ItemSlot>::iterator i;

    i = std::find_if(m_Items.begin(), m_Items.end(), find_item_slot_by_id(item_id));

    if (i == m_Items.end())
    {
        i = std::find_if(m_Items.begin(), m_Items.end(), find_item_slot_by_id(-1));

        if (i == m_Items.end())
        {
            LOGGER->Log(LOGGER_WARNING, "Player::AddItems: There is no free plase left in items to insert new item. Max items now set to MAX_ITEMS_SLOT.");
        }
        else
        {
            (*i).id        = item_id;
            (*i).quantity  = quantity;
        }
    }
    else
    {
        (*i).quantity += quantity;

        if ((*i).quantity > MAX_ITEM_PER_SLOT)
        {
            (*i).quantity = MAX_ITEM_PER_SLOT;
            LOGGER->Log(LOGGER_WARNING, "Player::AddItems: Try to add more than MAX_ITEM_PER_SLOT items of item with id %d.", item_id);
        }
    }
}



const Uint32
Player::GetItemQuantityById(const Sint32 item_id)
{
    std::vector<ItemSlot>::iterator i;

    i = std::find_if(m_Items.begin(), m_Items.end(), find_item_slot_by_id(item_id));

    if (i == m_Items.end())
    {
        return 0;
    }
    else
    {
        return (*i).quantity;
    }
}



const Uint32
Player::GetItemQuantityBySlot(const Uint32 slot_id) const
{
    if (slot_id > MAX_ITEM_SLOT)
    {
        LOGGER->Log(LOGGER_WARNING, "Player::GetItemQuantityBySlot: Try to get item quantity by slot that exceed max slot number MAX_ITEM_SLOT.");
        return 0;
    }

    return m_Items[slot_id].quantity;
}



const Sint32
Player::GetItemIdBySlot(const Uint32 slot_id) const
{
    if (slot_id > MAX_ITEM_SLOT)
    {
        LOGGER->Log(LOGGER_WARNING, "Player::GetItemIdBySlot: Try to get item id by slot that exceed max slot number MAX_ITEM_SLOT.");
        return -1;
    }

    return m_Items[slot_id].id;
}



void
Player::RemoveItems(const Sint32 item_id, const Uint32 quantity)
{
    std::vector<ItemSlot>::iterator i;

    i = std::find_if(m_Items.begin(), m_Items.end(), find_item_slot_by_id(item_id));

    if (i == m_Items.end())
    {
        LOGGER->Log(LOGGER_WARNING, "Player::RemoveItems: Try to remove unexisted item %d.", item_id);
    }
    else
    {
        if ((*i).quantity < quantity)
        {
            (*i).quantity = 0;
            LOGGER->Log(LOGGER_WARNING, "Player::RemoveItems: Try to remove more items with id %d than current items quantity.", item_id);
        }
        else
        {
            (*i).quantity -= quantity;
        }

        // remove item from slot if there are no such items any more
        if ((*i).quantity == 0)
        {
            (*i).id = -1;
        }
    }
}



void
Player::AddMateria(const Sint32 materia_id, const Sint32 ap)
{
    std::vector<MateriaSlot>::iterator i;

    i = std::find_if(m_Materias.begin(), m_Materias.end(), find_materia_slot_by_id(-1));

    if (i == m_Materias.end())
    {
        LOGGER->Log(LOGGER_WARNING, "Player::AddMateria: There is no free place left in materias to insert new materia. Max materia now set to MAX_MATERIA_SLOT.");
    }
    else
    {
        (*i).id = materia_id;
        (*i).ap = ap;
    }
}



const Sint32
Player::GetMateriaIdBySlot(const Uint32 slot_id) const
{
    if (slot_id > MAX_MATERIA_SLOT)
    {
        LOGGER->Log(LOGGER_WARNING, "Player::GetMateriaIdBySlot: Try to get materia id by slot that exceed max slot number MAX_MATERIA_SLOT.");
        return 0;
    }

    return m_Materias[slot_id].id;
}



const Sint32
Player::GetMateriaApBySlot(const Uint32 slot_id) const
{
    if (slot_id > MAX_MATERIA_SLOT)
    {
        LOGGER->Log(LOGGER_WARNING, "Player::GetMateriaApBySlot: Try to get materia ap by slot that exceed max slot number MAX_MATERIA_SLOT.");
        return 0;
    }

    return m_Materias[slot_id].ap;
}



void
Player::RemoveMateria(const Uint32 slot_id)
{
    if (slot_id > MAX_MATERIA_SLOT)
    {
        LOGGER->Log(LOGGER_WARNING, "Player::RemoveMateria: Try to remove materia from slot that exceed max slot number MAX_MATERIA_SLOT.");
        return;
    }

    m_Materias[slot_id].id = -1;
    m_Materias[slot_id].ap = 0;
}



void
Player::AddMoney(const Uint32 amount)
{
    m_Money += amount;
    m_Money = (m_Money > MAX_MONEY) ? MAX_MONEY : m_Money;
}



const Uint32
Player::GetMoney(void) const
{
    return m_Money;
}



void
Player::RemoveMoney(const Uint32 amount)
{
    m_Money = (m_Money < amount) ? 0 : m_Money - amount;
}
