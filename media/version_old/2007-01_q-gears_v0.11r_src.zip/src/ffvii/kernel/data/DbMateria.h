// $Id: DbMateria.h 98 2006-11-21 21:46:28Z einherjar $

#ifndef DBMATERIA_H
#define DBMATERIA_H

#include "../../../common/TypeDefine.h"

struct DBMateria
{
    u8 Unknown[20];
};

#endif
