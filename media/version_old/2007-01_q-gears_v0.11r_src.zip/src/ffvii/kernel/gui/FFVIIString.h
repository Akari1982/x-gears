// $Id: FFVIIString.h 151 2007-03-04 11:28:52Z super_gb $

#ifndef FFVIISTRING_H
#define FFVIISTRING_H



#include "../../../common/utilites/StdString.h"

#include <vector>



typedef std::vector<unsigned char> FFVIIString;



// converter
FFVIIString RStringToFFVIIString(const RString& string);

RString     FFVIIStringToRString(const FFVIIString& string);



#endif
