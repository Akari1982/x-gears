// $Id: GuiBar.cpp 115 2006-12-15 21:05:15Z crazy_otaku $

#include "GuiBar.h"
#include "../../../common/display/3dTypes.h"
#include "../../../common/display/Display.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/Logger.h"



GuiBar::GuiBar()
{
    // HP line
    float red    = 192.0f/256.0f;
    float green  = 192.0f/256.0f;
    float blue   = 200.0f/256.0f;
    float red2   =   0.0f/256.0f;
    float green2 = 128.0f/256.0f;
    float blue2  = 248.0f/256.0f;

    Vertex point;
    point.p.x = 0.0f;  point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = red2;  point.c.g = green2; point.c.b = blue2; point.c.a = 1.0f;
    point.t.x = 0.0f;  point.t.y = 0.0f;
    mPolyHP.vertexes.push_back(point);
    point.p.x = 60.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = red;   point.c.g = green;  point.c.b = blue;  point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 0.0f;
    mPolyHP.vertexes.push_back(point);
    point.p.x = 60.0f; point.p.y = -1.0f;  point.p.z = 0.0f;
    point.c.r = red;   point.c.g = green;  point.c.b = blue;  point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 1.0f;
    mPolyHP.vertexes.push_back(point);
    point.p.x = 0.0f;  point.p.y = -1.0f;  point.p.z = 0.0f;
    point.c.r = red2;  point.c.g = green2; point.c.b = blue2; point.c.a =  1.0f;
    point.t.x = 0.0f;  point.t.y = 1.0f;
    mPolyHP.vertexes.push_back(point);



    // MP line
    red    = 192.0f/256.0f;
    green  = 200.0f/256.0f;
    blue   = 192.0f/256.0f;
    red2   =   0.0f/256.0f;
    green2 = 248.0f/256.0f;
    blue2  = 128.0f/256.0f;

    point.p.x = 0.0f;  point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = red2;  point.c.g = green2; point.c.b = blue2; point.c.a = 1.0f;
    point.t.x = 0.0f;  point.t.y = 0.0f;
    mPolyMP.vertexes.push_back(point);
    point.p.x = 60.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = red;   point.c.g = green;  point.c.b = blue;  point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 0.0f;
    mPolyMP.vertexes.push_back(point);
    point.p.x = 60.0f; point.p.y = -1.0f;  point.p.z = 0.0f;
    point.c.r = red;   point.c.g = green;  point.c.b = blue;  point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 1.0f;
    mPolyMP.vertexes.push_back(point);
    point.p.x = 0.0f;  point.p.y = -1.0f;  point.p.z = 0.0f;
    point.c.r = red2;  point.c.g = green2; point.c.b = blue2; point.c.a =  1.0f;
    point.t.x = 0.0f;  point.t.y = 1.0f;
    mPolyMP.vertexes.push_back(point);



    // Underline
    red = 40.0f/256.0f;
    point.p.x = 0.0f;  point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r = red;   point.c.g = 0.0f;  point.c.b = 0.0f; point.c.a = 1.0f;
    point.t.x = 0.0f;  point.t.y = 0.0f;
    mPolyUnder.vertexes.push_back(point);
    point.p.x = 60.0f; point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r = red;   point.c.g = 0.0f;  point.c.b = 0.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 0.0f;
    mPolyUnder.vertexes.push_back(point);
    point.p.x = 60.0f; point.p.y = -2.0f; point.p.z = 0.0f;
    point.c.r = red;   point.c.g = 0.0f;  point.c.b = 0.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 1.0f;
    mPolyUnder.vertexes.push_back(point);
    point.p.x = 0.0f;  point.p.y = -2.0f; point.p.z = 0.0f;
    point.c.r = red;   point.c.g = 0.0f;  point.c.b = 0.0f; point.c.a =  1.0f;
    point.t.x = 0.0f;  point.t.y = 1.0f;
    mPolyUnder.vertexes.push_back(point);



    // Back line
    red = 80.0f/256.0f;
    point.p.x = 0.0f;  point.p.y = 0.0f;  point.p.z = 0.0f;
    point.c.r = red;   point.c.g = 0.0f;  point.c.b = 0.0f; point.c.a = 1.0f;
    point.t.x = 0.0f;  point.t.y = 0.0f;
    mPolyBack.vertexes.push_back(point);
    point.p.x = 60.0f; point.p.y = 0.0f;  point.p.z = 0.0f;
    point.c.r = red;   point.c.g = 0.0f;  point.c.b = 0.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 0.0f;
    mPolyBack.vertexes.push_back(point);
    point.p.x = 60.0f; point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r = red;   point.c.g = 0.0f;  point.c.b = 0.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 1.0f;
    mPolyBack.vertexes.push_back(point);
    point.p.x = 0.0f;  point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r = red;   point.c.g = 0.0f;  point.c.b = 0.0f; point.c.a =  1.0f;
    point.t.x = 0.0f;  point.t.y = 1.0f;
    mPolyBack.vertexes.push_back(point);
}



GuiBar::~GuiBar()
{
}



void
GuiBar::DrawBar(const int &x, const int &y, const unsigned int &cur, const unsigned int &max, const BarType &type)
{
    DISPLAY->PushMatrix();
    DISPLAY->Translate(x, -y, 0);
    DISPLAY->DrawQuads(mPolyBack);

    float size = 60.0f * static_cast<float>(cur) / static_cast<float>(max);

    switch (type)
    {
        case HP_BAR:
        {
            mPolyHP.vertexes[1].p.x = size;
            mPolyHP.vertexes[2].p.x = size;
            DISPLAY->DrawQuads(mPolyHP);
            break;
        }
        case MP_BAR:
        {
            mPolyMP.vertexes[1].p.x = size;
            mPolyMP.vertexes[2].p.x = size;
            DISPLAY->DrawQuads(mPolyMP);
            break;
        }
    }

    DISPLAY->DrawQuads(mPolyUnder);
    DISPLAY->PopMatrix();
}
