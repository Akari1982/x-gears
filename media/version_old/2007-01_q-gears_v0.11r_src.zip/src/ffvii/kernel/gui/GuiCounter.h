// $Id: GuiCounter.h 103 2006-11-26 07:19:38Z crazy_otaku $

#ifndef GUICOUNTER_H
#define GUICOUNTER_H



#include "../../../common/display/3dTypes.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/NoCopy.h"
#include "../../../common/utilites/StdString.h"

#include <map>
#include <vector>



class GuiCounter : public NoCopy<GuiCounter>
{
public:
             GuiCounter(Surface* image);

    virtual ~GuiCounter();

    void     DrawCounter(const int &x, const int &y, const RString &string);

private:
    std::map<int, int> mCounterTexId;
    Geometry           mCounterPoly;
};



#endif
