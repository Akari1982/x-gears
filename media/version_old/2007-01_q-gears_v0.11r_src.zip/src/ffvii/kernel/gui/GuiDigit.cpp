// $Id: GuiDigit.cpp 147 2007-02-24 06:13:17Z super_gb $

#include "GuiDigit.h"
#include "../../../common/display/3dTypes.h"
#include "../../../common/display/Display.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/Logger.h"



GuiDigit::GuiDigit(Surface* image)
{
    Surface* temp;

    // 0
    temp = CreateSubSurface(136, 0, 8, 8, image);
    mDigitTexId.insert(std::make_pair(0x30, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 1
    temp = CreateSubSurface(144, 0, 8, 8, image);
    mDigitTexId.insert(std::make_pair(0x31, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 2
    temp = CreateSubSurface(152, 0, 8, 8, image);
    mDigitTexId.insert(std::make_pair(0x32, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 3
    temp = CreateSubSurface(160, 0, 8, 8, image);
    mDigitTexId.insert(std::make_pair(0x33, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 4
    temp = CreateSubSurface(168, 0, 8, 8, image);
    mDigitTexId.insert(std::make_pair(0x34, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 5
    temp = CreateSubSurface(176, 0, 8, 8, image);
    mDigitTexId.insert(std::make_pair(0x35, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 6
    temp = CreateSubSurface(184, 0, 8, 8, image);
    mDigitTexId.insert(std::make_pair(0x36, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 7
    temp = CreateSubSurface(192, 0, 8, 8, image);
    mDigitTexId.insert(std::make_pair(0x37, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 8
    temp = CreateSubSurface(200, 0, 8, 8, image);
    mDigitTexId.insert(std::make_pair(0x38, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 9
    temp = CreateSubSurface(208, 0, 8, 8, image);
    mDigitTexId.insert(std::make_pair(0x39, DISPLAY->CreateTexture(temp)));
    delete temp;



    Vertex point;
    point.p.x = 0.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f; point.t.y = 0.0f;
    mDigitPoly.vertexes.push_back(point);
    point.p.x = 8.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f; point.t.y = 0.0f;
    mDigitPoly.vertexes.push_back(point);
    point.p.x = 8.0f; point.p.y = -8.0f; point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f; point.t.y = 1.0f;
    mDigitPoly.vertexes.push_back(point);
    point.p.x = 0.0f; point.p.y = -8.0f; point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a =  1.0f;
    point.t.x = 0.0f; point.t.y = 1.0f;
    mDigitPoly.vertexes.push_back(point);
}



GuiDigit::~GuiDigit()
{
    std::map<int, int>::iterator i;

    for (i = mDigitTexId.begin(); i != mDigitTexId.end(); ++i)
    {
        DISPLAY->DeleteTexture((*i).second);
    }
}



void
GuiDigit::DrawDigit(const int &x, const int &y, const RString &string)
{
    DISPLAY->PushMatrix();
    DISPLAY->Translate(x, -y, 0);

    for (int i = 0; i < string.size(); ++i)
    {
        std::map<int, int>::const_iterator tile = mDigitTexId.find(static_cast<int>(string[i]));

        if (tile == mDigitTexId.end())
        {
            LOGGER->Log(LOGGER_WARNING, "Unidentify digit type %02x.",
				string[i]);
        }
        else
        {
            DISPLAY->SetTexture((*tile).second);
            DISPLAY->DrawQuads(mDigitPoly);
            DISPLAY->UnsetTexture();

            DISPLAY->Translate(7.0f, 0, 0);
        }
    }

    DISPLAY->PopMatrix();
}
