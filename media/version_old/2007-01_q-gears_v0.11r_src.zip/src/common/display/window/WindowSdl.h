// $Id: WindowSdl.h 93 2006-11-12 13:49:02Z einherjar $

#ifndef WINDOWSDL_H
#define WINDOWSDL_H
// The WindowSDL Class : Implementation of window



#include "Window.h"



class WindowSDL : public Window
{
public:
    ~WindowSDL();

    static Window* MakeWindow();

    void SwapBuffers();

private:
    WindowSDL();
};



#endif // WINDOWSDL_H
