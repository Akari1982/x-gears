// $Id: Splash.h 135 2007-02-06 05:21:01Z halkun $

/**
 * @brief Start splash screen module.
 */

#ifndef SPLASH_h
#define SPLASH_h

#include "../TypeDefine.h"
#include "../display/3dTypes.h"
#include "../display/actor/Actor.h"

#include <vector>



class Splash : public Actor
{
public:
// LIFECYCLE

    /**
     * @brief Default constructor.
     */
    Splash(void);

    /**
     * @brief Default destructor.
     */
    virtual ~Splash(void);

// OPERATIONS

    /**
     * @brief Init module.
     */
    virtual void Init(void);

    /**
     * @brief Draw module.
     */
    virtual void Draw(void) const;

    /**
     * @brief Handles input.
     *
     * @param input - single input event.
     */
    virtual void Input(const InputEvent& input);

    /**
     * @brief Handles update.
     *
     * @param deltaTime - time passed from last call.
     */
    virtual void Update(const Uint32 deltaTime);

private:
    u32      mTexId;    /**< @brief id of splash texture. */

    Geometry mQuadsTex; /**< @brief vertex for quad to draw splash texture. */
};



#endif // SPLASH_h
