// $Id: WalkMeshFile.cpp 97 2006-11-19 22:25:49Z einherjar $

#include "WalkMeshFile.h"
#include "../../common/utilites/Logger.h"

#include <vector>



WalkMeshFile::WalkMeshFile(const RString &file):
    File(file)
{
}



WalkMeshFile::WalkMeshFile(File *file, const u32 &offset, const u32 &length):
    File(file, offset, length)
{
}



WalkMeshFile::WalkMeshFile(u8* buffer, const u32 &offset, const u32 &length):
    File(buffer, offset, length)
{
}



WalkMeshFile::WalkMeshFile(File *file):
    File(file)
{
}



WalkMeshFile::~WalkMeshFile()
{
}



void
WalkMeshFile::GetWalkMesh(UnitManager* unitManager)
{
    // numbers of subblock
    u32 block_count = GetU32LE(0);
    u32 start = 0x04;

    WalkMeshTriangle triangle;

    for (u32 i = 0; i < 1 /*block_count*/; ++i)
    {
        u32 block_size   = GetU32LE(start + i * 0x04);
        u32 block_start  = GetU32LE(start + 0x14 + i * 0x08);
        u32 block_vertex = GetU32LE(start + 0x14 + i * 0x08 + 0x04);

        for (u32 j = 0; j < block_size;)
        {
            u16 a_offset = block_vertex + (GetU16LE(block_start + j + 0x00) * 0x08);
            triangle.A.x =  static_cast<s16>(GetU16LE(0x00 + a_offset));
            triangle.A.y = -static_cast<s16>(GetU16LE(0x02 + a_offset));
            triangle.A.z = -static_cast<s16>(GetU16LE(0x04 + a_offset));

            u16 b_offset = block_vertex + (GetU16LE(block_start + j + 0x02) * 0x08);
            triangle.B.x =  static_cast<s16>(GetU16LE(0x00 + b_offset));
            triangle.B.y = -static_cast<s16>(GetU16LE(0x02 + b_offset));
            triangle.B.z = -static_cast<s16>(GetU16LE(0x04 + b_offset));

            u16 c_offset = block_vertex + (GetU16LE(block_start + j + 0x04) * 0x08);
            triangle.C.x =  static_cast<s16>(GetU16LE(0x00 + c_offset));
            triangle.C.y = -static_cast<s16>(GetU16LE(0x02 + c_offset));
            triangle.C.z = -static_cast<s16>(GetU16LE(0x04 + c_offset));

            triangle.access[0] = GetU16LE(block_start + j + 0x06);
            triangle.access[1] = GetU16LE(block_start + j + 0x08);
            triangle.access[2] = GetU16LE(block_start + j + 0x0A);

            unitManager->AddWalkMeshTriangle(triangle);

            j += 0x0E;
        }
    }
}
