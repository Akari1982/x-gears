// $Id: FieldModule.h 96 2006-11-13 03:34:17Z crazy_otaku $

#ifndef FIELD_MODULE_h
#define FIELD_MODULE_h

#include <string>
#include <vector>

#include "../../common/module/Module.h"
#include "../../common/display/3dTypes.h"

#include "UnitManager.h"



class FieldModule : public Module
{
public:
    FieldModule();
    virtual ~FieldModule();

    virtual void Init();
    virtual void Input(const InputEvent &input);
    virtual void Update(const u32& delta_time);
    virtual void Draw();

private:
    void LoadMap(const u16& id);

private:
    std::vector<Vertex>     mAxis;

    // engine managing
    bool                    mViewAxis;

    // map related
    UnitManager*            mpUnitManager;
};



#endif // FIELD_MODULE_h
