// $Id: GameFileSystem.h 103 2006-11-26 07:19:38Z crazy_otaku $

#ifndef GAMEFILESYSTEM_H
#define GAMEFILESYSTEM_H

#include <vector>

#include "../../common/filesystem/FileSystem.h"
#include "../../common/filesystem/driver/RealFileDriver.h"
#include "../../common/utilites/StdString.h"

#ifdef HAVE_LINUX_CDXA_DRIVER
# include "../../common/filesystem/driver/LinuxCDXAFileDriver.h"
#endif



class GameFileSystem : public FileSystem
{
public:
                         GameFileSystem();
    virtual             ~GameFileSystem();

    virtual unsigned int GetFileSize(const RString &path);
    virtual bool         ReadFile(const RString &path, void* buffer, const unsigned int start, const unsigned int length);

private:
    RealFileDriver mFileDriver;
    // LinuxCDXAFileDriver mFileDriver;
};



extern GameFileSystem* GAMEFILESYSTEM;



#endif // GAMEFILESYSTEM_H
