// $Id: WorldMapModule.cpp 93 2006-11-12 13:49:02Z einherjar $

#include "WorldMapModule.h"
#include "../kernel/Kernel.h"

#include "../../common/display/Display.h"
#include "../../common/utilites/Logger.h"



WorldMapModule::WorldMapModule(void)
{
    Init();
}



WorldMapModule::~WorldMapModule(void)
{
}



void
WorldMapModule::Init()
{
}



void
WorldMapModule::Input(const InputEvent& input)
{
}



void
WorldMapModule::Update(const u32& deltaTime)
{
}



void
WorldMapModule::Draw(void)
{
  KERNEL->DrawString(RStringToFFVIIString("Placeholder for WorldMap module.\nJust as Halkun want ^_^"), 300, 100, F_WHITE);
}
