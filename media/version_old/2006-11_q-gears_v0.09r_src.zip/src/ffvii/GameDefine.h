// $Id: GameDefine.h 103 2006-11-26 07:19:38Z crazy_otaku $

#ifndef GAME_DEFINE_H
#define GAME_DEFINE_H



#define APPLICATION_NAME "FFVII v0.09"



#endif // GAME_DEFINE_H
