// $Id: ScriptManager.cpp 94 2006-11-12 19:44:43Z crazy_otaku $

#include "Entity.h"
#include "ScriptManager.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

ScriptManager::ScriptManager(FieldModule* pFieldModule):
    mpFieldModule(pFieldModule)
{
}



ScriptManager::~ScriptManager(void)
{
    Clear();
}



//============================= OPERATIONS ===================================

void
ScriptManager::Clear(void)
{
    for (int i = 0; i < mEntities.size(); ++i)
    {
        delete mEntities[i];
    }
    mEntities.clear();

    // clear current script
    Entity::DeleteScript();
}



void
ScriptManager::Run()
{
    for (int i = 0; i < mEntities.size(); ++i)
    {
        mEntities[i]->Run(mpFieldModule);
    }
}



void
ScriptManager::RequestRun(const u8& entityId, const u8& priority, const u8& scriptId)
{
    mEntities[entityId]->RequestRun(priority, scriptId);
}



void
ScriptManager::RequestRunUnit(const s8& unitId, const u8& priority, const u8& scriptId)
{
    for (u8 i = 0; i < mEntities.size(); ++i)
    {
        if (mEntities[i]->GetUnitId() == unitId)
        {
            mEntities[i]->RequestRun(priority, scriptId);
            break;
        }
    }
}



void
ScriptManager::PushEntity(Entity* pEntity)
{
    mEntities.push_back(pEntity);
}
