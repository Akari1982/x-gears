// $Id: Entity.cpp 94 2006-11-12 19:44:43Z crazy_otaku $

#include "Entity.h"

#include <cassert>

#include "../../../common/utilites/Logger.h"



Script* Entity::mScript(NULL);



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

Entity::Entity(void):
    mInited(false),

    mWait(false),
    mFramesToWait(0),

    mUnitId(-1)
{
    // initialize queue
    for (int i = 0; i < 8; ++i)
    {
        // -1 means no script
        mScriptQueue[i].id       = -1;
        mScriptQueue[i].position = 0;
    }

    // init and base scripts are always in priority 8
    mScriptQueue[7].id       = 0;
    mScriptQueue[7].position = 0;
}



Entity::~Entity(void)
{
}



//============================= OPERATIONS ===================================

void
Entity::Init(FieldModule* fieldModule)
{
    // must be run once... not with sync effects
    mScript->Run(fieldModule, this, mEntryPoints[0]);
    mInited = true;
    mScriptQueue[7].position = mEntryPoints[0];
}



void
Entity::SetScript(Script* script)
{
    mScript = script;
}



void
Entity::DeleteScript(void)
{
    if (mScript != NULL)
    {
        delete mScript;
    }
    mScript = NULL;
}



void
Entity::Run(FieldModule* fieldModule)
{
    // if we not inited
    if (mInited == false)
    {
        Init(fieldModule);
    }

    // if we syncronize with something
    if (IsWait() == true || mFramesToWait > 0)
    {
        if (mFramesToWait > 0)
        {
            --mFramesToWait;
        }

        return;
    }



    for (int i = 0; i < 8; ++i)
    {
        if (mScriptQueue[i].id != -1)
        {
            bool finish = mScript->Run(fieldModule, this, mScriptQueue[i].position);

            // if script finished it work
            if (finish)
            {
                if (i == 7)
                {
                    // if we run base script
                    mScriptQueue[i].position = mEntryPoints[0];
                }
                else
                {
                    mScriptQueue[i].id       = -1;
                    mScriptQueue[i].position = 0;
                }
            }

            break;
        }
    }
}



void
Entity::RequestRun(const u8& priority, const u8& scriptId)
{
    if (mScriptQueue[priority].id == -1)
    {
        mScriptQueue[priority].id       = scriptId;
        mScriptQueue[priority].position = mEntryPoints[scriptId];
    }
}



void
Entity::SetEntryPoint(const u8& id, const u32& entryPoint)
{
    assert(id < 32);

    mEntryPoints[id] = entryPoint;
}



//============================= ACCESS     ===================================

void
Entity::SetName(const RString& name)
{
    mName = name;
}



void
Entity::SetUnitId(const s8& id)
{
    mUnitId = id;
}



const s8&
Entity::GetUnitId(void)
{
    return mUnitId;
}



bool
Entity::IsWait(void) const
{
    return mWait;
}



void
Entity::SetWait(const bool& wait)
{
    mWait = wait;
}



void
Entity::SetFramesToWait(const u16& wait)
{
    mFramesToWait = wait;
}
