// $Id: FieldModule.cpp 103 2006-11-26 07:19:38Z crazy_otaku $

#include <libxml/tree.h>

#include "../../common/display/Display.h"
#include "../../common/module/ModuleManager.h"
#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "DatFile.h"
#include "DatXmlFile.h"
#include "FieldModule.h"
#include "FieldUtilites.h"
#include "script/Entity.h"
#include "script/Script.h"
#include "../battle/BattleModule.h"
#include "../kernel/Kernel.h"
#include "../menu/PartyMenu.h"



FieldModule::FieldModule():
    mRequestMapId(0),
    mRequestLoadMap(false),

    mViewAxis(true),
    mViewFromCamera(true),
    mViewDebugInfo(true),

    mFadeAlpha(0),
    mFadeSpeed(0),
    mFadeIn(false),
    mFadeCaller(NULL),

    // dangerous
    // we musn't use FieldModule pointer until it compleatly constructed
    mScriptManager(this),
    mUnitManager(this),
    mWindowManager(this),
    mBackgroundManager(this)
{
    Init();
}



FieldModule::~FieldModule()
{
}



void
FieldModule::Init()
{
    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
    DISPLAY->SetAlphaTest(true);
    DISPLAY->SetBlendMode(BLEND_PSX_0);
    DISPLAY->SetCullMode(CULL_NONE);

    Vertex point;
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 0.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 500.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 0.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 1.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 500.0f; point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 1.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 0.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 500.0f;
    point.c.r = 0.0f;   point.c.g = 0.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    mAxis.push_back(point);



    // load map from savemap
    LoadMap(KERNEL->GetGamestate().CurrentFieldGet());
}



void
FieldModule::LoadMap(const u16& id)
{
    // check if this is field file (not worldmap)
    if (id < 0x41)
    {
        LOGGER->Log("Tried to load worldmap with mapId = %04x.", id);
        return;
    }

    // remember current map
    KERNEL->GetGamestate().CurrentFieldSet(id);

    // clear all managers
    mBackgroundManager.Clear();
    mScriptManager.Clear();
    mUnitManager.Clear();
    mWindowManager.Clear();



    // load DAT file
    DatFile dat("data/FIELD/" + MapIdToRString(id) + ".DAT");
//    dat.WriteFile(MapIdToRString(id) + "_u.DAT");



    // try load xml file
    DatXmlFile xml_file("data/FIELD/" + MapIdToRString(id) + ".xml");



    LOGGER->Log("Load field %s", dat.GetFileName().c_str());



    // load dialogs
    if (xml_file.GetDialogs(&mWindowManager) != 0)
    {
        LOGGER->Log("Load dialogs from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log("Load entity from FieldFile.");
        dat.GetDialogs(&mWindowManager);
    }



    // load entity info
    if (xml_file.GetScripts(&mScriptManager) != 0)
    {
        LOGGER->Log("Load entitys from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log("Load entitys from FieldFile.");
        dat.GetScripts(&mScriptManager);
    }



    LOGGER->Log("Loading background image.");
    mBackgroundManager.LoadBackground("data/FIELD/" + MapIdToRString(id) + ".MIM");
    LOGGER->Log("Loading of background image has been complete.");
    LOGGER->Log("Loading background info from FieldFile.");
    dat.GetBackground(&mBackgroundManager);
    mBackgroundManager.UnloadBackground();



    // load walkmesh info
    if (xml_file.GetWalkMesh(&mUnitManager) != 0)
    {
        LOGGER->Log("Load walkmesh from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log("Loading walkmesh from FieldFile.");
        dat.GetWalkMesh(&mUnitManager);
    }



    // load gateways info
    if (xml_file.GetGateway(&mUnitManager) != 0)
    {
        LOGGER->Log("Load gateways from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log("Loading gateways from FieldFile.");
        dat.GetGateway(&mUnitManager);
    }



    // load encounters info
    if (xml_file.GetEncounter(&mUnitManager) != 0)
    {
        LOGGER->Log("Load encounters from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log("Loading encounter from FieldFile.");
        dat.GetEncounter(&mUnitManager);
    }



    // load camera matrix
    LOGGER->Log("Loading camera matrix from FieldFile.");
    dat.GetCameraMatrix(mMatrix);



    // we dont know how set scale yet
    mScale = 1.0f;



    // start fadeout
    mFadeColor.r = 0;
    mFadeColor.g = 0;
    mFadeColor.b = 0;
    mFadeAlpha = 255;
    mFadeSpeed = 5;
    mFadeIn    = false;



    DropAllInput();
}



void
FieldModule::RequestLoadMap(const u16& id)
{
    mRequestMapId = id;
    mRequestLoadMap = true;

    // start fade in
    mFadeColor.r = 0;
    mFadeColor.g = 0;
    mFadeColor.b = 0;
    mFadeAlpha = 0;
    mFadeSpeed = 5;
    mFadeIn    = true;
}



void
FieldModule::LoadBattle(const u16& id)
{
    MODULEMAN->PopTopModule();
    BattleModule* module = new BattleModule();
    module->LoadBattle(id);
    MODULEMAN->PushModule(module);
}



void
FieldModule::DropAllInput(void)
{
    mUnitManager.DropInput();
}



void
FieldModule::Fade(const u8& speed, const u8& start, const Color& color, const u8& type, Entity* caller)
{
    mFadeCaller = caller;



    if (type == 3)
    {
        mFadeAlpha = 0;
    }
    else if (type == 4)
    {
        mFadeColor.r = 0;
        mFadeColor.g = 0;
        mFadeColor.b = 0;
        mFadeAlpha = 255;
    }
    else if (type == 5)
    {
        mFadeAlpha = start;
        mFadeColor = color;
        mFadeSpeed = speed;
        mFadeIn = false;
    }
    else if (type == 6)
    {
        mFadeAlpha = start;
        mFadeColor = color;
        mFadeSpeed = speed;
        mFadeIn = true;
    }
}



void
FieldModule::Input(const InputEvent &input)
{
    // handle system input ourself
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_Co:    mScale += 0.01f;                                    break;
            case KEY_Cp:    mScale -= 0.01f;                                    break;

            case KEY_Ck:    mViewFromCamera = (mViewFromCamera) ? false : true; break;
            case KEY_Cl:    mViewAxis       = (mViewAxis)       ? false : true; break;
            case KEY_Cd:    mViewDebugInfo  = (mViewDebugInfo)  ? false : true; break;
        }
    }



    // give input to everything only if we not load next map.
    // we must stop all process in this case
    if (mRequestLoadMap != true)
    {
        // give input to background (for debug)
        if (mBackgroundManager.Input(input) == true)
        {
            // if we handled input - return
            return;
        }



        // give input to all opened windows
        if (mWindowManager.Input(input) == true)
        {
            // if we handled input - return
            return;
        }



        // give input to all unit on map
        if (mUnitManager.Input(input) == true)
        {
            // if we handled input - return
            return;
        }



        // handle other game input
        if (input.type == IET_FIRST_PRESS)
        {
            switch (input.button)
            {
                case KEY_Cs:
                {
                    PartyMenu* module = new PartyMenu();
                    MODULEMAN->PushModule(module);
                    break;
                }

                case KEY_Cb:
                {
                    LoadBattle(999);
                    break;
                }
            }
        }
    }
}



void
FieldModule::Update(const u32& delta_time)
{
    if (mRequestLoadMap == true && mFadeAlpha == 255)
    {
        LoadMap(mRequestMapId);

        mRequestLoadMap = false;
    }



    // update fade after request load map check
    // because we want to draw fully fade screen before map loading
    if (mFadeIn == true)
    {
        mFadeAlpha = ((mFadeAlpha + mFadeSpeed) > 255) ? 255 : mFadeAlpha + mFadeSpeed;
    }
    else
    {
        mFadeAlpha = ((mFadeAlpha - mFadeSpeed) < 0) ? 0 : mFadeAlpha - mFadeSpeed;
    }

    if ((mFadeAlpha == 0 || mFadeAlpha == 255) && mFadeCaller != NULL)
    {
        mFadeCaller->SetWait(false);
        mFadeCaller = NULL;
    }



    // update everything only if we not load next map.
    // we must stop all process in this case
    if (mRequestLoadMap != true)
    {
        // run script
        mScriptManager.Run();



        // update all opened windows
        mWindowManager.Update(delta_time);



        // update all units on map
        mUnitManager.Update(delta_time);



        // update background
        mBackgroundManager.Update(delta_time);
    }
}



void
FieldModule::DrawPosibleActions(void) const
{
    KERNEL->DrawString(RStringToFFVIIString("Press '1' to show/hide 1st layer"),       350, 340, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press '2' to show/hide 2nd layer"),       350, 355, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press '3' to show/hide alpha"),           350, 370, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press '4' to show/hide walkmesh"),        350, 385, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press '5' to show/hide unit collision"),  350, 400, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'D' to show/hide debug info"),      350, 415, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'O'/'P' to scale walkmesh"),        350, 430, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'K' to swich to/from camera view"), 350, 445, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'L' to show/hide axis"),            350, 460, F_WHITE);
}



void
FieldModule::Draw()
{
    // draw background;
    mBackgroundManager.Draw();



    DISPLAY->CameraPushMatrix();

    // set camera
    if (mViewFromCamera == true)
    {
        DISPLAY->LoadCameraMatrix(mMatrix);
    }
    else
    {
        DISPLAY->LoadLookAt(50, Vector3(-500, 200, 900), Vector3(0, 0, 0), Vector3(0, 1, 0));
    }

    // draw axis
    if (mViewAxis == true)
    {
        DISPLAY->SetPointSize(3);
        DISPLAY->DrawPoints(mAxis);
        DISPLAY->SetLineWidth(1);
        DISPLAY->DrawLines(mAxis);
    }

    // draw all units on map
    DISPLAY->PushMatrix();
    DISPLAY->Scale(mScale, mScale, mScale);
    mUnitManager.Draw();
    DISPLAY->PopMatrix();

    DISPLAY->CameraPopMatrix();



    // draw all opened windows
    mWindowManager.Draw();



    DrawPosibleActions();
    if (mViewDebugInfo == true)
    {
        mBackgroundManager.DrawDebugInfo();
        mUnitManager.DrawDebugInfo();
        mWindowManager.DrawDebugInfo();
    }



    mFadeColor.a = mFadeAlpha / 255.0f;
    KERNEL->DrawColorOverlay(mFadeColor);
}

