// $Id: UnitManager.h 103 2006-11-26 07:19:38Z crazy_otaku $

#ifndef UNIT_MANAGER_h
#define UNIT_MANAGER_h

#include <vector>
#include <ode/ode.h>

#include "../../common/TypeDefine.h"
#include "../../common/input/InputFilter.h"
#include "../../common/utilites/NoCopy.h"

#include "Model.h"
#include "Gateway.h"

class FieldModule;



struct EncounterTable
{
    EncounterTable(void):
        enabled(0),
        rate(0)
    {
        for (u8 i = 0; i < 6; ++i)
        {
            standart_encounter[i].rate  = 0;
            standart_encounter[i].scene = 0;
        }

        for (u8 i = 0; i < 4; ++i)
        {
            special_encounter[i].rate  = 0;
            special_encounter[i].scene = 0;
        }
    }

    struct Encounter
    {
        u8  rate;
        u16 scene;
    };

    bool      enabled;
    u8        rate;

    Encounter standart_encounter[6];
    Encounter special_encounter[4];
};



struct WalkMeshTriangle
{
    WalkMeshTriangle(void):
        accessible(true)
    {
    }

    Vector3 A;
    Vector3 B;
    Vector3 C;

    u16    access[3];
    bool   accessible;
};



struct UnitData
{
    UnitData():
        position(0.0f, 0.0f, 0.0f),
        triangle(0),
        position_set(false),
        solid(false),
        visible(false),
        talkable(false),
        direction(0),

        pc(false),
        pc_id(0)
    {
    }

    Model*       model;
    dGeomID      collision;
    dGeomID      collision_talk;
    bool         solid;
    bool         visible;
    bool         talkable;      // we can talk with unit (seted and unseted in collision check). Used only first true talkable in stack

    Vector3      position;
    u16          triangle;
    bool         position_set;
    u8           direction;

    bool         pc;
    u8           pc_id;
};



class UnitManager : public NoCopy<UnitManager>
{
public:
    explicit UnitManager(FieldModule* pFieldModule);
    virtual ~UnitManager(void);

    void     Clear(void);
    void     Draw(void) const;
    void     DrawDebugInfo(void) const;
    bool     Input(const InputEvent& input);
    void     Update(const u32& deltaTime);

    void     AddWalkMeshTriangle(const WalkMeshTriangle& triangle);
    void     AddGateway(const Vector3& point1, const Vector3& point2, const Vector3& position, const u16& mapId);
    void     AddEncounterTable(const EncounterTable& encounterTable);

    void     DropInput(void);

    const s8 AddChar(const u8& characterId);
    void     SetPC(const s8& unitId, const u8& playableId);
    void     SetPositionByXYZTriangle(const s8& unitId, const Vector3& coords, const u16& triangleIndex);
    void     SetPositionByXZ(const s8& unitId, const Vector3& coords);
    void     SetPosition(const s8& unitId);
    void     SetDirection(const s8& unitId, const u8& direction);

    void     SetTriangleAccess(const u16& triangleId, const u8& lock);
    void     SetEncounterTable(const u8& encounter_table);
    void     DisableEncounter(const bool& disable);

private:
    bool     SetNextStep(const Vector3& moveVector, const bool slide);
    void     CheckTriggers(const s8& unitId);
    void     CheckEncounters(void);

private:
    FieldModule*                  mpFieldModule;  /**< @brief feed back to field module */



    // move managing
    bool                          mMoveForward;
    bool                          mMoveBack;
    bool                          mMoveLeft;
    bool                          mMoveRight;



    std::vector<WalkMeshTriangle> mWalkMesh;
    std::vector<Gateway*>         mGateways;



    // units
    std::vector<UnitData>         mUnits;         /**< @brief array of units */
    u8                            mPC;            /**< @brief playable chatacter id */


    // collision detection
    dSpaceID                      mSpace;



    // encounters
    std::vector<EncounterTable>   mEncounters;
    bool                          mEncounterDisabled;
    u32                           mDangerCounter;


    // debug
    bool                          mDisplayCollisions;
    bool                          mDisplayWalkmesh;
};



#endif // UNIT_MANAGER_h
