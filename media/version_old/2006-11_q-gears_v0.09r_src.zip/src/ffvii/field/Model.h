// $Id: Model.h 94 2006-11-12 19:44:43Z crazy_otaku $

#ifndef MODEL_h
#define MODEL_h

#include "../../common/display/3dTypes.h"
#include "../../common/utilites/NoCopy.h"



class Model : public NoCopy<Model>
{
public:
    Model(void);

    virtual ~Model(void);

    void Draw(void);

private:
    std::vector<Vertex> mDirectionLine;
};



#endif // MODEL_h
