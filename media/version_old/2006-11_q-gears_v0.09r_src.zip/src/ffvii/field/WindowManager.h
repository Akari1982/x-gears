// $Id: WindowManager.h 103 2006-11-26 07:19:38Z crazy_otaku $

#ifndef WINDOW_MANAGER_h
#define WINDOW_MANAGER_h

#include <vector>

#include "script/Entity.h"
#include "../kernel/gui/FFVIIString.h"
#include "../../common/TypeDefine.h"
#include "../../common/input/InputFilter.h"
#include "../../common/utilites/NoCopy.h"

class FieldModule;



struct DialogWindowData
{
    bool              show;

    bool              inited;
    u8                init_state;

    u16               x;
    u16               y;
    u16               width;
    u16               height;
    u8                style;
    u8                cbc;

    struct SpecialData
    {
        u16     x;
        u16     y;
        u8      type;

        // for numerical display
        u32     digit;
        u8      digit_number;
    } special;

    struct MessageDialogData
    {
        u8      memory_bank;
        u8      offset;
        u8      dialog_id;
        u8      first;
        u8      last;
        Entity* caller;
    } message;
};



class WindowManager : public NoCopy<WindowManager>
{
public:
    explicit WindowManager(FieldModule* pFieldModule);
    virtual ~WindowManager(void);

    void     Init(void);

    void     Clear(void);
    void     Draw(void) const;
    void     DrawDebugInfo(void) const;
    bool     Input(const InputEvent& input);
    void     Update(const u32& deltaTime);

    void     SetMapName(const s8& dialogId);
    void     SetWindow(const u8& id, const u16& x, const u16& y, const u16& width, const u16& height);
    void     ResetWindow(const u8& id);
    void     SetWindowStyle(const u8& id, const u8& style, const u8& cbc);
    void     SetSpecialStyle(const u8& id, const u8& x, const u8& y, const u8& type);
    void     SetSpecialNumber(const u8& id, const u32& digit, const u8& digitNumber);
    void     ShowMessage(const u8& id, const s8& dialogId, const u8& first, const u8& last, const u8& memoryBank, const u8& offset, Entity* entity);
    void     CloseWindow(const u8& id);
    void     AddDialog(const FFVIIString& dialog);

private:
    FieldModule*                   mpFieldModule; /**< @brief feed back to field module         */

    DialogWindowData               mWindows[8];   /**< @brief array of windows                  */

    std::vector<FFVIIString>       mDialogs;      /**< @brief vector of dialogs                 */

    u8                             mPointerPos;   /**< @brief current pointer position          */
};



#endif // WINDOW_MANAGER_h
