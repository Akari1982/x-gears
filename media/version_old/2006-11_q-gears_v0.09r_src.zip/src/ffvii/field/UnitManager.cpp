// $Id: UnitManager.cpp 103 2006-11-26 07:19:38Z crazy_otaku $

#include "../../common/display/Display.h"
#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "FieldModule.h"
#include "Math.h"
#include "UnitManager.h"
#include "../kernel/Kernel.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

UnitManager::UnitManager(FieldModule* pFieldModule):
    mpFieldModule(pFieldModule),

    mMoveForward(false),
    mMoveBack(false),
    mMoveLeft(false),
    mMoveRight(false),

    mEncounterDisabled(false),
    mDangerCounter(0),

    mDisplayCollisions(true),
    mDisplayWalkmesh(true)
{
    mSpace = dSimpleSpaceCreate(0);
}



UnitManager::~UnitManager(void)
{
    Clear();

    dSpaceDestroy(mSpace);
}



//============================= OPERATIONS ===================================

void
UnitManager::Clear(void)
{
    // clear character
    for (u8 i = 0; i < mUnits.size(); ++i)
    {
        delete mUnits[i].model;
    }
    mUnits.clear();



    mWalkMesh.clear();



    mEncounters.clear();
    mEncounterDisabled = false;



    for (u8 i = 0; i < mGateways.size(); ++i)
    {
        delete mGateways[i];
    }
    mGateways.clear();



    // clear ode space (collision)
    dSpaceDestroy(mSpace);
    mSpace = dSimpleSpaceCreate(0);
}



void
UnitManager::Draw(void) const
{
    if (mDisplayWalkmesh == true)
    {
        std::vector<Vertex> line;
        line.resize(2);

        Vertex v;
        Color color_grant(217.0f / 255.0f, 217.0f / 255.0f, 217.0f / 255.0f, 1.0f);
        Color color_deny(191.0f / 255.0f, 0.0f, 0.0f, 1.0f);
        Color color_point(0.0f, 0.0f, 217.0f / 255.0f, 1.0f);

        DISPLAY->SetPolygonMode(POLYGON_LINE);
        DISPLAY->SetLineWidth(1);
        DISPLAY->SetPointSize(3);

        for (u8 i = 0; i < mWalkMesh.size(); ++i)
        {
            // if this triangle is accessible
            // if we allowed to cross border
            // and if triangle to which we can cross is allowed
            v.c = (mWalkMesh[i].accessible == true && mWalkMesh[i].access[0] != 0xFFFF && mWalkMesh[mWalkMesh[i].access[0]].accessible == true) ? color_grant : color_deny;
            v.p.x = mWalkMesh[i].A.x; v.p.y = mWalkMesh[i].A.y; v.p.z = mWalkMesh[i].A.z;
            line[0] = v;
            v.p.x = mWalkMesh[i].B.x; v.p.y = mWalkMesh[i].B.y; v.p.z = mWalkMesh[i].B.z;
            line[1] = v;
            DISPLAY->DrawLines(line);
            line[0].c = color_point;
            line[1].c = color_point;
            DISPLAY->DrawPoints(line);

            v.c = (mWalkMesh[i].accessible == true && mWalkMesh[i].access[1] != 0xFFFF && mWalkMesh[mWalkMesh[i].access[1]].accessible == true) ? color_grant : color_deny;
            v.p.x = mWalkMesh[i].B.x; v.p.y = mWalkMesh[i].B.y; v.p.z = mWalkMesh[i].B.z;
            line[0] = v;
            v.p.x = mWalkMesh[i].C.x; v.p.y = mWalkMesh[i].C.y; v.p.z = mWalkMesh[i].C.z;
            line[1] = v;
            DISPLAY->DrawLines(line);
            line[0].c = color_point;
            line[1].c = color_point;
            DISPLAY->DrawPoints(line);

            v.c = (mWalkMesh[i].accessible == true && mWalkMesh[i].access[2] != 0xFFFF && mWalkMesh[mWalkMesh[i].access[2]].accessible == true) ? color_grant : color_deny;
            v.p.x = mWalkMesh[i].A.x; v.p.y = mWalkMesh[i].A.y; v.p.z = mWalkMesh[i].A.z;
            line[0] = v;
            v.p.x = mWalkMesh[i].C.x; v.p.y = mWalkMesh[i].C.y; v.p.z = mWalkMesh[i].C.z;
            line[1] = v;
            DISPLAY->DrawLines(line);
            line[0].c = color_point;
            line[1].c = color_point;
            DISPLAY->DrawPoints(line);
        }

        DISPLAY->SetPolygonMode(POLYGON_FILL);
    }



    // draw character
    for (u8 i = 0; i < mUnits.size(); ++i)
    {
        if (mUnits[i].visible == true && mDisplayCollisions == true)
        {
            DISPLAY->PushMatrix();
            DISPLAY->Translate(mUnits[i].position.x, mUnits[i].position.y, mUnits[i].position.z);
            DISPLAY->RotateY(360 * mUnits[i].direction / 255);
            mUnits[i].model->Draw();
            DISPLAY->PopMatrix();

            const dReal* pos = dGeomGetPosition(mUnits[i].collision);
            const dReal* rot = dGeomGetRotation(mUnits[i].collision);
            dVector3 sides;
            dGeomBoxGetLengths(mUnits[i].collision, sides);

            DISPLAY->PushMatrix();
            Matrix matrix(rot[0], rot[4], rot[8], 0, rot[1], rot[5], rot[9], 0, rot[2], rot[6], rot[10], 0, pos[0], pos[1], pos[2], 1);
            DISPLAY->PreMultMatrix(matrix);

            Geometry quads;
            quads.vertexes.resize(16);

            Vertex v;
            Color color(0.0f, 1.0f, 1.0f, 1.0f);
            v.c = color;

            DISPLAY->SetPolygonMode(POLYGON_LINE);
            DISPLAY->SetLineWidth(1);

            float lx = sides[0] / 2.0f;
            float ly = sides[1] / 2.0f;
            float lz = sides[2] / 2.0f;

            v.p.x =  lx; v.p.y =  ly; v.p.z =  lz; quads.vertexes[ 0] = v;
            v.p.x =  lx; v.p.y =  ly; v.p.z = -lz; quads.vertexes[ 1] = v;
            v.p.x =  lx; v.p.y = -ly; v.p.z = -lz; quads.vertexes[ 2] = v;
            v.p.x =  lx; v.p.y = -ly; v.p.z =  lz; quads.vertexes[ 3] = v;

            v.p.x =  lx; v.p.y =  ly; v.p.z = -lz; quads.vertexes[ 4] = v;
            v.p.x = -lx; v.p.y =  ly; v.p.z = -lz; quads.vertexes[ 5] = v;
            v.p.x = -lx; v.p.y = -ly; v.p.z = -lz; quads.vertexes[ 6] = v;
            v.p.x =  lx; v.p.y = -ly; v.p.z = -lz; quads.vertexes[ 7] = v;

            v.p.x = -lx; v.p.y =  ly; v.p.z = -lz; quads.vertexes[ 8] = v;
            v.p.x = -lx; v.p.y =  ly; v.p.z =  lz; quads.vertexes[ 9] = v;
            v.p.x = -lx; v.p.y = -ly; v.p.z =  lz; quads.vertexes[10] = v;
            v.p.x = -lx; v.p.y = -ly; v.p.z = -lz; quads.vertexes[11] = v;

            v.p.x = -lx; v.p.y =  ly; v.p.z =  lz; quads.vertexes[12] = v;
            v.p.x =  lx; v.p.y =  ly; v.p.z =  lz; quads.vertexes[13] = v;
            v.p.x =  lx; v.p.y = -ly; v.p.z =  lz; quads.vertexes[14] = v;
            v.p.x = -lx; v.p.y = -ly; v.p.z =  lz; quads.vertexes[15] = v;

            DISPLAY->DrawQuads(quads);
            DISPLAY->SetPolygonMode(POLYGON_FILL);
            DISPLAY->PopMatrix();
        }
    }



    // draw triggers
    for (u8 i = 0; i < mGateways.size(); ++i)
    {
        mGateways[i]->Draw();
    }
}



void
UnitManager::DrawDebugInfo(void) const
{
    RString temp;

    if (mPC >= 0 && mPC < mUnits.size())
    {
        temp.Format("x(%f) y(%f) z(%f)", mUnits[mPC].position.x, mUnits[mPC].position.y, mUnits[mPC].position.z);
        KERNEL->DrawString(RStringToFFVIIString(temp), 10, 10, F_WHITE);
        temp.Format("triangle = %d", mUnits[mPC].triangle);
        KERNEL->DrawString(RStringToFFVIIString(temp), 10, 25, F_WHITE);
        temp.Format("direction = %d", mUnits[mPC].direction);
        KERNEL->DrawString(RStringToFFVIIString(temp), 10, 40, F_WHITE);
    }

    temp.Format("danger counter = %d", mDangerCounter);
    KERNEL->DrawString(RStringToFFVIIString(temp), 10, 65, F_WHITE);
}



bool
UnitManager::Input(const InputEvent &input)
{
    bool ret = false;

    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_UP:    mMoveForward       = true; ret = true; break;
            case KEY_DOWN:  mMoveBack          = true; ret = true; break;
            case KEY_LEFT:  mMoveRight         = true; ret = true; break;
            case KEY_RIGHT: mMoveLeft          = true; ret = true; break;

            case KEY_C4:    mDisplayWalkmesh   = (mDisplayWalkmesh) ? false : true; break;
            case KEY_C5:    mDisplayCollisions = (mDisplayCollisions) ? false : true; break;
        }
    }

    if (input.type == IET_RELEASE)
    {
        switch (input.button)
        {
            case KEY_UP:    mMoveForward = false; ret = true; break;
            case KEY_DOWN:  mMoveBack    = false; ret = true; break;
            case KEY_LEFT:  mMoveRight   = false; ret = true; break;
            case KEY_RIGHT: mMoveLeft    = false; ret = true; break;

            case KEY_Cx:
            {
                for (u8 i = 0; i < mUnits.size(); ++i)
                {
                    if (mUnits[i].talkable == true)
                    {
                        mpFieldModule->mScriptManager.RequestRunUnit(i, 0, 1);
                        ret = true;
                        break;
                    }
                }
            }
            break;
        }
    }
}



void
UnitManager::Update(const u32& deltaTime)
{
    static float step = 5.0f;
    Vector3 next_step(0.0f, 0.0f, 0.0f);

    if (mMoveForward)
    {
        next_step.z =  step;
    }

    if (mMoveBack)
    {
        next_step.z = -step;
    }

    if (mMoveLeft)
    {
        next_step.x =  step;
    }

    if (mMoveRight)
    {
        next_step.x = -step;
    }

    if ((next_step.x != 0.0f || next_step.z != 0.0f) &&
         mPC >= 0 && mPC < mUnits.size() &&
         mUnits[mPC].pc           == true &&
         mUnits[mPC].position_set == true &&
         mUnits[mPC].visible      == true)
    {
        // if we make move
        if (SetNextStep(next_step, false) == true)
        {
            CheckTriggers(mPC);
            CheckEncounters();
        }
    }



    // ode collision
    // update collision position
    for (u8 i = 0; i < mUnits.size(); ++i)
    {
        dGeomSetPosition(mUnits[i].collision     , mUnits[i].position.x, mUnits[i].position.y, mUnits[i].position.z);
        dGeomSetPosition(mUnits[i].collision_talk, mUnits[i].position.x, mUnits[i].position.y, mUnits[i].position.z);
        dMatrix3 rot;
        dRFromAxisAndAngle(rot, 0, 1, 0, ((float)mUnits[i].direction / (float)255) * 2 * 3.1415926);
        dGeomSetRotation(mUnits[i].collision,      rot);
        dGeomSetRotation(mUnits[i].collision_talk, rot);
    }



    // check talk
    dContact contact;

    for (u8 i = 0; i < mUnits.size(); ++i)
    {
        if (i == mPC)
        {
            continue;
        }

        int numc = dCollide(mUnits[mPC].collision_talk, mUnits[i].collision_talk, 1, &contact.geom, sizeof(dContact));

        if (numc > 0)
        {
            mUnits[i].talkable = true;
        }
        else
        {
            mUnits[i].talkable = false;
        }
    }
}



void
UnitManager::AddWalkMeshTriangle(const WalkMeshTriangle& triangle)
{
    mWalkMesh.push_back(triangle);
}



void
UnitManager::AddGateway(const Vector3& point1, const Vector3& point2, const Vector3& position, const u16& mapId)
{
    dGeomID ray = dCreateRay(mSpace, 1);
    dGeomRaySet(ray, point1.x, point1.y, point1.z, point2.x - point1.x, point2.y - point1.y, point2.z - point1.z);

    Gateway* gateway = new Gateway(mpFieldModule, ray, position, mapId);
    mGateways.push_back(gateway);
}



void
UnitManager::AddEncounterTable(const EncounterTable& encounterTable)
{
    // if this table is enabled - disable all others
    if (encounterTable.enabled == true)
    {
        for (u8 i = 0; i < mEncounters.size(); ++i)
        {
            mEncounters[i].enabled = false;
        }
    }

    mEncounters.push_back(encounterTable);
}



void
UnitManager::DropInput(void)
{
    mMoveForward = false;
    mMoveBack    = false;
    mMoveLeft    = false;
    mMoveRight   = false;
}



const s8
UnitManager::AddChar(const u8& characterId)
{
    UnitData unit;

    Model* model = new Model();

    unit.model          = model;
    unit.collision      = dCreateBox(mSpace, 40, 50, 40);
    unit.collision_talk = dCreateBox(mSpace, 50, 50, 50);



    mUnits.push_back(unit);

    return mUnits.size() - 1;
}



void
UnitManager::SetPC(const s8& unitId, const u8& playableId)
{
    if (unitId < 0 || unitId >= mUnits.size())
    {
        return;
    }

    mUnits[unitId].pc    = true;
    mUnits[unitId].pc_id = playableId;

    if (playableId == 0)
    {
        mPC = unitId;

        // load position from gamestate
        if (KERNEL->GetGamestate().PlayerPositionIsSet() == true)
        {
            mUnits[unitId].position = KERNEL->GetGamestate().PlayerPositionGet();

            if (KERNEL->GetGamestate().PlayerTriangleIsSet() == true)
            {
                mUnits[unitId].triangle = KERNEL->GetGamestate().PlayerTriangleGet();
                SetPosition(unitId);
            }
            else
            {
                SetPositionByXZ(unitId, mUnits[unitId].position);
            }
        }
        else
        {
            mUnits[unitId].position_set = false;
        }
    }
}



void
UnitManager::SetPositionByXYZTriangle(const s8& unitId, const Vector3& coords, const u16& triangleIndex)
{
    if (unitId < 0 || unitId >= mUnits.size() || mUnits[unitId].position_set == true)
    {
        return;
    }

    mUnits[unitId].position = coords;
    mUnits[unitId].triangle = triangleIndex;
    SetPosition(unitId);
}



void
UnitManager::SetPositionByXZ(const s8& unitId, const Vector3& coords)
{
    if (unitId < 0 || unitId >= mUnits.size() || mUnits[unitId].position_set == true)
    {
        return;
    }

    Vector3 point1 = coords;

    Vector3 point2;
    point2.x = point1.x + 1000.0f;
    point2.y = point1.y;
    point2.z = point1.z;

    for (u32 i = 0; i < mWalkMesh.size(); ++i)
    {
        point1.y = point_elevation(point1, mWalkMesh[i].A, mWalkMesh[i].B, mWalkMesh[i].C);
        point2.y = point_elevation(point2, mWalkMesh[i].A, mWalkMesh[i].B, mWalkMesh[i].C);

        u8 check = 0;
        // if we cross line 1
        if (line_crossing(point1, point2, mWalkMesh[i].A, mWalkMesh[i].B) == true)
        {
            ++check;
        }
        // if we cross line 2
        if (line_crossing(point1, point2, mWalkMesh[i].B, mWalkMesh[i].C) == true)
        {
            ++check;
        }
        // if we cross line 3
        if (line_crossing(point1, point2, mWalkMesh[i].A, mWalkMesh[i].C) == true)
        {
            ++check;
        }



        // we are in triangle only if we cross one side
        if (check == 1)
        {
            mUnits[unitId].position = point1;
            mUnits[unitId].triangle = i;
            SetPosition(unitId);
            break;
        }
    }
}



void
UnitManager::SetPosition(const s8& unitId)
{
    if (unitId < 0 || unitId >= mUnits.size())
    {
        return;
    }

    // fix unit position
    mUnits[unitId].position_set = true;
    // store player position set in gamestate
    if (unitId == mPC)
    {
        KERNEL->GetGamestate().PlayerPositionSet(mUnits[mPC].position);
        KERNEL->GetGamestate().PlayerTriangleSet(mUnits[mPC].triangle);
    }

    mUnits[unitId].visible = true;
    mUnits[unitId].solid   = true;
}



void
UnitManager::SetDirection(const s8& unitId, const u8& direction)
{
    if (unitId < 0 || unitId >= mUnits.size())
    {
        return;
    }

    mUnits[unitId].direction = direction;
}



void
UnitManager::SetTriangleAccess(const u16& triangleId, const u8& lock)
{
    if (triangleId > mWalkMesh.size())
    {
        return;
    }

    mWalkMesh[triangleId].accessible = (lock == 1) ? false : true;
}



void
UnitManager::SetEncounterTable(const u8& encounter_table)
{
    if (encounter_table > mEncounters.size())
    {
        LOGGER->Log("UnitManager::SetEncounterTable - tried set mActiveEncounter greater than current mEncounters number.");
        return;
    }

    // enable this table, disable others
    for (u8 i = 0; i < mEncounters.size(); ++i)
    {
        if (i == encounter_table)
        {
            mEncounters[i].enabled = true;
        }
        else
        {
            mEncounters[i].enabled = false;
        }
    }
}



void
UnitManager::DisableEncounter(const bool& disable)
{
    mEncounterDisabled = disable;
}



bool
UnitManager::SetNextStep(const Vector3& moveVector, const bool slide)
{
    // if we are not moving anywhere
    if (moveVector.x == 0.0f && moveVector.y == 0.0f && moveVector.z == 0.0f)
    {
        return false;
    }



    u16 triangle = mUnits[mPC].triangle;
    u16 prev_triangle = 0xFFFE; // number of triangles never must be such great

    Vector3 start_point = mUnits[mPC].position;
    Vector3 end_point(mUnits[mPC].position.x + moveVector.x,
                      mUnits[mPC].position.y + moveVector.y,
                      mUnits[mPC].position.z + moveVector.z);

    for (;;)
    {
        Vector3 A = mWalkMesh[triangle].A;
        Vector3 B = mWalkMesh[triangle].B;
        Vector3 C = mWalkMesh[triangle].C;



        // check if we cross board of current triangle
        u8 cross = 0x00;
        // if we cross line 1
        if      (line_crossing(start_point, end_point, A, B) == true && mWalkMesh[triangle].access[0] != prev_triangle)
        {
            cross = 0x01;
        }
        // if we cross line 2
        else if (line_crossing(start_point, end_point, B, C) == true && mWalkMesh[triangle].access[1] != prev_triangle)
        {
            cross = 0x02;
        }
        // if we cross line 3
        else if (line_crossing(start_point, end_point, A, C) == true && mWalkMesh[triangle].access[2] != prev_triangle)
        {
            cross = 0x03;
        }

        // if we do not cross border
        if (cross == 0x00)
        {
            end_point.y = point_elevation(end_point, A, B, C);

            if (CONFIG->mDumpSpecificGameData == true)
            {
                LOGGER->Log("final triangle = %d", triangle);
            }

            // check ode collision
            // update collision position
            dGeomSetPosition(mUnits[mPC].collision, end_point.x, end_point.y, end_point.z);

            dContact contact;
            int numc = 0;

            for (u8 i = 0; i < mUnits.size(); ++i)
            {
                if (i == mPC || mUnits[i].solid == false)
                {
                    continue;
                }

                numc = dCollide(mUnits[mPC].collision, mUnits[i].collision, 1, &contact.geom, sizeof(dContact));

                if (numc != 0)
                {
                    break;
                }
            }

            if (numc == 0)
            {
                mUnits[mPC].triangle = triangle;
                mUnits[mPC].position = end_point;
                // store new place in gamestate
                KERNEL->GetGamestate().PlayerPositionSet(end_point);
                KERNEL->GetGamestate().PlayerTriangleSet(triangle);

                return true;
            }

            return false;
        }
        else
        {
            // if board can be crossed
            if (mWalkMesh[triangle].accessible == true &&
                mWalkMesh[triangle].access[cross - 1] != 0xFFFF &&
                mWalkMesh[mWalkMesh[triangle].access[cross - 1]].accessible == true)
            {
                // if line crosses corner of the triangle move final point a bit and recheck all things
                if (point_on_line(A, start_point, end_point) == true ||
                    point_on_line(B, start_point, end_point) == true ||
                    point_on_line(C, start_point, end_point) == true)
                {
                    if (CONFIG->mDumpSpecificGameData == true)
                    {
                        LOGGER->Log("We try to cross corner of triangle");
                    }
                    end_point.z += 0.01f;
                    end_point.x += 0.01f;
                    continue;
                }

                prev_triangle = triangle;
                triangle      = mWalkMesh[triangle].access[cross - 1];

                if (CONFIG->mDumpSpecificGameData == true)
                {
                    LOGGER->Log("cross = %d, prev_triangle = %d, triangle = %d", cross, prev_triangle, triangle);
                }
            }
            else
            {
                if (slide == false)
                {
                    Vector3 sp1 = (cross == 1 || cross == 3) ? A : B;
                    Vector3 sp2 = (cross == 1) ? B : C;

                    if (CONFIG->mDumpSpecificGameData == true)
                    {
                        LOGGER->Log("we met border");
                    }
                    Vector3 new_move = get_projection_on_line(moveVector, sp1, sp2);

                    if (CONFIG->mDumpSpecificGameData == true)
                    {
                        LOGGER->Log("we slide");
                    }

                    return SetNextStep(new_move, true);
                }
                else
                {
                    if (CONFIG->mDumpSpecificGameData == true)
                    {
                        LOGGER->Log("we met border");
                        LOGGER->Log("we can't slide");
                    }

                    return false;
                }
            }
        }
    }
}



void
UnitManager::CheckTriggers(const s8& unitId)
{
    if (unitId < 0 || unitId >= mUnits.size())
    {
        return;
    }

    for (u8 i = 0; i < mGateways.size(); ++i)
    {
        mGateways[i]->CheckCollision(mUnits[unitId].collision);
    }
}



void
UnitManager::CheckEncounters(void)
{
    // if battle locked
    if (KERNEL->GetGamestate().BattleLockGet() == true || mEncounterDisabled == true)
    {
        return;
    }



    for (u8 j = 0; j < mEncounters.size(); ++j)
    {
        // if field encounter not active
        if (mEncounters[j].enabled != true || mEncounters[j].rate == 0xFF)
        {
            continue;
        }

        mDangerCounter += 1024 / (mEncounters[j].rate + 1);

        // check encounter
        if (rand() % 255 < mDangerCounter / 256)
        {
            u16 battle = 0;

            // check special encounter
            for (u8 i = 0; i < 4; ++i)
            {
                if (rand() % 64 < mEncounters[j].special_encounter[i].rate)
                {
                    battle = mEncounters[j].special_encounter[i].scene;
                    break;
                }
            }



            // check standard encounter
            if (battle == 0)
            {
                u8 chance = rand() % 64;
                u8 chance_sum = 0;

                for (u8 i = 0; i < 6; ++i)
                {
                    if (mEncounters[j].standart_encounter[i].rate + chance_sum > chance)
                    {
                        battle = mEncounters[j].standart_encounter[i].scene;
                        break;
                    }

                    chance_sum += mEncounters[j].standart_encounter[i].rate;
                }
            }



            LOGGER->Log("Encount battle %d from table %d", battle, j);
            mpFieldModule->LoadBattle(battle);
            return;
        }
    }
}
