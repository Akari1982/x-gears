// $Id: DatXmlFile.h 96 2006-11-13 03:34:17Z crazy_otaku $

#ifndef DAT_XML_FILE_h
#define DAT_XML_FILE_h

#include "../../common/filesystem/XmlFile.h"

#include "UnitManager.h"
#include "WindowManager.h"
#include "script/ScriptManager.h"



class DatXmlFile : public XmlFile
{
public:
    explicit DatXmlFile(const RString& file);
    virtual ~DatXmlFile(void);

    bool GetDialogs(WindowManager* windowManager);
    bool GetScripts(ScriptManager* scriptManager);
    bool GetWalkMesh(UnitManager* unitManager);
    bool GetGateway(UnitManager* unitManager);
    bool GetEncounter(UnitManager* unitManager);

private:
    bool       mNormalFile;

    xmlNodePtr mRootNode;
};



#endif // DAT_XML_FILE_h
