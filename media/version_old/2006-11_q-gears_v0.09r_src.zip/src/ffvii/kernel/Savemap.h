// $Id: Savemap.h 98 2006-11-21 21:46:28Z einherjar $

#ifndef SAVEMAP_H
#define SAVEMAP_H
// The Savemap Struct : Here stored all data about game state

#include "../../common/TypeDefine.h"

struct CharacterRecord
{
    u8  Id;
    u8  Level;
    u8  Strength;
    u8  Vitality;
    u8  Magic;
    u8  Spirit;
    u8  Dexterity;
    u8  Luck;
    u8  StrengthBonus;
    u8  VitalityBonus;
    u8  MagicBonus;
    u8  SpiritBonus;
    u8  DexterityBonus;
    u8  LuckBonus;
    u8  CurrentLimitLevel;
    u8  CurrentLimitBar; // 0xFF - limit break
    u8  Name[12];
    u8  EquippedWeapon;
    u8  EquippedArmor;
    u8  EquippedAccessory;
    u8  StatusFlags;
    u8  RowFlags;
    u8  LevelProgressBar;
    u16 LearnedLimitSkills;
    u16 NumberOfKills;
    u16 TimesUsedLimit11;
    u16 TimesUsedLimit21;
    u16 TimesUsedLimit31;
    u16 CurrentHP;
    u16 BaseHP; // before materia alterations
    u16 CurrentMP;
    u16 BaseMP; // before materia alterations
    u8  Unknown1[4];
    u16 MaximumHP; // after materia alterations
    u16 MaximumMP; // after materia alterations
    u32 CurrentEXP;
    u32 WeaponMateriaSlot1;
    u32 WeaponMateriaSlot2;
    u32 WeaponMateriaSlot3;
    u32 WeaponMateriaSlot4;
    u32 WeaponMateriaSlot5;
    u32 WeaponMateriaSlot6;
    u32 WeaponMateriaSlot7;
    u32 WeaponMateriaSlot8;
    u32 ArmorMateriaSlot1;
    u32 ArmorMateriaSlot2;
    u32 ArmorMateriaSlot3;
    u32 ArmorMateriaSlot4;
    u32 ArmorMateriaSlot5;
    u32 ArmorMateriaSlot6;
    u32 ArmorMateriaSlot7;
    u32 ArmorMateriaSlot8;
    u32 NextLevelEXP;
};



struct ChocoboRecord
{
    u16 SprintSpeed;
    u16 MaxSprintSpeed;
    u16 Speed;
    u16 MaxSpeed;
    u8  Acceleration;
    u8  Cooperation;
    u8  Intelligence;
    u8  Personality;
    u8  Pcount; // ???
    u8  NumberOfRacesWon;
    u8  Sex; // 1 - female
    u8  Type; // Yellow, Green, Blue, Black, Gold
};


struct Savemap
{
    u32 Checksum;

    // Preview
    u8  PreviewLeadCharacterLevel;
    u8  PreviewLeadCharacterPortrait;
    u8  PreviewSecondCharacterPortrait;
    u8  PreviewThirdCharacterPortrait;
    u8  PreviewLeadCharacterName[16];
    u16 PreviewLeadCharacterCurrentHP;
    u16 PreviewLeadCharacterMaxHP;
    u16 PreviewLeadCharacterCurrentMP;
    u16 PreviewLeadCharacterMaxMP;
    u32 PreviewGilAmount;
    u32 PreviewPlayedSeconds;
    u8  PreviewCurrentLocationName[32];

    // Real data
    u8  WindowRGBUpperLeft[3];
    u8  WindowRGBUpperRight[3];
    u8  WindowRGBLowerLeft[3];
    u8  WindowRGBLowerRight[3];

    // Cloud, Barret, Tifa, Aeris, RedXIII, Yuffie, CaitSith, Vincent, Cid
    CharacterRecord Character[9];

    u8  Slot1Char;
    u8  Slot2Char;
    u8  Slot3Char;

    u8:8;

    u16 PartyItemStock[320];
    u32 PartyMateriaStock[200];
    u32 MateriaStolenByYuffie[48];

    u8  Unknown1[32];

    u32 GilAmount;
    u32 PlayedSeconds;

    u8  Unknown2[16];

    u16 CurrentMap;

    u16 CurrentField;                           // current field where character placed

    u8  Unknown3[2];

    u16 MapLocationX;
    u16 MapLocationY;
    u16 MapLocationZ;

    u8  Unknown4[4];

    u8  MemoryBank12[256];                      // memory bank 1/2
    u8  MemoryBank34[256];                      // memory bank 3/4
    u8  MemoryBankBC[256];                      // memory bank B/C
    u8  MemoryBankDE[256];                      // memory bank D/E
    u8  MemoryBank7F[256];                      // memory bank 7/F

    u8  Unknown5[54];

    u8  BattleSpeed;
    u8  BattleMessageSpeed;
    u16 GeneralConfiguration;

    u8  UnknownFE[16];

    u8  MessageSpeed;

    u8  UnknownFF[7];
};



#endif // SAVEMAP_H
