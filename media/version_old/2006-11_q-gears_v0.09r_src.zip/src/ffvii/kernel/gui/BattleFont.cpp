// $Id: BattleFont.cpp 103 2006-11-26 07:19:38Z crazy_otaku $

#include <vector>
#include <map>
#include <utility>

#include "BattleFont.h"

#include "../../../common/display/Display.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/Logger.h"
#include "../../../common/utilites/StdString.h"



BattleFont::BattleFont(Surface* image_gray,
                       Surface* image_blue,
                       Surface* image_white):
    mLetterWidth  (8),
    mLetterHeight (8),
    mLetterSpacing(0),
    mRowSpacing   (4)

{
    // battle font ascii assotiation
    unsigned char ptr[] = {
        // spesial symbol
        0x09, // tab
        0x0A, // new string
        // ascii codes
        0x20, 0x00, 0x00, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x21, 0x3F,
        0x00, 0x00, 0x2E, 0x2B, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C,
        0x4D, 0x4E, 0x4F, 0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x00, 0x00,
        0x00, 0x7E, 0x00, 0x25, 0x2F, 0x3A, 0x26, 0x5B, 0x5D, 0x00, 0x3E, 0x00, 0x00, 0x00, 0x00, 0x28,
        0x29, 0x2D, 0x3D, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x2C
    };

    int i = 0;

    // tab and new line
    mTab     = ptr[i++];
    mNewLine = ptr[i++];

    for (int y = 152; y < 256; y += mLetterHeight)
    {
        for (int x = 128; x < 256; x += mLetterWidth)
        {
            if (i < sizeof(ptr))
            {
                Surface* font;
                font = CreateSubSurface(x, y, mLetterWidth, mLetterHeight, image_gray);
                mFontGrayTexId.insert(std::make_pair(ptr[i], DISPLAY->CreateTexture(font)));
                delete font;

                font = CreateSubSurface(x, y, mLetterWidth, mLetterHeight, image_blue);
                mFontBlueTexId.insert(std::make_pair(ptr[i], DISPLAY->CreateTexture(font)));
                delete font;

                font = CreateSubSurface(x, y, mLetterWidth, mLetterHeight, image_white);
                mFontWhiteTexId.insert(std::make_pair(ptr[i], DISPLAY->CreateTexture(font)));
                delete font;

                ++i;
            }
            else
            {
                LOGGER->Log("Warning: glyth ended earlier than given picture.");
            }
        }
    }

    Vertex point;
    point.p.x =  0.0f;        point.p.y =  0.0f;          point.p.z =  0.0f;
    point.c.r =  1.0f;        point.c.g =  1.0f;          point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  0.0f;        point.t.y =  0.0f;
    mFontPoly.vertexes.push_back(point);
    point.p.x = mLetterWidth; point.p.y =  0.0f;          point.p.z =  0.0f;
    point.c.r =  1.0f;        point.c.g =  1.0f;          point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  1.0f;        point.t.y =  0.0f;
    mFontPoly.vertexes.push_back(point);
    point.p.x = mLetterWidth; point.p.y = -mLetterHeight; point.p.z =  0.0f;
    point.c.r =  1.0f;        point.c.g =  1.0f;          point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  1.0f;        point.t.y =  1.0f;
    mFontPoly.vertexes.push_back(point);
    point.p.x =  0.0f;        point.p.y = -mLetterHeight; point.p.z =  0.0f;
    point.c.r =  1.0f;        point.c.g =  1.0f;          point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  0.0f;        point.t.y =  1.0f;
    mFontPoly.vertexes.push_back(point);
}



BattleFont::~BattleFont()
{
    std::map<int, int>::iterator i;

    for (i = mFontGrayTexId.begin(); i != mFontGrayTexId.end(); ++i)
    {
        DISPLAY->DeleteTexture((*i).second);
    }

    for (i = mFontBlueTexId.begin(); i != mFontBlueTexId.end(); ++i)
    {
        DISPLAY->DeleteTexture((*i).second);
    }

    for (i = mFontWhiteTexId.begin(); i != mFontWhiteTexId.end(); ++i)
    {
        DISPLAY->DeleteTexture((*i).second);
    }
}



void
BattleFont::DrawString(const RString &string, const int &x, const int &y, const BattleFontColor &color)
{
    DISPLAY->Translate(x, -y, 0);
    DISPLAY->PushMatrix();

    for (int i = 0; i < string.size(); ++i)
    {
        if (string[i] == mTab)
        {
            DISPLAY->Translate(4 * (mLetterWidth + mLetterSpacing), 0, 0);
        }
        else if (string[i] == mNewLine)
        {
            DISPLAY->PopMatrix();
            DISPLAY->Translate(0, -(mLetterHeight + mRowSpacing), 0);
            DISPLAY->PushMatrix();
        }
        else
        {
            std::map<int, int>::const_iterator tile, end;

            switch (color)
            {
                case BF_GRAY :
                    tile = mFontGrayTexId.find(static_cast<int>(string[i]));
                    end  = mFontGrayTexId.end();
                    break;
                case BF_BLUE:
                    tile = mFontBlueTexId.find(static_cast<int>(string[i]));
                    end  = mFontBlueTexId.end();
                    break;
                case BF_WHITE:
                    tile = mFontWhiteTexId.find(static_cast<int>(string[i]));
                    end  = mFontWhiteTexId.end();
                    break;
                default:
                    LOGGER->Log("Unidentify font color %d.", static_cast<int>(color));
                    return;
            }

            if (tile == end)
            {
                LOGGER->Log("Warning: Letter '0x%02x' not found in this font", string[i]);
            }
            else
            {
                DISPLAY->SetTexture((*tile).second);
                DISPLAY->DrawQuads(mFontPoly);
                DISPLAY->UnsetTexture();
            }
            DISPLAY->Translate(mLetterWidth + mLetterSpacing, 0, 0);
        }
    }

    DISPLAY->PopMatrix();
}
