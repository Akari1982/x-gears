// $Id: InputUtils.cpp 93 2006-11-12 13:49:02Z einherjar $

#include "InputUtils.h"
#include "../utilites/Logger.h"



#include <string>



std::string
ButtonToString(const Button key)
{
LOGGER->Log("1");
    if ( key >= 33 && key < 127 && !(key >= 'A' && key <= 'Z' ))
    {
        // All printable ASCII except for uppercase alpha characters line up.
        char temp[2];
        sprintf(temp, "%c", key);
        return std::string(temp);
    }
LOGGER->Log("2");
    if (key >= KEY_OTHER_0 && key < KEY_LAST_OTHER)
    {
        char temp[2];
        sprintf(temp, "unk %i", key - KEY_OTHER_0);
        return std::string(temp);
    }

    switch (key)
    {
        case KEY_SPACE:         return "space";
        case KEY_DEL:           return "delete";

        case KEY_BACK:          return "backspace";
        case KEY_TAB:           return "tab";
        case KEY_ENTER:         return "enter";
        case KEY_PAUSE:         return "pause";
        case KEY_ESC:           return "escape";

        case KEY_F1:            return "F1";
        case KEY_F2:            return "F2";
        case KEY_F3:            return "F3";
        case KEY_F4:            return "F4";
        case KEY_F5:            return "F5";
        case KEY_F6:            return "F6";
        case KEY_F7:            return "F7";
        case KEY_F8:            return "F8";
        case KEY_F9:            return "F9";
        case KEY_F10:           return "F10";
        case KEY_F11:           return "F11";
        case KEY_F12:           return "F12";
        case KEY_F13:           return "F13";
        case KEY_F14:           return "F14";
        case KEY_F15:           return "F15";
        case KEY_F16:           return "F16";

        case KEY_LCTRL:         return "left ctrl";
        case KEY_RCTRL:         return "right ctrl";
        case KEY_LSHIFT:        return "left shift";
        case KEY_RSHIFT:        return "right shift";
        case KEY_LALT:          return "left alt";
        case KEY_RALT:          return "right alt";
        case KEY_LMETA:         return "left meta";
        case KEY_RMETA:         return "right meta";
        case KEY_LSUPER:        return "left wnd";
        case KEY_RSUPER:        return "right wnd";
        case KEY_MENU:          return "menu";

        case KEY_NUMLOCK:       return "num lock";
        case KEY_SCRLLOCK:      return "scroll lock";
        case KEY_CAPSLOCK:      return "caps lock";
        case KEY_PRTSC:         return "prtsc";

        case KEY_UP:            return "up";
        case KEY_DOWN:          return "down";
        case KEY_LEFT:          return "left";
        case KEY_RIGHT:         return "right";

        case KEY_INSERT:        return "insert";
        case KEY_HOME:          return "home";
        case KEY_END:           return "end";
        case KEY_PGUP:          return "pgup";
        case KEY_PGDN:          return "pgdn";

        case KEY_KP_C0:         return "KP 0";
        case KEY_KP_C1:         return "KP 1";
        case KEY_KP_C2:         return "KP 2";
        case KEY_KP_C3:         return "KP 3";
        case KEY_KP_C4:         return "KP 4";
        case KEY_KP_C5:         return "KP 5";
        case KEY_KP_C6:         return "KP 6";
        case KEY_KP_C7:         return "KP 7";
        case KEY_KP_C8:         return "KP 8";
        case KEY_KP_C9:         return "KP 9";
        case KEY_KP_SLASH:      return "KP /";
        case KEY_KP_ASTERISK:   return "KP *";
        case KEY_KP_HYPHEN:     return "KP -";
        case KEY_KP_PLUS:       return "KP +";
        case KEY_KP_PERIOD:     return "KP .";
        case KEY_KP_EQUAL:      return "KP =";
        case KEY_KP_ENTER:      return "KP enter";
        default:                return "unknown";
    }
}



Button
StringToButton(const std::string &s)
{
    for (int i = 0; i < NUM_KEYS; i++)
    {
        if (ButtonToString((Button)i) == s)
        {
            return (Button)i;
        }
    }
    return KEY_INVALID;
}
