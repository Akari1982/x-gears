// $Id: Config.h 93 2006-11-12 13:49:02Z einherjar $

#ifndef CONFIG_H
#define CONFIG_H
// The Config Class : Implements basic config file



#include "NoCopy.h"
#include "StdString.h"
#include <string>



class Config : public NoCopy<Config>
{
public:
    Config();

    virtual ~Config();

    void ReadConfig(const std::string &file);

public:
    // Debug:
    bool    mDumpSpecificGameData;

    RString mField;
    RString mGameCD;
};



extern Config* CONFIG; // global and accessable from anywhere in our program



#endif // CONFIG_H
