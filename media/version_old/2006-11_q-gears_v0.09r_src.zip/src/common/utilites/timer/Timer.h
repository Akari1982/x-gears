// $Id: Timer.h 93 2006-11-12 13:49:02Z einherjar $

#ifndef TIMER_H
#define TIMER_H



#include "../NoCopy.h"



class Timer : public NoCopy<Timer>
{
public:
    virtual             ~Timer();

    unsigned int         GetDeltaTime();

protected:
                         Timer();
                         Timer(const unsigned int &seconds);
    virtual unsigned int GetTime() = 0;

public:
    unsigned int mSeconds;
};



Timer* MakeTimer();



Timer* MakeTimer(const unsigned int &seconds);



#endif
