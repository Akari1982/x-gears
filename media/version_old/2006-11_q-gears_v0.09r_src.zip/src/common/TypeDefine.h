// $Id: TypeDefine.h 98 2006-11-21 21:46:28Z einherjar $

#ifndef TYPE_DEFINE_h
#define TYPE_DEFINE_h

#ifdef HAVE_CONFIG_H
# include "config.h"
#endif // HAVE_CONFIG_H

#ifdef HAVE_INTTYPES_H
# include <inttypes.h>
#else
typedef unsigned char      uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned long int  uint32_t;

typedef signed char        int8_t;
typedef signed short int   int16_t;
typedef signed long int    int32_t;
#endif // HAVE_INTTYPES_H

typedef uint8_t  u8;  /**< @brief shortcut for 1 unsigned byte type. */
typedef uint16_t u16; /**< @brief shortcut for 2 unsigned byte type. */
typedef uint32_t u32; /**< @brief shortcut for 4 unsigned byte type. */

typedef int8_t   s8;  /**< @brief shortcut for 1 signed byte type. */
typedef int16_t  s16; /**< @brief shortcut for 2 signed byte type. */
typedef int32_t  s32; /**< @brief shortcut for 4 signed byte type. */

#endif // TYPE_DEFINE_h
