// $Id: DisplayOgl.h 103 2006-11-26 07:19:38Z crazy_otaku $

#ifndef DISPLAYOGL_H
#define DISPLAYOGL_H
// DisplayOGL - OpenGL renderer.



#include "Display.h"
#include "window/Window.h"

#include <vector>



class DisplayOGL : public Display
{
public:
    virtual         ~DisplayOGL();

    static Display* MakeDisplay();

    void            BeginFrame();
    void            EndFrame();

    void            DrawPoints   (const std::vector<Vertex>& vertexes);
    void            DrawLines    (const std::vector<Vertex>& vertexes);
    void            DrawTriangles(const Geometry&            triangles);
    void            DrawQuads    (const Geometry&            quads);
    void            DrawGeometrys(const TotalGeometry&       geometrys);

    u32             CreateTexture(Surface *image);
    void            UpdateTexture(unsigned int tex_handle, Surface *image, int xoffset, int yoffset, int width, int height);
    void            DeleteTexture(unsigned int tex_handle);
    void            SetTexture(unsigned int tex_handle);
    void            UnsetTexture();

    void            SetAlphaTest(bool b);
    void            SetZTestMode(ZTestMode mode);
    void            SetBlendMode(BlendMode mode);
    void            SetCullMode(CullMode mode);
    void            SetPolygonMode(PolygonMode pm);
    void            SetLineWidth(float width);
    void            SetPointSize(float size);

protected:
    void            SetupVertices(const std::vector<Vertex>& vertexes);
    void            SendCurrentMatrices();

private:
    void            Init();

    DisplayOGL();

private:
    Window* mWindow;
};



#endif
