#include <stdio.h>
#include "script.h"

/*
	Holy twisted code Batman! I had to get out of that main(); routine QUICK!
	This should make things nice and modular with little damage to the main
	program. That is, if I don't make *THIS* a train-wreck of code in the
	process
*/


/*
	Welcome to the actual heavy lifter that dumps the opcodes. As we
	are generating code that, one day, might want to be parsed with
	some kind of flex/bison thingy, it's best to keep the grammar as easy
	as possable.

	The commands are printed with a "C-ish" type grammar. This means
	that the opcodes become keywords, are switched to lower case, arguments
	are in parens, blocks in curlies, and jump labels have a colon after them.
	However I am dropping the semicolon as every command should be on a line.

	I'm making some assumptions about the original fieldscript, first as
	the original seemed not to use a stack in the typical sense, there
	shouldn't be "long jumps" outside one entity's script. I'm also assuming
	that the original conditional blocks  were bracketed as well and jumping
	out of them, though legal, was just bad programming form. We'll see how it
	goes.
 
	This is, of course, subject to change and might be wholly inacuurate.
*/

unsigned char op_arg[15];	/* holds the arguments */
int op_trans[15];		/* holds converted arguments */

int base_flag = 0;

unsigned char high_split;
unsigned char low_split;

/* This helper function splits the FF7 memory bank arguments into its */
/* compnent parts. I'm rusty on my decrete math, so I used bit shifts */
void mem_split(unsigned char mem_loc)
{
	high_split=(mem_loc>>4);
	low_split=(mem_loc<<4);
	low_split=(mem_loc>>4);	
}


/* this is a rip-off of my get_mips_u16() function to flip byte order */
int comb_long(unsigned char high, unsigned char low)
{
    int n=0;
    unsigned char ch;
                                                                                
    /* Char 0 */
    n |= high;
    /* Char 1 */
    n |= (low << 8);
    return(n);
}


/* starting off, we need some helper functions to parse the opcode arguments */
void read_arg(FILE *fp, int arg_num)
{
	int count;
	for (count=0; count < arg_num; count++)
		{op_arg[count]=getc(fp);}
}

void print_cond(FILE *fp, unsigned char cond)
{
	switch (cond)
	{
		case 0:
		fprintf(fp," == "); break;
		case 1:
		fprintf(fp," != "); break;
		case 2:
		fprintf(fp," > "); break;
		case 3:
		fprintf(fp," < "); break;
		case 4:
		fprintf(fp," >= "); break;
		case 5:
		fprintf(fp," <= "); break;
		case 6:
		fprintf(fp," & "); break;
		case 7:
		fprintf(fp," ^ "); break;
		case 8:
		fprintf(fp," | "); break;
		case 9:
		fprintf(fp," << 1  & "); break;
		case 10:
		fprintf(fp," << 1  &! "); break;
	}
}

void dumpscript(FILE *fp, FILE *outfp, int beg_addr, int end_addr, int script_num)
{
	unsigned char curr_opcode;
	int curr_loc;

	if (beg_addr == end_addr) /* this catches the one-byte scripts */
		{end_addr++;}         /* this is a bug, by the way */

	/* Move the filepointer to the beginning of the script */
	fseek(fp,beg_addr,SEEK_SET);

/*
It's assumption time again. If the script is script 0, it actually has
two scripts in it. The first is an init script, and the second is the base
script. These need to be labeled accordingly
*/


	if (script_num == 0)
	{
		fprintf(outfp,"      INIT:\n");
		{
			curr_opcode=getc(fp);
			while (curr_opcode != RET)
			{
				decode(fp,outfp,curr_opcode);
				curr_opcode=getc(fp);
			}
			fprintf(outfp,"%x:\tret\n      BASE:\n",(ftell(fp))-1);
		}
	}

	/* loop away */	
	while (ftell(fp) < end_addr)
	{
		decode(fp,outfp,getc(fp));  /* decode the opcode */
	}

}


void decode (FILE *fp, FILE *outfp, unsigned char opcode)
{
/* This function exists as the switch statement is hella big */

int addr=ftell(fp)-1;

	fprintf(outfp,"%x:",addr);	/* print the address */
	switch (opcode)
	{
		case RET:		/* return */
			fprintf(outfp,"\tret\n");
			break;
		case REQ:
			/*  u8 entity_id = GetU8(i + 1);
                u8 priority  = GetU8(i + 2) >> 5;  <-- from akari, useful!
                u8 script_id = GetU8(i + 2) & 0x1F;
			*/
			read_arg(fp,2);
			fprintf(outfp,"\treq(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case REQSW:
			read_arg(fp,2);
			fprintf(outfp,"\treqsw(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case REQEW:
			read_arg(fp,2);
			fprintf(outfp,"\treqew(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case PREQ:
			read_arg(fp,2);
			fprintf(outfp,"\tpreq(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case PRQSW:
			read_arg(fp,2);
			fprintf(outfp,"\tprqsw(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case PRQEW:
			read_arg(fp,2);
			fprintf(outfp,"\tprqew(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case RETTO:
			read_arg(fp,3);
			fprintf(outfp,"\tretto(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case JOIN:
			fprintf(outfp,"\tjoin(%x)\n",getc(fp));
			break;
		case SPLIT:
			read_arg(fp,14);
			fprintf(outfp,
			"\tsplit(%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",
			op_arg[0],op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],
			op_arg[6],op_arg[7],op_arg[8],op_arg[9],op_arg[10],op_arg[11],
			op_arg[12],op_arg[13]);
			break;
		case SPTYE:
			read_arg(fp,5);
			fprintf(outfp,"\tsptye(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case GTPYE:
			read_arg(fp,5);
			fprintf(outfp,"\tgtpye(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case x0Cx:
			fprintf(outfp,"\t?0C?\n");
			break;
		case x0Dx:
			fprintf(outfp,"\t?0D?\n");
			break;
		case DSKCG:
			fprintf(outfp,"\tdiskcg(%x)\n",getc(fp));
			break;
		case SPECIAL:
			op_arg[0]=getc(fp);
			fprintf(outfp,"\tspecial(%x",op_arg[0]);
		if (op_arg[0]==0xf9 || 
				op_arg[0]==0xfa || 
				op_arg[0]==0xfe || 
				op_arg[0]==0xff )
			{
				fprintf(outfp,")\n");
				break;
			}
			if (op_arg[0]==0xf5 ||
				op_arg[0]==0xfb || 
				op_arg[0]==0xfc )
			{
				op_arg[1]=getc(fp);
				fprintf(outfp,",%x)\n",op_arg[1]);
				break;
			}
			if (op_arg[0]==0xf7 || 
				op_arg[0]==0xf8 || 
				op_arg[0]==0xfd ) 
			{
				op_arg[1]=getc(fp);
				op_arg[2]=getc(fp);
				fprintf(outfp,",%x,%x)\n",op_arg[1],op_arg[2]);
				break;
			}
			if (op_arg[0]==0xf6)
			{
				op_arg[1]=getc(fp);
				op_arg[2]=getc(fp);
				op_arg[3]=getc(fp);
				op_arg[4]=getc(fp);
				fprintf(outfp,",%x,%x,%x,%x)\n",op_arg[1],op_arg[2],op_arg[3],
					op_arg[4]);
				break;
			}
				fprintf(outfp,")\t\t// UNKNOWN\n");
			break;
		case JMPF:		/* Jump Forward */
			fprintf(outfp,"\tjmpf(%x)\n\n",getc(fp)+addr+1);
			break;
		case JMPFL:
			read_arg(fp,2);
			fprintf(outfp,"\tjmpfl(%x)\n\n",
				comb_long(op_arg[0],op_arg[1])+addr+1);
			break;
		case JMPB:		/* Jump Backward*/
			fprintf(outfp,"\tjmpb(%x)\n\n",addr-getc(fp));
			break;
		case JMPBL:
			read_arg(fp,2);
			fprintf(outfp,"\tjmpbl(%x)\n\n",
				(addr - (comb_long(op_arg[0],op_arg[1]))));
			break;
		case IFUB:
			read_arg(fp,5);
			mem_split(op_arg[0]);
			fprintf(outfp,"\tif-ub([%x]<%x>",high_split,op_arg[1]);
			print_cond(outfp,op_arg[3]);
			fprintf(outfp,"%x then cont; else jmp %x)\n",op_arg[2],
				op_arg[4]+(addr+5));


			//fprintf(outfp,"\tif-ub(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			//op_arg[2],op_arg[3],op_arg[4]);
			break;
		case IFUBL:
			read_arg(fp,6);
			mem_split(op_arg[0]);
			fprintf(outfp,"\tif-ubl([%x]<%x>",high_split,op_arg[1]);
			print_cond(outfp,op_arg[3]);
			fprintf(outfp,"%x then cont; else jmpl %x)\n",op_arg[2],
				comb_long(op_arg[4],op_arg[5])+(addr+5));
			break;
		case IFSW:
			read_arg(fp,7);
			fprintf(outfp,"\tif-sw(%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6]);
			break;
		case IFSWL:
			read_arg(fp,8);
			fprintf(outfp,"\tif-swl(%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7]);
			break;
		case IFUW:
			read_arg(fp,7);
			fprintf(outfp,"\tif-uw(%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6]);
			break;
		case IFUWL:
			read_arg(fp,8);
			fprintf(outfp,"\tif-uwl(%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7]);
			break;
		case x1Ax:
			fprintf(outfp,"\t?1A?\n");
			break;
		case x1Bx:
			fprintf(outfp,"\t?1B?\n");
			break;
		case x1Cx:
			fprintf(outfp,"\t?1C?\n");
			break;
		case x1Dx:
			fprintf(outfp,"\t?1D?\n");
			break;
		case x1Ex:
			fprintf(outfp,"\t?1E?\n");
			break;
		case x1Fx:
			fprintf(outfp,"\t?1F?\n");
			break;
		case MINIGAME:
			read_arg(fp,10);
			fprintf(outfp,"\tminigame(%x,%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",
			op_arg[0],op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],
			op_arg[6],op_arg[7],op_arg[8],op_arg[9]);
			break;
		case TUTOR:
			fprintf(outfp,"\ttutor(%x)\n",getc(fp));
			break;
		case BTMD2:
			read_arg(fp,4);
			fprintf(outfp,"\tmtmd2(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case BTRLD:
			read_arg(fp,2);
			fprintf(outfp,"\tbtrld(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case WAIT:
			read_arg(fp,2);
			fprintf(outfp,"\twait(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case NFADE:
			read_arg(fp,8);
			fprintf(outfp,"\tnfade(%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7]);
			break;
		case BLINK:
			fprintf(outfp,"\tblink(%x)\n",getc(fp));
			break;
		case BGMOVIE:
			fprintf(outfp,"\tbgmovie(%x)\n",getc(fp));
			break;
		case KAWAI:
			/* WARNING - This is a variable argument command */ 
			fprintf(outfp,"\tkawai(%x)\n",getc(fp));
			break;
		case KAWIW:
			fprintf(outfp,"\tkawiw\n");
			break;
		case PMOVA:
			fprintf(outfp,"\tpmova(%x)\n",getc(fp));
			break;
		case SLIP:
			fprintf(outfp,"\tslip(%x)\n",getc(fp));
			break;
		case BGPDH:
			read_arg(fp,4);
			fprintf(outfp,"\tbgpdh(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case BGSCR:
			read_arg(fp,6);
			fprintf(outfp,"\tbgscr(%x,%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4],op_arg[5]);
			break;
		case WCLS:
			fprintf(outfp,"\twcls(%x)\n",getc(fp));
			break;
		case WSIZW:
			read_arg(fp,9);
			fprintf(outfp,"\twsizw(%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7],op_arg[8]);
			break;
		case IFKEY:
			read_arg(fp,3);
			fprintf(outfp,"\tif-key(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case IFKEYON:
			read_arg(fp,3);
			fprintf(outfp,"\tif-keyon(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case IFKEYOFF:
			read_arg(fp,3);
			fprintf(outfp,"\tif-keyoff(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case UC:
			fprintf(outfp,"\tuc(%x)\n",getc(fp));
			break;
		case PDIRA:
			fprintf(outfp,"\tpdira(%x)\n",getc(fp));
			break;
		case PTURA:
			read_arg(fp,3);
			fprintf(outfp,"\tptura(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case WSPCL:
			read_arg(fp,4);
			fprintf(outfp,"\twspcl(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case WNUMB:
			read_arg(fp,7);
			fprintf(outfp,"\twnumb(%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6]);
			break;
		case STTIM:
			read_arg(fp,5);
			fprintf(outfp,"\tsttim(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case GOLDu:
			read_arg(fp,5);
			fprintf(outfp,"\tgold+(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case GOLDd:
			read_arg(fp,5);
			fprintf(outfp,"\tgold-(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case CHGLD:
			read_arg(fp,3);
			fprintf(outfp,"\tchgld(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case HMPMAX1:
			fprintf(outfp,"\thmpmax1\n");
			break;
		case HMPMAX2:
			fprintf(outfp,"\thmpmax2\n");
			break;
		case MHMMX:
			fprintf(outfp,"\tmhmmx\n");
			break;
		case HMPMAX3:
			fprintf(outfp,"\thmpmax3\n");
			break;
		case MESSAGE:
			read_arg(fp,2);
			fprintf(outfp,"\tmessage(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case MPARA:
			read_arg(fp,4);
			fprintf(outfp,"\tmpara(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case MPRA2:
			read_arg(fp,5);
			fprintf(outfp,"\tmpra2(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case MPNAM:
			fprintf(outfp,"\tmpnam(%x)\n",getc(fp));
			break;
		case x44x:
			fprintf(outfp,"\t?44?\n");
			break;
		case MPu:
			read_arg(fp,4);
			fprintf(outfp,"\tmp+(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case x46x:
			fprintf(outfp,"\t?46?\n");
			break;
		case MPd:
			read_arg(fp,4);
			fprintf(outfp,"\tmp-(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case ASK:
			read_arg(fp,6);
			fprintf(outfp,"\task(%x,%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4],op_arg[5]);
			break;
		case MENU:
			read_arg(fp,3);
			fprintf(outfp,"\tmenu(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case MENU2:
			fprintf(outfp,"\tmenu2(%x)\n",getc(fp));
			break;
		case BTLTB:
			fprintf(outfp,"\tbtltb(%x)\n",getc(fp));
			break;
		case x4Cx:
			fprintf(outfp,"\t?4C?\n");
			break;
		case HPu:
			read_arg(fp,4);
			fprintf(outfp,"\thp+(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case x4Ex:
			fprintf(outfp,"\t?4E?\n");
			break;
		case HPd:
			read_arg(fp,4);
			fprintf(outfp,"\thp-(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case WINDOW:
			read_arg(fp,9);
			fprintf(outfp,"\twindow(%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7],op_arg[8]);
			break;
		case WMOVE:
			read_arg(fp,5);
			fprintf(outfp,"\twmove(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case WMODE:
			read_arg(fp,3);
			fprintf(outfp,"\twmode(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case WREST:
			fprintf(outfp,"\twrest(%x)\n",getc(fp));
			break;
		case WCLSE:
			fprintf(outfp,"\twclse(%x)\n",getc(fp));
			break;
		case WROW:
			read_arg(fp,2);
			fprintf(outfp,"\twrow(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case GWCOL:
			read_arg(fp,6);
			fprintf(outfp,"\tgwcol(%x,%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4],op_arg[5]);
			break;
		case SWCOL:
			read_arg(fp,6);
			fprintf(outfp,"\tswcol(%x,%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4],op_arg[5]);
			break;
		case STITM:
			read_arg(fp,4);
			fprintf(outfp,"\tst-itm(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case DLITM:
			read_arg(fp,4);
			fprintf(outfp,"\tdl-itm(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case CKITM:
			read_arg(fp,4);
			fprintf(outfp,"\tck-itm(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case SMTRA:
			read_arg(fp,6);
			fprintf(outfp,"\ts-mtra(%x,%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4],op_arg[5]);
			break;
		case DMTRA:
			read_arg(fp,7);
			fprintf(outfp,"\td-mtra(%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6]);
			break;
		case CMTRA:
			read_arg(fp,9);
			fprintf(outfp,"\tc-mtra(%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7],op_arg[8]);
			break;
		case SHAKE:
			read_arg(fp,7);
			fprintf(outfp,"\tshake(%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6]);
			break;
		case NOP:
			fprintf(outfp,"\tnop\n");
			break;
		case MAPJUMP:
			read_arg(fp,9);
			fprintf(outfp,"\tmapjump(%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7],op_arg[8]);
			break;
		case SCRLO:
			fprintf(outfp,"\tscrlo(%x)\n",getc(fp));
			break;
		case SCRLC:
			read_arg(fp,4);
			fprintf(outfp,"\tscrlc(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case SCRLA:
			read_arg(fp,5);
			fprintf(outfp,"\tscrla(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case SCR2D:
			read_arg(fp,5);
			fprintf(outfp,"\tscr2d(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case SCRCC:
			fprintf(outfp,"\tscrcc\n");
			break;
		case SCR2DC:
			read_arg(fp,8);
			fprintf(outfp,"\tscr2dc(%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7]);
			break;
		case SCRLW:
			fprintf(outfp,"\tscrlw\n");
			break;
		case SCR2DL:
			read_arg(fp,8);
			fprintf(outfp,"\tscr2dl(%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7]);
			break;
		case MPDSP:
			fprintf(outfp,"\tmpdsp(%x)\n",getc(fp));
			break;
		case VWOFT:
			read_arg(fp,6);
			fprintf(outfp,"\tvwoft(%x,%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4],op_arg[5]);
			break;
		case FADE:
			read_arg(fp,8);
			fprintf(outfp,"\tfade(%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7]);
			break;
		case FADEW:
			fprintf(outfp,"\tfadew\n");
			break;
		case IDLCK:
			read_arg(fp,3);
			fprintf(outfp,"\tidlck(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case LSTMP:
			read_arg(fp,2);
			fprintf(outfp,"\tlstmp(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case SCRLP:
			read_arg(fp,5);
			fprintf(outfp,"\tscrlp(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case BATTLE:
			read_arg(fp,3);
			fprintf(outfp,"\tbattle(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case BTLON:
			fprintf(outfp,"\tbtlon(%x)\n",getc(fp));
			break;
		case BTLMD:
			read_arg(fp,2);
			fprintf(outfp,"\tbtlmd(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case PGTDR:
			read_arg(fp,3);
			fprintf(outfp,"\tpgtdr(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case GETPC:
			read_arg(fp,3);
			fprintf(outfp,"\tgetpc(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case PXYZI:
			read_arg(fp,7);
			fprintf(outfp,"\tpxyzi(%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6]);
			break;
		case PLUSx:
			read_arg(fp,3);
			fprintf(outfp,"\tplus!(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case PLUS2x:
			read_arg(fp,4);
			fprintf(outfp,"\tplus2!(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case MINUSx:
			read_arg(fp,3);
			fprintf(outfp,"\tminus!(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case MINUS2x:
			read_arg(fp,4);
			fprintf(outfp,"\tminus2!(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case INCx:
			read_arg(fp,2);
			fprintf(outfp,"\tinc!(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case INC2x:
			read_arg(fp,2);
			fprintf(outfp,"\tinc2!(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case DECx:
			read_arg(fp,2);
			fprintf(outfp,"\tdec!(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case DEC2x:
			read_arg(fp,2);
			fprintf(outfp,"\tdec2!(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case TLKON:
			fprintf(outfp,"\ttlkon(%x)\n",getc(fp));
			break;
		case RDMSD:
			read_arg(fp,2);
			fprintf(outfp,"\trdmsd(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case SETBYTE:
			read_arg(fp,3);
			fprintf(outfp,"\tset-byte(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case SETWORD:
			read_arg(fp,4);
			fprintf(outfp,"\tset-word(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case BITON:
			read_arg(fp,3);
			fprintf(outfp,"\tbit-on(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case BITOFF:
			read_arg(fp,3);
			fprintf(outfp,"\tbit-off(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case BITXOR:
			read_arg(fp,3);
			fprintf(outfp,"\tbit-xor(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case PLUS:
			read_arg(fp,3);
			fprintf(outfp,"\tplus(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case PLUS2:
			read_arg(fp,4);
			fprintf(outfp,"\tplus2(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case MINUS:
			read_arg(fp,3);
			fprintf(outfp,"\tminus(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case MINUS2:
			read_arg(fp,4);
			fprintf(outfp,"\tminus2(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case MUL:
			read_arg(fp,3);
			fprintf(outfp,"\tmul(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case MUL2:
			read_arg(fp,4);
			fprintf(outfp,"\tmul2(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case DIV:
			read_arg(fp,3);
			fprintf(outfp,"\tdiv(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case DIV2:
			read_arg(fp,4);
			fprintf(outfp,"\tdiv2(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case MOD:
			read_arg(fp,3);
			fprintf(outfp,"\tmod(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case MOD2:
			read_arg(fp,4);
			fprintf(outfp,"\tmod2(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case AND:
			read_arg(fp,3);
			fprintf(outfp,"\tand(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case AND2:
			read_arg(fp,4);
			fprintf(outfp,"\tand2(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case OR:
			read_arg(fp,3);
			fprintf(outfp,"\tor(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case OR2:
			read_arg(fp,4);
			fprintf(outfp,"\tor2(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case XOR:
			read_arg(fp,3);
			fprintf(outfp,"\txor(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case XOR2:
			read_arg(fp,4);
			fprintf(outfp,"\txor2(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case INC:
			read_arg(fp,2);
			fprintf(outfp,"\tinc(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case INC2:
			read_arg(fp,2);
			fprintf(outfp,"\tinc2(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case DEC:
			read_arg(fp,2);
			fprintf(outfp,"\tdec(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case DEC2:
			read_arg(fp,2);
			fprintf(outfp,"\tdec2(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case RANDOM:
			read_arg(fp,2);
			fprintf(outfp,"\trandom(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case LBYTE:
			read_arg(fp,3);
			fprintf(outfp,"\tlbyte(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case HBYTE:
			read_arg(fp,4);
			fprintf(outfp,"\thbyte(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case TWOBYTE:
			read_arg(fp,5);
			fprintf(outfp,"\ttwobyte(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case SETX:
			read_arg(fp,6);
			fprintf(outfp,"\tsetx(%x,%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4],op_arg[5]);
			break;
		case GETX:
			read_arg(fp,6);
			fprintf(outfp,"\tgetx(%x,%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4],op_arg[5]);
			break;
		case SEARCHX:
			read_arg(fp,10);
			fprintf(outfp,"\tsearchx(%x,%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",
			op_arg[0],op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],
			op_arg[6],op_arg[7],op_arg[8],op_arg[9]);
			break;
		case PC:
			fprintf(outfp,"\tpc(%d)\n",getc(fp));
			break;
		case CHAR:
			fprintf(outfp,"\tchar(%d)\n",getc(fp));
			break;
		case DFANM:
			read_arg(fp,2);
			fprintf(outfp,"\tdfanm(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case ANIME1:
			read_arg(fp,2);
			fprintf(outfp,"\tanime1(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case VISI:
			fprintf(outfp,"\tvisi(%d)\n",getc(fp));
			break;
		case XYZI:
			read_arg(fp,10);
			fprintf(outfp,"\txyzi(%x,%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",
			op_arg[0],op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],
			op_arg[6],op_arg[7],op_arg[8],op_arg[9]);
			break;
		case XYI:
			read_arg(fp,8);
			fprintf(outfp,"\txyi(%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7]);
			break;
		case XYZ:
			read_arg(fp,8);
			fprintf(outfp,"\txyz(%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7]);
			break;
		case MOVE:
			read_arg(fp,5);
			fprintf(outfp,"\tmove(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case CMOVE:
			read_arg(fp,5);
			fprintf(outfp,"\tcmove(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case MOVA:
			fprintf(outfp,"\tmova(%x)\n",getc(fp));
			break;
		case TURA:
			read_arg(fp,3);
			fprintf(outfp,"\ttura(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case ANIMW:
			fprintf(outfp,"\tanimw\n");
			break;
		case FMOVE:
			read_arg(fp,5);
			fprintf(outfp,"\tfmove(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case ANIME2:
			read_arg(fp,2);
			fprintf(outfp,"\tanime2(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case ANIMx1:
			read_arg(fp,2);
			fprintf(outfp,"\tanim!1(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case CANIM1:
			read_arg(fp,4);
			fprintf(outfp,"\tcanim1(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case CANMx1:
			read_arg(fp,4);
			fprintf(outfp,"\tcanm!1(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case MSPED:
			read_arg(fp,3);
			fprintf(outfp,"\tmsped(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case DIR:
			read_arg(fp,2);
			fprintf(outfp,"\tdir(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case TURNGEN:
			read_arg(fp,5);
			fprintf(outfp,"\tturngen(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case TURN:
			read_arg(fp,5);
			fprintf(outfp,"\tturn(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case DIRA:
			fprintf(outfp,"\tdira(%x)\n",getc(fp));
			break;
		case GETDIR:
			read_arg(fp,3);
			fprintf(outfp,"\tgetdir(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case GETAXY:
			read_arg(fp,4);
			fprintf(outfp,"\tgetaxy(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case GETAI:
			read_arg(fp,3);
			fprintf(outfp,"\tgetai(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case ANIMx2:
			read_arg(fp,2);
			fprintf(outfp,"\tanim!2(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case CANIM2:
			read_arg(fp,4);
			fprintf(outfp,"\tcanim2(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case CANMx2:
			read_arg(fp,4);
			fprintf(outfp,"\tcanm!2(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case ASPED:
			read_arg(fp,3);
			fprintf(outfp,"\tasped(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case xBEx:
			fprintf(outfp,"\t?BE?\n");
			break;
		case CC:
			fprintf(outfp,"\tcc(%x)\n",getc(fp));
			break;
		case JUMP:
			read_arg(fp,10);
			fprintf(outfp,"\tjump(%x,%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",
			op_arg[0],op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],
			op_arg[6],op_arg[7],op_arg[8],op_arg[9]);
			break;
		case AXYZI:
			read_arg(fp,7);
			fprintf(outfp,"\taxyzi(%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6]);
			break;
		case LADER:
			read_arg(fp,14);
			fprintf(outfp,
			"\tlader(%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",
			op_arg[0],op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],
			op_arg[6],op_arg[7],op_arg[8],op_arg[9],op_arg[10],op_arg[11],
			op_arg[12],op_arg[13]);
			break;
		case OFST:
			read_arg(fp,11);
			fprintf(outfp,"\tofst(%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",
			op_arg[0],op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],
			op_arg[6],op_arg[7],op_arg[8],op_arg[9],op_arg[10]);
			break;
		case OFSTW:
			fprintf(outfp,"\tofstw\n");
			break;
		case TALKR:
			read_arg(fp,2);
			fprintf(outfp,"\ttalkr(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case SLIDR:
			read_arg(fp,2);
			fprintf (outfp,"\tslidr(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case SOLID:
			fprintf (outfp,"\tsolid(%d)\n",getc(fp));
			break;
		case PRTYP:
			/* Party Player */
			fprintf (outfp,"\tprtyp(%x)\n",getc(fp));
			break;
		case PRTYM:
			fprintf (outfp,"\tprtym(%x)\n",getc(fp));
			break;
		case PRTYE:
			read_arg(fp,3);
			fprintf(outfp,"\tprtye(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case IFPRTYQ:
			read_arg(fp,2);
			fprintf(outfp,"\tif-prtyq(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case IFMEMBQ:
			read_arg(fp,2);
			fprintf(outfp,"\tif-membq(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case MMBud:
			read_arg(fp,2);
			fprintf(outfp,"\tmmb+-(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case MMBLK:
			fprintf (outfp,"\tmmblk(%x)\n",getc(fp));
			break;
		case MMBUK:
			fprintf (outfp,"\tmmbuk(%x)\n",getc(fp));
			break;
		case LINE:
			read_arg(fp,12);
			fprintf(outfp,"\tline(%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",
			op_arg[0],op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],
			op_arg[6],op_arg[7],op_arg[8],op_arg[9],op_arg[10],op_arg[11]);
			break;
		case LINON:
			fprintf (outfp,"\tlinon(%x)\n",getc(fp));
			break;
		case MPJPO:
			fprintf (outfp,"\tmpjpo(%x)\n",getc(fp));
			break;
		case SLINE:
			read_arg(fp,15);
			fprintf(outfp,
			"\tsline(%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",
			op_arg[0],op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],
			op_arg[6],op_arg[7],op_arg[8],op_arg[9],op_arg[10],op_arg[11],
			op_arg[12],op_arg[13],op_arg[14]);
			break;
		case SIN:
			read_arg(fp,9);
			fprintf(outfp,"\tsin(%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7],op_arg[8]);
			break;
		case COS:
			read_arg(fp,9);
			fprintf(outfp,"\tcos(%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7],op_arg[8]);
			break;
		case TLKR2:
			read_arg(fp,3);
			fprintf(outfp,"\ttlkr2(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case SLDR2:
			read_arg(fp,3);
			fprintf(outfp,"\tsldr2(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case PMJMP:
			read_arg(fp,2);
			fprintf(outfp,"\tpmjmp(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case PMJMP2:
			fprintf(outfp,"\tpmjmp2\n");
			break;
		case AKAO2:
			read_arg(fp,14);
			fprintf(outfp,
			"\takao2(%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",
			op_arg[0],op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],
			op_arg[6],op_arg[7],op_arg[8],op_arg[9],op_arg[10],op_arg[11],
			op_arg[12],op_arg[13]);
			break;
		case FCFIX:
			fprintf (outfp,"\tfcfix(%x)\n",getc(fp));
			break;
		case CCANM:
			read_arg(fp,3);
			fprintf(outfp,"\tccanm(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case ANIMB:
			fprintf(outfp,"\tanimb\n");
			break;
		case TURNW:
			fprintf(outfp,"\ttrunw\n");
			break;
		case MPPAL:
			read_arg(fp,10);
			fprintf(outfp,"\tmppal(%x,%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",
			op_arg[0],op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],
			op_arg[6],op_arg[7],op_arg[8],op_arg[9]);
			break;
		case BGON:
			read_arg(fp,3);
			fprintf(outfp,"\tbgon(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case BGOFF:
			read_arg(fp,3);
			fprintf(outfp,"\tbgoff(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case BGROL:
			read_arg(fp,2);
			fprintf(outfp,"\tbgrol(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case BGROL2:
			read_arg(fp,2);
			fprintf(outfp,"\tbgrol2(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case BGCLR:
			read_arg(fp,2);
			fprintf(outfp,"\tbgclr(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case STPAL:
			read_arg(fp,4);
			fprintf(outfp,"\tstpal(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case LDPAL:
			read_arg(fp,4);
			fprintf(outfp,"\tldpal(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case CPPAL:
			read_arg(fp,4);
			fprintf(outfp,"\tcppal(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case RTPAL:
			read_arg(fp,6);
			fprintf(outfp,"\trtpal(%x,%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4],op_arg[5]);
			break;
		case ADPAL:
			read_arg(fp,9);
			fprintf(outfp,"\tadpal(%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7],op_arg[8]);
			break;
		case MPPAL2:
			read_arg(fp,9);
			fprintf(outfp,"\tmppal2(%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6],
			op_arg[7],op_arg[8]);
			break;
		case STPLS:
			read_arg(fp,4);
			fprintf(outfp,"\tstpls(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case LDPLS:
			read_arg(fp,4);
			fprintf(outfp,"\tldpls(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case CPPAL2:
			read_arg(fp,7);
			fprintf(outfp,"\tcppal2(%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6]);
			break;
		case RTPAL2:
			read_arg(fp,7);
			fprintf(outfp,"\trtpal2(%x,%x,%x,%x,%x,%x,%x)\n",op_arg[0],
			op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],op_arg[6]);
			break;
		case ADPAL2:
			read_arg(fp,10);
			fprintf(outfp,"\tadpal2(%x,%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",
			op_arg[0],op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],
			op_arg[6],op_arg[7],op_arg[8],op_arg[9]);
			break;
		case MUSIC:
			fprintf (outfp,"\tmusic(%x)\n",getc(fp));
			break;
		case SOUND:
			read_arg(fp,4);
			fprintf(outfp,"\tsound(%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3]);
			break;
		case AKAO:
			read_arg(fp,13);
			fprintf(outfp,"\takao(%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x)\n",
			op_arg[0],op_arg[1],op_arg[2],op_arg[3],op_arg[4],op_arg[5],
			op_arg[6],op_arg[7],op_arg[8],op_arg[9],op_arg[10],op_arg[11],
			op_arg[12]);
			break;
		case MUSVT:
			fprintf (outfp,"\tmusvt(%x)\n",getc(fp));
			break;
		case MUSVM:
			fprintf (outfp,"\tmusvm(%x)\n",getc(fp));
			break;
		case MULCK:
			fprintf (outfp,"\tmulck(%x)\n",getc(fp));
			break;
		case BMUSC:
			fprintf (outfp,"\tbmusc(%x)\n",getc(fp));
			break;
		case CHMPH:
			read_arg(fp,3);
			fprintf(outfp,"\tchmph(%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2]);
			break;
		case PMVIE:
			fprintf (outfp,"\tpmvie(%x)\n",getc(fp));
			break;
		case MOVIE:
			fprintf (outfp,"\tmovie(%x)\n",getc(fp));
			break;
		case MVIEF:
			read_arg(fp,2);
			fprintf(outfp,"\tmvief(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case MVCAM:
			fprintf (outfp,"\tmvcam(%x)\n",getc(fp));
			break;
		case FMUSC:
			fprintf (outfp,"\tfmusc(%x)\n",getc(fp));
			break;
		case CMUSC:
			read_arg(fp,5);
			fprintf(outfp,"\tcmusc(%x,%x,%x,%x,%x)\n",op_arg[0],op_arg[1],
			op_arg[2],op_arg[3],op_arg[4]);
			break;
		case CHMST:
			read_arg(fp,2);
			fprintf(outfp,"\tchmst(%x,%x)\n",op_arg[0],op_arg[1]);
			break;
		case GAMEOVER:
			fprintf(outfp,"\tgameover\n");
			break;
	}

}
