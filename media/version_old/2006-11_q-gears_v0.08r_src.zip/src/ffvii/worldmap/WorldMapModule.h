// $Id: WorldMapModule.h 93 2006-11-12 13:49:02Z einherjar $

#ifndef WORLD_MAP_MODULE_h
#define WORLD_MAP_MODULE_h



#include "../../common/module/Module.h"




class WorldMapModule : public Module
{
public:
    WorldMapModule(void);
    virtual ~WorldMapModule(void);

    virtual void Init(void);

    virtual void Draw(void);

    virtual void Input(const InputEvent& input);

    virtual void Update(const u32& deltaTime);


};



#endif //  WORLD_MAP_MODULE_h
