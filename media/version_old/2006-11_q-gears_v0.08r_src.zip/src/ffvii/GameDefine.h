// $Id: GameDefine.h 94 2006-11-12 19:44:43Z crazy_otaku $

#ifndef GAME_DEFINE_H
#define GAME_DEFINE_H



#define APPLICATION_NAME "FFVII v0.08"



#endif // GAME_DEFINE_H
