// $Id: Menu.cpp 94 2006-11-12 19:44:43Z crazy_otaku $

#include "Menu.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

Menu::Menu(void)
{
    Init();
}



Menu::~Menu(void)
{
}



//============================= OPERATIONS ===================================

void
Menu::Init(void)
{
}



void
Menu::Draw(void)
{
}



void
Menu::Input(const InputEvent &input)
{
}



void
Menu::Update(const u32& deltaTime)
{
}
