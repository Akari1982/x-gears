// $Id: Kernel.cpp 94 2006-11-12 19:44:43Z crazy_otaku $

#include "Kernel.h"
#include "Database.h"
#include "../filetypes/BinGZipFile.h"
#include "../filetypes/TimFile.h"
#include "../../common/display/Display.h"
#include "../../common/display/surface/Surface.h"
#include "../../common/display/surface/SurfaceSaveBmp.h"
#include "../../common/utilites/Logger.h"
#include "../../common/utilites/StdString.h"
#include "../../common/utilites/Utilites.h"



Kernel* KERNEL = NULL; // global and accessable from anywhere in our program



Kernel::Kernel()
{
    Init();
}



Kernel::~Kernel()
{
    delete mGuiAvatar;
    delete mGuiBar;
    delete mGuiBarExp;
    delete mGuiCounter;
    delete mGuiDigit;
    delete mGuiPointer;
    delete mGuiSlash;
    delete mGuiTriangle;
    delete mBattleFont;
    delete mFont;
    delete mWindow;
}



void
Kernel::Init()
{
    InitDatabase();
    InitGraphics();
}



void
Kernel::Update()
{
    mGamestate.Update();
}



Database&
Kernel::GetDatabase()
{
    return mDatabase;
}



Gamestate&
Kernel::GetGamestate()
{
    return mGamestate;
}



void
Kernel::SetFrontScreen()
{
    DISPLAY->PushMatrix();
    DISPLAY->LoadIdentity();
    DISPLAY->Translate(-1.0f, 1.0f, 0.0f);
    DISPLAY->Scale(2.0f/640.0f, 2.0f/480.0f, 1.0f);

    DISPLAY->CameraPushMatrix();
    DISPLAY->CameraLoadIdentity();
    DISPLAY->TexturePushMatrix();
    DISPLAY->TextureLoadIdentity();
}



void
Kernel::UnsetFrontScreen()
{
    DISPLAY->TexturePopMatrix();
    DISPLAY->CameraPopMatrix();
    DISPLAY->PopMatrix();
}



void
Kernel::DrawAvatar(const int &x, const int &y, const unsigned char &avatar_id)
{
    SetFrontScreen();
    mGuiAvatar->DrawAvatar(x, y, avatar_id);
    UnsetFrontScreen();
}



void
Kernel::DrawBar(const int &x, const int &y, const unsigned int &cur, const unsigned int &max, const BarType &type)
{
    SetFrontScreen();
    mGuiBar->DrawBar(x, y, cur, max, type);
    UnsetFrontScreen();
}



void
Kernel::DrawBarExp(const int &x, const int &y, const unsigned int &cur, const unsigned int &max, const BarExpType &type)
{
    SetFrontScreen();
    mGuiBarExp->DrawBarExp(x, y, cur, max, type);
    UnsetFrontScreen();
}



void
Kernel::DrawBattleString(const RString &string, const int &x, const int &y, const BattleFontColor &color)
{
    SetFrontScreen();
    mBattleFont->DrawString(string, x, y, color);
    UnsetFrontScreen();
}


void
Kernel::DrawTriangle(const int& x, const int& y, const u8& frame, const TriangleColor &color)
{
    SetFrontScreen();
    mGuiTriangle->Draw(x, y, frame, color);
    UnsetFrontScreen();
}



void
Kernel::DrawString(const FFVIIString& string, const int& x, const int& y, const FontColor& color, const int& size)
{
    SetFrontScreen();
    mFont->DrawString(string, x, y, color, size);
    UnsetFrontScreen();
}



void
Kernel::DrawWindow(const int& x, const int& y, const int& width, const int& height, const bool& opacity)
{
    SetFrontScreen();
    mWindow->DrawWindow(x, y, width, height, opacity);
    UnsetFrontScreen();
}



void
Kernel::DrawPointer(const int& x, const int& y, const PointerType& type)
{
    SetFrontScreen();
    mGuiPointer->DrawPointer(x, y, type);
    UnsetFrontScreen();
}



void
Kernel::DrawSlash(const int& x, const int& y)
{
    SetFrontScreen();
    mGuiSlash->DrawSlash(x, y);
    UnsetFrontScreen();
}



void
Kernel::DrawCounter(const int &x, const int &y, const RString &string)
{
    SetFrontScreen();
    mGuiCounter->DrawCounter(x, y, string);
    UnsetFrontScreen();
}



void
Kernel::DrawDigit(const int &x, const int &y, const RString &string)
{
    SetFrontScreen();
    mGuiDigit->DrawDigit(x, y, string);
    UnsetFrontScreen();
}



void
Kernel::LoadSavemap(File* file)
{
    unsigned char* temp = reinterpret_cast<unsigned char*>(&(mGamestate.mSavemap));
    file->GetFileBuffer(temp, 0, file->GetFileSize());
}



void
Kernel::InitDatabase()
{
    BinGZipFile* kernel_file = new BinGZipFile("data/INIT/KERNEL.BIN");

    File* file;



    // set savemap

//    file = kernel_file->ExtractGZip(3);
//    file->WriteFile("03");
//    unsigned char* temp = reinterpret_cast<unsigned char*>(&(mGamestate.mSavemap)) + 0x54;
//    file->GetFileBuffer(temp, 0, file->GetFileSize());
//    delete file;

    File* save_file = new File("data/savemap");
    LoadSavemap(save_file);
//    mGamestate.DumpSavemap();
    delete save_file;



    // load commands
    file = kernel_file->ExtractGZip(0);
    int file_size = file->GetFileSize();
    for (int i = 0; i < file_size; i += 16)
    {
        DBCommand data;
        file->GetFileBuffer(reinterpret_cast<unsigned char*>(&data), i, 16);
        mDatabase.mCommands.push_back(data);
    }
    delete file;

    // load attacks
    file = kernel_file->ExtractGZip(1);
    file_size = file->GetFileSize();
    for (int i = 0; i < file_size; i += 28)
    {
        DBAttack data;
        file->GetFileBuffer(reinterpret_cast<unsigned char*>(&data), i, 28);
        mDatabase.mAttacks.push_back(data);
    }
    delete file;

    // load items
    file = kernel_file->ExtractGZip(4);
    file_size = file->GetFileSize();
    for (int i = 0; i < file_size; i += 27)
    {
        DBItem data;
        file->GetFileBuffer(reinterpret_cast<unsigned char*>(&data), i, 27);
        mDatabase.mItems.push_back(data);
    }
    delete file;

    // load weapons
    file = kernel_file->ExtractGZip(5);
    file_size = file->GetFileSize();
    for (int i = 0; i < file_size; i += 44)
    {
        DBWeapon data;
        file->GetFileBuffer(reinterpret_cast<unsigned char*>(&data), i, 44);
        mDatabase.mWeapons.push_back(data);
    }
    delete file;

    // load armors
    file = kernel_file->ExtractGZip(6);
    file_size = file->GetFileSize();
    for (int i = 0; i < file_size; i += 36)
    {
        DBArmor data;
        file->GetFileBuffer(reinterpret_cast<unsigned char*>(&data), i, 36);
        mDatabase.mArmors.push_back(data);
    }
    delete file;

    // load accessorys
    file = kernel_file->ExtractGZip(7);
    file_size = file->GetFileSize();
    for (int i = 0; i < file_size; i += 16)
    {
        DBAccessory data;
        file->GetFileBuffer(reinterpret_cast<unsigned char*>(&data), i, 16);
        mDatabase.mAccessorys.push_back(data);
    }
    delete file;

    // load materias
    file = kernel_file->ExtractGZip(8);
    file_size = file->GetFileSize();
    for (int i = 0; i < file_size; i += 20)
    {
        DBMateria data;
        file->GetFileBuffer(reinterpret_cast<unsigned char*>(&data), i, 20);
        mDatabase.mMaterias.push_back(data);
    }
    delete file;

    // load commands descriptions
    file = kernel_file->ExtractGZip(9);
    LoadKernelString(mDatabase.mCommandDescriptions, file);
    delete file;

    // load magic descriptions
    file = kernel_file->ExtractGZip(10);
    LoadKernelString(mDatabase.mMagicDescriptions, file);
    delete file;

    // load item descriptions
    file = kernel_file->ExtractGZip(11);
    LoadKernelString(mDatabase.mItemDescriptions, file);
    delete file;

    // load weapon descriptions
    file = kernel_file->ExtractGZip(12);
    LoadKernelString(mDatabase.mWeaponDescriptions, file);
    delete file;

    // load armor descriptions
    file = kernel_file->ExtractGZip(13);
    LoadKernelString(mDatabase.mArmorDescriptions, file);
    delete file;

    // load accessory descriptions
    file = kernel_file->ExtractGZip(14);
    LoadKernelString(mDatabase.mAccessoryDescriptions, file);
    delete file;

    // load materia descriptions
    file = kernel_file->ExtractGZip(15);
    LoadKernelString(mDatabase.mMateriaDescriptions, file);
    delete file;

    // load key item descriptions
    file = kernel_file->ExtractGZip(16);
    LoadKernelString(mDatabase.mKeyItemDescriptions, file);
    delete file;

    // load command names
    file = kernel_file->ExtractGZip(17);
    LoadKernelString(mDatabase.mCommandNames, file);
    delete file;

    // load magic names
    file = kernel_file->ExtractGZip(18);
    LoadKernelString(mDatabase.mMagicNames, file);
    delete file;

    // load item names
    file = kernel_file->ExtractGZip(19);
    LoadKernelString(mDatabase.mItemNames, file);
    delete file;

    // load weapon names
    file = kernel_file->ExtractGZip(20);
    LoadKernelString(mDatabase.mWeaponNames, file);
    delete file;

    // load armor names
    file = kernel_file->ExtractGZip(21);
    LoadKernelString(mDatabase.mArmorNames, file);
    delete file;

    // load accessory names
    file = kernel_file->ExtractGZip(22);
    LoadKernelString(mDatabase.mAccessoryNames, file);
    delete file;

    // load materia names
    file = kernel_file->ExtractGZip(23);
    LoadKernelString(mDatabase.mMateriaNames, file);
    delete file;

    // load key item names
    file = kernel_file->ExtractGZip(24);
    LoadKernelString(mDatabase.mKeyItemNames, file);
    delete file;

    // load battle text
    file = kernel_file->ExtractGZip(25);
    LoadKernelString(mDatabase.mBattleText, file);
    delete file;

    // load summon names
    file = kernel_file->ExtractGZip(26);
    LoadKernelString(mDatabase.mSummonNames, file);
    delete file;

    delete kernel_file;
}



void
Kernel::LoadKernelString(std::vector<FFVIIString> &string_vector, File* &file)
{
    unsigned int offset;
    unsigned int file_size;
    unsigned int i;

    // get command description
    file_size = file->GetFileSize();
    i = 0;
    while (1)
    {
        // get offset of string data
        offset = file->GetU16LE(i * 0x02);

        // if we reached end of file stop the process
        if (offset >= file_size - 1)
        {
            break;
        }

        // read the string and add it to database
        FFVIIString name;
        for (unsigned char temp = 0x00; temp != 0xFF; ++offset)
        {
            temp = file->GetU8(offset);

            if (temp == 0xF9)
            {
                // simple string compression, reference an earlier substring
                ++offset;
                int dist  = (file->GetU8(offset) & 0x3F) + 2;

                int count = (file->GetU8(offset) >> 6) * 2 + 4;
                for (int k = 0; (k < count) && (file->GetU8(offset - dist + k) != 0xFF); ++k)
                {
                    name.push_back(file->GetU8(offset - dist + k));
                }
            }
            else if (temp == 0xF8)
            {
                ++offset;
                ++offset;
//                LOGGER->Log("Unknown text opcode 0xF8.");
            }
            else
            {
                name.push_back(temp);
            }
        }
        string_vector.push_back(name);

        ++i;
    }
}



void
Kernel::InitGraphics()
{
    BinGZipFile* file = new BinGZipFile("data/INIT/WINDOW.BIN");
    File* window_graf  = file->ExtractGZip(0);
    File* font_graf    = file->ExtractGZip(1);
    File* font_padding = file->ExtractGZip(2);
    delete file;

    TimFile* image = new TimFile(window_graf);
    delete window_graf;



    // Init window
    Surface* texture0 = image->GetSurface(0);
    if (texture0 != NULL)
    {
        mWindow = new DialogWindow(texture0);
    }
    else
    {
        LOGGER->Log("Can't load window texture.");
    }



    // Init pointer
    Surface* texture1 = image->GetSurface(1);
    Surface* texture7 = image->GetSurface(7);
    if (texture1 != NULL && texture7 != NULL)
    {
        mGuiPointer   = new GuiPointer(texture1, texture7);
        mGuiSlash     = new GuiSlash(texture1);
        delete texture1;
    }
    else
    {
        LOGGER->Log("Can't load pointer and slash texture.");
    }



    // Init battle font
    Surface* texture5 = image->GetSurface(5);
    if (texture0 != NULL && texture5 != NULL && texture7 != NULL)
    {
        mBattleFont = new BattleFont(texture0, texture5, texture7);
        mGuiDigit   = new GuiDigit(texture7);
        mGuiBarExp  = new GuiBarExp(texture7);
        delete texture0;
        delete texture5;
        delete texture7;
    }
    else
    {
        LOGGER->Log("Can't load battle font, digit and bar exp texture.");
    }



    // Init triangle
    Surface* texture8 = image->GetSurface(8);
    Surface* texture9 = image->GetSurface(9);
    if (texture8 != NULL && texture9 != NULL)
    {
        mGuiTriangle = new GuiTriangle(texture8, texture9);
        delete texture8;
        delete texture9;
    }
    else
    {
        LOGGER->Log("Can't load triangle texture.");
    }



    // Init counter
    Surface* texture12 = image->GetSurface(12);
    if (texture12 != NULL)
    {
        mGuiCounter = new GuiCounter(texture12);
        delete texture12;
    }
    else
    {
        LOGGER->Log("Can't load counter font texture.");
    }



    delete image;



    // Init usual font
    TimFile* image2 = new TimFile(font_graf);
    delete font_graf;



    Surface* texture2_0 = image2->GetSurface(0);
    Surface* texture2_5 = image2->GetSurface(5);
    Surface* texture2_7 = image2->GetSurface(7);

    if (texture2_0 != NULL && texture2_5 != NULL && texture2_7 != NULL && font_padding != NULL)
    {
        mFont = new Font(texture2_0, texture2_5, texture2_7, font_padding);
        delete texture2_0;
        delete texture2_5;
        delete texture2_7;
        delete font_padding;
    }
    else
    {
        LOGGER->Log("Can't load font texture.");
    }

    delete image2;



    mGuiAvatar = new GuiAvatar();
    mGuiBar    = new GuiBar();
}
