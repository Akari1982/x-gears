// $Id: GuiBar.h 93 2006-11-12 13:49:02Z einherjar $

#ifndef GUIBAR_H
#define GUIBAR_H



#include "../../../common/display/3dTypes.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/NoCopy.h"



enum BarType {HP_BAR, MP_BAR};



class GuiBar : public NoCopy<GuiBar>
{
public:
             GuiBar();
    virtual ~GuiBar();

    void     DrawBar(const int &x, const int &y, const unsigned int &cur, const unsigned int &max, const BarType &type);

private:
    std::vector<Vertex> mPolyHP;
    std::vector<Vertex> mPolyMP;
    std::vector<Vertex> mPolyBack;
    std::vector<Vertex> mPolyUnder;
};



#endif
