// $Id: GuiAvatar.h 93 2006-11-12 13:49:02Z einherjar $

#ifndef GUIAVATAR_H
#define GUIAVATAR_H



#include "../../../common/display/3dTypes.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/NoCopy.h"
#include "../../../common/utilites/StdString.h"



class GuiAvatar : public NoCopy<GuiAvatar>
{
public:
             GuiAvatar();
    virtual ~GuiAvatar();

    void     DrawAvatar(const int &x, const int &y, const unsigned char &avatar_id);

private:
    int      LoadAvatar(const RString &name);

private:
    int                 mAvatarTexId[12];
    std::vector<Vertex> mAvatarPoly;
};



#endif
