// $Id: FFVIIString.h 93 2006-11-12 13:49:02Z einherjar $

#ifndef FFVIISTRING_H
#define FFVIISTRING_H



#include "../../../common/utilites/StdString.h"

#include <vector>



typedef std::vector<unsigned char> FFVIIString;



// converter
FFVIIString RStringToFFVIIString(const RString &string);



#endif
