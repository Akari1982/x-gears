// $Id: DialogWindow.cpp 93 2006-11-12 13:49:02Z einherjar $

#include "DialogWindow.h"
#include "../Kernel.h"

#include "../../../common/display/3dTypes.h"
#include "../../../common/display/Display.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/Logger.h"



DialogWindow::DialogWindow(Surface* image):
    mBorderWidth(8.0f),
    mBorderHeight(8.0f)
{
    Surface* temp;

    // +---+---+---+
    // | 1 | 5 | 2 |
    // +---+---+---+
    // | 6 | 9 | 7 |
    // +---+---+---+
    // | 3 | 8 | 4 |
    // +---+---+---+

    // 1
    temp = CreateSubSurface(0, 232, 8, 8, image);
    mWindowTexId[0] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 2
    temp = CreateSubSurface(8, 232, 8, 8, image);
    mWindowTexId[1] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 3
    temp = CreateSubSurface(16, 224, 8, 8, image);
    mWindowTexId[2] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 4
    temp = CreateSubSurface(24, 224, 8, 8, image);
    mWindowTexId[3] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 5
    temp = CreateSubSurface(0, 224, 16, 8, image);
    mWindowTexId[4] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 6
    temp = CreateSubSurface(0, 240, 8, 16, image);
    mWindowTexId[5] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 7
    temp = CreateSubSurface(24, 240, 8, 16, image);
    mWindowTexId[6] = DISPLAY->CreateTexture(temp);
    delete temp;
    // 8
    temp = CreateSubSurface(16, 232, 16, 8, image);
    mWindowTexId[7] = DISPLAY->CreateTexture(temp);
    delete temp;



    Vertex point;
    point.p.x = 0.0f;         point.p.y = 0.0f;           point.p.z = 0.0f;
    point.c.r = 1.0f;         point.c.g = 1.0f;           point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f;         point.t.y = 0.0f;
    mWindowPoly.push_back(point);
    point.p.x = mBorderWidth; point.p.y = 0.0f;           point.p.z = 0.0f;
    point.c.r = 1.0f;         point.c.g = 1.0f;           point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;         point.t.y = 0.0f;
    mWindowPoly.push_back(point);
    point.p.x = mBorderWidth; point.p.y = -mBorderHeight; point.p.z = 0.0f;
    point.c.r = 1.0f;         point.c.g = 1.0f;           point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;         point.t.y = 1.0f;
    mWindowPoly.push_back(point);
    point.p.x = 0.0f;         point.p.y = -mBorderHeight; point.p.z = 0.0f;
    point.c.r = 1.0f;         point.c.g = 1.0f;           point.c.b = 1.0f; point.c.a =  1.0f;
    point.t.x = 0.0f;         point.t.y = 1.0f;
    mWindowPoly.push_back(point);
}



DialogWindow::~DialogWindow()
{
    DISPLAY->DeleteTexture(mWindowTexId[0]);
    DISPLAY->DeleteTexture(mWindowTexId[1]);
    DISPLAY->DeleteTexture(mWindowTexId[2]);
    DISPLAY->DeleteTexture(mWindowTexId[3]);
    DISPLAY->DeleteTexture(mWindowTexId[4]);
    DISPLAY->DeleteTexture(mWindowTexId[5]);
    DISPLAY->DeleteTexture(mWindowTexId[6]);
    DISPLAY->DeleteTexture(mWindowTexId[7]);
    DISPLAY->DeleteTexture(mWindowTexId[8]);
}



void
DialogWindow::DrawWindow(const int &x, const int &y, const int &width, const int &height, const bool& opacity)
{
    DISPLAY->Translate(x, -y, 0);
    DISPLAY->PushMatrix();

    // reset color and opacity settings
    mWindowPoly[0].c.r =  1.0f; mWindowPoly[0].c.g =  1.0f; mWindowPoly[0].c.b =  1.0f; mWindowPoly[0].c.a =  1.0f;
    mWindowPoly[1].c.r =  1.0f; mWindowPoly[1].c.g =  1.0f; mWindowPoly[1].c.b =  1.0f; mWindowPoly[1].c.a =  1.0f;
    mWindowPoly[2].c.r =  1.0f; mWindowPoly[2].c.g =  1.0f; mWindowPoly[2].c.b =  1.0f; mWindowPoly[2].c.a =  1.0f;
    mWindowPoly[3].c.r =  1.0f; mWindowPoly[3].c.g =  1.0f; mWindowPoly[3].c.b =  1.0f; mWindowPoly[3].c.a =  1.0f;

    // sector 1
    mWindowPoly[0].p.x = 0.0f;         mWindowPoly[0].p.y = 0.0f;
    mWindowPoly[1].p.x = mBorderWidth; mWindowPoly[1].p.y = 0.0f;
    mWindowPoly[2].p.x = mBorderWidth; mWindowPoly[2].p.y = -mBorderHeight;
    mWindowPoly[3].p.x = 0.0f;         mWindowPoly[3].p.y = -mBorderHeight;
    DISPLAY->SetTexture(mWindowTexId[0]);
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();

    // sector 2
    mWindowPoly[0].p.x = width - mBorderWidth; mWindowPoly[0].p.y = 0.0f;
    mWindowPoly[1].p.x = width;                mWindowPoly[1].p.y = 0.0f;
    mWindowPoly[2].p.x = width;                mWindowPoly[2].p.y = -mBorderHeight;
    mWindowPoly[3].p.x = width - mBorderWidth; mWindowPoly[3].p.y = -mBorderHeight;
    DISPLAY->SetTexture(mWindowTexId[1]);
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();

    // sector 3
    mWindowPoly[0].p.x = 0.0f;         mWindowPoly[0].p.y = -height + mBorderHeight;
    mWindowPoly[1].p.x = mBorderWidth; mWindowPoly[1].p.y = -height + mBorderHeight;
    mWindowPoly[2].p.x = mBorderWidth; mWindowPoly[2].p.y = -height;
    mWindowPoly[3].p.x = 0.0f;         mWindowPoly[3].p.y = -height;
    DISPLAY->SetTexture(mWindowTexId[2]);
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();

    // sector 4
    mWindowPoly[0].p.x = width - mBorderWidth; mWindowPoly[0].p.y = -height + mBorderHeight;
    mWindowPoly[1].p.x = width;                mWindowPoly[1].p.y = -height + mBorderHeight;
    mWindowPoly[2].p.x = width;                mWindowPoly[2].p.y = -height;
    mWindowPoly[3].p.x = width - mBorderWidth; mWindowPoly[3].p.y = -height;
    DISPLAY->SetTexture(mWindowTexId[3]);
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();

    // sector 5
    mWindowPoly[0].p.x = mBorderWidth;         mWindowPoly[0].p.y = 0.0f;
    mWindowPoly[1].p.x = width - mBorderWidth; mWindowPoly[1].p.y = 0.0f;
    mWindowPoly[2].p.x = width - mBorderWidth; mWindowPoly[2].p.y = -mBorderHeight;
    mWindowPoly[3].p.x = mBorderWidth;         mWindowPoly[3].p.y = -mBorderHeight;
    DISPLAY->SetTexture(mWindowTexId[4]);
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();

    // sector 6
    mWindowPoly[0].p.x = 0.0f;         mWindowPoly[0].p.y = -mBorderHeight;
    mWindowPoly[1].p.x = mBorderWidth; mWindowPoly[1].p.y = -mBorderHeight;
    mWindowPoly[2].p.x = mBorderWidth; mWindowPoly[2].p.y = -height + mBorderHeight;
    mWindowPoly[3].p.x = 0.0f;         mWindowPoly[3].p.y = -height + mBorderHeight;
    DISPLAY->SetTexture(mWindowTexId[5]);
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();

    // sector 7
    mWindowPoly[0].p.x = width - mBorderWidth; mWindowPoly[0].p.y = -mBorderHeight;
    mWindowPoly[1].p.x = width;                mWindowPoly[1].p.y = -mBorderHeight;
    mWindowPoly[2].p.x = width;                mWindowPoly[2].p.y = -height + mBorderHeight;
    mWindowPoly[3].p.x = width - mBorderWidth; mWindowPoly[3].p.y = -height + mBorderHeight;
    DISPLAY->SetTexture(mWindowTexId[6]);
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();

    // sector 8
    mWindowPoly[0].p.x = mBorderWidth;         mWindowPoly[0].p.y = -height + mBorderHeight;
    mWindowPoly[1].p.x = width - mBorderWidth; mWindowPoly[1].p.y = -height + mBorderHeight;
    mWindowPoly[2].p.x = width - mBorderWidth; mWindowPoly[2].p.y = -height;
    mWindowPoly[3].p.x = mBorderWidth;         mWindowPoly[3].p.y = -height;
    DISPLAY->SetTexture(mWindowTexId[7]);
    DISPLAY->DrawQuads(mWindowPoly);
    DISPLAY->UnsetTexture();

    // sector 9
    mWindowPoly[0].p.x = 3.0f;         mWindowPoly[0].p.y = -3.0f;
    mWindowPoly[1].p.x = width - 3.0f; mWindowPoly[1].p.y = -3.0f;
    mWindowPoly[2].p.x = width - 3.0f; mWindowPoly[2].p.y = -height + 3.0f;
    mWindowPoly[3].p.x = 3.0f;         mWindowPoly[3].p.y = -height + 3.0f;
    mWindowPoly[0].c.r = KERNEL->GetGamestate().GetSavemap().WindowRGBUpperLeft[0]/255.0f;
    mWindowPoly[0].c.g = KERNEL->GetGamestate().GetSavemap().WindowRGBUpperLeft[1]/255.0f;
    mWindowPoly[0].c.b = KERNEL->GetGamestate().GetSavemap().WindowRGBUpperLeft[2]/255.0f;
    mWindowPoly[0].c.a = (opacity == false) ? 1.0f : 0.5f;
    mWindowPoly[1].c.r = KERNEL->GetGamestate().GetSavemap().WindowRGBUpperRight[0]/255.0f;
    mWindowPoly[1].c.g = KERNEL->GetGamestate().GetSavemap().WindowRGBUpperRight[1]/255.0f;
    mWindowPoly[1].c.b = KERNEL->GetGamestate().GetSavemap().WindowRGBUpperRight[2]/255.0f;
    mWindowPoly[1].c.a = (opacity == false) ? 1.0f : 0.5f;
    mWindowPoly[2].c.r = KERNEL->GetGamestate().GetSavemap().WindowRGBLowerRight[0]/255.0f;
    mWindowPoly[2].c.g = KERNEL->GetGamestate().GetSavemap().WindowRGBLowerRight[1]/255.0f;
    mWindowPoly[2].c.b = KERNEL->GetGamestate().GetSavemap().WindowRGBLowerRight[2]/255.0f;
    mWindowPoly[2].c.a = (opacity == false) ? 1.0f : 0.5f;
    mWindowPoly[3].c.r = KERNEL->GetGamestate().GetSavemap().WindowRGBLowerLeft[0]/255.0f;
    mWindowPoly[3].c.g = KERNEL->GetGamestate().GetSavemap().WindowRGBLowerLeft[1]/255.0f;
    mWindowPoly[3].c.b = KERNEL->GetGamestate().GetSavemap().WindowRGBLowerLeft[2]/255.0f;
    mWindowPoly[3].c.a = (opacity == false) ? 1.0f : 0.5f;
    DISPLAY->DrawQuads(mWindowPoly);

    DISPLAY->PopMatrix();
}
