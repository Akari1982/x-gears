// $Id: DbItem.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef DBITEM_H
#define DBITEM_H



typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;



struct DBItem
{
    u8 Unknown[27];
};




#endif
