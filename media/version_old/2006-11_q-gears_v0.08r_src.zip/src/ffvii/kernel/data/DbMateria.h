// $Id: DbMateria.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef DBMATERIA_H
#define DBMATERIA_H



typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;



struct DBMateria
{
    u8 Unknown[20];
};




#endif
