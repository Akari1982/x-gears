// $Id: DisplayTest.h 94 2006-11-12 19:44:43Z crazy_otaku $

#ifndef SCREENDISPLAYTEST_H
#define SCREENDISPLAYTEST_H

#include <vector>

#include "../../common/TypeDefine.h"
#include "../../common/module/Module.h"
#include "../../common/display/3dTypes.h"



class ScreenDisplayTest : public Module
{
public:
    ScreenDisplayTest();
    virtual ~ScreenDisplayTest();

    virtual void Init();

    virtual void Input(const InputEvent &input);

    virtual void Update(const u32& delta_time);

    virtual void Draw();

private:
    int                 mRotation;
    int                 mTexId;

    std::vector<Vertex> mPoints;
    TotalGeometry       mPyramid;
    std::vector<Vertex> mQuadsTex;
};



#endif // SCREENDISPLAYTEST_H
