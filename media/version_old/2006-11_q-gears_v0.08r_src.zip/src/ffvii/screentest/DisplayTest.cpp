// $Id: DisplayTest.cpp 94 2006-11-12 19:44:43Z crazy_otaku $

#include "../../common/display/Display.h"
#include "../../common/display/surface/SurfaceLoad.h"
#include "../../common/display/surface/SurfaceSaveBmp.h"
#include "../../common/module/ModuleManager.h"
#include "../../common/utilites/Logger.h"

#include "DisplayTest.h"
#include "GuiTest.h"
#include "../filetypes/BinGZipFile.h"
#include "../filetypes/TimFile.h"
#include "../kernel/Kernel.h"
#include "../field/FieldModule.h"
#include "../menu/PartyMenu.h"
#include "../worldmap/WorldMapModule.h"



ScreenDisplayTest::ScreenDisplayTest():
    mRotation(0),
    mTexId(0)
{
    Init();
}



ScreenDisplayTest::~ScreenDisplayTest()
{
    DISPLAY->DeleteTexture(mTexId);
}



void
ScreenDisplayTest::Init()
{
    Vertex point;

    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
    DISPLAY->SetAlphaTest(true);
    DISPLAY->SetBlendMode(BLEND_NORMAL);
    DISPLAY->SetCullMode(CULL_NONE);

    DISPLAY->LoadLookAt(50, Vector3(10.1, 5.1, 10.1), Vector3(0, 0, 0), Vector3(0, 1, 0));

    point.p.x = -5.0f; point.p.y =  0.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    mPoints.push_back(point);
    point.p.x =  5.0f; point.p.y =  0.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y = -5.0f; point.p.z =  0.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y =  5.0f; point.p.z =  0.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a =  1.0f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y =  0.0f; point.p.z = -5.0f;
    point.c.r =  0.0f; point.c.g =  0.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y =  0.0f; point.p.z =  5.0f;
    point.c.r =  0.0f; point.c.g =  0.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    mPoints.push_back(point);

    Vertex tr[3];
    Vertex qu[4];
    Geometry geom;
    geom.TexEnabled = false;

    tr[0].p.x = -1.0f; tr[0].p.y =  0.0f; tr[0].p.z =  1.0f;
    tr[0].c.r =  1.0f; tr[0].c.g =  0.0f; tr[0].c.b =  0.0f; tr[0].c.a =  1.0f;
    tr[1].p.x = -1.0f; tr[1].p.y =  0.0f; tr[1].p.z =  3.0f;
    tr[1].c.r =  0.0f; tr[1].c.g =  0.0f; tr[1].c.b =  1.0f; tr[1].c.a =  1.0f;
    tr[2].p.x = -2.0f; tr[2].p.y =  2.0f; tr[2].p.z =  2.0f;
    tr[2].c.r =  0.0f; tr[2].c.g =  1.0f; tr[2].c.b =  0.0f; tr[2].c.a =  1.0f;
    geom.AddTriangle(tr);

    tr[0].p.x = -1.0f; tr[0].p.y =  0.0f; tr[0].p.z =  1.0f;
    tr[0].c.r =  1.0f; tr[0].c.g =  0.0f; tr[0].c.b =  0.0f; tr[0].c.a =  1.0f;
    tr[1].p.x = -3.0f; tr[1].p.y =  0.0f; tr[1].p.z =  1.0f;
    tr[1].c.r =  1.0f; tr[1].c.g =  1.0f; tr[1].c.b =  0.0f; tr[1].c.a =  1.0f;
    tr[2].p.x = -2.0f; tr[2].p.y =  2.0f; tr[2].p.z =  2.0f;
    tr[2].c.r =  0.0f; tr[2].c.g =  1.0f; tr[2].c.b =  0.0f; tr[2].c.a =  1.0f;
    geom.AddTriangle(tr);

    tr[0].p.x = -3.0f; tr[0].p.y =  0.0f; tr[0].p.z =  3.0f;
    tr[0].c.r =  1.0f; tr[0].c.g =  0.0f; tr[0].c.b =  0.0f; tr[0].c.a =  1.0f;
    tr[1].p.x = -3.0f; tr[1].p.y =  0.0f; tr[1].p.z =  1.0f;
    tr[1].c.r =  1.0f; tr[1].c.g =  1.0f; tr[1].c.b =  0.0f; tr[1].c.a =  1.0f;
    tr[2].p.x = -2.0f; tr[2].p.y =  2.0f; tr[2].p.z =  2.0f;
    tr[2].c.r =  0.0f; tr[2].c.g =  1.0f; tr[2].c.b =  0.0f; tr[2].c.a =  1.0f;
    geom.AddTriangle(tr);

    tr[0].p.x = -3.0f; tr[0].p.y =  0.0f; tr[0].p.z =  3.0f;
    tr[0].c.r =  1.0f; tr[0].c.g =  0.0f; tr[0].c.b =  0.0f; tr[0].c.a =  1.0f;
    tr[1].p.x = -1.0f; tr[1].p.y =  0.0f; tr[1].p.z =  3.0f;
    tr[1].c.r =  0.0f; tr[1].c.g =  0.0f; tr[1].c.b =  1.0f; tr[1].c.a =  1.0f;
    tr[2].p.x = -2.0f; tr[2].p.y =  2.0f; tr[2].p.z =  2.0f;
    tr[2].c.r =  0.0f; tr[2].c.g =  1.0f; tr[2].c.b =  0.0f; tr[2].c.a =  1.0f;
    geom.AddTriangle(tr);

    qu[0].p.x = -1.0f; qu[0].p.y =  0.0f; qu[0].p.z =  1.0f;
    qu[0].c.r =  1.0f; qu[0].c.g =  0.0f; qu[0].c.b =  0.0f; qu[0].c.a =  1.0f;
    qu[1].p.x = -3.0f; qu[1].p.y =  0.0f; qu[1].p.z =  1.0f;
    qu[1].c.r =  1.0f; qu[1].c.g =  1.0f; qu[1].c.b =  0.0f; qu[1].c.a =  1.0f;
    qu[2].p.x = -3.0f; qu[2].p.y =  0.0f; qu[2].p.z =  3.0f;
    qu[2].c.r =  1.0f; qu[2].c.g =  0.0f; qu[2].c.b =  0.0f; qu[2].c.a =  1.0f;
    qu[3].p.x = -1.0f; qu[3].p.y =  0.0f; qu[3].p.z =  3.0f;
    qu[3].c.r =  0.0f; qu[3].c.g =  0.0f; qu[3].c.b =  1.0f; qu[3].c.a =  1.0f;
    geom.AddQuad(qu);

    mPyramid.GeometryVector.push_back(geom);



    TimFile* image = new TimFile("data/MENU/YUFI.TIM");
    Surface* texture = NULL;
    if (image != NULL)
    {
        texture = image->GetSurface(0);
        delete image;
//        SurfaceUtils::SaveBMP("bmp.bmp", texture);
    }
    else
    {
        LOGGER->Log("Can't load texture.");
    }

    if (texture != NULL)
    {
        SetSurfaceSize(texture, 64, 64);
        mTexId = DISPLAY->CreateTexture(texture);
        delete texture;
    }
    else
    {
        LOGGER->Log("Can't get texture.");
    }

    point.p.x =  0.5f; point.p.y = -1.0f; point.p.z =  4.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  0.0f; point.t.y =  0.0f;
    mQuadsTex.push_back(point);
    point.p.x =  4.5f; point.p.y = -1.0f; point.p.z =  4.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  0.0f; point.t.y =  1.0f;
    mQuadsTex.push_back(point);
    point.p.x =  4.5f; point.p.y = -1.0f; point.p.z = -4.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  1.0f; point.t.y =  1.0f;
    mQuadsTex.push_back(point);
    point.p.x =  0.5f; point.p.y = -1.0f; point.p.z = -4.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b =  1.0f; point.c.a =  1.0f;
    point.t.x =  1.0f; point.t.y =  0.0f;
    mQuadsTex.push_back(point);
}



void
ScreenDisplayTest::Input(const InputEvent &input)
{
    switch (input.button)
    {
        case KEY_Cg:
        {
            GuiTest* screen = new GuiTest();
            MODULEMAN->PushModule(screen);
            break;
        }
        case KEY_Cs:
        {
            PartyMenu* screen = new PartyMenu();
            MODULEMAN->PushModule(screen);
            break;
        }
        case KEY_Cn:
        {
            MODULEMAN->PopTopModule();
            FieldModule* screen = new FieldModule();
            MODULEMAN->PushModule(screen);
            break;
        }
        case KEY_Cm:
        {
            MODULEMAN->PopTopModule();
            WorldMapModule* module = new WorldMapModule();
            MODULEMAN->PushModule(module);
            break;
        }
    }

}



void
ScreenDisplayTest::Update(const u32 &delta_time)
{
    ++mRotation;
}



void
ScreenDisplayTest::Draw(void)
{
    DISPLAY->SetPointSize(3);
    DISPLAY->DrawPoints(mPoints);
    DISPLAY->SetLineWidth(1);
    DISPLAY->DrawLines(mPoints);

    DISPLAY->PushMatrix();
    DISPLAY->RotateX(mRotation);
    DISPLAY->DrawTotalGeometry(mPyramid);
    DISPLAY->PopMatrix();

    DISPLAY->SetAlphaTest(false);
    DISPLAY->SetBlendMode(BLEND_DISABLED);
//    DISPLAY->TextureTranslate(0.01f, 0.0f);
    DISPLAY->SetTexture(mTexId);
    DISPLAY->DrawQuads(mQuadsTex);
    DISPLAY->UnsetTexture();
    DISPLAY->SetAlphaTest(true);
    DISPLAY->SetBlendMode(BLEND_NORMAL);

    KERNEL->DrawString(RStringToFFVIIString("Press 'N' button to go to 'Field Module'"), 400, 400, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'M' button to go to 'WorldMap Module'"), 400, 415, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'S' button to go to 'Party Menu'"), 400, 430, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'G' button to go to 'Gui Test Screen'"), 400, 445, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'Z' button to dismiss both"), 400, 460, F_WHITE);
}
