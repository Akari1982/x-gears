// $Id: WindowManager.cpp 94 2006-11-12 19:44:43Z crazy_otaku $

#include "../../common/utilites/Logger.h"

#include "FieldModule.h"
#include "WindowManager.h"
#include "../kernel/Kernel.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

WindowManager::WindowManager(FieldModule* pFieldModule):
    mpFieldModule(pFieldModule),
    mPointerPos(0)
{
    Init();
}



WindowManager::~WindowManager(void)
{
}



//============================= OPERATIONS ===================================

void
WindowManager::Init(void)
{
    for (u8 i = 0; i < 8; ++i)
    {
        ResetWindow(i);
    }
}



void
WindowManager::Clear(void)
{
    // clear window info
    Init();
    // clear dialogs
    mDialogs.clear();
}



void
WindowManager::Draw(void)
{
    for (int i = 0; i < 8 ; ++i)
    {
        if (mWindows[i].show)
        {
            if (mWindows[i].style != 1)
            {
                KERNEL->DrawWindow(mWindows[i].x,
                                   mWindows[i].y,
                                   mWindows[i].width,
                                   mWindows[i].height,
                                  (mWindows[i].style == 2) ? true : false);
            }

            KERNEL->DrawString(mDialogs[mWindows[i].message.dialog_id],
                               mWindows[i].x + 8,
                               mWindows[i].y + 8,
                               F_WHITE,
                               mWindows[i].init_state);

            // if this is ask
            if ((mWindows[i].message.first != 0 || mWindows[i].message.last != 0) && mWindows[i].inited == true)
            {
                KERNEL->DrawPointer(mWindows[i].x + 6,
                                    mWindows[i].y + 8 + mPointerPos * 16,
                                    TO_RIGHT);
            }



            // if it is timer or Clock (00:00) or Numeric (000000)
            if (mWindows[i].special.type)
            {
                RString string;
                if (mWindows[i].special.type == 1)
                {
                    // format data from memory bank.
                    // hours are just added to minutes
                    string.Format("%02d:%02d", KERNEL->GetGamestate().MemoryBankGet((u8)0x01, (u8)0x15) * 60 + KERNEL->GetGamestate().MemoryBankGet((u8)0x01, (u8)0x16), KERNEL->GetGamestate().MemoryBankGet((u8)0x01, (u8)0x17));
                }
                else if (mWindows[i].special.type == 2)
                {
                    // construct output string
                    string.Format("%08u", mWindows[i].special.digit);
                    string = string.Right(mWindows[i].special.digit_number);
                }

                // draw counter
                KERNEL->DrawCounter(mWindows[i].x + mWindows[i].special.x, mWindows[i].y + mWindows[i].special.y, string);
            }
        }
    }
}



bool
WindowManager::Input(const InputEvent &input)
{
    for (u8 i = 0; i < 8 ; ++i)
    {
        if (mWindows[i].show == true && mWindows[i].inited == true && mWindows[i].cbc == 0)
        {
            if (input.type == IET_RELEASE)
            {
                switch (input.button)
                {
                    case KEY_Cx:
                    {
                        KERNEL->GetGamestate().MemoryBankPut(mWindows[i].message.memory_bank, mWindows[i].message.offset, mPointerPos);
                        CloseWindow(i);
                    }
                    break;

                    case KEY_UP:
                    {
                        if (mPointerPos > mWindows[i].message.first)
                        {
                            mPointerPos--;
                        }
                    }
                    break;

                    case KEY_DOWN:
                    {
                        if (mPointerPos < mWindows[i].message.last)
                        {
                            mPointerPos++;
                        }
                    }
                    break;
                }
            }
        }
    }



    // if we have at least one shown clickable window - handle input
    for (u8 i = 0; i < 8 ; ++i)
    {
        if (mWindows[i].show == true && mWindows[i].cbc == 0)
        {
            return true;
        }
    }
    return false;
}



void
WindowManager::Update(const u32& deltaTime)
{
    for (u8 i = 0; i < 8 ; ++i)
    {
        if (mWindows[i].show && mWindows[i].inited == false)
        {
            // add init state (in future this must be added according to message speed)
            ++(mWindows[i].init_state);

            printf("Window %d state: %d.\n", i, mWindows[i].init_state);

            // if we displayed whole message or no message has been set - set window to inited
            if (mWindows[i].init_state >= mDialogs[mWindows[i].message.dialog_id].size())
            {
                mWindows[i].inited = true;
            }
        }
    }
}



void
WindowManager::SetMapName(const s8& dialogId)
{
    if (dialogId >= mDialogs.size())
    {
        LOGGER->Log("WindowManager::SetMapName - tried set dialogId for map name greater than current mDialogs number.");
        return;
    }

    KERNEL->GetGamestate().CurrentFieldNameSet(mDialogs[dialogId]);
}



void
WindowManager::SetWindow(const u8& id, const u16& x, const u16& y, const u16& width, const u16& height)
{
    if (id < 8)
    {
        mWindows[id].x      = x;
        mWindows[id].y      = y;
        mWindows[id].width  = width;
        mWindows[id].height = height;
    }
}



void
WindowManager::ResetWindow(const u8& id)
{
    if (id < 8)
    {
        mWindows[id].show       = false;

        mWindows[id].inited     = false;
        mWindows[id].init_state = 0;

        mWindows[id].x          = 0x05;
        mWindows[id].y          = 0x05;
        mWindows[id].width      = 0x0130;
        mWindows[id].height     = 0x0045;
        mWindows[id].style      = 0;
        mWindows[id].cbc        = 0;

        mWindows[id].special.x            = 0;
        mWindows[id].special.y            = 0;
        mWindows[id].special.type         = 0;
        mWindows[id].special.digit        = 0;
        mWindows[id].special.digit_number = 0;

        mWindows[id].message.memory_bank  = 0;
        mWindows[id].message.offset       = 0;
        mWindows[id].message.dialog_id    = 0;
        mWindows[id].message.first        = 0;
        mWindows[id].message.last         = 0;
        mWindows[id].message.caller       = NULL;
    }
}



void
WindowManager::SetWindowStyle(const u8& id, const u8& style, const u8& cbc)
{
    if (id < 8)
    {
        mWindows[id].style = style;
        mWindows[id].cbc   = cbc;
    }
}



void
WindowManager::SetSpecialStyle(const u8& id, const u8& x, const u8& y, const u8& type)
{
    if (id < 8)
    {
        mWindows[id].special.x    = x;
        mWindows[id].special.y    = y;
        mWindows[id].special.type = type;
    }
}



void
WindowManager::SetSpecialNumber(const u8& id, const u32& digit, const u8& digitNumber)
{
    if (id < 8)
    {
        mWindows[id].special.digit        = digit;
        mWindows[id].special.digit_number = digitNumber;
    }
}



void
WindowManager::ShowMessage(const u8& id, const s8& dialogId, const u8& first, const u8& last, const u8& memoryBank, const u8& offset, Entity* entity)
{
    if (dialogId >= mDialogs.size())
    {
        LOGGER->Log("WindowManager::ShowMessage - tried set dialogId greater than current dialogs number.");
        return;
    }

    mWindows[id].show       = true;

    mWindows[id].inited     = false;
    mWindows[id].init_state = 0;

    mWindows[id].message.dialog_id   = dialogId;
    mWindows[id].message.first       = first;
    mWindows[id].message.last        = last;

    // set pointer to 0 for new ask
    if (mWindows[id].message.first != 0 || mWindows[id].message.last != 0)
    {
        mPointerPos = 0;
    }

    mWindows[id].message.memory_bank = memoryBank;
    mWindows[id].message.offset      = offset;
    mWindows[id].message.caller      = entity;

    // if this window cant be clicked - release sync
    if (mWindows[id].cbc != 0)
    {
        entity->SetWait(false);
    }
    else
    {
        mpFieldModule->DropAllInput();
    }

    // if we want to display timer - start count down
    if (mWindows[id].special.type == 1)
    {
        KERNEL->GetGamestate().TimerStart();
    }
}



void
WindowManager::CloseWindow(const u8& id)
{
    mWindows[id].message.caller->SetWait(false);
    mWindows[id].show = false;

    // if we want to close timer - stop count down
    if (mWindows[id].special.type == 1)
    {
        KERNEL->GetGamestate().TimerStop();
    }
}



void
WindowManager::AddDialog(const FFVIIString& dialog)
{
    mDialogs.push_back(dialog);
}
