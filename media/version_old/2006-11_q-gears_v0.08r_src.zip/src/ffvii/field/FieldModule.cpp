// $Id: FieldModule.cpp 96 2006-11-13 03:34:17Z crazy_otaku $

#include <libxml/tree.h>

#include "../../common/display/Display.h"
#include "../../common/filesystem/RealFileSystem.h"
#include "../../common/module/ModuleManager.h"
#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "DatFile.h"
#include "DatXmlFile.h"
#include "FieldModule.h"
#include "FieldUtilites.h"
#include "script/Entity.h"
#include "script/Script.h"
#include "../battle/BattleModule.h"
#include "../kernel/Kernel.h"
#include "../menu/PartyMenu.h"



FieldModule::FieldModule():
    mRequestMapId(0),
    mRequestLoadMap(false),

    mViewAxis(true),
    mViewFromCamera(true),
    mViewDebugInfo(true)
{
    mpScriptManager = new ScriptManager(this);
    mpUnitManager   = new UnitManager(this);
    mpWindowManager = new WindowManager(this);

    Init();
}



FieldModule::~FieldModule()
{
    delete mpScriptManager;
    delete mpUnitManager;
    delete mpWindowManager;
}



void
FieldModule::Init()
{
    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
    DISPLAY->SetAlphaTest(true);
    DISPLAY->SetBlendMode(BLEND_NORMAL);
    DISPLAY->SetCullMode(CULL_NONE);

    Vertex point;
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 0.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 500.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 0.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 1.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 500.0f; point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 1.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 0.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 500.0f;
    point.c.r = 0.0f;   point.c.g = 0.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    mAxis.push_back(point);



    // load map from savemap
    LoadMap(KERNEL->GetGamestate().CurrentFieldGet());
}



void
FieldModule::LoadMap(const u16& id)
{
    // check if this is field file (not worldmap)
    if (id < 0x41)
    {
        LOGGER->Log("Tried to load worldmap with mapId = %04x.", id);
        return;
    }

    // remember current map
    KERNEL->GetGamestate().CurrentFieldSet(id);

    // clear all managers
    mpWindowManager->Clear();
    mpScriptManager->Clear();
    mpUnitManager->Clear();



    // load DAT file
    DatFile dat("data/FIELD/" + MapIdToRString(id) + ".DAT");

    // try load xml file
    DatXmlFile xml_file("data/FIELD/" + MapIdToRString(id) + ".xml");



    LOGGER->Log("Load field %s", dat.GetFileName().c_str());



    // load dialogs
    if (xml_file.GetDialogs(mpWindowManager) != 0)
    {
        LOGGER->Log("Load dialogs from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log("Load entity from FieldFile.");
        dat.GetDialogs(mpWindowManager);
    }



    // load entity info
    if (xml_file.GetScripts(mpScriptManager) != 0)
    {
        LOGGER->Log("Load entitys from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log("Load entitys from FieldFile.");
        dat.GetScripts(mpScriptManager);
    }



    // load walkmesh info
    if (xml_file.GetWalkMesh(mpUnitManager) != 0)
    {
        LOGGER->Log("Load walkmesh from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log("Loading walkmesh from FieldFile.");
        dat.GetWalkMesh(mpUnitManager);
    }



    // load gateways info
    if (xml_file.GetGateway(mpUnitManager) != 0)
    {
        LOGGER->Log("Load gateways from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log("Loading gateways from FieldFile.");
        dat.GetGateway(mpUnitManager);
    }



    // load encounters info
    if (xml_file.GetEncounter(mpUnitManager) != 0)
    {
        LOGGER->Log("Load encounters from Xml FieldFile.");
    }
    else
    {
        LOGGER->Log("Loading encounter from FieldFile.");
        dat.GetEncounter(mpUnitManager);
    }



    // load camera matrix
    LOGGER->Log("Loading camera matrix from FieldFile.");
    dat.GetCameraMatrix(mMatrix);



    // we dont know how set scale yet
    mScale = 1.0f;
}



void
FieldModule::RequestLoadMap(const u16& id)
{
    mRequestMapId = id;
    mRequestLoadMap = true;
}



void
FieldModule::LoadBattle(const u16& id)
{
    MODULEMAN->PopTopModule();
    BattleModule* module = new BattleModule();
    module->LoadBattle(id);
    MODULEMAN->PushModule(module);
}



void
FieldModule::DropAllInput(void)
{
    mpUnitManager->DropInput();
}



void
FieldModule::Input(const InputEvent &input)
{
    // handle system input ourself
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_Co:    mScale += 0.01f;                                    break;
            case KEY_Cp:    mScale -= 0.01f;                                    break;

            case KEY_Ck:    mViewFromCamera = (mViewFromCamera) ? false : true; break;
            case KEY_Cl:    mViewAxis       = (mViewAxis)       ? false : true; break;
            case KEY_Cd:    mViewDebugInfo  = (mViewDebugInfo)  ? false : true; break;
        }
    }

    // give input to all opened windows
    if (mpWindowManager->Input(input) == true)
    {
        // if we handled input - return
        return;
    }



    // give input to all unit on map
    if (mpUnitManager->Input(input) == true)
    {
        // if we handled input - return
        return;
    }



    // handle other game input
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_Cs:
            {
                PartyMenu* module = new PartyMenu();
                MODULEMAN->PushModule(module);
                break;
            }

            case KEY_Cb:
            {
                LoadBattle(999);
                break;
            }
        }
    }
}



void
FieldModule::Update(const u32& delta_time)
{
    // run script
    mpScriptManager->Run();



    // update all opened windows
    mpWindowManager->Update(delta_time);



    // update all units on map
    mpUnitManager->Update(delta_time);



    if (mRequestLoadMap == true)
    {
        LoadMap(mRequestMapId);

        mRequestLoadMap = false;
    }
}



void
FieldModule::DrawPosibleActions(void) const
{
    KERNEL->DrawString(RStringToFFVIIString("Press 'D' button to show/hide debug info"),      350, 415, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'O'/'P' button to scale walkmesh"),        350, 430, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'K' button to swich to/from camera view"), 350, 445, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'L' button to show/hide axis"),            350, 460, F_WHITE);
}



void
FieldModule::Draw()
{
    DISPLAY->CameraPushMatrix();

    // set camera
    if (mViewFromCamera == true)
    {
        DISPLAY->LoadCameraMatrix(mMatrix);
    }
    else
    {
        DISPLAY->LoadLookAt(50, Vector3(-500, 200, 900), Vector3(0, 0, 0), Vector3(0, 1, 0));
    }

    // draw axis
    if (mViewAxis == true)
    {
        DISPLAY->SetPointSize(3);
        DISPLAY->DrawPoints(mAxis);
        DISPLAY->SetLineWidth(1);
        DISPLAY->DrawLines(mAxis);
    }

    // draw all units on map
    DISPLAY->PushMatrix();
    DISPLAY->Scale(mScale, mScale, mScale);
    mpUnitManager->Draw();
    DISPLAY->PopMatrix();

    // draw all opened windows
    mpWindowManager->Draw();



    DrawPosibleActions();
    if (mViewDebugInfo == true)
    {
        mpUnitManager->DrawDebugInfo();
    }
}
