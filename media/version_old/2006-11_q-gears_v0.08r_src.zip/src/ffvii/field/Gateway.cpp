// $Id: Gateway.cpp 96 2006-11-13 03:34:17Z crazy_otaku $

#include "../../common/utilites/Logger.h"

#include "FieldModule.h"
#include "Gateway.h"



Gateway::Gateway(FieldModule* pFieldModule, const dGeomID& collision, const Vector3& position, const u16& mapId):
    mpFieldModule(pFieldModule),
    Trigger(collision),
    mPosition(position),
    mMapId(mapId)
{
}



Gateway::~Gateway(void)
{
}



void
Gateway::Action(void)
{
    if (mMapId != 0x7FFF)
    {
        printf("Gateway activates. Load next Map %d\n", mMapId);

        KERNEL->GetGamestate().PlayerPositionSet(mPosition);
        KERNEL->GetGamestate().PlayerTriangleUnset();

        mpFieldModule->RequestLoadMap(mMapId);
    }
    else
    {
        printf("Gateway inactive.\n");
    }
}
