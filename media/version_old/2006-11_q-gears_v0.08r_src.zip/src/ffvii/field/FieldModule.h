// $Id: FieldModule.h 96 2006-11-13 03:34:17Z crazy_otaku $

#ifndef FIELDSCREEN_H
#define FIELDSCREEN_H



#include "DatFile.h"
#include "UnitManager.h"
#include "WindowManager.h"
#include "script/ScriptManager.h"
#include "../kernel/Kernel.h"
#include "../../common/module/Module.h"
#include "../../common/display/3dTypes.h"

#include <string>
#include <vector>

// forward declaration
class Script;



class FieldModule : public Module
{
friend class Script;
friend class WindowManager;
friend class UnitManager;

public:
    FieldModule();
    virtual ~FieldModule();

    virtual void Init();
    virtual void Input(const InputEvent &input);
    virtual void Update(const u32& delta_time);
    virtual void Draw();

    void RequestLoadMap(const u16& id);
    void LoadBattle(const u16& id);

    void DropAllInput(void);

private:
    void LoadMap(const u16& id);

    void DrawDebugInfo(void) const;
    void DrawPosibleActions(void) const;

private:
    std::vector<Vertex>     mAxis;

    // engine managing
    bool                    mViewAxis;
    bool                    mViewFromCamera;
    bool                    mViewDebugInfo;



    // map loading related
    u16                     mRequestMapId;
    bool                    mRequestLoadMap;


    // map related
    ScriptManager*          mpScriptManager;
    UnitManager*            mpUnitManager;
    WindowManager*          mpWindowManager;

    float                   mScale;
    Matrix                  mMatrix;
};



#endif // FIELDSCREEN_H
