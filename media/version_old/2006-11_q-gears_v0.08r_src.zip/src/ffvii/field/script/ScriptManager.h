// $Id: ScriptManager.h 94 2006-11-12 19:44:43Z crazy_otaku $

/**
 * @brief Manager that handles different entity scripts.
 */

#ifndef SCRIPT_MANAGER_h
#define SCRIPT_MANAGER_h

#include "../../../common/TypeDefine.h"
#include "../../../common/utilites/NoCopy.h"

#include <vector>

class Entity;
class FieldModule;



class ScriptManager : public NoCopy<ScriptManager>
{
public:
// LIFECYCLE

    /**
     * @brief Default constructor.
     *
     * @param pFieldModule - pointer to this FieldModule object
     */
    explicit ScriptManager(FieldModule* pFieldModule);

    /**
     * @brief Default destructor.
     */
    virtual ~ScriptManager(void);

// OPERATIONS

    /**
     * @brief Clear data.
     */
    void Clear(void);

    /**
     * @brief Run scripts.
     */
    void Run(void);

    /**
     * @brief Request to run scripts in entity.
     *
     * Request to run scripts in entity. Asynchronous , non-guaranteed. Call from REQ.
     * @param entityId - ID of the target entity.
     * @param priority - The priority at which we want to execute the remote script.
     * @param scriptId - ID of the specific member function of E to be executed.
     */
    void RequestRun(const u8& entityId, const u8& priority, const u8& scriptId);

    void RequestRunUnit(const s8& unitId, const u8& priority, const u8& scriptId);

    /**
     * @brief Add new entity to array.
     *
     * @param pModule - pointer to new module that we want to add.
     */
    void PushEntity(Entity* pEntity);

private:
    FieldModule*         mpFieldModule; /**< @brief feed back to field module */

    std::vector<Entity*> mEntities;     /**< @brief array of entities         */
};



#endif // SCRIPTS_MANAGER_h
