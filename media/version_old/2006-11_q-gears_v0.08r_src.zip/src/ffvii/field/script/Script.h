// $Id: Script.h 94 2006-11-12 19:44:43Z crazy_otaku $

/**
 * @brief Script holder.
 */

#ifndef SCRIPT_h
#define SCRIPT_h

#include "ScriptManager.h"
#include "../../../common/TypeDefine.h"
#include "../../../common/utilites/NoCopy.h"

class Entity;
class WindowManager;



u8* OpcodesToRawScript(u8* pBuffer, const u32& bufferSize, u32& rawScriptSize);



class Script : public NoCopy<Script>
{
friend class WindowManager;

public:
// LIFECYCLE

    /**
     * @brief A constructor.
     *
     * @param pBuffer - buffer from which we want to load script.
     * @param length  - size of buffer.
     */
    Script(u8* pBuffer, const u32& length);

    /**
     * @brief Default destructor.
     */
    virtual ~Script(void);

// OPERATIONS

    /**
     * @brief Run script.
     *
     * @param fieldModule    - pointer to this FieldModule object.
     * @param entity         - pointer to caller.
     * @param scriptPosition - current position of script.
     * @return true if we finishes the script, false otherwise.
     */
    bool Run(FieldModule* fieldModule, Entity* entity, u32& scriptPosition);

    /**
     * @brief Get 1 byte.
     *
     * Utility function that extract data with given offset from buffer
     * @param offset - offset to 1 byte that we want to get.
     * @return 1 byte from file buffer with given offset.
     */
    const u8 GetU8(const u32& offset) const;

    /**
     * @brief Get 2 bytes.
     *
     * Utility function that extract data with given offset from buffer
     * @param offset - offset to 2 bytes that we want to get.
     * @return 2 bytes from file buffer with given offset.
     */
    const u16 GetU16LE(const u32& offset) const;

private:
    u8*               mpBuffer;      /**< @brief script buffer */
    u32               mLength;       /**< @brief length of script buffer */
};



#endif // SCRIPT_h
