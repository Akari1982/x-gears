// $Id: Entity.h 94 2006-11-12 19:44:43Z crazy_otaku $

/**
 * @brief Entity object that contains script and may be linked to model on field.
 */

#ifndef ENTITY_h
#define ENTITY_h

#include "Script.h"
#include "ScriptManager.h"
#include "../../../common/TypeDefine.h"
#include "../../../common/utilites/NoCopy.h"
#include "../../../common/utilites/StdString.h"



class Entity : public NoCopy<Entity>
{
public:
// LIFECYCLE

    /**
     * @brief Default constructor.
     */
    Entity(void);

    /**
     * @brief Default destructor.
     */
    virtual ~Entity(void);

// OPERATIONS

    void Init(FieldModule* fieldModule);

    static void SetScript(Script* script);

    static void DeleteScript(void);

    /**
     * @brief Run entity script.
     *
     * @param fieldModule - pointer to this FieldModule object
     */
    void Run(FieldModule* fieldModule);

    /**
     * @brief Request to run scripts in entity.
     *
     * Request to run scripts in entity. Asynchronous , non-guaranteed. Call from REQ.
     * @param priority - The priority at which we want to execute the remote script.
     * @param scriptId - ID of the specific member function of E to be executed.
     */
    void RequestRun(const u8& priority, const u8& scriptId);

    void SetEntryPoint(const u8& id, const u32& entryPoint);

// ACCESS

    /**
     * @brief Set name to entity.
     *
     * @param name - name to be set.
     */
    void SetName(const RString& name);

    /**
     * @brief Set unit id.
     *
     * @param id - id to be set.
     */
    void SetUnitId(const s8& id);

    /**
     * @brief Get unit id.
     *
     * @return id of assigned unit.
     */
    const s8& GetUnitId(void);

    /**
     * @brief Check if script is wait for syncronize with command.
     *
     * @return true if we wait for syncronize, false otherwise.
     */
    bool IsWait(void) const;

    /**
     * @brief Set if script is wait for syncronize with command.
     *
     * @param wait - true if we wait for syncronize, false otherwise.
     */
    void SetWait(const bool& wait);

    void SetFramesToWait(const u16& wait);

private:
    RString         mName;                /** name of entity */
    bool            mInited;

    u32             mEntryPoints[32];     /** scripts entry points */
    static Script*  mScript;              /** script */

    struct ScriptQueueItem
    {
        s8  id;
        u32 position;
    };
    ScriptQueueItem mScriptQueue[8];

    bool            mWait;                /**< @brief bool value tha shows if we wait for syncronize with command */
    u16             mFramesToWait;        /**< @brief number of frames to wait */



    s8              mUnitId;            /**< @brief field unit that assigned to this entity */
};



#endif // ENTITY_h
