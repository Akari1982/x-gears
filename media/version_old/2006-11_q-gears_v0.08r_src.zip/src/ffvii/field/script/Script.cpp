// $Id: Script.cpp 94 2006-11-12 19:44:43Z crazy_otaku $

#include <cassert>
#include <memory>

#include "../../../common/utilites/Logger.h"

#include "Entity.h"
#include "Script.h"
#include "../FieldModule.h"
#include "../WindowManager.h"
#include "../../kernel/Kernel.h"



// This is is handy to call opcodes by thier name, not number
// Note: little "x" replaces "!" in opcode to make enum happy
// "u" replaces "+" and "d" replaces "-" ; 2BYTE changed to TWOBYTE
// xNNx are undefined opcodes
enum
{
    RET,      REQ,      REQSW,    REQEW,    PREQ,     PRQSW,    PRQEW,    RETTO,    // 0x00 - 0x07
    JOIN,     SPLIT,    SPTYE,    GTPYE,    x0Cx,     x0Dx,     DSKCG,    SPECIAL,  // 0x08 - 0x0F
    JMPF,     JMPFL,    JMPB,     JMPBL,    IFUB,     IFUBL,    IFSW,     IFSWL,    // 0x10 - 0x17
    IFUW,     IFUWL,    x1Ax,     x1Bx,     x1Cx,     x1Dx,     x1Ex,     x1Fx,     // 0x18 - 0x1F
    MINIGAME, TUTOR,    BTMD2,    BTRLD,    WAIT,     NFADE,    BLINK,    BGMOVIE,  // 0x18 - 0x1F
    KAWAI,    KAWIW,    PMOVA,    SLIP,     BGPDH,    BGSCR,    WCLS,     WSIZW,    // 0x28 - 0x2F
    IFKEY,    IFKEYON,  IFKEYOFF, UC,       PDIRA,    PTURA,    WSPCL,    WNUMB,    // 0x30 - 0x37
    STTIM,    GOLDu,    GOLDd,    CHGLD,    HMPMAX1,  HMPMAX2,  MHMMX,    HMPMAX3,  // 0x38 - 0x3F
    MESSAGE,  MPARA,    MPRA2,    MPNAM,    x44x,     MPu,      x46x,     MPd,      // 0x40 - 0x47
    ASK,      MENU,     MENU2,    BTLTB,    x4Cx,     HPu,      x4Ex,     HPd,
    WINDOW,   WMOVE,    WMODE,    WREST,    WCLSE,    WROW,     GWCOL,    SWCOL,
    STITM,    DLITM,    CKITM,    SMTRA,    DMTRA,    CMTRA,    SHAKE,    NOP,
    MAPJUMP,  SCRLO,    SCRLC,    SCRLA,    SCR2D,    SCRCC,    SCR2DC,   SCRLW,
    SCR2DL,   MPDSP,    VWOFT,    FADE,     FADEW,    IDLCK,    LSTMP,    SCRLP,
    BATTLE,   BTLON,    BTLMD,    PGTDR,    GETPC,    PXYZI,    PLUSx,    PLUS2x,
    MINUSx,   MINUS2x,  INCx,     INC2x,    DECx,     DEC2x,    TLKON,    RDMSD,
    SETBYTE,  SETWORD,  BITON,    BITOFF,   BITXOR,   PLUS,     PLUS2,    MINUS,
    MINUS2,   MUL,      MUL2,     DIV,      DIV2,     MOD,      MOD2,     AND,
    AND2,     OR,       OR2,      XOR,      XOR2,     INC,      INC2,     DEC,
    DEC2,     RANDOM,   LBYTE,    HBYTE,    TWOBYTE,  SETX,     GETX,     SEARCHX,
    PC,       CHAR,     DFANM,    ANIME1,   VISI,     XYZI,     XYI,      XYZ,
    MOVE,     CMOVE,    MOVA,     TURA,     ANIMW,    FMOVE,    ANIME2,   ANIMx1,
    CANIM1,   CANMx1,   MSPED,    DIR,      TURNGEN,  TURN,     DIRA,     GETDIR,
    GETAXY,   GETAI,    ANIMx2,   CANIM2,   CANMx2,   ASPED,    xBEx,     CC,
    JUMP,     AXYZI,    LADER,    OFST,     OFSTW,    TALKR,    SLIDR,    SOLID,
    PRTYP,    PRTYM,    PRTYE,    IFPRTYQ,  IFMEMBQ,  MMBud,    MMBLK,    MMBUK,
    LINE,     LINON,    MPJPO,    SLINE,    SIN,      COS,      TLKR2,    SLDR2,
    PMJMP,    PMJMP2,   AKAO2,    FCFIX,    CCANM,    ANIMB,    TURNW,    MPPAL,
    BGON,     BGOFF,    BGROL,    BGROL2,   BGCLR,    STPAL,    LDPAL,    CPPAL,
    RTPAL,    ADPAL,    MPPAL2,   STPLS,    LDPLS,    CPPAL2,   RTPAL2,   ADPAL2,
    MUSIC,    SOUND,    AKAO,     MUSVT,    MUSVM,    MULCK,    BMUSC,    CHMPH,
    PMVIE,    MOVIE,    MVIEF,    MVCAM,    FMUSC,    CMUSC,    CHMST,    GAMEOVER
};



enum
{
    FMSSP = 0xF8,
    AAMAT,
    AAITM,
    BTLLK,
    MOVLK,
    DFTNM,
    GLRST,
    RMITM
};



RString opcodes_names[256] = {
    "RET",       "REQ",       "REQSW",    "REQEW",   "PREQ",    "PRQSW",   "PRQEW",  "RETTO",    // 0x00 - 0x07
    "JOIN",      "SPLIT",     "SPTYE",    "GTPYE",   "",        "",        "DSKCG",  "SPECIAL",  // 0x08 - 0x0F
    "JMPF",      "JMPFL",     "JMPB",     "JMPBL",   "IFUB",    "IFUBL",   "IFSW",   "IFSWL",    // 0x10 - 0x17
    "IFUW",      "IFUWL",     "",         "",        "",        "",        "",       "",         // 0x18 - 0x1F
    "MINIGAME",  "TUTOR",     "BTMD2",    "BTRLD",   "WAIT",    "NFADE",   "BLINK",  "BGMOVIE",  // 0x18 - 0x1F
    "KAWAI",     "KAWIW",     "PMOVA",    "SLIP",    "BGPDH",   "BGSCR",   "WCLS",   "WSIZW",    // 0x28 - 0x2F
    "IFKEY",     "IFKEYON",   "IFKEYOFF", "UC",      "PDIRA",   "PTURA",   "WSPCL",  "WNUMB",    // 0x30 - 0x37
    "STTIM",     "GOLD+",     "GOLD-",    "CHGLD",   "HMPMAX1", "HMPMAX2", "MHMMX",  "HMPMAX3",  // 0x38 - 0x3F
    "MESSAGE",   "MPARA",     "MPRA2",    "MPNAM",   "",        "MP+",     "",       "MP-",      // 0x40 - 0x47
    "ASK",       "MENU",      "MENU2",    "BTLTB",   "",        "HP+",     "",       "HP-",
    "WINDOW",    "WMOVE",     "WMODE",    "WREST",   "WCLSE",   "WROW",    "GWCOL",  "SWCOL",
    "STITM",     "DLITM",     "CKITM",    "SMTRA",   "DMTRA",   "CMTRA",   "SHAKE",  "NOP",
    "MAPJUMP",   "SCRLO",     "SCRLC",    "SCRLA",   "SCR2D",   "SCRCC",   "SCR2DC", "SCRLW",
    "SCR2DL",    "MPDSP",     "VWOFT",    "FADE",    "FADEW",   "IDLCK",   "LSTMP",  "SCRLP",
    "BATTLE",    "BTLON",     "BTLMD",    "PGTDR",   "GETPC",   "PXYZI",   "PLUS!",  "PLUS2!",
    "MINUS!",    "MINUS2!",   "INC!",     "INC2!",   "DEC!",    "DEC2!",   "TLKON",  "RDMSD",
    "SET-BYTE!", "SET-WORD!", "BITON",    "BITOFF",  "BITXOR",  "PLUS",    "PLUS2",  "MINUS",
    "MINUS2",    "MUL",       "MUL2",     "DIV",     "DIV2",    "MOD",     "MOD2",   "AND",
    "AND2",      "OR",        "OR2",      "XOR",     "XOR2",    "INC",     "INC2",   "DEC",
    "DEC2",      "RANDOM",    "LBYTE",    "HBYTE",   "2BYTE",   "SETX",    "GETX",   "SEARCHX",
    "PC",        "CHAR",      "DFANM",    "ANIME1",  "VISI",    "XYZI",    "XYI",    "XYZ",
    "MOVE",      "CMOVE",     "MOVA",     "TURA",    "ANIMW",   "FMOVE",   "ANIME2", "ANIM!1",
    "CANIM1",    "CANM!1",    "MSPED",    "DIR",     "TURNGEN", "TURN",    "DIRA",   "GETDIR",
    "GETAXY",    "GETAI",     "ANIM!2",   "CANIM2",  "CANM!2",  "ASPED",   "",       "CC",
    "JUMP",      "AXYZI",     "LADER",    "OFST",    "OFSTW",   "TALKR",   "SLIDR",  "SOLID",
    "PRTYP",     "PRTYM",     "PRTYE",    "IFPRTYQ", "IFMEMBQ", "MMB+-",   "MMBLK",  "MMBUK",
    "LINE",      "LINON",     " MPJPO",    "SLINE",   "SIN",     "COS",     "TLKR2",  "SLDR2",
    "PMJMP",     "PMJMP2",    "AKAO2",    "FCFIX",   "CCANM",   "ANIMB",   "TURNW",  "MPPAL",
    "BGON",      "BGOFF",     "BGROL",    "BGROL2",  "BGCLR",   "STPAL",   "LDPAL",  "CPPAL",
    "RTPAL",     "ADPAL",     "MPPAL2",   "STPLS",   "LDPLS",   "CPPAL2",  "RTPAL2", "ADPAL2",
    "MUSIC",     "SOUND",     "AKAO",     "MUSVT",   "MUSVM",   "MULCK",   "BMUSC",  "CHMPH",
    "PMVIE",     "MOVIE",     "MVIEF",    "MVCAM",   "FMUSC",   "CMUSC",   "CHMST",  "GAMEOVER"
};



RString special_opcodes_names[8] = {
    "FMSSP",
    "AAMAT",
    "AAITM",
    "BTLLK",
    "MOVLK",
    "DFTNM",
    "GLRST",
    "RMITM"
};



u8 opcodes_size[256] = {
     1,  3,  3,  3,  3,  3,  3,  5,  2, 15,  6,  6,  0,  0,  0,  0, // 0x00 - 0x0F
     2,  3,  2,  3,  6,  7,  8,  9,  8,  9,  0,  0,  0,  0,  0,  0, // 0x10 - 0x1F
    11,  2,  5,  3,  3,  9,  2,  2,  0,  1,  2,  2,  5,  7,  2, 10, // 0x20 - 0x2F
     4,  4,  4,  2,  2,  4,  5,  8,  6,  6,  6,  4,  1,  1,  1,  1, // 0x30 - 0x3F
     3,  5,  6,  2,  0,  5,  0,  5,  7,  4,  2,  2,  0,  5,  0,  5, // 0x40 - 0x4F
    10,  6,  4,  2,  2,  3,  7,  7,  5,  5,  5,  7,  8, 10,  8,  1, // 0x50 - 0x5F
    10,  2,  5,  6,  6,  1,  9,  1,  9,  2,  7,  9,  1,  4,  3,  6, // 0x60 - 0x6F
     4,  2,  3,  4,  4,  8,  4,  5,  4,  5,  3,  4,  3,  4,  2,  3, // 0x70 - 0x7F
     4,  5,  4,  4,  4,  4,  5,  4,  5,  4,  5,  4,  5,  4,  5,  4, // 0x80 - 0x8F
     5,  4,  5,  4,  5,  3,  3,  3,  3,  3,  4,  5,  6,  7,  7, 11, // 0x90 - 0x9F
     2,  2,  3,  3,  2, 11,  9,  9,  6,  6,  2,  4,  1,  6,  3,  3, // 0xA0 - 0xAF
     5,  5,  4,  3,  6,  6,  2,  4,  5,  4,  3,  5,  5,  4,  0,  2, // 0xB0 - 0xBF
    11,  8, 15, 12,  1,  3,  3,  2,  2,  2,  4,  3,  3,  3,  2,  2, // 0xC0 - 0xCF
    13,  2,  2, 16, 10, 10,  4,  4,  3,  1, 15,  2,  4,  1,  1, 11, // 0xD0 - 0xDF
     4,  4,  3,  3,  3,  5,  5,  5,  7, 10, 10,  5,  5,  8,  8, 11, // 0xE0 - 0xEF
     2,  5, 14,  2,  2,  2,  2,  4,  2,  2,  3,  2,  2,  6,  3,  1  // 0xF0 - 0xFF
};



u8 special_opcodes_size[8] = {
    3, 1, 1, 2, 2, 3, 1, 1
};



u8*
OpcodesToRawScript(u8* pBuffer, const u32& bufferSize, u32& rawScriptSize)
{
    rawScriptSize = 0;
    u8* raw_script = NULL;

    raw_script = (u8*)malloc(rawScriptSize);
    u32 script_size = 0;
    u32 current_position = 0;



    for (unsigned int i = 0; i < bufferSize;)
    {
        u32 string_size = 0;
        // get the size of string
        while (pBuffer[i + string_size] != '\r' && pBuffer[i + string_size] != '\n' && i + string_size < bufferSize)
        {
            ++string_size;
        }



        // Read the string
        std::string line = "";
        char* temp_string = new char[string_size + 1];
        memcpy(temp_string, pBuffer + i, string_size);
        temp_string[string_size] = '\0';
        line = temp_string;
        delete[] temp_string;



        i += string_size;
        // skip '\r' or '\n' on the end of string and go to start of new string
        while (pBuffer[i] == '\r' || pBuffer[i] == '\n')
        {
            ++i;
        }



        // comments or empty string
        if (line[0] == '#' || line.size() == 0 || (line[0] == '/' && line[1] == '/'))
        {
            continue;
        }



        // add new opcode to raw.
        int equal_index = line.find(" ");
        if (equal_index != std::string::npos)
        {
            std::string opcode_name = line.substr(0, equal_index);

            // we skip space and ( and then read string after that
            std::string opcode_data = line.substr(equal_index + 2, line.size() - equal_index - 2);

            // search for opcode (if it finds nothing - it inserts RET opcode)
            u16 k = 0;
            for (; k < 256; ++k)
            {
                if (opcodes_names[k] == opcode_name)
                {
                    break;
                }
            }

            if (k != 256 && opcodes_size[k] != 0)
            {
                rawScriptSize += opcodes_size[k];
                raw_script = (u8*)realloc(raw_script, rawScriptSize);
                raw_script[current_position] = k;

                ++current_position;

                for (u8 j = 1; j < opcodes_size[k]; ++j)
                {
                    if (opcode_data.size() >= 3)
                    {
                        std::string value = opcode_data.substr(0, 2);
                        opcode_data       = opcode_data.substr(3, opcode_data.size() - 3);

                        u32 hex = 0;
                        sscanf(value.c_str(), "%02x", &hex);
                        raw_script[current_position] = (u8)hex;
                        ++current_position;
                    }
                    else
                    {
                        LOGGER->Log("Not enough arguments in opcode '%s'", opcodes_names[k].c_str());
                    }
                }
            }
            else
            {
                // search in special opcodes
                u16 s = 0;
                for (; s < 8; ++s)
                {
                    if (special_opcodes_names[s] == opcode_name)
                    {
                        break;
                    }
                }

                if (s != 8)
                {
                    rawScriptSize += special_opcodes_size[s] + 1;
                    raw_script = (u8*)realloc(raw_script, rawScriptSize);
                    raw_script[current_position] = 0x0F;
                    ++current_position;
                    raw_script[current_position] = s + 0xF8;
                    ++current_position;

                    for (u8 j = 1; j < special_opcodes_size[s]; ++j)
                    {
                        if (opcode_data.size() >= 3)
                        {
                            std::string value = opcode_data.substr(0, 2);
                            opcode_data       = opcode_data.substr(3, opcode_data.size() - 3);

                            u32 hex = 0;
                            sscanf(value.c_str(), "%02x", &hex);
                            raw_script[current_position] = (u8)hex;
                            ++current_position;
                        }
                        else
                        {
                            LOGGER->Log("Not enough arguments in opcode '%s'", special_opcodes_names[s].c_str());
                        }
                    }
                }
                else
                {
                    LOGGER->Log("Opcode '%s' not found!", opcode_name.c_str());
                }
            }
        }
        else
        {
            LOGGER->Log("Row '%s' incorrect! Must contain space.", line.c_str());
        }
    }



    return raw_script;
}


/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

Script::Script(u8* pBuffer, const u32& length):
    mpBuffer(0),
    mLength(length)
{
    assert(pBuffer != 0);

    mpBuffer = (u8*)malloc(sizeof(u8) * mLength);
    memcpy(mpBuffer, pBuffer, mLength);
}



Script::~Script(void)
{
    free(mpBuffer);
}



//============================= OPERATIONS ===================================

bool
Script::Run(FieldModule* fieldModule, Entity* entity, u32& scriptPosition)
{
    // sanity check
    if (scriptPosition >= mLength)
    {
        return true;
    }



    for (u8 i = 0; scriptPosition < mLength; ++i)
    {
        if (i >= 20)
        {
            return false;
        }

        u8 opcode = GetU8(scriptPosition);

        switch (opcode)
        {
            // Return from subroutine
            case RET:
            {
                printf("RET()\n");

                scriptPosition += opcodes_size[opcode];

                return true;
            }
            break;



            // Request remote execution (asynchronous , non-guaranteed)
            case REQ:
            {
                u8 entity_id = GetU8(scriptPosition + 1);
                u8 priority  = GetU8(scriptPosition + 2) >> 5;
                u8 script_id = GetU8(scriptPosition + 2) & 0x1F;
                fieldModule->mpScriptManager->RequestRun(entity_id, priority, script_id);

                printf("REQ\n");
            }
            break;



//case 0x02:
//case 0x03:
//case 0x04:
//case 0x05:
//case 0x06:
//case 0x07:
//case 0x08:
//case 0x09:
//case 0x0A:
//case 0x0B:
//case 0x0C:
//case 0x0D:
//case 0x0E:



            // Special Command
            case SPECIAL: // 0x0F
            {
                u8 special_opcode = GetU8(scriptPosition + 1);

                switch (special_opcode)
                {
                    case BTLLK:
                    {
                        u8 lock = GetU8(scriptPosition + 2);

                        KERNEL->GetGamestate().BattleLockSet(lock);

                        printf("BTLLK(lock = %02x)\n", lock);
                    }
                    break;



                    default:
                    {
                        LOGGER->Log("Unimplemented special opcode %02x", special_opcode);

                        if (special_opcodes_size[special_opcode] <= 0)
                        {
                            return true;
                        }
                    }
                }

                // move script position
                scriptPosition += special_opcodes_size[special_opcode - 0xF8] + 1;
            }
            break;



            // Jump ahead relative (8-bit)
            case JMPF: // 0x10
            {
                u8 jump = GetU8(scriptPosition + 1);

                printf("JMPF(jump = %02x)\n", jump);

                scriptPosition += jump - 1;
            }
            break;



            // Jump ahead relative (16-bit)
            case JMPFL:
            {
                u16 jump = GetU16LE(scriptPosition + 1);

                printf("JMPFL(jump = %04x)\n", jump);

                scriptPosition += jump - 2;
            }
            break;



            // Jump backward relative (8-bit)
            case JMPB:
            {
                u8 jump = GetU8(scriptPosition + 1);

                printf("JMPB(jump = %02x)\n", jump);

                scriptPosition -= jump + opcodes_size[opcode];
            }
            break;



            // Jump back relative (16-bit)
            case JMPBL:
            {
                u16 jump = GetU16LE(scriptPosition + 1);

                printf("JMPBL(jump = %04x)\n", jump);

                scriptPosition -= jump + opcodes_size[opcode];
            }
            break;



            // Unsigned byte conditional with byte relative jump
            case IFUB:
            {
                u8  memory_bank = GetU8(scriptPosition + 1) >> 4;
                u8  offset      = GetU8(scriptPosition + 2);
                u16 value1      = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);
                u16 value2      = GetU8(scriptPosition + 3);
                u8  relation    = GetU8(scriptPosition + 4);
                u8  jump        = GetU8(scriptPosition + 5);

                printf("IFUB(bank = %02x, offset = %02x, value2 = %02x, relation = %02x, jump = %02x)\n", memory_bank, offset, value2, relation, jump);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  ((value1 << 1) & value2); break;
                    case 0x0A: result = !((value1 << 1) & value2); break;
                    default: printf("Strange relation: %02x\n", relation);
                }

                if (result != true)
                {
                    scriptPosition += jump - 1;
                }
            }
            break;



            // Unsigned byte conditional with long relative jump
            case IFUBL:
            {
                u8  memory_bank = GetU8(scriptPosition + 1) >> 4;
                u8  offset      = GetU8(scriptPosition + 2);
                u16 value1      = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);
                u16 value2      = GetU8(scriptPosition + 3);
                u8  relation    = GetU8(scriptPosition + 4);
                u16 jump        = GetU16LE(scriptPosition + 5);

                printf("IFUBL(bank = %02x, offset = %02x, value2 = %02x, relation = %02x, jump = %04x)\n", memory_bank, offset, value2, relation, jump);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  ((value1 << 1) & value2); break;
                    case 0x0A: result = !((value1 << 1) & value2); break;
                    default: printf("Strange relation: %02x\n", relation);
                }

                if (result != true)
                {
                    scriptPosition += jump - 2;
                }
            }
            break;



            // Signed word conditional with byte relative jump
            case IFSW:
            {
                u8  memory_bank = GetU8(scriptPosition + 1) >> 4;
                u16 offset      = GetU16LE(scriptPosition + 2);
                s16 value1      = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);
                s16 value2      = GetU16LE(scriptPosition + 4);
                u8  relation    = GetU8(scriptPosition + 6);
                u8  jump        = GetU8(scriptPosition + 7);

                printf("IFSW(bank = %02x, offset = %04x, value2 = %04x, relation = %02x, jump = %02x)\n", memory_bank, offset, value2, relation, jump);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  ((value1 << 1) & value2); break;
                    case 0x0A: result = !((value1 << 1) & value2); break;
                    default: printf("Strange relation: %02x\n", relation);
                }

                if (result != true)
                {
                    scriptPosition += jump - 1;
                }
            }
            break;



            // Signed word conditional with long relative jump
            case IFSWL:
            {
                u8  memory_bank = GetU8(scriptPosition + 1) >> 4;
                u16 offset      = GetU16LE(scriptPosition + 2);
                s16 value1      = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);
                s16 value2      = GetU16LE(scriptPosition + 4);
                u8  relation    = GetU8(scriptPosition + 6);
                u16 jump        = GetU16LE(scriptPosition + 7);

                printf("IFSWL(bank = %02x, offset = %04x, value2 = %04x, relation = %02x, jump = %04x)\n", memory_bank, offset, value2, relation, jump);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  ((value1 << 1) & value2); break;
                    case 0x0A: result = !((value1 << 1) & value2); break;
                    default: printf("Strange relation: %02x\n", relation);
                }

                if (result != true)
                {
                    scriptPosition += jump - 2;
                }
            }
            break;



            // Unsigned word conditional with byte relative jump
            case IFUW:
            {
                u8  memory_bank = GetU8(scriptPosition + 1) >> 4;
                u16 offset      = GetU16LE(scriptPosition + 2);
                u16 value1      = KERNEL->GetGamestate().MemoryBankGet(memory_bank, offset);
                u16 value2      = GetU16LE(scriptPosition + 4);
                u8  relation    = GetU8(scriptPosition + 6);
                u8  jump        = GetU8(scriptPosition + 7);

                printf("IFUW(bank = %02x, offset = %04x, value2 = %04x, relation = %02x, jump = %02x)\n", memory_bank, offset, value2, relation, jump);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  ((value1 << 1) & value2); break;
                    case 0x0A: result = !((value1 << 1) & value2); break;
                    default: printf("Strange relation: %02x\n", relation);
                }

                if (result == true)
                {
                    scriptPosition += jump - 1;
                }
            }
            break;



            // Unsigned word conditional with long relative jump
            case IFUWL:
            {
                u8  memory_bank = GetU8(scriptPosition + 1) >> 4;
                u16 value1      = KERNEL->GetGamestate().MemoryBankGet(memory_bank, GetU16LE(scriptPosition + 2));
                u16 value2      = GetU16LE(scriptPosition + 4);
                u8  relation    = GetU8(scriptPosition + 6);
                u16 jump        = GetU16LE(scriptPosition + 7);

                printf("IFUWL(bank = %02x, value1 = %04x, value2 = %04x, relation = %02x, jump = %04x)\n", memory_bank, value1, value2, relation, jump);

                bool result = false;
                switch (relation)
                {
                    case 0x00: result =  (value1 == value2);       break;
                    case 0x01: result =  (value1 != value2);       break;
                    case 0x02: result =  (value1 >  value2);       break;
                    case 0x03: result =  (value1 <  value2);       break;
                    case 0x04: result =  (value1 >= value2);       break;
                    case 0x05: result =  (value1 <= value2);       break;
                    case 0x06: result =  (value1 &  value2);       break;
                    case 0x07: result =  (value1 ^  value2);       break;
                    case 0x08: result =  (value1 |  value2);       break;
                    case 0x09: result =  ((value1 << 1) & value2); break;
                    case 0x0A: result = !((value1 << 1) & value2); break;
                    default: printf("Strange relation: %02x\n", relation);
                }

                if (result != true)
                {
                    scriptPosition += jump - 2;
                }
            }
            break;



//case A lot of!!



            // Wait specified number of frames
            case WAIT:
            {
                u16 frames_to_wait = GetU16LE(scriptPosition + 1);

                entity->SetFramesToWait(frames_to_wait);

                printf("WAIT(frames = %02x)\n", frames_to_wait);

                scriptPosition += opcodes_size[opcode];

                return false;
            }
            break;



//case A lot of!!



            // Window Special
            case WSPCL:
            {
                u8 window_id = GetU8(scriptPosition + 1);
                u8 type      = GetU8(scriptPosition + 2);
                u8 x         = GetU8(scriptPosition + 3);
                u8 y         = GetU8(scriptPosition + 4);

                fieldModule->mpWindowManager->SetSpecialStyle(window_id, x, y, type);

                printf("WSPCL(id = %02x, type = %02x, x = %02x, y = %02x)\n", window_id, x, y, type);
            }
            break;



            // Set Number
            case WNUMB:
            {
                // need to be fixed
                u8  memory_bank_1 = GetU8(scriptPosition + 1) >> 4;
                u8  memory_bank_2 = GetU8(scriptPosition + 1) & 0x0F;
                u8  window_id     = GetU8(scriptPosition + 2);
                u32 digit         = KERNEL->GetGamestate().MemoryBankGet(memory_bank_1, GetU16LE(scriptPosition + 3)) | (KERNEL->GetGamestate().MemoryBankGet(memory_bank_2, GetU16LE(scriptPosition + 5)) << 16);
                u8  digit_number  = GetU8(scriptPosition + 7);

                fieldModule->mpWindowManager->SetSpecialNumber(window_id, digit, digit_number);

                printf("WNUMB(mb1 = %02x, mb2 = %02x, w_id = %02x, digit = %08x, num = %02x)\n", memory_bank_1, memory_bank_2, window_id, digit, digit_number);
            }
            break;



            // Set Timer
            case STTIM:
            {
                // need to be fixed
                u8  memory_bank_1 = GetU8(scriptPosition + 1) >> 4;
                u8  memory_bank_2 = GetU8(scriptPosition + 1) & 0x0F;
                u8  memory_bank_3 = GetU8(scriptPosition + 2) & 0x0F;
                u8  hours         = KERNEL->GetGamestate().MemoryBankGet(memory_bank_1, GetU8(scriptPosition + 3));
                u8  minutes       = KERNEL->GetGamestate().MemoryBankGet(memory_bank_2, GetU8(scriptPosition + 4));
                u8  seconds       = KERNEL->GetGamestate().MemoryBankGet(memory_bank_3, GetU8(scriptPosition + 5));

                // set timer in memory bank
                KERNEL->GetGamestate().MemoryBankPut(0x01, 0x15, hours);
                KERNEL->GetGamestate().MemoryBankPut(0x01, 0x16, minutes);
                KERNEL->GetGamestate().MemoryBankPut(0x01, 0x17, seconds);

                printf("STTIM(hours = %02x, minutes = %02x, seconds = %02x)\n", hours, minutes, seconds);
            }
            break;



//case A lot of!!



            // Open a message
            case MESSAGE: // 0x40
            {
                u8 memory_bank = 0;
                u8 window_id   = GetU8(scriptPosition + 1);
                u8 dialog_id   = GetU8(scriptPosition + 2);
                u8 first       = 0;
                u8 last        = 0;
                u8 offset      = 0;

                // set syncronize with window
                entity->SetWait(true);
                fieldModule->mpWindowManager->ShowMessage(window_id, dialog_id, first, last, memory_bank, offset, entity);

                printf("MESSAGE(w_id = %02x, d_id = %02x)\n", window_id, dialog_id);

                scriptPosition += opcodes_size[opcode];

                return false;
            }
            break;



//case A lot of!!



            // Set dialog as map name
            case MPNAM: // 0x43
            {
                u8 dialog_id   = GetU8(scriptPosition + 1);

                fieldModule->mpWindowManager->SetMapName(dialog_id);

                printf("MPNAM(dialog_id = %02x)\n", dialog_id);
            }
            break;



//case A lot of!!



            // Open a choice dialog box
            case ASK: // 0x48
            {
                u8 memory_bank = GetU8(scriptPosition + 1);
                u8 window_id   = GetU8(scriptPosition + 2);
                u8 dialog_id   = GetU8(scriptPosition + 3);
                u8 first       = GetU8(scriptPosition + 4);
                u8 last        = GetU8(scriptPosition + 5);
                u8 offset      = GetU8(scriptPosition + 6);

                // set syncronize with window
                entity->SetWait(true);
                fieldModule->mpWindowManager->ShowMessage(window_id, dialog_id, first, last, memory_bank, offset, entity);

                printf("ASK(bank = %02x, w_id = %02x, d_id = %02x, 1st = %02x, last = %02x, offset = %02x)\n", memory_bank, window_id, dialog_id, first, last, offset);

                scriptPosition += opcodes_size[opcode];

                return false;
            }
            break;



//case A lot of!!



            // Set dialog as map name
            case BTLTB: // 0x4B
            {
                u8 encounter_table = GetU8(scriptPosition + 1);

                fieldModule->mpUnitManager->SetEncounterTable(encounter_table);

                printf("BTLTB(encounter_table = %02x)\n", encounter_table);
            }
            break;



//case A lot of!!



            // Initializes a windowpane
            case WINDOW: // 0x50
            {
                u8  id     = GetU8(scriptPosition + 1);
                u16 x      = GetU16LE(scriptPosition + 2);
                u16 y      = GetU16LE(scriptPosition + 4);
                u16 width  = GetU16LE(scriptPosition + 6);
                u16 height = GetU16LE(scriptPosition + 8);

                fieldModule->mpWindowManager->SetWindow(id, x, y, width, height);

                printf("WINDOW(id = %02x, x = %04x, y = %04x, width = %04x, height = %04x)\n", id, x, y, width, height);
            }
            break;



//case 0x51:



            // Change window mode
            case WMODE:
            {
                u8 id    = GetU8(scriptPosition + 1);
                u8 style = GetU8(scriptPosition + 2);
                u8 cbc   = GetU8(scriptPosition + 3);

                fieldModule->mpWindowManager->SetWindowStyle(id, style, cbc);

                printf("WMODE(id = %02x, style = %02x, cbc = %02x)\n", id, style, cbc);
            }
            break;



            // Reset window
            case WREST:
            {
                u8 id = GetU8(scriptPosition + 1);

                fieldModule->mpWindowManager->ResetWindow(id);

                printf("WREST(id = %02x)\n", id);
            }
            break;



//case A lot of!!



            // No operation
            case NOP:
            {
                printf("NOP()\n");
            }
            break;



            // Load another map (not compleatly implemented)
            case MAPJUMP:
            {
                u16 map_id    = GetU16LE(scriptPosition + 1);

                float x       = static_cast<s16>(GetU16LE(scriptPosition + 3));
                float z       = static_cast<s16>(GetU16LE(scriptPosition + 5));
                float y       = static_cast<s16>(GetU16LE(scriptPosition + 7));

                u8  direction = GetU8(scriptPosition + 9);

                fieldModule->RequestLoadMap(map_id);
                KERNEL->GetGamestate().PlayerPositionUnset();
                KERNEL->GetGamestate().PlayerTriangleUnset();

                printf("MAPJUMP(id = %04x)\n", map_id);
            }
            break;



//case A lot of!!



            // Triangle Boundary
            case IDLCK: // 0x6D
            {
                u16 id    = GetU16LE(scriptPosition + 1);
                u8  lock  = GetU8(scriptPosition + 3);

                fieldModule->mpUnitManager->SetTriangleAccess(id, lock);

                printf("IDLCK(id = %04x, lock = %02x)\n", id, lock);
            }
            break;



//case A lot of!!



            case BATTLE: // 0x70
            {
                u8  bank      = GetU8(scriptPosition + 1) & 0x0F;
                u16 offset    = GetU16LE(scriptPosition + 2);

                u16 battle_id = KERNEL->GetGamestate().MemoryBankGet(bank, offset);

                fieldModule->LoadBattle(battle_id);

                printf("BATTLE(bank = %02x, offset = %04x)\n", bank, offset);
            }



            // enable or disable battle on current field
            case BTLON: // 0x71
            {
                u8  disable = GetU8(scriptPosition + 1);

                fieldModule->mpUnitManager->DisableEncounter(disable);

                printf("BTLON(disable = %02x)\n", disable);
            }



//case A lot of!!



            // Saturated Addition (8-bit)
            case PLUSx: // 0x77
            {
                u8  destination_bank   = GetU8(scriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(scriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(scriptPosition + 2);
                u8  source_offset      = GetU8(scriptPosition + 3);

                u8  value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);
                u8  value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                u16 result = (u16)value1 + (u16)value2;
                result = (result > 0xFF) ? 0xFF : result;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, (u8)result);

                printf("PLUS!(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %02x)\n", destination_bank, source_bank, destination_offset, source_offset);
            }
            break;



            // Saturated Addition (16-bit)
            case PLUS2x:
            {
                u8  destination_bank   = GetU8(scriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(scriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(scriptPosition + 2);
                u16 source_offset      = GetU16LE(scriptPosition + 3);

                s16 value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, (u16)destination_offset);
                s16 value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                s32 result = (s32)value1 + (s32)value2;
                result = (result > 32767) ? 32767 : result;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, (u16)((s16)result));

                printf("PLUS2!(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)\n", destination_bank, source_bank, destination_offset, source_offset);
            }
            break;



            // Saturated Subtraction (8-bit)
            case MINUSx:
            {
                u8  destination_bank   = GetU8(scriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(scriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(scriptPosition + 2);
                u8  source_offset      = GetU8(scriptPosition + 3);

                u8  value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);
                u8  value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                u8  result = (value1 > value2) ? value1 - value2 : 0;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, result);

                printf("MINUS!(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %02x)\n", destination_bank, source_bank, destination_offset, source_offset);
            }
            break;



            // Saturated Subtraction (16-bit)
            case MINUS2x:
            {
                u8  destination_bank   = GetU8(scriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(scriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(scriptPosition + 2);
                u16 source_offset      = GetU16LE(scriptPosition + 3);

                s16 value1             = KERNEL->GetGamestate().MemoryBankGet(destination_bank, (u16)destination_offset);
                s16 value2             = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                s32 result = (s32)value1 - (s32)value2;
                result = (result < -32767) ? -32767 : result;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, (u16)((s16)result));

                printf("MINUS2!(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)\n", destination_bank, source_bank, destination_offset, source_offset);
            }
            break;



            // Saturated Increment (8-bit)
            case INCx:
            {
                u8  destination_bank   = GetU8(scriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(scriptPosition + 2);

                u8 value = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);

                value = (value >= 0xFF) ? 0xFF : value + 1;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, value);

                printf("INC!(destination_bank = %02x, destination_offset = %02x)\n", destination_bank, destination_offset);
            }
            break;



            // Saturated Increment (16-bit)
            case INC2x:
            {
                u8  destination_bank   = GetU8(scriptPosition + 1) & 0x0F;
                u16 destination_offset = GetU16LE(scriptPosition + 2);

                s16 value              = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);

                value = (value >= 32767) ? 32767 : value + 1;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, (u16)value);

                printf("INC2!(destination_bank = %02x, destination_offset = %04x)\n", destination_bank, destination_offset);
            }
            break;



            // Saturated Decrement (8-bit)
            case DECx:
            {
                u8  destination_bank   = GetU8(scriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(scriptPosition + 2);

                u8 value = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);

                value = (value <= 0x00) ? 0x00 : value - 1;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, value);

                printf("DEC!(destination_bank = %02x, destination_offset = %02x)\n", destination_bank, destination_offset);
            }
            break;



            // Saturated Decrement (16-bit)
            case DEC2x:
            {
                u8  destination_bank   = GetU8(scriptPosition + 1) & 0x0F;
                u16 destination_offset = GetU16LE(scriptPosition + 2);

                s16 value              = KERNEL->GetGamestate().MemoryBankGet(destination_bank, destination_offset);

                value = (value <= -32767) ? -32767 : value - 1;

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, (u16)value);

                printf("DEC2!(destination_bank = %02x, destination_offset = %04x)\n", destination_bank, destination_offset);
            }
            break;



//case A lot of!!



            // Assignment (8 bit)
            case SETBYTE:
            {
                u8  destination_bank   = GetU8(scriptPosition + 1) >> 4;
                u8  source_bank        = GetU8(scriptPosition + 1) & 0x0F;
                u8  destination_offset = GetU8(scriptPosition + 2);
                u8  source_offset      = GetU8(scriptPosition + 3);

                u8  value              = KERNEL->GetGamestate().MemoryBankGet(source_bank, source_offset);

                KERNEL->GetGamestate().MemoryBankPut(destination_bank, destination_offset, value);

                printf("SET-BYTE!(destination_bank = %02x, source_bank = %02x, destination_offset = %02x, source_offset = %04x)\n", destination_bank, source_bank, destination_offset, source_offset);
            }
            break;



//case A lot of!!



            // Define Playable character
            case PC:
            {
                u8 pc_id = GetU8(scriptPosition + 1);

                fieldModule->mpUnitManager->SetPC(entity->GetUnitId(), pc_id);

                printf("PC(pc_id = %02x)\n", pc_id);
            }
            break;



            // Character definition
            case CHAR:
            {
                u8 character_id = GetU8(scriptPosition + 1);

                entity->SetUnitId(fieldModule->mpUnitManager->AddChar(character_id));

                printf("CHAR(character_id = %02x)\n", character_id);
            }
            break;



//case A lot of!!



            // Place Object 
            case XYZI: // 0xA5
            {
                u8  memory_bank_1 = GetU8(scriptPosition + 1) >> 4;
                u8  memory_bank_2 = GetU8(scriptPosition + 1) & 0x0F;
                u8  memory_bank_3 = GetU8(scriptPosition + 2) >> 4;
                u8  memory_bank_4 = GetU8(scriptPosition + 2) & 0x0F;
                float x      = static_cast<s16>(KERNEL->GetGamestate().MemoryBankGet(memory_bank_1, GetU16LE(scriptPosition + 3)));
                float z      = static_cast<s16>(KERNEL->GetGamestate().MemoryBankGet(memory_bank_2, GetU16LE(scriptPosition + 5)));
                float y      = static_cast<s16>(KERNEL->GetGamestate().MemoryBankGet(memory_bank_3, GetU16LE(scriptPosition + 7)));
                u16 triangle = KERNEL->GetGamestate().MemoryBankGet(memory_bank_4, GetU16LE(scriptPosition + 9));

                fieldModule->mpUnitManager->SetPositionByXYZTriangle(entity->GetUnitId(), Vector3(x, y, z), triangle);

                printf("XYZI(x = %f, y = %f, z = %f, triangle = %04x)\n", x, y, z, triangle);
            }
            break;



//case A lot of!!



            // Set direction
            case DIR: // 0xB3
            {
                u8  direction = KERNEL->GetGamestate().MemoryBankGet(GetU8(scriptPosition + 1), GetU8(scriptPosition + 2));

                fieldModule->mpUnitManager->SetDirection(entity->GetUnitId(), direction);

                printf("DIR(direction = %02x)\n", direction);
            }
            break;



//case A lot of!!



            // Set direction
            case PRTYP: // 0xC8
            {
                u8 character = GetU8(scriptPosition + 1);

                // add party character
                KERNEL->GetGamestate().PartyCharAdd(character);

                printf("PRTYP(char = %02x)\n", character);
            }
            break;



//case A lot of!!



            default:
            {
                LOGGER->Log("Unimplemented opcode %02x", opcode);

                if (opcodes_size[opcode] <= 0)
                {
                    return true;
                }
            }
        }



        // move script position
        scriptPosition += opcodes_size[opcode];
    }

    return true;
}



const u8
Script::GetU8(const u32& offset) const
{
    return static_cast<u8>(*(mpBuffer + offset));
}



const u16
Script::GetU16LE(const u32& offset) const
{
    return ((u8*)mpBuffer + offset)[0] | (((u8*)mpBuffer + offset)[1] << 8);
}
