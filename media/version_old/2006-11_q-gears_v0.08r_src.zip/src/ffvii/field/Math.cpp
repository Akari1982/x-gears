// $Id: Math.cpp 96 2006-11-13 03:34:17Z crazy_otaku $

#include "../../common/display/math/VectorMath.h"
#include "../../common/utilites/Logger.h"

#include "Math.h"



float
point_elevation(const Vector3& point, const Vector3& A, const Vector3& B, const Vector3& C)
{
    float _A = A.y * (B.z - C.z) + B.y * (C.z - A.z) + C.y * (A.z - B.z);
    float _B = A.z * (B.x - C.x) + B.z * (C.x - A.x) + C.z * (A.x - B.x);
    float _C = A.x * (B.y - C.y) + B.x * (C.y - A.y) + C.x * (A.y - B.y);
    float _D = A.x * (B.y * C.z - C.y * B.z) + B.x * (C.y * A.z - A.y * C.z) + C.x * (A.y * B.z - B.y * A.z);

    return (_D - _C * point.z - _A * point.x) / _B;
}



bool
line_crossing(const Vector3& p11, const Vector3& p12, const Vector3& p21, const Vector3& p22)
{
    float D  = (p12.z - p11.z) * (p21.x - p22.x) - (p21.z - p22.z) * (p12.x - p11.x);
    float D1 = (p12.z - p11.z) * (p21.x - p11.x) - (p21.z - p11.z) * (p12.x - p11.x);
    float D2 = (p21.z - p11.z) * (p21.x - p22.x) - (p21.z - p22.z) * (p21.x - p11.x);

    // if lines are the same
    if ((D == 0) && (D1 == 0) && (D2 == 0))
    {
        return false;
    }

    // if lines are paralel
    if (D == 0)
    {
        return false;
    }

    // find time
    float t1 = D2 / D;
    float t2 = D1 / D;

    // if our line ends on triangle border - we cross the line otherwise not
    // so we check 0 < t1 instead of 0 <= t1
    if ((0 < t1) && (t1 <= 1) && (0 <= t2) && (t2 <= 1))
    {
//        x = p11.x + (p12.x - p11.x) * (t1 - 0.01f);
//        y = p11.y + (p12.y - p11.y) * (t1 - 0.01f);
//        z = p11.z + (p12.z - p11.z) * (t1 - 0.01f);
        return true;
    }

    return false;
}



bool
point_on_line(const Vector3& point, const Vector3& p1, const Vector3& p2)
{
    float tx = (point.x - p1.x) / (p2.x - p1.x);
    float tz = (point.z - p1.z) / (p2.z - p1.z);

    if (((p1.x == p2.x) && (tz >= 0) && (tz <= 1)) ||
        ((p1.z == p2.z) && (tx >= 0) && (tx <= 1)) ||
        ((tx == tz) && (tx >= 0) && (tx <= 1)))
    {
        return true;
    }

    return false;
}



Vector3
get_projection_on_line(const Vector3& moveVector, const Vector3& sp1, const Vector3& sp2)
{
    Vector2 v(0.0f, 0.0f);
    v.x = sp2.x - sp1.x;
    v.y = sp2.z - sp1.z;
    Vector2Normalize(v, v);

    v *= moveVector.x * v.x + moveVector.z * v.y;
    Vector3 ret(v.x, 0.0f, v.y);
    return ret;
}



bool
find_point_on_plane(Vector3& ret, const Vector3& point1, const Vector3& point2,
                    const Vector3& A, const Vector3& B, const Vector3& C)
{
    float _A = A.y * (B.z - C.z) + B.y * (C.z - A.z) + C.y * (A.z - B.z);
    float _B = A.z * (B.x - C.x) + B.z * (C.x - A.x) + C.z * (A.x - B.x);
    float _C = A.x * (B.y - C.y) + B.x * (C.y - A.y) + C.x * (A.y - B.y);
    float NV = (_A * (point2.x - point1.x) + _B * (point2.y - point1.y) + _C * (point2.z - point1.z));

    // if there line and plane are paralel
    if (NV == 0)
    {
        return false;
    }

    // put it here so we will not count this if lines not intersect
    float _D = -(A.x * (B.y * C.z - C.y * B.z) + B.x * (C.y * A.z - A.y * C.z) + C.x * (A.y * B.z - B.y * A.z));
    float NSD = -(_A * point1.x + _B * point1.y + _C * point1.z + _D);

    // if line is on the plane
    if (NSD == 0)
    {
        return false;
    }

    // time when we got to the point
    float t = NSD / NV;

//    LOGGER->Log("A.x = %f, B.x = %f, , C.x = %f", A.x, B.x, C.x);
//    LOGGER->Log("A.z = %f, B.z = %f, , C.z = %f", A.z, B.z, C.z);
//    LOGGER->Log("t = %f, point1.x = %f, , point2.x = %f", t, point1.x, point2.x);
//    LOGGER->Log("t = %f, point1.z = %f, , point2.z = %f", t, point1.z, point2.z);
    if (t >= 0 && t <= 1)
    {
        // get final point
        ret.x = point1.x + (point2.x - point1.x) * t;
        ret.y = point1.y + (point2.y - point1.y) * t;
        ret.z = point1.z + (point2.z - point1.z) * t;
        return true;
    }

    // no intersection
    return false;
}
