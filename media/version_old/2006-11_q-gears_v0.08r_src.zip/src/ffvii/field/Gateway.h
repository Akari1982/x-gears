// $Id: Gateway.h 96 2006-11-13 03:34:17Z crazy_otaku $

#ifndef GATEWAY_h
#define GATEWAY_h

#include "../../common/TypeDefine.h"

#include "Trigger.h"

class FieldModule;



class Gateway : public Trigger
{
public:
    Gateway(FieldModule* pFieldModule, const dGeomID& collision, const Vector3& position, const u16& mapId);

    virtual ~Gateway(void);

    void Action(void);

private:
    FieldModule* mpFieldModule; /**< @brief feed back to field module */

    Vector3      mPosition;
    u16          mMapId;
};



#endif // GATEWAY_h
