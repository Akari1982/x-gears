// $Id: Trigger.h 96 2006-11-13 03:34:17Z crazy_otaku $

#ifndef TRIGGER_h
#define TRIGGER_h

#include <ode/ode.h>

#include "../../common/display/3dTypes.h"
#include "../../common/utilites/NoCopy.h"



class Trigger : public NoCopy<Trigger>
{
public:
    Trigger(const dGeomID& collision);

    virtual ~Trigger(void);

    void Draw(void);

    void CheckCollision(const dGeomID& unitCollision);

    virtual void Action(void) = 0;

private:
    dGeomID mCollision;
};



#endif // TRIGGER_h
