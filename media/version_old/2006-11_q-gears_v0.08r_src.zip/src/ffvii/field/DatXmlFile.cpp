// $Id: DatXmlFile.cpp 96 2006-11-13 03:34:17Z crazy_otaku $

#include "DatXmlFile.h"
#include "../../common/utilites/Logger.h"




DatXmlFile::DatXmlFile(const RString& file):
    XmlFile(file)
{
    mRootNode = xmlDocGetRootElement(mFile);

    if (!mRootNode || !xmlStrEqual(mRootNode->name, BAD_CAST "field"))
    {
        mNormalFile = false;
        LOGGER->Log("Field XML Manager: %s is not a valid field file! No <field> in root.", file.c_str());
    }
    else
    {
        mNormalFile = true;
    }
}



DatXmlFile::~DatXmlFile(void)
{
}



bool
DatXmlFile::GetDialogs(WindowManager* windowManager)
{
    if (mNormalFile != true)
    {
        return false;
    }

    if (GetInt(mRootNode, "dialogs") != 0)
    {
        for (xmlNodePtr node = mRootNode->xmlChildrenNode; node != NULL; node = node->next)
        {
            // load dialogs from xml
            if (xmlStrEqual(node->name, BAD_CAST "dialogs"))
            {
                for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                {
                    if (!xmlStrEqual(node_2->name, BAD_CAST "dialog"))
                    {
                        continue;
                    }

                    // add dialog to mpWindowManager
                    RString dialog((const char*)node_2->xmlChildrenNode->content, strlen((const char*)node_2->xmlChildrenNode->content));
                    windowManager->AddDialog(RStringToFFVIIString(dialog));
                }
            }
        }

        return true;
    }

    return false;
}



bool
DatXmlFile::GetScripts(ScriptManager* scriptManager)
{
    if (mNormalFile != true)
    {
        return false;
    }

    if (GetInt(mRootNode, "entitys") != 0)
    {
        for (xmlNodePtr node = mRootNode->xmlChildrenNode; node != NULL; node = node->next)
        {
            // load entity and scripts from xml
            if (xmlStrEqual(node->name, BAD_CAST "entitys"))
            {
                // whole script buffer
                u8* script_buffer = NULL;
                u32 script_size = 0;
                script_buffer = (u8*)malloc(script_size);
                for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                {
                    if (!xmlStrEqual(node_2->name, BAD_CAST "entity"))
                    {
                        continue;
                    }

                    Entity* entity = new Entity();

                    RString name = GetString(node_2, "name");
                    entity->SetName(name);

                    u8 script_number = 0;

                    for (xmlNodePtr node_3 = node_2->xmlChildrenNode; node_3 != NULL; node_3 = node_3->next)
                    {
                        if (!xmlStrEqual(node_3->name, BAD_CAST "script"))
                        {
                            continue;
                        }

                        u32 script_temp_size = 0;
                        u8* script_temp_buffer = OpcodesToRawScript((u8*)node_3->xmlChildrenNode->content, strlen((const char*)node_3->xmlChildrenNode->content), script_temp_size);

                        if (script_temp_size != 0)
                        {
                            entity->SetEntryPoint(script_number, script_size);
                            ++script_number;

                            script_buffer = (u8*)realloc(script_buffer, script_size + script_temp_size);
                            memcpy(script_buffer + script_size, script_temp_buffer, script_temp_size);
                            script_size += script_temp_size;
                        }

                        free(script_temp_buffer);
                    }

                    scriptManager->PushEntity(entity);
                }

                Script* script = new Script(script_buffer, script_size);
                Entity::SetScript(script);
            }
        }

        return true;
    }

    return false;
}



bool
DatXmlFile::GetWalkMesh(UnitManager* unitManager)
{
    if (mNormalFile != true)
    {
        return false;
    }

    if (GetInt(mRootNode, "walkmesh") != 0)
    {
        for (xmlNodePtr node = mRootNode->xmlChildrenNode; node != NULL; node = node->next)
        {
            // load walkmesh from xml
            if (xmlStrEqual(node->name, BAD_CAST "walkmesh"))
            {
                for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                {
                    if (!xmlStrEqual(node_2->name, BAD_CAST "triangle"))
                    {
                        continue;
                    }

                    WalkMeshTriangle triangle;

                    triangle.A = GetVector3(node_2, "a");
                    triangle.B = GetVector3(node_2, "b");
                    triangle.C = GetVector3(node_2, "c");

                    triangle.access[0] = GetInt(node_2, "access1");
                    triangle.access[1] = GetInt(node_2, "access2");
                    triangle.access[2] = GetInt(node_2, "access3");

                    unitManager->AddWalkMeshTriangle(triangle);
                }
            }
        }

        return true;
    }

    return false;
}



bool
DatXmlFile::GetGateway(UnitManager* unitManager)
{
    if (mNormalFile != true)
    {
        return false;
    }

    if (GetInt(mRootNode, "gateways") != 0)
    {
        for (xmlNodePtr node = mRootNode->xmlChildrenNode; node != NULL; node = node->next)
        {
            // load gateways from xml
            if (xmlStrEqual(node->name, BAD_CAST "gateways"))
            {
                for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                {
                    if (!xmlStrEqual(node_2->name, BAD_CAST "gateway"))
                    {
                        continue;
                    }

                    // add gateway to UnitManager
                    Vector3 point1   = GetVector3(node_2, "point1");
                    Vector3 point2   = GetVector3(node_2, "point2");
                    Vector3 position = GetVector3(node_2, "position");

                    int map_id = GetInt(node_2, "map_id");

                    unitManager->AddGateway(point1, point2, position, map_id);
                }
            }
        }

        return true;
    }

    return false;
}



bool
DatXmlFile::GetEncounter(UnitManager* unitManager)
{
    if (mNormalFile != true)
    {
        return false;
    }

    if (GetInt(mRootNode, "encounters") != 0)
    {
        for (xmlNodePtr node = mRootNode->xmlChildrenNode; node != NULL; node = node->next)
        {
            // load encounters from xml
            if (xmlStrEqual(node->name, BAD_CAST "encounters"))
            {
                for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                {
                    if (!xmlStrEqual(node_2->name, BAD_CAST "table"))
                    {
                        continue;
                    }

                    EncounterTable table;

                    table.enabled = GetInt(node_2, "enabled");
                    table.rate    = GetInt(node_2, "rate");

                    for (xmlNodePtr node_3 = node_2->xmlChildrenNode; node_3 != NULL; node_3 = node_3->next)
                    {
                        if (xmlStrEqual(node_3->name, BAD_CAST "standart"))
                        {
                            u8 i = 0;
                            for (xmlNodePtr node_4 = node_3->xmlChildrenNode; (node_4 != NULL) && (i < 6); node_4 = node_4->next)
                            {
                                if (!xmlStrEqual(node_4->name, BAD_CAST "encounter"))
                                {
                                    continue;
                                }

                                table.standart_encounter[i].rate  = GetInt(node_4, "rate");
                                table.standart_encounter[i].scene = GetInt(node_4, "scene");
                                ++i;
                            }
                        }

                        if (xmlStrEqual(node_3->name, BAD_CAST "special"))
                        {
                            u8 i = 0;
                            for (xmlNodePtr node_4 = node_3->xmlChildrenNode; (node_4 != NULL) && (i < 4); node_4 = node_4->next)
                            {
                                if (!xmlStrEqual(node_4->name, BAD_CAST "encounter"))
                                {
                                    continue;
                                }

                                table.special_encounter[i].rate  = GetInt(node_4, "rate");
                                table.special_encounter[i].scene = GetInt(node_4, "scene");
                                ++i;
                            }
                        }
                    }

                    unitManager->AddEncounterTable(table);
                }
            }
        }

        return true;
    }

    return false;
}
