// $Id: InputFilter.cpp 93 2006-11-12 13:49:02Z einherjar $

#include "InputFilter.h"
#include "InputUtils.h"
#include "handlers/InputHandlerSdl.h"

#include <vector>



std::vector<Button> ButtonsToProcess;



InputFilter* INPUTFILTER = NULL;



InputFilter::InputFilter()
{
    mInputHandler = new InputHandlerSDL();
    Reset();
}



InputFilter::~InputFilter()
{
    delete mInputHandler;
}



void
InputFilter::Reset()
{
    for (int button = 0; button < MAX_BUTTONS; button++)
    {
        ButtonPressed((enum Button)button, false);
    }
}



InputFilter::ButtonState::ButtonState():
    mBeingHeld(false),
    mLastReportedHeld(false)
{
}



void
InputFilter::ButtonPressed(Button b, bool Down)
{
    ButtonState &bs = mButtonState[b];

    if (bs.mBeingHeld != Down)
    {
        // Flush any delayed input, like Update() (in case Update() isn't being called).
        CheckButtonChange(bs, b);

        bs.mBeingHeld = Down;

        // Try to report presses immediately.
        CheckButtonChange(bs, b);
    }

    ButtonsToProcess.push_back(b);
}



// Check for reportable presses.
void
InputFilter::CheckButtonChange(ButtonState &bs, Button button)
{
    if (bs.mBeingHeld == bs.mLastReportedHeld)
    {
        return;
    }

    bs.mLastReportedHeld = bs.mBeingHeld;

    queue.push_back(InputEvent(button, bs.mLastReportedHeld ? IET_FIRST_PRESS : IET_RELEASE));
}



void
InputFilter::Update()
{
    mInputHandler->Update();

    for (int i = 0; i < ButtonsToProcess.size(); i++)
    {
        ButtonState &bs = mButtonState[ButtonsToProcess[i]];

        // Generate IET_FIRST_PRESS and IET_RELEASE events that were delayed.
        CheckButtonChange(bs, ButtonsToProcess[i]);
    }
}



bool
InputFilter::IsBeingPressed(Button button)
{
    return mButtonState[button].mLastReportedHeld;
}



void
InputFilter::GetInputEvents(InputEventArray &array)
{
    array = queue;
    queue.clear();
}
