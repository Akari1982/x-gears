// $Id: Main.cpp 93 2006-11-12 13:49:02Z einherjar $

#include <stdio.h>
#include <libxml/parser.h>

#include "Define.h"
#include "Main.h"
#include "display/DisplayOgl.h"
#include "filesystem/RealFileSystem.h"
#include "input/InputFilter.h"
#include "module/ModuleManager.h"
#include "utilites/Config.h"
#include "utilites/Logger.h"
#include "utilites/Utilites.h"



int
main(int argc, char *argv[])
{
    REALFILESYSTEM = new RealFileSystem();
    LOGGER         = new Logger(DEFAULT_LOG);
    CONFIG         = new Config();
    DISPLAY        = DisplayOGL::MakeDisplay();
    MODULEMAN      = new ModuleManager();
    INPUTFILTER    = new InputFilter();



    // Initialize libxml2 and check for potential ABI mismatches between
    // compiled version and the shared library actually used.
    xmlInitParser();
    LIBXML_TEST_VERSION;

    // Redirect libxml errors to /dev/null
    FILE* nullFile = fopen("/dev/null", "w");
    xmlSetGenericErrorFunc(nullFile, NULL);



    game_main();



    // Shutdown libxml
    xmlCleanupParser();



    SAFE_DELETE(INPUTFILTER)
    SAFE_DELETE(MODULEMAN)
    SAFE_DELETE(DISPLAY)
    SAFE_DELETE(CONFIG)
    SAFE_DELETE(LOGGER)
    SAFE_DELETE(REALFILESYSTEM)

    return 0;
}
