// $Id: Module.cpp 93 2006-11-12 13:49:02Z einherjar $

#include "Module.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

Module::Module(void)
{
}



Module::~Module(void)
{
}
