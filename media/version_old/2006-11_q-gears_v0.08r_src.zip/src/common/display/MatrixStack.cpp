// $Id: MatrixStack.cpp 93 2006-11-12 13:49:02Z einherjar $

#include "MatrixStack.h"
#include "math/MatrixMath.h"



MatrixStack::MatrixStack()
{
    stack.resize(1);
    LoadIdentity();
}



MatrixStack::~MatrixStack()
{
}



void
MatrixStack::Pop()
{
    stack.pop_back();
}



void
MatrixStack::Push()
{
    stack.push_back(stack.back());
}



const Matrix*
MatrixStack::GetTop()
{
    return &stack.back();
}



void
MatrixStack::LoadIdentity()
{
    MatrixIdentity(stack.back());
}



void
MatrixStack::LoadMatrix(const Matrix &m)
{
    stack.back() = m;
}



void
MatrixStack::MultMatrix(const Matrix &m)
{
    MatrixMultiply(stack.back(), m, stack.back());
}



void
MatrixStack::MultMatrixLocal(const Matrix &m)
{
    MatrixMultiply(stack.back(), stack.back(), m);
}



void
MatrixStack::RotateX(float degrees)
{
    Matrix m;
    MatrixRotationX(m, degrees);
    MultMatrix(m);
}



void
MatrixStack::RotateY(float degrees)
{
    Matrix m;
    MatrixRotationY(m, degrees);
    MultMatrix(m);
}



void
MatrixStack::RotateZ(float degrees)
{
    Matrix m;
    MatrixRotationZ(m, degrees);
    MultMatrix(m);
}



void
MatrixStack::RotateXLocal(float degrees)
{
    Matrix m;
    MatrixRotationX(m, degrees);
    MultMatrixLocal(m);
}



void
MatrixStack::RotateYLocal(float degrees)
{
    Matrix m;
    MatrixRotationY(m, degrees);
    MultMatrixLocal(m);
}



void
MatrixStack::RotateZLocal(float degrees)
{
    Matrix m;
    MatrixRotationZ(m, degrees);
    MultMatrixLocal(m);
}



void
MatrixStack::Scale(float x, float y, float z)
{
    Matrix m;
    MatrixScaling(m, x, y, z);
    MultMatrix(m);
}



void
MatrixStack::ScaleLocal(float x, float y, float z)
{
    Matrix m;
    MatrixScaling(m, x, y, z);
    MultMatrixLocal(m);
}



void
MatrixStack::Translate(float x, float y, float z)
{
    Matrix m;
    MatrixTranslation(m, x, y, z);
    MultMatrix(m);
}



void
MatrixStack::TranslateLocal(float x, float y, float z)
{
    Matrix m;
    MatrixTranslation(m, x, y, z);
    MultMatrixLocal(m);
}
