// $Id: WindowSdl.cpp 93 2006-11-12 13:49:02Z einherjar $

#include "WindowSdl.h"

#include "../../Main.h"
#include "../../utilites/Logger.h"

#include <SDL/SDL.h>



Window *
WindowSDL::MakeWindow()
{
    return new WindowSDL();
}



WindowSDL::WindowSDL()
{
    LOGGER->Log("SDL init begin");

    // Start SDL (with no subsystems), to make sure we don't use SDL's error handler.
    SDL_Init(SDL_INIT_NOPARACHUTE);

    // By default, ignore all SDL events. We'll enable them as we need them.
    // We must not enable any events we don't actually want, since we won't
    // query for them and they'll fill up the event queue.
    SDL_EventState(0xFF /*SDL_ALLEVENTS*/, SDL_IGNORE);

    if (SDL_InitSubSystem(SDL_INIT_VIDEO) == -1)
    {
        LOGGER->Log("SDL_INIT_VIDEO failed: %s", SDL_GetError());
    }
    else
    {
        LOGGER->Log("SDL_INIT_VIDEO initialized");
    }

    // Set SDL window title, icon and cursor -before- creating the window
    SDL_WM_SetCaption(game_title(), "");
    SDL_ShowCursor(SDL_ENABLE);
    SDL_WM_SetIcon(NULL, NULL);

    SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 5);     // Use at least 5 bits of Red
    SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 5);   // Use at least 5 bits of Green
    SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 5);    // Use at least 5 bits of Blue
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 16);  // Use at least 16 bits for the depth buffer
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1); // Enable double buffering

    SDL_Surface *screen = SDL_SetVideoMode(640, 480, 16, SDL_OPENGLBLIT | SDL_HWSURFACE);
    if (!screen)
    {
        LOGGER->Log("SDL_SetVideoMode failed: %s", SDL_GetError());
    }
    else
    {
        LOGGER->Log("SDL video mode set 640x480, 16 bit SDL_OPENGLBLIT | SDL_HWSURFACE");
    }

    // Find out what we really got.
    int r, g, b, a, colorbits, depth, stencil;

    SDL_GL_GetAttribute(SDL_GL_RED_SIZE, &r);
    SDL_GL_GetAttribute(SDL_GL_GREEN_SIZE, &g);
    SDL_GL_GetAttribute(SDL_GL_BLUE_SIZE, &b);
    SDL_GL_GetAttribute(SDL_GL_ALPHA_SIZE, &a);
    SDL_GL_GetAttribute(SDL_GL_BUFFER_SIZE, &colorbits);
    SDL_GL_GetAttribute(SDL_GL_DEPTH_SIZE, &depth);
    SDL_GL_GetAttribute(SDL_GL_STENCIL_SIZE, &stencil);
    LOGGER->Log("Got %i bpp (%i%i%i%i), %i depth, %i stencil", colorbits, r, g, b, a, depth, stencil);
    LOGGER->Log("SDL init complete");
}



WindowSDL::~WindowSDL()
{
    SDL_QuitSubSystem(SDL_INIT_VIDEO);

    SDL_EventState(SDL_QUIT, SDL_IGNORE);

    SDL_Quit();
    LOGGER->Log("SDL quited.");
}



void
WindowSDL::SwapBuffers()
{
    SDL_GL_SwapBuffers();
}
