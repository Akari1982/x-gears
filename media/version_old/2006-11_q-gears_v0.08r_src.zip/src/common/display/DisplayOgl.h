// $Id: DisplayOgl.h 93 2006-11-12 13:49:02Z einherjar $

#ifndef DISPLAYOGL_H
#define DISPLAYOGL_H
// DisplayOGL - OpenGL renderer.



#include "Display.h"
#include "window/Window.h"

#include <vector>



class DisplayOGL : public Display
{
public:
    virtual         ~DisplayOGL();

    static Display* MakeDisplay();

    void            BeginFrame();
    void            EndFrame();

    u32    CreateTexture(Surface *image);
    void            UpdateTexture(unsigned int tex_handle, Surface *image, int xoffset, int yoffset, int width, int height);
    void            DeleteTexture(unsigned int tex_handle);
    void            SetTexture(unsigned int tex_handle);
    void            UnsetTexture();

    void            SetAlphaTest(bool b);
    void            SetZTestMode(ZTestMode mode);
    void            SetBlendMode(BlendMode mode);
    void            SetCullMode(CullMode mode);
    void            SetPolygonMode(PolygonMode pm);
    void            SetLineWidth(float width);
    void            SetPointSize(float size);

protected:
    void            DrawPointsInternal(const std::vector<Vertex> &v);
    void            DrawLinesInternal(const std::vector<Vertex> &v);
    void            DrawTrianglesInternal(const std::vector<Vertex> &v);
    void            DrawQuadsInternal(const std::vector<Vertex> &v);

    void            SetupVertices(const std::vector<Vertex> &v);
    void            SendCurrentMatrices();

private:
    void            Init();

    DisplayOGL();

private:
    Window* mWindow;
};



#endif
