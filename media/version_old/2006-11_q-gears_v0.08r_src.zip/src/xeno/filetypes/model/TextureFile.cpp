// $Id: TextureFile.cpp 93 2006-11-12 13:49:02Z einherjar $

#include "../../../common/utilites/Logger.h"

#include "TextureFile.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

TextureFile::TextureFile(const RString& file):
    File(file)
{
}



TextureFile::TextureFile(File* pFile):
    File(pFile)
{
}



TextureFile::TextureFile(File* pFile, const u32& offset, const u32& length):
    File(pFile, offset, length)
{
}



TextureFile::TextureFile(u8* pBuffer, const u32& offset, const u32& length):
    File(pBuffer, offset, length)
{
}



TextureFile::~TextureFile(void)
{
}



//============================= OPERATIONS ===================================

void
TextureFile::GetSurfaces(Surface* pClut, Surface* pVram)
{
    TextureHeader* texture_header = (TextureHeader*)(mpBuffer);

    // palette
    if (texture_header->id == 0x00001101)
    {
        u16 vram_x = texture_header->vram_x + texture_header->move_x;
        u16 vram_y = texture_header->vram_y + texture_header->move_y;

        for (int y = vram_y; y < vram_y + texture_header->height; ++y)
        {
            for (int x = vram_x; x < vram_x + texture_header->width; ++x)
            {
                u16 src1 = GetU16LE(0x10 + (x - vram_x) * 0x02 + (y - vram_y) * texture_header->width * 0x02);

                *(pClut->pixels + x * 4 + pClut->width * 4 * y + 0) = ((src1      ) & 31) * 255 / 31;
                *(pClut->pixels + x * 4 + pClut->width * 4 * y + 1) = ((src1 >>  5) & 31) * 255 / 31;
                *(pClut->pixels + x * 4 + pClut->width * 4 * y + 2) = ((src1 >> 10) & 31) * 255 / 31;
                // set alpha only for first entry in clut if byte is set or all zero
                *(pClut->pixels + x * 4 + pClut->width * 4 * y + 3) = (x == vram_x && (src1 & 0x8000) || (src1 == 0)) ? 0 : 255;
            }
        }
    }

    // textures
    else if (texture_header->id == 0x00001100)
    {
        u16 vram_x = texture_header->vram_x + texture_header->move_x;
        u16 vram_y = texture_header->vram_y + texture_header->move_y;

        for (int y = vram_y; y < vram_y + texture_header->height; y++)
        {
            for (int x = vram_x * 2; x < vram_x * 2 + texture_header->width * 2; x++)
            {
                *(pVram->pixels + x + pVram->width * 4 * y) = GetU8(0x10 + (x - vram_x * 2) + (y - vram_y) * texture_header->width * 2);
            }
        }
    }
}
